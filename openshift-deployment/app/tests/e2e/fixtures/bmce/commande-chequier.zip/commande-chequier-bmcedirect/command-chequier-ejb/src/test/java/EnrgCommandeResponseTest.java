import ma.eai.boa.xbanking.icommandeservice.EnrgCommandeResponse;
import org.junit.Test;

import static org.junit.Assert.*;

public class EnrgCommandeResponseTest {

    @Test
    public void testGetSetOut() {
        EnrgCommandeResponse response = new EnrgCommandeResponse();

        // Test setting and getting a value
        String expectedValue = "responseValue";
        response.setOut(expectedValue);
        assertEquals(expectedValue, response.getOut());

        // Test setting and getting a null value
        response.setOut(null);
        assertNull(response.getOut());
    }
}
