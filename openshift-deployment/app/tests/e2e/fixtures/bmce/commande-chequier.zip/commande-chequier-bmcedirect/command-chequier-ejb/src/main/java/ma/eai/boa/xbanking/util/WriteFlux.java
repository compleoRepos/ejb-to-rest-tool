package ma.eai.boa.xbanking.util;


import ma.eai.commons.services.parsing.Envelope;
public class WriteFlux {

	public static void ecrireString(Envelope envOut, String noeud,String element, String valeur, String valDefault) throws Exception {
		final String valeurOut = StringHelper.isString(valeur) ? valeur.trim()
				: valDefault.trim();
		envOut.addNode(noeud + Constants.SEPARATEUR + element, valeurOut);
	}

	public static void ecrireString2(Envelope envOut, String noeud,String element1, String element2, String valeur, String valDefault) {
		final String valeurOut = StringHelper.isString(valeur) ? valeur.trim()
				: valDefault.trim();
		envOut.addNode(noeud + Constants.SEPARATEUR + element1+element2, valeurOut);
		
	}
	public static Envelope writeFluxMsg(String codeRetour,String MsgErreur) throws Exception {
		Envelope envOut = new Envelope();
		WriteFlux.ecrireString(envOut,Constants.FLUX,"code",codeRetour,"");
		WriteFlux.ecrireString(envOut,Constants.FLUX,"message",MsgErreur,"");
		return envOut;
	}

	



}
