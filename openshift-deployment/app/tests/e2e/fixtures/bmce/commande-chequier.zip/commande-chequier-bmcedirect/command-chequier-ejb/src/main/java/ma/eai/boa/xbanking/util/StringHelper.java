/**
 * 
 */
package ma.eai.boa.xbanking.util;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @author marhfoyo
 *
 */
public class StringHelper {
	/***
	 * Termine a gauche une chaine de caracteres par des caracteres specifies jusqu'a une longueur specifiee
	 * @param str
	 * @param nombreDigits
	 * @param charOfPadding
	 * @return la chaine formattée
	 */
	public static String padLeft(String str, int nombreDigits, char charOfPadding){
		while(str.length()<nombreDigits){
			str = charOfPadding + str;
		}
		
		return str;
	}
	/***
	 * Termine a droite une chaine de caracteres par des caracteres specifies jusqu'a une longueur specifiee
	 * @param str
	 * @param nombreDigits
	 * @param charOfPadding
	 * @return la chaine formattée
	 */
	public static String padRight(String str, int nombreDigits, char charOfPadding){
		while(str.length()<nombreDigits) {
			str += charOfPadding;
		}
		return str;
	}
	public static String Substring(String str, int start, int length){
		if(str.length()<=start) return "";
		if(str.length()<(start + length)) return str;
		return str.substring(start, (start + length));
	}
	public static String Substring(String str, int start){
		if(str.length()<=start) return "";
		return str.substring(start);
	}
	public static String splitAndGetAt(String str, String splitStr, int index){
		String[] strTmp = str.split(splitStr);
		if(strTmp.length<index) {
			return "";
		}
		return strTmp[index];
		
	}
	public static String formatDecimalForDB(BigDecimal dec, int tailleTotal){
		String str = "";
		
		DecimalFormat df = new DecimalFormat("#.00");        

		str = StringHelper.padLeft(df.format(dec.doubleValue())
				.replace(".", "")
				.replace(",", "")
				.replace("+", "")
				.replace("-", ""), 
				tailleTotal, '0');
		
		return str;
	}
	public static String getAnneeMois(Date date){
		DateFormat dateFormat = new SimpleDateFormat("yyyyMM");
		return dateFormat.format(date);
	}
	
	public static String formatterDateFromYYYYMMDD(String dateYYYYMMDD){
		if(dateYYYYMMDD.trim().equals("")) return "";
		if(dateYYYYMMDD.length()<8) return "";
		if(dateYYYYMMDD.startsWith("0001")) return "";
		
		return Substring(dateYYYYMMDD, 6, 2)
		+"/" + Substring(dateYYYYMMDD, 4, 2)
		+"/" + Substring(dateYYYYMMDD, 0, 4);
	}
	public static String formatteDateToYYYYMMDDHHmm(Date date){
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm");
		return dateFormat.format(date);
	}
	public static String formatteDateToYYYYMMDD(Date date){
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		return dateFormat.format(date);
	}
	public static String formatteDateToMiliseconde(Date date){
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		return dateFormat.format(date);
	}
	public static String formatteDateToYYYYMM(Date date){
		DateFormat dateFormat = new SimpleDateFormat("yyyyMM");
		return dateFormat.format(date);
	}
	
	public static boolean isString(final String valeur) {
        return !(valeur == null || "".equals(valeur) || " ".equals(valeur));
  }
	
	@SuppressWarnings("static-access")
	public static String getDateJmoin1(){
		Date datej;
		Calendar calendar = new java.util.GregorianCalendar();
		calendar.add(calendar.DATE, -1);
		datej=calendar.getTime();
		return StringHelper.formatteDateToYYYYMMDD(datej);	
	}
	
}
