package ma.eai.boa.xbanking.util;
import java.io.IOException;
import java.util.Properties;    
import javax.mail.Session;
import javax.mail.PasswordAuthentication;
import javax.mail.Message;
import javax.mail.Transport;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.InternetAddress;


import ma.eai.ingdev.fwk.logging.EaiLog;

public class Mailer{
	
	private Mailer() {
		
	}
	
    public static boolean send(String to,String subject,String content) throws IOException{  
    			// Vérification du nombre d'arguments
    			
    			String from = "bmce.direct@bmcebank.co.ma";
    			String host = "outlook.eurafric.com";
    			Properties props = new Properties();
    			props.setProperty("mail.smtp.host", host);
    			props.put("mail.smtp.auth", "true");
    			props.put("mail.smtp.ssl.trust", host);
    			props.put("mail.smtp.starttls.enable", "true");
    			props.put("mail.smtp.host", host);
    			props.put("mail.smtp.port", "587");
    			props.put("mail.debug", "true");

    			props.put("mail.smtp.socketFactory.port", "587");
    			// ajoutée lors erreur SSL
    			props.put("mail.smtp.socketFactory.fallback", "true");
    			Session session = null;
    			session = Session.getInstance(props,
    					new javax.mail.Authenticator() {
    						@Override
    						protected PasswordAuthentication getPasswordAuthentication() {
    							return new PasswordAuthentication("bmce.direct","EurafricInformation*2018@");

    						}
    					});
    			
    			// SMTP utilise une connexion sécurisée

    			try {


    				Message message = new MimeMessage(session);

    				message.setFrom(new InternetAddress(from, "BMCE Direct"));
    				InternetAddress[] address = { new InternetAddress(to) };
    				message.setRecipients(Message.RecipientType.TO,address);
    				message.setReplyTo(new javax.mail.Address[]
    						{
    						    new javax.mail.internet.InternetAddress("NEPASREPONDRE@bmcebank.co.ma")
    						});

    				// Modification du sujet
    				message.setSubject(subject);
    				message.setContent(content, "text/html;charset=utf-8");
    	            Transport.send(message);
    	            
    	            EaiLog.info("Sent message successfully....pour " + to);
    				

    			} catch (Exception e) {
			    EaiLog.error(e);

    				return false;
    			}

    			return true; 
             
    }  
}  