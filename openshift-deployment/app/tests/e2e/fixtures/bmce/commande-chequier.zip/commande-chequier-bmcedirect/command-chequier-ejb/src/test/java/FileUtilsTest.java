import ma.eai.boa.xbanking.util.FileUtils;
import org.junit.Test;

import static junit.framework.Assert.assertEquals;

public class FileUtilsTest {
    @Test
    public void testFileReader() {
        // Arrange
        String fileName = "testfile.txt"; // Make sure this file exists in your resources directory
        String expectedContent = "This is a test file."; // Expected content of the file

        // Act
        String result = FileUtils.fileReader(fileName);

        // Assert
        assertEquals(expectedContent, result); // Check if the read content matches the expected content
    }

}
