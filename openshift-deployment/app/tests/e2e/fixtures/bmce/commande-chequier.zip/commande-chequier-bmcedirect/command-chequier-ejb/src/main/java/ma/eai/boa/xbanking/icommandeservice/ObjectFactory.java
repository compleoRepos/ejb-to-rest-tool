
package ma.eai.boa.xbanking.icommandeservice;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the icommandeservice package.
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: icommandeservice
     * 
     */
    public ObjectFactory() {
        // Empty constructor required by JAXB framework
    }

    /**
     * Create an instance of {@link EnrgCommande }
     * 
     */
    public EnrgCommande createEnrgCommande() {
        return new EnrgCommande();
    }

    /**
     * Create an instance of {@link NbrCommandeCanal1 }
     * 
     */
    public NbrCommandeCanal1 createNbrCommandeCanal1() {
        return new NbrCommandeCanal1();
    }

    /**
     * Create an instance of {@link SuiviCommande }
     * 
     */
    public SuiviCommande createSuiviCommande() {
        return new SuiviCommande();
    }

    /**
     * Create an instance of {@link NbrCommandeCanalResponse }
     * 
     */
    public NbrCommandeCanalResponse createNbrCommandeCanalResponse() {
        return new NbrCommandeCanalResponse();
    }

    /**
     * Create an instance of {@link EnrgCommandeResponse }
     * 
     */
    public EnrgCommandeResponse createEnrgCommandeResponse() {
        return new EnrgCommandeResponse();
    }

    /**
     * Create an instance of {@link NbrCommandeCanal1Response }
     * 
     */
    public NbrCommandeCanal1Response createNbrCommandeCanal1Response() {
        return new NbrCommandeCanal1Response();
    }

    /**
     * Create an instance of {@link SuiviCommande2 }
     * 
     */
    public SuiviCommande2 createSuiviCommande2() {
        return new SuiviCommande2();
    }

    /**
     * Create an instance of {@link SuiviCommande2Response }
     * 
     */
    public SuiviCommande2Response createSuiviCommande2Response() {
        return new SuiviCommande2Response();
    }

    /**
     * Create an instance of {@link SuiviCommandeResponse }
     * 
     */
    public SuiviCommandeResponse createSuiviCommandeResponse() {
        return new SuiviCommandeResponse();
    }

    /**
     * Create an instance of {@link NbrCommandeCanal }
     * 
     */
    public NbrCommandeCanal createNbrCommandeCanal() {
        return new NbrCommandeCanal();
    }

}
