package ma.eai.boa.xbanking.models;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.SequenceGenerator;
import javax.persistence.GeneratedValue;


import org.hibernate.annotations.Type;

@Entity
@Table(name = "COMMAND_CHEQUIER")
public class CommandChequierEntity {
	
	@Id
	@Column(name = "ID_CMD")
	@SequenceGenerator(initialValue=0,
	allocationSize=1,
	name="COMMAND_CHEQUIER_SEQ",
	sequenceName="COMMAND_CHEQUIER_SEQ")
	@GeneratedValue(generator="COMMAND_CHEQUIER_SEQ")
	private Long id;
	
	@Column(name = "CREATION_DATE")
	@Type(type = "timestamp")
	private Date creationDate;
	
	@Column(name = "NB_VIGNETTES")
	private String nbVignettes;
	
	@Column(name = "TYPE_COMMAND")
	private String typeCommand;
	
	@Column(name = "QUANTITE")
	private String quantite;
	
	@Column(name = "ORIGIN")
	private String origin;
	
	@Column(name = "NUM_ACCOUNT")
	private String numAccount;
	
	@Column(name = "CODE_ETAT")
	private String codeEtat;
	
	@Column(name = "ID_ORDONNATEUR")
	private String idOrdonnateur;
	
	@Column(name = "TIERS")
	private String tiers;
	
	@Column(name = "EMAIL")
	private String email;
	
	@Column(name = "TELEPHONE")
	private String telephone;
		
	public Date getCreationDate() {
	    return (creationDate != null) ? new Date(creationDate.getTime()) : null;
	}
	
	public void setCreationDate(Date creationDate) {
	    this.creationDate = (creationDate != null) ? new Date(creationDate.getTime()) : null;
	}

	public String getNbVignettes() {
		return nbVignettes;
	}

	public void setNbVignettes(String nbVignettes) {
		this.nbVignettes = nbVignettes;
	}

	public String getQuantite() {
		return quantite;
	}

	public void setQuantite(String quantite) {
		this.quantite = quantite;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getNumAccount() {
		return numAccount;
	}

	public void setNumAccount(String numAccount) {
		this.numAccount = numAccount;
	}

	public String getCodeEtat() {
		return codeEtat;
	}

	public void setCodeEtat(String codeEtat) {
		this.codeEtat = codeEtat;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTypeCommand() {
		return typeCommand;
	}

	public void setTypeCommand(String typeCommand) {
		this.typeCommand = typeCommand;
	}

	public String getIdOrdonnateur() {
		return idOrdonnateur;
	}

	public void setIdOrdonnateur(String idOrdonnateur) {
		this.idOrdonnateur = idOrdonnateur;
	}

	public String getTiers() {
		return tiers;
	}

	public void setTiers(String tiers) {
		this.tiers = tiers;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	
	
}

