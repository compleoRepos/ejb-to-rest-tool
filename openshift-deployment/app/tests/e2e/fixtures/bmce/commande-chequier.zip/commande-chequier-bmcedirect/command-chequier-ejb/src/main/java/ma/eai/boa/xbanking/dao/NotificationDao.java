package ma.eai.boa.xbanking.dao;

import ma.eai.ingdev.fwk.logging.EaiLog;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;



public class NotificationDao {
	
	//Notification Table add New Entry :
			@SuppressWarnings("finally")
			public static boolean addNotif(String tiers, String contrat_bad,String delegue, String canal,String date_notif,String email,String type_transact,String ref_op,int status,
					Connection connexionEbankDirect) throws SQLException {
				boolean retour = false;
				String query = "";
				PreparedStatement stmt = null;
				//ResultSet results = null;
				try {
					
					query = "INSERT INTO NOTIF_EBANKING (TIERS, CONTRAT_BAD, DELEGUE,CANAL,DATE_NOTIF,EMAIL,TYPE_TRANSACT,REF_OP,STATUS,ID) VALUES (?,?, ?, ?,?, ?, ?,?, ?, NOTIF_EBANKING_ID_SEQ.NEXTVAL)"; 
					stmt = connexionEbankDirect.prepareStatement(query);			
					stmt.setObject(1,tiers, Types.VARCHAR); //TIERS
					stmt.setObject(2,contrat_bad, Types.VARCHAR); //CONTRAT_BAD
					stmt.setObject(3,delegue, Types.VARCHAR); //DELEGUE
					stmt.setObject(4,canal, Types.VARCHAR); //CANAL
					stmt.setObject(5,date_notif, Types.VARCHAR); //DATE_NOTIF
					stmt.setObject(6,email, Types.VARCHAR); //EMAIL
					stmt.setObject(7,type_transact, Types.VARCHAR); //TYPE_TRANSACT
					stmt.setObject(8, ref_op, Types.VARCHAR); //REF_OP
					stmt.setInt(9, status); //STATUS
					//EaiLog.info("requette ajout  notif " + stmt.toString());
					//System.out.println("requette ajout  notif " + stmt.toString());
					stmt.executeUpdate();
					retour = true;
					
				} catch (Exception e) {
					EaiLog.error(e);
					//System.out.println("requette ajout  notif error " + e.getMessage());

					retour = false;
				} finally {
					/*if (results != null) {
						results.close();
					}*/
					if (stmt != null) {
						stmt.close();
					} 
					connexionEbankDirect.close();
					return retour;
				}

			}


}
