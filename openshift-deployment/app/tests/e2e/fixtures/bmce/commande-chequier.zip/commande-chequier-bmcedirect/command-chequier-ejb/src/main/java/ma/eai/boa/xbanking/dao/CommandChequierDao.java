package ma.eai.boa.xbanking.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import ma.eai.boa.xbanking.models.CommandChequierEntity;
import ma.eai.ingdev.fwk.logging.EaiLog;

public class CommandChequierDao {
	public static void save(CommandChequierEntity commandChequier, Connection connexionEbankDirect) throws SQLException{
		
		PreparedStatement stmt = null;
		try {
			String query = "INSERT INTO COMMAND_CHEQUIER (TYPE_COMMAND, NB_VIGNETTES, QUANTITE, ORIGIN, NUM_ACCOUNT, CREATION_DATE, CODE_ETAT, ID_CMD, ID_ORDONNATEUR, TIERS, EMAIL, TELEPHONE) "
					+ "VALUES (?, ?, ?, ?, ?, TO_TIMESTAMP(?, 'YYYY-MM-DD HH24:MI:SS'),?, COMMAND_CHEQUIER_SEQ.NEXTVAL, ?,?,?,?)";
			EaiLog.info("commandChequier insert query :" + query);
			//System.out.println("commandChequier insert query :" + query);

			stmt = connexionEbankDirect.prepareStatement(query);
			// Set the parameters
			stmt.setString(1, commandChequier.getTypeCommand());
			stmt.setString(2, commandChequier.getNbVignettes());
			stmt.setString(3, commandChequier.getQuantite());
			stmt.setString(4, commandChequier.getOrigin());
			stmt.setString(5, commandChequier.getNumAccount());
			stmt.setString(6, new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(commandChequier.getCreationDate()));
			stmt.setString(7, commandChequier.getCodeEtat());
			stmt.setString(8, commandChequier.getIdOrdonnateur());
			stmt.setString(9, commandChequier.getTiers());
			stmt.setString(10, commandChequier.getEmail());
			stmt.setString(11, commandChequier.getTelephone());

			stmt.executeUpdate();
		
		}catch (Exception e) {
			EaiLog.error(e);
		}finally {
			
			if (stmt != null) {
				stmt.close();
			} 
			if (connexionEbankDirect != null) {
				connexionEbankDirect.close();
			}
			
		}
		
	}


}
