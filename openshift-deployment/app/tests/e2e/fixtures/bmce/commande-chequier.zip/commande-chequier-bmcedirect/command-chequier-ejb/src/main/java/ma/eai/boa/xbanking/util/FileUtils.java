	package ma.eai.boa.xbanking.util;

import ma.eai.ingdev.fwk.logging.EaiLog;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;


public class FileUtils {
	public static String fileReader(String file){

		InputStream inputStream = FileUtils.class.getResourceAsStream("/"+file);
		
	    String inputLine = "";
	    String content = "";
	    try {
	    	 BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream,"UTF-8"));
	    	while ((inputLine = reader.readLine()) != null){
	    		content += inputLine;
			}
	    	reader.close();
		} catch (IOException e) {
			//e.printStackTrace();
		EaiLog.info(e);
		}
	    
		return content;
	}
}