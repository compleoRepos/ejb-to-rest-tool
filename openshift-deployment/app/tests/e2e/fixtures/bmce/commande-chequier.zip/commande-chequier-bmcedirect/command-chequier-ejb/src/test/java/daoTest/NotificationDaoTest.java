package daoTest;

import ma.eai.boa.xbanking.dao.NotificationDao;
import ma.eai.boa.xbanking.models.CommandChequierEntity;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.*;
import java.text.SimpleDateFormat;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

public class NotificationDaoTest {
    @Mock private Connection mockConnection;
    @Mock private PreparedStatement mockPreparedStatement;

    @Before
    public void setup() throws SQLException {
	MockitoAnnotations.initMocks(this);
	when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
	mockPreparedStatement.setObject(anyInt(), anyString(), anyInt());
	mockPreparedStatement.setInt(anyInt(), anyInt());
	when(mockPreparedStatement.executeUpdate()).thenAnswer(invocation -> null);
    }

    @Test
    public void addNotifTest() throws SQLException {

	boolean result = NotificationDao.addNotif("T123", "C456", "D789", "EMAIL",
		"2025-10-27", "test@mail.com", "TRANSFERT",
		"REF001", 1,mockConnection);
	assertTrue(result);
    }
}
