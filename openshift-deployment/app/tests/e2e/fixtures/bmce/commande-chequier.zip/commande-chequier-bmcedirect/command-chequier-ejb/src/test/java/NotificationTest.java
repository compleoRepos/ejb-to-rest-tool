import ma.eai.boa.xbanking.dao.NotificationDao;
import org.junit.Before;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class NotificationTest {


    @Mock
    private Connection mockConnection;
    @Mock
    private PreparedStatement mockStatement;

    @Before
    public void setUp() throws SQLException {
	MockitoAnnotations.openMocks(this);

	// Configurez le mock pour retourner le PreparedStatement simulé
	when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
	when(mockStatement.executeUpdate()).thenReturn(1);
    }



    @Test
    public void testAddNotif() throws SQLException {

	boolean result = NotificationDao.addNotif("tiers", "contrat_bad", "delegue", "canal", "date_notif", "email", "type_transact", "ref_op", 0, mockConnection);

	assertTrue(result);
	verify(mockStatement).setObject(1, "tiers", Types.VARCHAR);
	verify(mockStatement).setObject(2, "contrat_bad", Types.VARCHAR);
	verify(mockStatement).setObject(3, "delegue", Types.VARCHAR);
	verify(mockStatement).setObject(4, "canal", Types.VARCHAR);
	verify(mockStatement).setObject(5, "date_notif", Types.VARCHAR);
	verify(mockStatement).setObject(6, "email", Types.VARCHAR);
	verify(mockStatement).setObject(7, "type_transact", Types.VARCHAR);
	verify(mockStatement).setObject(8, "ref_op", Types.VARCHAR);
	verify(mockStatement).setInt(9, 0);
	verify(mockStatement).executeUpdate();
	verify(mockConnection).close();
    }



}
