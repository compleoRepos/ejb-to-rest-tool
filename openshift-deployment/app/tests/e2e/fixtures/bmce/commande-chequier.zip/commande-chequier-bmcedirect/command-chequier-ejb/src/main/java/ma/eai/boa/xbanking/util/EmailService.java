package ma.eai.boa.xbanking.util;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.MessagingException;

import javax.mail.Transport;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.InternetAddress;

import ma.eai.ingdev.fwk.logging.EaiLog;

public class EmailService {
	
	private EmailService() {
		
	}

	public static void send(String pEmail, String pBody) {
		final String username = "bmce.dev@gmail.com";
		final String pss = "eai*123@";

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props,
		 new javax.mail.Authenticator() {
			@Override	
		protected PasswordAuthentication getPasswordAuthentication() {
		return new PasswordAuthentication(username, pss);
		}
		 });

		try {

		Message message = new MimeMessage(session);
		message.setFrom(new InternetAddress("bmce.dev@gmail.com"));
		message.setRecipients(Message.RecipientType.TO,
		InternetAddress.parse(pEmail));
		message.setSubject(pEmail);
		message.setText(pBody);

		Transport.send(message);

		//System.out.println("Done");

		} catch (MessagingException e) {
		//throw new RuntimeException(e);
			EaiLog.error(e);
		}

	}
}