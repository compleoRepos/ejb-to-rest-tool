import junit.framework.TestCase;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.Parser;
import ma.eai.commons.utilities.UtilFile;
import ma.eai.commons.utilities.UtilString;
import ma.eai.ingdev.fwk.logging.EaiLog;

import java.util.List;

public class ClientUCTest extends TestCase {

	public static void testVadCarteParamsByMarket() throws Exception {

		try {


			Envelope env = Parser.unmarshall(UtilString.toString(UtilFile.searchResource("cmd-chq.xml")));
			List<String> lst = env.getNodeAsList("flux/accounts");

			// Assertions to validate the test case
			assertNotNull("The list should not be null", lst);
			assertFalse("The list should not be empty", lst.isEmpty());


			//System.out.println("Resultat :" + lst);

		} catch (Exception e) {
		    EaiLog.error(e);
			fail("Exception thrown during test execution: " + e.getMessage());
		}
	}
}