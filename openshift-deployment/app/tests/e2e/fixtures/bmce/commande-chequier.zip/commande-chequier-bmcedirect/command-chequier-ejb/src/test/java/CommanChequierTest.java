import junit.framework.TestCase;
import ma.eai.boa.xbanking.services.CommandChequier;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.Parser;
import ma.eai.commons.utilities.UtilFile;
import ma.eai.commons.utilities.UtilString;
import ma.eai.boa.xbanking.util.DateUtil;
import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;
import java.util.Calendar;
import java.util.Date;
import java.sql.Timestamp;
public class CommanChequierTest {
    CommandChequier commandChequier = new CommandChequier();

    @Test
    public void testGetActionWithEnrgCommande() {
	Object action = commandChequier.getAction("enrgCommande");


	assertNotNull(action);
	assertTrue(action instanceof Enum);
	assertEquals("ENRG_COMMANDE", ((Enum<?>) action).name());
    }

    @Test
    public void testGetActionWithHistoryCmd() {
	Object action = commandChequier.getAction("historyCmd");

	assertNotNull(action);
	assertTrue(action instanceof Enum);
	assertEquals("HISTORY_CMD", ((Enum<?>) action).name());
    }

    @Test
    public void testGetActionWithSuiviCommande() {
	Object action = commandChequier.getAction("suiviCommande");

	assertNotNull(action);
	assertTrue(action instanceof Enum);
	assertEquals("SUIVI_COMMANDE", ((Enum<?>) action).name());
    }

    @Test
    public void testGetActionWithInvalidValue() {
	Object action = commandChequier.getAction("invalidCommand");

	assertNull(action);
    }

}
