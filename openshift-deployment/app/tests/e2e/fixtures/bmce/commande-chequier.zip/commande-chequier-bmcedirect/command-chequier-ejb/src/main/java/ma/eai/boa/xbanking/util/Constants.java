package ma.eai.boa.xbanking.util;

public class Constants {


	public static final String DEFAULT_LANG = "FR";

	private  Constants() {
		
	}

	public static final String UDDI_PUSH_NOTIF_MOBILE = "pushNotificationBmceDirect";
	public static final String CODE_NOTIF_APP = "CHQ";
	public static final int MAX_CMD = 3;
	public static final String SEPARATEUR="/";
	public  static final String ROWS="flux/rows";
	public  static final String FLUX="flux";
	public  static final String FLUX_NODE_COMMAND="flux/Command";

	//public static final  String URL_WS = "http://demchq-sy.bmcebank.co.ma/demChq/services/ICommandeService?wsdl"; // SYPrime
	public  static final String URL_WS = "commande-chequier-ws";

}
