package ma.eai.boa.xbanking.models;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class History {
    private String date;
    private String numCompte;
    private String typeCarnet;
    private String nbVignettes;
    private String etat;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getNumCompte() {
        return numCompte;
    }

    public void setNumCompte(String numCompte) {
        this.numCompte = numCompte;
    }

    public String getTypeCarnet() {
        return typeCarnet;
    }

    public void setTypeCarnet(String typeCarnet) {
        this.typeCarnet = typeCarnet;
    }

    public String getNbVignettes() {
        return nbVignettes;
    }

    public void setNbVignettes(String nbVignettes) {
        this.nbVignettes = nbVignettes;
    }

    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }

    public Date toDate(){
        try {
            return new SimpleDateFormat("dd/MM/yyyy").parse(this.date);
        } catch (ParseException e) {
           return null;
        }
    }
}
