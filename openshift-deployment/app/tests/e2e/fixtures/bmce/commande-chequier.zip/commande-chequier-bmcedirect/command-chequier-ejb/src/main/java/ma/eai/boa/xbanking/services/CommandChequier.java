package ma.eai.boa.xbanking.services;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Objects;


import javax.annotation.Resource;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.sql.DataSource;

import ma.eai.boa.xbanking.SendNotifcationCommand;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.Parser;
import ma.eai.commons.services.parsing.ParsingException;
import ma.eai.boa.xbanking.dao.CommandChequierDao;
import ma.eai.midw.connectors.SynchroneService;
import ma.eai.boa.xbanking.models.CommandChequierEntity;
import ma.eai.boa.xbanking.models.History;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.util.DateUtil;
import ma.eai.boa.xbanking.util.FileUtils;
import ma.eai.boa.xbanking.util.Mailer;
import ma.eai.boa.xbanking.util.WriteFlux;
import ma.eai.ingdev.fwk.logging.EaiLog;
import ma.eai.boa.xbanking.icommandeservice.ICommandeService;
import ma.eai.boa.xbanking.icommandeservice.ICommandeServicePortType;

@Stateless(name = "CommandChequierService")
@TransactionAttribute(TransactionAttributeType.REQUIRED)
@Remote(SynchroneService.class)
public class CommandChequier implements SynchroneService {
    @Resource(name = "jdbc/ebankdirect_xa")
    private DataSource ebankdirectXA;

    private enum Action {
        ENRG_COMMANDE, SUIVI_COMMANDE, HISTORY_CMD
    }

    private static final String FLUX_ACTION_PATH = "flux/action";
    private static final String FLUX_NUM_ACCOUNT_PATH = "flux/numAccount";
    private static final String ERROR_I_COMMANDE_SERVICE = "Error ICommandeService suiviCommand : ";
    private static final String ERROR_ENRG_COMMANDE = "Error ICommandeService enrgCommande : ";
    private static final String TECHNICAL_PROBLEM_MSG = "Problème technique, merci de réssayer plus tard";
    private static final String ERROR_SUIVI_COMMAND = "Error suiviCommand : ";

    public Action getAction(String actionValue) {
        Action action = null;
        switch (actionValue) {
            case "enrgCommande":
                action = Action.ENRG_COMMANDE;
                break;
            case "historyCmd":
                action = Action.HISTORY_CMD;
                break;
            case "suiviCommande":
                action = Action.SUIVI_COMMANDE;
                break;
            default:
                break;
        }
        return action;
    }

    @Override
    public Envelope process(Envelope pEnvelopeIn) throws Exception {

        EaiLog.initLogTraceInfos(pEnvelopeIn);
        EaiLog.setServiceName(pEnvelopeIn.getNodeAsString(FLUX_ACTION_PATH));
        EaiLog.setNewThreadId();


        EaiLog.info("CommandChequierService: flux en entrée pour l'action :  "
                + pEnvelopeIn.getNodeAsString(FLUX_ACTION_PATH) + Parser.unmarshall(pEnvelopeIn.toString()));

        Envelope envelopeOut = new Envelope();

        String actionValue = pEnvelopeIn.getNodeAsString(FLUX_ACTION_PATH);

        String numAccount = pEnvelopeIn.getNodeAsString(FLUX_NUM_ACCOUNT_PATH);
        switch (Objects.requireNonNull(getAction(actionValue))) {
            case ENRG_COMMANDE:

                String typeCommand = pEnvelopeIn.getNodeAsString("flux/typeCommand");
                String nbVignettes = pEnvelopeIn.getNodeAsString("flux/nbVignettes");
                String quantite = pEnvelopeIn.getNodeAsString("flux/quantite");
                String origin = pEnvelopeIn.getNodeAsString("flux/origin");
                String tiers = pEnvelopeIn.getNodeAsString("flux/tiers");
                String idClient = pEnvelopeIn.getNodeAsString("flux/idClient");
                String email = pEnvelopeIn.getNodeAsString("flux/email");
                String telephone = pEnvelopeIn.getNodeAsString("flux/telephone");
                EaiLog.info("display phone number : " + telephone);
                String libCompte = pEnvelopeIn.getNodeAsString("flux/libCompte");
                String typeCommandStr = pEnvelopeIn.getNodeAsString("flux/typeCommandStr");
                String lang = pEnvelopeIn.getNodeAsString("flux/lang");
                Boolean confirmation = Boolean.parseBoolean(pEnvelopeIn.getNodeAsString("flux/confirmation"));

                EaiLog.info("Confirmation :  " + confirmation);
                if (lang == null || lang.isEmpty()) {
                    lang = Constants.DEFAULT_LANG;
                }
                lang = lang.toUpperCase();
                envelopeOut = enrgCommande(numAccount, typeCommand, nbVignettes, quantite, origin, confirmation, idClient, tiers,
                        email, libCompte, typeCommandStr, telephone, lang);
                break;
            case SUIVI_COMMANDE:

                envelopeOut = suiviCommande(numAccount);
                break;
            case HISTORY_CMD:
                int nbrAccounts = pEnvelopeIn.getNodeAsInt("flux/nbrAccounts");
                List<String> numAccounts = new ArrayList<>();
                for (int i = 1; i <= nbrAccounts; i++) {
                    numAccounts.add(pEnvelopeIn.getNodeAsString("flux/accounts/numAccount," + i));
                }
                EaiLog.info("Get Accounts history " + numAccounts);

                envelopeOut = historyCmd(numAccounts);
                break;
        }
        EaiLog.info(String.format("Flux out %s", envelopeOut.toString()));

        return envelopeOut;
    }

    private Envelope historyCmd(List<String> pNumAccounts) throws Exception {
        Envelope envelopeOut = new Envelope();

        String codeResponse = "";
        String messageResponse = "";

        ICommandeService cmdService = new ICommandeService();
        ICommandeServicePortType cmd = cmdService.getICommandeServiceHttpPort();
        try {
            List<History> commandsData = new ArrayList<>();
            for (String numAccount : pNumAccounts) {
                String siviCommandeResponse = cmd.suiviCommande2(numAccount);
                if (siviCommandeResponse == null || siviCommandeResponse.length() == 0) {
                    continue;
                }
                EaiLog.info(String.format("account : (%s ) commands %s", numAccount, siviCommandeResponse));
                String[] commands = siviCommandeResponse.split("&");
                for (String commandRow : commands) {
                    String[] commandCulmns = commandRow.split(";");

                    History history = new History();
                    history.setDate(getDataFromArray(commandCulmns, 0));
                    history.setNumCompte(getDataFromArray(commandCulmns, 1));
                    history.setTypeCarnet(getDataFromArray(commandCulmns, 2));
                    history.setNbVignettes(getDataFromArray(commandCulmns, 3));
                    history.setEtat(getDataFromArray(commandCulmns, 4));

                    commandsData.add(history);
                }
            }
            Collections.sort(commandsData, Comparator.comparing(History::toDate).reversed());
            codeResponse = "000";
            messageResponse = "OK";
            WriteFlux.ecrireString(envelopeOut, Constants.FLUX, "code", codeResponse, "");
            WriteFlux.ecrireString(envelopeOut, Constants.FLUX, "message", messageResponse, "");
            int i = 1;
            for (History commandRow : commandsData) {
                WriteFlux.ecrireString(envelopeOut, Constants.ROWS, "row," + i + "/date", commandRow.getDate(), "");

                WriteFlux.ecrireString(envelopeOut, Constants.ROWS, "row," + i + "/numCompte",
                        commandRow.getNumCompte(), "");

                WriteFlux.ecrireString(envelopeOut, Constants.ROWS, "row," + i + "/typeCarnet",
                        commandRow.getTypeCarnet(), "");

                WriteFlux.ecrireString(envelopeOut, Constants.ROWS, "row," + i + "/nbVignettes", commandRow.getNbVignettes(),
                        "");

                WriteFlux.ecrireString(envelopeOut, Constants.ROWS, "row," + i + "/etat", commandRow.getEtat(), "");
                i++;
            }


        } catch (Exception e) {
            EaiLog.error(ERROR_I_COMMANDE_SERVICE + e.getMessage());
            EaiLog.error(ERROR_I_COMMANDE_SERVICE, e);
            codeResponse = "003";
            messageResponse = TECHNICAL_PROBLEM_MSG;

            envelopeOut = WriteFlux.writeFluxMsg(codeResponse, messageResponse);
        }


        return envelopeOut;
    }

    private String getDataFromArray(String[] commandCulmns, int index) {
        if (index >= commandCulmns.length || index < 0) {
            return "";
        } else {
            return commandCulmns[index];
        }
    }

    public static Envelope suiviCommande(String pNumAccount) throws Exception {
        Envelope envelopeOut = new Envelope();
        ICommandeService cmdService = new ICommandeService();
        ICommandeServicePortType cmd = cmdService.getICommandeServiceHttpPort();
        String siviCommandeResponse;

        try {
            siviCommandeResponse = getSiviCommandeResponse(cmd, pNumAccount);
            if (siviCommandeResponse != null && !siviCommandeResponse.isEmpty()) {
                processCommandeResponse(envelopeOut, siviCommandeResponse);
            }
        } catch (Throwable e) {
            envelopeOut = handleException(e, envelopeOut);
        }

        return envelopeOut;
    }

    private static String getSiviCommandeResponse(ICommandeServicePortType cmd, String pNumAccount) {
        try {
            return cmd.suiviCommande(pNumAccount);
        } catch (Throwable e) {
            EaiLog.error(ERROR_I_COMMANDE_SERVICE + e.getMessage());
            EaiLog.error(ERROR_I_COMMANDE_SERVICE, e);
            throw e; // Rethrow to be handled in the main method
        }
    }

    private static void processCommandeResponse(Envelope envelopeOut, String siviCommandeResponse) throws Exception {
        String codeResponse = "000";
        String messageResponse = "OK";
        WriteFlux.ecrireString(envelopeOut, Constants.FLUX, "code", codeResponse, "");
        WriteFlux.ecrireString(envelopeOut, Constants.FLUX, "message", messageResponse, "");

        String[] commands = siviCommandeResponse.split("&");
        int i = 1;
        for (String commandRow : commands) {
            processCommandRow(envelopeOut, commandRow, i);
            i++;
        }
    }

    private static void processCommandRow(Envelope envelopeOut, String commandRow, int index) throws Exception {
        String[] commandColumns = commandRow.split(";");
        WriteFlux.ecrireString(envelopeOut, Constants.ROWS, "row," + index + "/date", commandColumns[0], "");
        WriteFlux.ecrireString(envelopeOut, Constants.ROWS, "row," + index + "/typeCarnet", commandColumns[1], "");
        WriteFlux.ecrireString(envelopeOut, Constants.ROWS, "row," + index + "/nbVignettes", commandColumns[2], "");
        WriteFlux.ecrireString(envelopeOut, Constants.ROWS, "row," + index + "/Quantite", commandColumns[3], "");
        WriteFlux.ecrireString(envelopeOut, Constants.ROWS, "row," + index + "/etat", commandColumns[4], "");
    }

    private static Envelope handleException(Throwable e, Envelope envelopeOut) throws Exception {
        EaiLog.error(ERROR_SUIVI_COMMAND + e.getMessage());
        EaiLog.error(ERROR_SUIVI_COMMAND, e);
        String codeResponse = "003";
        String messageResponse = TECHNICAL_PROBLEM_MSG;
        return WriteFlux.writeFluxMsg(codeResponse, messageResponse);
    }

    private Envelope enrgCommande(String pNumAccount, String pTypeCommand, String pNbVignettes, String pQuantite,
                                  String pOrigin, Boolean pConfirmation, String pIdClient, String pTiers, String pEmail,
                                  String pLibCompte, String pTypeCommandStr, String telephone, String lang) throws Exception {
        Envelope envelopeOut = new Envelope();
        EaiLog.info("debut  enrgCommande pour le compte " + pNumAccount);

        try {
            String selectedStatusCmd = determineStatusCmd(pOrigin);
            int[] commandCounts = getCommandCounts(pNumAccount, selectedStatusCmd);
            if (shouldRejectCommand(commandCounts)) {
                return handleRejectedCommand(pNumAccount, pTypeCommand, pNbVignettes, pQuantite, pOrigin, pIdClient, pTiers, pEmail, telephone, envelopeOut);
            }

            String enrgCommandeResponse = executeCommand(pNumAccount, pTypeCommand, pNbVignettes, pQuantite, pOrigin, pConfirmation);
            EaiLog.info("CommandChequierService:  enrgCommande response => " + enrgCommandeResponse);

            if (handleSuccessfulCommand(enrgCommandeResponse, pTypeCommandStr, pNbVignettes, pNumAccount, pLibCompte, pEmail, lang, pIdClient, pTiers, telephone)) {
                envelopeOut = WriteFlux.writeFluxMsg("000", "OK");
            } else {
                envelopeOut = handleCommandError(enrgCommandeResponse, pIdClient, pTiers, pEmail, telephone);
            }

        } catch (Throwable e) {
            EaiLog.error("Error enrgCommande : " + e.getMessage(), e);
            envelopeOut = WriteFlux.writeFluxMsg("004", TECHNICAL_PROBLEM_MSG);
        }

        EaiLog.info("CommandChequierService: fluxout enrgCommande" + Parser.unmarshall(envelopeOut.toString()));
        return envelopeOut;
    }

    private String determineStatusCmd(String pOrigin) {
        return "M".equalsIgnoreCase(pOrigin) || "I".equalsIgnoreCase(pOrigin) ? "2" : "1";
    }

    private int[] getCommandCounts(String pNumAccount, String selectedStatusCmd) throws ParsingException {
        int[] counts = new int[4]; // [Mobile, Internet, GAB, Agence]
        ICommandeService cmdService = new ICommandeService();
        ICommandeServicePortType cmd = cmdService.getICommandeServiceHttpPort();
        String nbrCmdCanal = cmd.nbrCommandeCanal1(pNumAccount, selectedStatusCmd);
        EaiLog.info("nbrCmdCanal : " + nbrCmdCanal);

        if (isValidCommandString(nbrCmdCanal)) {
            processCommandCounts(nbrCmdCanal, counts);
        }

        return counts;
    }

    private boolean isValidCommandString(String nbrCmdCanal) {
        return nbrCmdCanal != null && !nbrCmdCanal.isEmpty();
    }

    private void processCommandCounts(String nbrCmdCanal, int[] counts) {
        String[] nbByCanals = nbrCmdCanal.split(";");
        for (String nbCanal : nbByCanals) {
            if (isValidCanalString(nbCanal)) {
                updateCounts(nbCanal, counts);
            }
        }
    }

    private boolean isValidCanalString(String nbCanal) {
        return nbCanal != null && !nbCanal.isEmpty();
    }

    private void updateCounts(String nbCanal, int[] counts) {
        String[] canal = nbCanal.split(":");
        String[] nbr = canal[1].split("-");
        int nbrInt;
        try {
            nbrInt = Integer.parseInt(nbr[1]);
        } catch (NumberFormatException e) {
            //System.err.println("Invalid number format (parsing error): " + nbr[1]);
            EaiLog.error(e);
            return;
        }

        switch (canal[0].toUpperCase()) {
            case "A":
                counts[3] = nbrInt; // Agence
                break;
            case "G":
                counts[2] = nbrInt; // GAB
                break;
            case "I":
                counts[1] = nbrInt; // Internet
                break;
            case "M":
                counts[0] = nbrInt; // Mobile
                break;
            default:
                // Handle unexpected canal type
                //System.err.println("Unexpected canal type: " + canal[0]);
                break;
        }
    }

    private boolean shouldRejectCommand(int[] commandCounts) {
        int nbrTotalCmd = commandCounts[0] + commandCounts[1] + commandCounts[2] + commandCounts[3];
        EaiLog.info("nbrTotalCmd : " + nbrTotalCmd);
        return nbrTotalCmd >= Constants.MAX_CMD;
    }

    private Envelope handleRejectedCommand(String pNumAccount, String pTypeCommand, String pNbVignettes, String pQuantite,
                                           String pOrigin, String pIdClient, String pTiers, String pEmail, String telephone,
                                           Envelope envelopeOut) throws Exception {
        String codeResponse = "005";
        String messageResponse = "Demande refusée. Vous avez atteint le nombre maximal de chéquiers autorisés. Veuillez contacter votre agence s’il vous plait.";

        saveCommandChequier(pNumAccount, pTypeCommand, pNbVignettes, pQuantite, pOrigin, pIdClient, pTiers, pEmail, telephone, codeResponse);

        Envelope responseEnvelope = WriteFlux.writeFluxMsg(codeResponse, messageResponse);
        WriteFlux.ecrireString(responseEnvelope, Constants.FLUX, "wsResponse", "", "");
        EaiLog.info("CommandChequierService: fluxout enrgCommande" + Parser.unmarshall(responseEnvelope.toString()));

        return responseEnvelope;
    }

    private void saveCommandChequier(String pNumAccount, String pTypeCommand, String pNbVignettes, String pQuantite,
                                     String pOrigin, String pIdClient, String pTiers, String pEmail, String telephone,
                                     String codeResponse) throws ParsingException {
        CommandChequierEntity cmdChequierEntity = new CommandChequierEntity();
        cmdChequierEntity.setCreationDate(new Date());
        cmdChequierEntity.setTypeCommand(pTypeCommand);
        cmdChequierEntity.setNbVignettes(pNbVignettes);
        cmdChequierEntity.setNumAccount(pNumAccount);
        cmdChequierEntity.setOrigin(pOrigin);
        cmdChequierEntity.setQuantite(pQuantite);
        cmdChequierEntity.setCodeEtat(codeResponse);
        cmdChequierEntity.setIdOrdonnateur(pIdClient);
        cmdChequierEntity.setTiers(pTiers);
        cmdChequierEntity.setEmail(pEmail);
        cmdChequierEntity.setTelephone(telephone);
        try (Connection connexionEbankDirect = ebankdirectXA.getConnection()) {
            CommandChequierDao.save(cmdChequierEntity, connexionEbankDirect);
        } catch (SQLException e) {
            EaiLog.error("Error saving CommandChequierEntity", e);
        }
    }

    private String executeCommand(String pNumAccount, String pTypeCommand, String pNbVignettes, String pQuantite,
                                  String pOrigin, Boolean pConfirmation) throws ParsingException {
        ICommandeService cmdService = new ICommandeService();
        ICommandeServicePortType cmd = cmdService.getICommandeServiceHttpPort();
        return cmd.enrgCommande(pNumAccount, pTypeCommand, pNbVignettes, pQuantite, pOrigin, pConfirmation);
    }

    private boolean handleSuccessfulCommand(String enrgCommandeResponse, String pTypeCommandStr, String pNbVignettes,
                                            String pNumAccount, String pLibCompte, String pEmail, String lang,
                                            String pIdClient, String pTiers, String telephone) throws ParsingException, IOException {
        if ("M01".equalsIgnoreCase(enrgCommandeResponse)) {
            sendSuccessEmail(pEmail, pTypeCommandStr, pNbVignettes, pNumAccount, pLibCompte, lang);
            sendPushNotification(pTiers);
            saveCommandChequier(pNumAccount, pTypeCommandStr, pNbVignettes, "", "", pIdClient, pTiers, pEmail, telephone, "000");
            return true;
        }
        return false;
    }

    private void sendSuccessEmail(String pEmail, String pTypeCommandStr, String pNbVignettes, String pNumAccount,
                                  String pLibCompte, String lang) throws IOException {
        String filePath = "CmdChequier_" + lang + ".html";
        EaiLog.info("email content path : " + filePath);
        String content = FileUtils.fileReader(filePath);
        String dateNow = DateUtil.dateToString("dd-MM-yyyy", new Date());
        String heureNow = DateUtil.dateToString("HH:mm:ss", new Date());

        content = content.replace("Date_", dateNow)
                .replace("heure_", heureNow)
                .replace("TypeChequier_", pTypeCommandStr)
                .replace("nbrCheques_", pNbVignettes)
                .replace("NumCompte_", pNumAccount)
                .replace("LibCompte_", pLibCompte);

        String subject = "FR".equalsIgnoreCase(lang) ? "Avis d'opération Commande de chéquier" : "TRANSACTION ADVICE CHECK BOOK ORDER";

        if (pEmail != null && !pEmail.isEmpty()) {
            boolean sent = Mailer.send(pEmail, subject, content);
            if (sent) {
                EaiLog.info("Mail sent !!");
            } else {
                EaiLog.info("Mail not sent !! to : " + pEmail);
            }
        }
    }

    private void sendPushNotification(String pTiers) {
        try {
            SendNotifcationCommand sendNotifcationCommand = new SendNotifcationCommand(pTiers, "Avis d'opération Commande de chéquier", "Nous vous confirmons que nous avons exécuté votre  commande de chéquier");
            sendNotifcationCommand.execute();
        } catch (Exception e) {
            EaiLog.error("command push notif error ", e);
        }
    }

    private Envelope handleCommandError(String enrgCommandeResponse, String pIdClient, String pTiers, String pEmail, String telephone) throws Exception {
        String codeResponse;
        String messageResponse;

        if (enrgCommandeResponse.startsWith("M06")) {
            codeResponse = "001";
            messageResponse = "Vous avez une commande encours";
        } else if (enrgCommandeResponse.startsWith("M07")) {
            codeResponse = "002";
            messageResponse = "Vous avez des carnet en stock";
        } else {
            codeResponse = "003";
            messageResponse = enrgCommandeResponse;
        }

        EaiLog.info("CommandChequierService: " + codeResponse + " msg :" + messageResponse);
        saveCommandChequier("", "", "", "", "", pIdClient, pTiers, pEmail, telephone, codeResponse);
        return WriteFlux.writeFluxMsg(codeResponse, messageResponse);
    }

}
