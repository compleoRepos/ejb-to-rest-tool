package daoTest;

import ma.eai.boa.xbanking.dao.CommandChequierDao;
import ma.eai.boa.xbanking.models.CommandChequierEntity;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.sql.*;
import java.text.SimpleDateFormat;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class CommandChequierDaoTest {
    @Mock
    private CommandChequierEntity mockCommandChequier;
    @Mock private Connection mockConnection;
    @Mock private PreparedStatement mockPreparedStatement;
    @Mock private ResultSet mockResultSet;
    @Mock private Date mockDate;
    @Mock private SimpleDateFormat mockSimpleDateFormat;

    @Before
    public void setUp() throws Exception {
	MockitoAnnotations.initMocks(this);

	// Stub the behavior of connection.prepareStatement
	when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);

	// Stub the behavior of statement.execute and getResultSet
	when(mockPreparedStatement.executeUpdate()).thenReturn(1);
	when(mockPreparedStatement.getResultSet()).thenReturn(mockResultSet);
	when(mockCommandChequier.getCreationDate()).thenReturn(mockDate);
    }

    @Test
    public void testSave(){
	// Mock the static method Services.find using mockStatic
	try (MockedStatic<EaiLog> mockedEailLog = mockStatic(EaiLog.class)) {
	    // Mocking EaiLog.info static method
	    mockedEailLog.when(() -> EaiLog.info("commandChequier insert query :" + anyString())).thenAnswer(invocation -> null);
	    when(mockSimpleDateFormat.format(any(Date.class))).thenReturn("2025-10-27 10:00:00");
	    mockPreparedStatement.setString(anyInt(), anyString());

	    // Call the static method Traitement under test
	    CommandChequierDao.save(mockCommandChequier, mockConnection);

	    // Validate the expected outcome
	    assertNotNull(mockPreparedStatement);
	} catch (SQLException e) {
	    throw new RuntimeException(e);
	}
    }



}
