import ma.eai.boa.xbanking.models.History;
import org.junit.Test;
import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.Date;

public class HistoryTest {

    @Test
    public void testSettersAndGetters() {
        // Arrange
        History history = new History();
        String testDate = "20/09/2024";
        String testNumCompte = "123456";
        String testTypeCarnet = "TypeA";
        String testNbVignettes = "5";
        String testEtat = "Active";

        // Act
        history.setDate(testDate);
        history.setNumCompte(testNumCompte);
        history.setTypeCarnet(testTypeCarnet);
        history.setNbVignettes(testNbVignettes);
        history.setEtat(testEtat);

        // Assert
        assertEquals(testDate, history.getDate());
        assertEquals(testNumCompte, history.getNumCompte());
        assertEquals(testTypeCarnet, history.getTypeCarnet());
        assertEquals(testNbVignettes, history.getNbVignettes());
        assertEquals(testEtat, history.getEtat());
    }

    @Test
    public void testToDate_ValidDate() {
        // Arrange
        History history = new History();
        history.setDate("20/09/2024");

        // Act
        Date date = history.toDate();

        // Assert
        assertNotNull(date);
        assertEquals("20/09/2024", new SimpleDateFormat("dd/MM/yyyy").format(date));
    }

    @Test
    public void testToDate_InvalidDate() {
        // Arrange
        History history = new History();
        history.setDate("invalid-date");

        // Act
        Date date = history.toDate();

        // Assert
        assertNull(date); // Should return null for invalid date
    }
}
