@javax.xml.bind.annotation.XmlSchema(namespace = "http://xfire.codehaus.org/ICommandeService", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package ma.eai.boa.xbanking.icommandeservice;
