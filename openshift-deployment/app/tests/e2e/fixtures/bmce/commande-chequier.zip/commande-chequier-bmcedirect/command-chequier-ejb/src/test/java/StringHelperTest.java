import ma.eai.boa.xbanking.util.StringHelper;
import org.junit.Test;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import static junit.framework.Assert.*;


public class StringHelperTest {

    @Test
    public void testPadLeft() {
        assertEquals("   123", StringHelper.padLeft("123", 6, ' '));
        assertEquals("000123", StringHelper.padLeft("123", 6, '0'));
    }

    @Test
    public void testPadRight() {
        assertEquals("123   ", StringHelper.padRight("123", 6, ' '));
        assertEquals("123000", StringHelper.padRight("123", 6, '0'));
    }

    @Test
    public void testSubstringWithLength() {
        assertEquals("lo", StringHelper.Substring("Hello", 3, 2));
        assertEquals("Hello", StringHelper.Substring("Hello", 0, 5));
    }

    @Test
    public void testSubstringWithoutLength() {
        assertEquals("llo", StringHelper.Substring("Hello", 2));
        assertEquals("", StringHelper.Substring("Hello", 10));
    }

    @Test
    public void testEmptyString() {
        assertEquals("", StringHelper.splitAndGetAt("", ",", 0));
    }

    @Test
    public void testFormatDecimalForDB() {
        assertEquals("00123400", StringHelper.formatDecimalForDB(new BigDecimal("1234"), 8));
        assertEquals("00000001", StringHelper.formatDecimalForDB(new BigDecimal("0.01"), 8));
        assertEquals("00000000", StringHelper.formatDecimalForDB(new BigDecimal("0.00"), 8)); // Test for zero
        assertEquals("00004567", StringHelper.formatDecimalForDB(new BigDecimal("45.67"), 8)); // Test for decimal values
    }

    @Test
    public void testGetAnneeMois() {
        Calendar cal = Calendar.getInstance();
        cal.set(2023, Calendar.SEPTEMBER, 19);
        Date date = cal.getTime();
        assertEquals("202309", StringHelper.getAnneeMois(date));
    }

    @Test
    public void testFormatterDateFromYYYYMMDD() {
        assertEquals("19/09/2023", StringHelper.formatterDateFromYYYYMMDD("20230919"));
        assertEquals("", StringHelper.formatterDateFromYYYYMMDD("00010001"));
    }

    @Test
    public void testFormatteDateToYYYYMMDDHHmm() {
        Calendar cal = Calendar.getInstance();
        cal.set(2023, Calendar.SEPTEMBER, 19, 15, 30);
        Date date = cal.getTime();
        assertEquals("202309191530", StringHelper.formatteDateToYYYYMMDDHHmm(date));
    }

    @Test
    public void testFormatteDateToYYYYMMDD() {
        Calendar cal = Calendar.getInstance();
        cal.set(2023, Calendar.SEPTEMBER, 19);
        Date date = cal.getTime();
        assertEquals("20230919", StringHelper.formatteDateToYYYYMMDD(date));
    }

    @Test
    public void testFormatteDateToMiliseconde() {
        Calendar cal = Calendar.getInstance();
        cal.set(2023, Calendar.SEPTEMBER, 19, 15, 30, 45);
        cal.set(Calendar.MILLISECOND, 123);
        Date date = cal.getTime();
        assertEquals("20230919153045123", StringHelper.formatteDateToMiliseconde(date));
    }

    @Test
    public void testFormatteDateToYYYYMM() {
        Calendar cal = Calendar.getInstance();
        cal.set(2023, Calendar.SEPTEMBER, 19);
        Date date = cal.getTime();
        assertEquals("202309", StringHelper.formatteDateToYYYYMM(date));
    }

    @Test
    public void testIsString() {
        assertTrue(StringHelper.isString("Hello"));
        assertFalse(StringHelper.isString(null));
        assertFalse(StringHelper.isString(""));
        assertFalse(StringHelper.isString(" "));
    }

    @Test
    public void testGetDateJmoin1() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        Date expectedDate = cal.getTime();
        String expectedFormattedDate = StringHelper.formatteDateToYYYYMMDD(expectedDate);
        assertEquals(expectedFormattedDate, StringHelper.getDateJmoin1());
    }
}
