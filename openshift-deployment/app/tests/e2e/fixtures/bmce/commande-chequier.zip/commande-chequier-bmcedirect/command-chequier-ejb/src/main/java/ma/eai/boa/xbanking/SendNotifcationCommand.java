package ma.eai.boa.xbanking;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandProperties;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.Parser;
import ma.eai.commons.utilities.UtilHash;
import ma.eai.midw.connectors.SynchroneService;
import ma.eai.midw.integration.Services;
import ma.eai.ingdev.fwk.logging.EaiLog;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class SendNotifcationCommand extends HystrixCommand<Envelope> {
    private String numTiers;
    private String title;
    private String description;

    public SendNotifcationCommand(String numTiers, String title, String description) {
	super(HystrixCommand.Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("SendNotifcationCommand"))
		.andCommandPropertiesDefaults(HystrixCommandProperties.Setter().withExecutionTimeoutEnabled(true)
			.withExecutionTimeoutInMilliseconds((int) 1000)));
	this.numTiers = numTiers;
	this.title = title;
	this.description = description;
    }

    @Override
    protected Envelope getFallback() {
	Envelope envNotif = new Envelope();
	EaiLog.info(" command fallback");
	return envNotif;
    }

    private Envelope sendNotificatoin() throws Exception {
	Envelope envNotifIn = new Envelope();
	envNotifIn.addNode("flux/entete/fonction", "NotificationUC");
	List<UtilHash> attributes = new ArrayList<UtilHash>();
	UtilHash utilHash = new UtilHash("class", "ma.eai.web.vo.NotificationVoIn");
	attributes.add(utilHash);
	envNotifIn.addNode("flux/object", null, attributes);
	envNotifIn.addNode("flux/object/code", Constants.CODE_NOTIF_APP);
	envNotifIn.addNode("flux/object/title", this.title);
	envNotifIn.addNode("flux/object/description", this.description);
	envNotifIn.addNode("flux/object/url", null);
	envNotifIn.addNode("flux/object/user/TiersNumber", this.numTiers);
	SynchroneService service = Services.find(Constants.UDDI_PUSH_NOTIF_MOBILE, SynchroneService.class);
	envNotifIn = Parser.update(envNotifIn);
	LocalDateTime startDate = LocalDateTime.now();

	EaiLog.info(String.format("Flux in ( %s ) %s", Constants.UDDI_PUSH_NOTIF_MOBILE, envNotifIn.toString()));
	Envelope envOut = service.process(envNotifIn);
	EaiLog.info(String.format("Flux out ( %s ) %s", Constants.UDDI_PUSH_NOTIF_MOBILE, envOut.toString()));
	LocalDateTime endDate = LocalDateTime.now();

	long diff = ChronoUnit.SECONDS.between(startDate, endDate);
	EaiLog.info(String.format("Execution time %s (in seconds) : %d", Constants.UDDI_PUSH_NOTIF_MOBILE, diff));
	return envOut;
    }

    @Override
    protected Envelope run() throws Exception {
	return sendNotificatoin();
    }
}
