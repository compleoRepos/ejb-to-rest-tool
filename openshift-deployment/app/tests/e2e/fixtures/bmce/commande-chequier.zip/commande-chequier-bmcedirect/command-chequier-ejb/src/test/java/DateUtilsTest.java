import ma.eai.boa.xbanking.util.DateUtil;
import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;
import java.util.Calendar;
import java.util.Date;
import java.sql.Timestamp;

public class DateUtilsTest {

    private static final String TEST_FORMAT = "dd/MM/yyyy";
    private static final String TEST_DATE_STRING = "2023/09/19";
    private static final String TEST_DATE_INVALID = "invalid_date";

    private Calendar testCalendar;

    @Before
    public void setUp() {
        testCalendar = Calendar.getInstance();
        testCalendar.set(2023, Calendar.SEPTEMBER, 19, 12, 0, 0);
        testCalendar.setTimeZone(java.util.TimeZone.getTimeZone("UTC+01:00"));
    }

    @Test
    public void testGetFormattedDate() {
        String formattedDate = DateUtil.getFormattedDate(testCalendar);
        assertEquals("20230919", formattedDate);

        assertNull(DateUtil.getFormattedDate(null));
    }

    @Test
    public void testGetFormattedDateEdgeCases() {
        // Test with a leap year
        Calendar leapYearCalendar = Calendar.getInstance();
        leapYearCalendar.set(2020, Calendar.FEBRUARY, 29);
        assertEquals("20200229", DateUtil.getFormattedDate(leapYearCalendar));

        // Test with the last day of the year
        Calendar lastDayCalendar = Calendar.getInstance();
        lastDayCalendar.set(2023, Calendar.DECEMBER, 31);
        assertEquals("20231231", DateUtil.getFormattedDate(lastDayCalendar));
    }

    @Test
    public void testGetDate() {
        Date date = DateUtil.getDate(TEST_FORMAT, TEST_DATE_STRING);
        assertNotNull(date);

        assertNull(DateUtil.getDate(TEST_FORMAT, TEST_DATE_INVALID));
    }

    @Test
    public void testDateToString() {
        String dateString = DateUtil.dateToString(TEST_FORMAT, testCalendar.getTime());
        assertEquals("19/09/2023", dateString);
    }

    @Test
    public void testSqlDateToString() {
        java.sql.Date sqlDate = new java.sql.Date(testCalendar.getTimeInMillis());
        String dateString = DateUtil.sqlDateToString(TEST_FORMAT, sqlDate);
        assertEquals("19/09/2023", dateString);
    }

    @Test
    public void testCalendarToString() {
        String dateString = DateUtil.calendarToString(TEST_FORMAT, testCalendar);
        assertEquals("19/09/2023", dateString);
    }

    @Test
    public void testTimeStampToString() {
        Timestamp timestamp = new Timestamp(testCalendar.getTimeInMillis());
        String dateString = DateUtil.timeStampToString(TEST_FORMAT, timestamp);
        assertEquals("19/09/2023", dateString);
    }

    @Test
    public void testTimeStampToStringEdgeCases() {
        assertNull(DateUtil.timeStampToString(TEST_FORMAT, null));
    }

    @Test
    public void testDateCompare() {
        Timestamp ts1 = new Timestamp(testCalendar.getTimeInMillis());
        Timestamp ts2 = new Timestamp(testCalendar.getTimeInMillis());
        assertTrue(DateUtil.dateCompare(ts1, ts2));

        assertFalse(DateUtil.dateCompare(ts1, null));
        assertFalse(DateUtil.dateCompare(null, ts2));
        assertFalse(DateUtil.dateCompare(new Timestamp(System.currentTimeMillis()), ts1));
    }

    @Test
    public void testDateCalendarCourante() {
        Calendar currentCalendar = DateUtil.dateCalendarCourante();
        assertNotNull(currentCalendar);
        assertEquals(0, currentCalendar.get(Calendar.SECOND)); // should be zeroed
    }

    @Test
    public void testDifferenceCalendarWithFormat() {
        Calendar start = Calendar.getInstance();
        Calendar end = (Calendar) start.clone();
        end.add(Calendar.DAY_OF_MONTH, 1);

        String difference = DateUtil.differenceCalendar(start, end, TEST_FORMAT);
        assertNotNull(difference);
    }

    @Test
    public void testDifferenceCalendarWithFormatEdgeCases() {
        Calendar start = Calendar.getInstance();
        Calendar end = (Calendar) start.clone();
        end.add(Calendar.HOUR_OF_DAY, -1);

        String difference = DateUtil.differenceCalendar(end, start, TEST_FORMAT);
        assertNotNull(difference);
    }

    @Test
    public void testDifferenceCalendarInMillis() {
        Calendar start = Calendar.getInstance();
        Calendar end = (Calendar) start.clone();
        end.add(Calendar.DAY_OF_MONTH, 1);

        long differenceMillis = DateUtil.differenceCalendar(start, end);
        assertTrue(differenceMillis > 0);
    }

    @Test
    public void testDifferenceCalendarInMillisEdgeCases() {
        Calendar start = Calendar.getInstance();
        Calendar end = (Calendar) start.clone();
        end.add(Calendar.SECOND, 5);

        long differenceMillis = DateUtil.differenceCalendar(start, end);
        assertEquals(5000, differenceMillis);
    }

    @Test
    public void testDifferenceTimestamp() {
        Timestamp ts1 = new Timestamp(testCalendar.getTimeInMillis());
        Timestamp ts2 = new Timestamp(testCalendar.getTimeInMillis() + 1000);

        long difference = DateUtil.differenceTimestamp(ts2, ts1);
        assertEquals(1000, difference);
    }

    @Test
    public void testDifferenceTimestampEdgeCases() {
        Timestamp ts1 = new Timestamp(testCalendar.getTimeInMillis());
        Timestamp ts2 = new Timestamp(testCalendar.getTimeInMillis() - 1000);

        long difference = DateUtil.differenceTimestamp(ts1, ts2);
        assertEquals(1000, difference); // Expecting a positive difference of 1000 milliseconds
    }


    @Test
    public void testDateCourante() {
        java.sql.Date currentDate = DateUtil.dateCourante();
        assertNotNull(currentDate);
    }

    @Test
    public void testDateUtilCourante() {
        Date currentDate = DateUtil.dateUtilCourante();
        assertNotNull(currentDate);
    }

    @Test
    public void testTimestampCourante() {
        Timestamp currentTimestamp = DateUtil.timestampCourante();
        assertNotNull(currentTimestamp);
    }

    @Test
    public void testCalcHMS() {
        // Testing exactly one day (86400000 ms)
        String result = DateUtil.calcHMS(86400000, "J.H", "en");
        assertEquals("1.00", result);

        // Testing one day plus one hour (86400000 + 3600000 ms)
        result = DateUtil.calcHMS(86400000 + 3600000, "J.H", "en");
        assertTrue(result.startsWith("1")); // Expecting at least 1 day
        assertTrue(result.endsWith(".00") || result.endsWith(".04")); // Check for proper decimal place

        // Testing in Arabic
        result = DateUtil.calcHMS(86400000, "J.H", "Ar");
        assertEquals("1.00", result);
    }


    @Test
    public void testCalcHMSEdgeCases() {
        // Testing with zero seconds
        String result = DateUtil.calcHMS(0, "J.H", "en");
        assertEquals("0", result);

        // Testing with negative seconds
        result = DateUtil.calcHMS(-3600, "J.H", "en"); // Negative time
        assertTrue(result.startsWith("-")); // Check that it starts with a negative sign
        assertTrue(result.length() > 1); // Ensure it's longer than just "-"
    }


    @Test
    public void testIsDate() {
        assertTrue(DateUtil.isDate("2023/09/19"));
        assertFalse(DateUtil.isDate(TEST_DATE_INVALID));
    }

    @Test
    public void testIsDateEdgeCases() {
        assertTrue(DateUtil.isDate("2023/01/01")); // valid date
        assertTrue(DateUtil.isDate(null)); // null input should return true (as per implementation)
        assertFalse(DateUtil.isDate("")); // empty string should return false
        assertFalse(DateUtil.isDate("invalid_date")); // invalid date format should return false
        assertFalse(DateUtil.isDate("2023/01/32")); // Invalid day should return false
        assertFalse(DateUtil.isDate("2023/13/01")); // Invalid month should return false
    }


    @Test
    public void testStringToDate() {
        Date date = DateUtil.StringToDate(TEST_DATE_STRING);
        assertNotNull(date);

        assertNull(DateUtil.StringToDate(TEST_DATE_INVALID));
    }

    @Test
    public void testStringToDateEdgeCases() {
        assertNull(DateUtil.StringToDate("2023/01/32")); // Invalid day
        assertNull(DateUtil.StringToDate("2023/13/01")); // Invalid month
        assertNull(DateUtil.StringToDate("2023/01")); // Too short
    }

    @Test
    public void testGetDateJplus() {
        Date datePlus = DateUtil.getDateJplus(1);
        Calendar expectedCalendar = Calendar.getInstance();
        expectedCalendar.add(Calendar.DATE, 1);
        assertEquals(expectedCalendar.getTime().toString(), datePlus.toString());
    }

    @Test
    public void testGetDateJmoins() {
        Date dateMinus = DateUtil.getDateJmoins(1);
        Calendar expectedCalendar = Calendar.getInstance();
        expectedCalendar.add(Calendar.DATE, -1);
        assertEquals(expectedCalendar.getTime().toString(), dateMinus.toString());
    }

    @Test
    public void testGetDateJmoinsEdgeCases() {
        Date dateMinus = DateUtil.getDateJmoins(0); // same day
        assertEquals(new Date().toString(), dateMinus.toString());
    }
}
