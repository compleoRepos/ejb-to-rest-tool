import ma.eai.boa.xbanking.icommandeservice.EnrgCommande;
import org.junit.Test;

import static org.junit.Assert.*;

public class EnrgCommandeTest {

    @Test
    public void testGetSetIn0() {
        EnrgCommande enrgCommande = new EnrgCommande();
        String value = "testValue0";
        enrgCommande.setIn0(value);
        assertEquals(value, enrgCommande.getIn0());
    }

    @Test
    public void testGetSetIn1() {
        EnrgCommande enrgCommande = new EnrgCommande();
        String value = "testValue1";
        enrgCommande.setIn1(value);
        assertEquals(value, enrgCommande.getIn1());
    }

    @Test
    public void testGetSetIn2() {
        EnrgCommande enrgCommande = new EnrgCommande();
        String value = "testValue2";
        enrgCommande.setIn2(value);
        assertEquals(value, enrgCommande.getIn2());
    }

    @Test
    public void testGetSetIn3() {
        EnrgCommande enrgCommande = new EnrgCommande();
        String value = "testValue3";
        enrgCommande.setIn3(value);
        assertEquals(value, enrgCommande.getIn3());
    }

    @Test
    public void testGetSetIn4() {
        EnrgCommande enrgCommande = new EnrgCommande();
        String value = "testValue4";
        enrgCommande.setIn4(value);
        assertEquals(value, enrgCommande.getIn4());
    }

    @Test
    public void testGetSetIn5() {
        EnrgCommande enrgCommande = new EnrgCommande();
        boolean value = true;
        enrgCommande.setIn5(value);
        assertTrue(enrgCommande.isIn5());

        value = false;
        enrgCommande.setIn5(value);
        assertFalse(enrgCommande.isIn5());
    }
}
