import ma.eai.boa.xbanking.util.DateUtil;
import org.junit.Test;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;

import static junit.framework.Assert.*;

public class DateUtilTest {

    @Test
    public void testValidDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.SEPTEMBER, 5); // Set to September 5, 2023

        String formattedDate = DateUtil.getFormattedDate(calendar);
        assertEquals("20230905", formattedDate);
    }

    @Test
    public void testSingleDigitMonthAndDay() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.JANUARY, 1); // Set to January 1, 2023

        String formattedDate = DateUtil.getFormattedDate(calendar);
        assertEquals("20230101", formattedDate);
    }

    @Test
    public void testGetDate_ValidInput() throws Exception {
        String format = "yyyy-MM-dd";
        String fDate = "2023-09-18";

        // Set timezone to UTC+01:00
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC+01:00"));
        Date expectedDate = sdf.parse(fDate);

        // Call the method under test
        Date resultDate = DateUtil.getDate(format, fDate);

        // Set the same timezone for the comparison
        sdf.setTimeZone(TimeZone.getTimeZone("UTC+01:00"));

        assertEquals(expectedDate, resultDate);
    }

    @Test
    public void testGetDate_InvalidInput() {
        String format = "yyyy-MM-dd";
        String fDate = "invalid-date";

        Date resultDate = DateUtil.getDate(format, fDate);

        assertNull(resultDate); // Expecting null due to invalid date
    }

    @Test
    public void testGetCalendar_ValidInput() throws Exception {
        String format = "yyyy-MM-dd";
        String fDate = "2023-09-18";

        // Create a Calendar instance representing the expected date
        Calendar expectedCalendar = Calendar.getInstance(TimeZone.getDefault(), Locale.getDefault());
        expectedCalendar.set(2023, Calendar.SEPTEMBER, 18, 0, 0, 0);
        expectedCalendar.set(Calendar.MILLISECOND, 0);

        Calendar resultCalendar = DateUtil.getCalendar(format, fDate);

        assertEquals(expectedCalendar.getTimeInMillis(), resultCalendar.getTimeInMillis());
    }

    /*@Test
    public void testGetCalendar_InvalidInput() {
        String format = "yyyy-MM-dd";
        String fDate = "invalid-date";

        Calendar resultCalendar = DateUtil.getCalendar(format, fDate);

        assertNull(resultCalendar); // Expecting null due to invalid date
    }*/

    @Test
    public void testSqlDateToString_ValidDate() {
        String format = "yyyy-MM-dd";
        java.sql.Date fDate = java.sql.Date.valueOf("2024-09-18");

        String expected = "2024-09-18";
        String actual = DateUtil.sqlDateToString(format, fDate);

        assertEquals(expected, actual);
    }

    @Test
    public void testCalendarToString() {
        // Arrange
        String format = "yyyy-MM-dd";
        Calendar calendar = new GregorianCalendar(2023, Calendar.SEPTEMBER, 18); // 2023-09-18

        // Act
        String result = DateUtil.calendarToString(format, calendar);

        // Assert
        assertEquals("2023-09-18", result);
    }

    @Test
    public void testTimeStampToString() {
        // Arrange
        String format = "yyyy-MM-dd HH:mm:ss";
        Timestamp timestamp = Timestamp.valueOf("2023-09-18 10:15:30");

        // Act
        String result = DateUtil.timeStampToString(format, timestamp);

        // Assert
        assertEquals("2023-09-18 10:15:30", result);
    }

    @Test
    public void testDateCompare() {
        // Arrange
        Timestamp lDate = Timestamp.valueOf("2023-09-18 10:15:30");
        Timestamp fDate = Timestamp.valueOf("2023-09-18 10:15:30");

        // Act
        boolean result = DateUtil.dateCompare(lDate, fDate);

        // Assert
        assertTrue(result); // lDate should equal fDate
    }

    @Test
    public void testDateCompareDifferentDates() {
        // Arrange
        Timestamp lDate = Timestamp.valueOf("2023-09-18 10:15:30");
        Timestamp fDate = Timestamp.valueOf("2023-09-19 10:15:30");

        // Act
        boolean result = DateUtil.dateCompare(lDate, fDate);

        // Assert
        assertFalse(result); // lDate should not equal fDate
    }

    @Test
    public void testDateCompareNulls() {
        // Arrange
        Timestamp lDate = null;
        Timestamp fDate = Timestamp.valueOf("2023-09-18 10:15:30");

        // Act
        boolean result = DateUtil.dateCompare(lDate, fDate);

        // Assert
        assertFalse(result); // One is null, should return false
    }

    @Test
    public void testDateCompareBothNull() {
        // Arrange
        Timestamp lDate = null;
        Timestamp fDate = null;

        // Act
        boolean result = DateUtil.dateCompare(lDate, fDate);

        // Assert
        assertFalse(result); // Both are null, should return false
    }

    @Test
    public void testDifferenceCalendar() {
        // Arrange
        LocalDateTime debut = LocalDateTime.of(2023, 9, 18, 10, 0);
        LocalDateTime fin = LocalDateTime.of(2023, 9, 19, 10, 0);

        // Act
        long daysDifference = ChronoUnit.DAYS.between(debut, fin);

        // Assert
        assertEquals(1, daysDifference); // Difference should be 1 day
    }

    @Test
    public void testDifferenceTimestamp() {
        // Arrange
        Timestamp debut = Timestamp.valueOf("2023-09-18 10:00:00");
        Timestamp fin = Timestamp.valueOf("2023-09-19 10:00:00");

        // Act
        long result = DateUtil.differenceTimestamp(debut, fin);

        // Assert
        assertEquals(-24 * 60 * 60 * 1000, result); // Difference should be -1 day in milliseconds
    }
    @Test
    public void testCalcHMSJHFormat() {
        // Arrange
        int timeInSeconds = 86400000; // 1 day in milliseconds
        String format = "J.H";
        String langue = "En";

        // Act
        String result = DateUtil.calcHMS(timeInSeconds, format, langue);

        // Assert
        assertEquals("1.00", result); // 1 day should be represented as 1.00
    }

    @Test
    public void testCalcHMSRegularFormat() {
        // Arrange
        int timeInSeconds = 90061000; // 1 day, 1 hour, and 1 minute in milliseconds
        String format = "Regular";
        String langue = "En";

        // Act
        String result = DateUtil.calcHMS(timeInSeconds, format, langue);

        // Assert
        assertEquals("1 - 1", result); // 1 day and 1 hour
    }

    @Test
    public void testCalcHMSArabicFormat() {
        // Arrange
        int timeInSeconds = 90061000; // 1 day, 1 hour, and 1 minute in milliseconds
        String format = "Regular";
        String langue = "Ar";

        // Act
        String result = DateUtil.calcHMS(timeInSeconds, format, langue);

        // Assert
        assertEquals("1 - 1", result); // Should still give the same output but with Arabic formatting
    }
    @Test
    public void testStringToDateValid() {
        // Arrange
        String SDate = "2023/09/18"; // Valid date string
        DateFormat expectedFormatter = new SimpleDateFormat("yyyy/MM/dd");
        Date expectedDate = null;
        try {
            expectedDate = expectedFormatter.parse(SDate);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Act
        Date result = DateUtil.StringToDate(SDate);

        // Assert
        assertEquals(expectedDate, result); // The parsed date should match the expected date
    }

    @Test
    public void testStringToDateInvalidFormat() {
        // Arrange
        String SDate = "2023-09-18"; // Invalid format

        // Act
        Date result = DateUtil.StringToDate(SDate);

        // Assert
        assertNull(result); // Should return null for invalid format
    }

    @Test
    public void testStringToDateEmpty() {
        // Arrange
        String SDate = ""; // Empty string

        // Act
        Date result = DateUtil.StringToDate(SDate);

        // Assert
        assertNull(result); // Should return null for empty string
    }

    @Test
    public void testStringToDateShortLength() {
        // Arrange
        String SDate = "2023/09"; // Short length

        // Act
        Date result = DateUtil.StringToDate(SDate);

        // Assert
        assertNull(result); // Should return null for short length
    }

    @Test
    public void testGetDateJplus() {
        // Arrange
        int daysToAdd = 5;
        Calendar expectedCalendar = Calendar.getInstance();
        expectedCalendar.add(Calendar.DATE, daysToAdd);
        Date expectedDate = expectedCalendar.getTime();

        // Act
        Date result = DateUtil.getDateJplus(daysToAdd);

        // Assert
        assertEquals(expectedDate.toString(), result.toString()); // The result should match the expected date
    }

    @Test
    public void testGetDateJmoins() {
        // Arrange
        int daysToSubtract = 3;
        Calendar expectedCalendar = Calendar.getInstance();
        expectedCalendar.add(Calendar.DATE, -daysToSubtract);
        Date expectedDate = expectedCalendar.getTime();

        // Act
        Date result = DateUtil.getDateJmoins(daysToSubtract);

        // Assert
        assertEquals(expectedDate.toString(), result.toString()); // The result should match the expected date
    }
}
