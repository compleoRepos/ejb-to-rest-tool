package servicesTest;

import ma.eai.boa.xbanking.icommandeservice.ICommandeService;
import ma.eai.boa.xbanking.icommandeservice.ICommandeServicePortType;
import ma.eai.boa.xbanking.services.CommandChequier;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.Parser;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.util.WriteFlux;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockedConstruction;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * ✅ Test case for CommandChequier.process() with HISTORY_CMD
 * Using Mockito-inline only (no PowerMock, no subclassing)
 */
public class CommandChequierProcessHistoryCmdTest {

    @Mock
    private Envelope mockEnvelopeIn;
    @Mock
    private Envelope mockEnvelopeOut;
    @Mock
    private ICommandeServicePortType mockPort;

    private CommandChequier commandChequier;

    @Before
    public void setup() {
	MockitoAnnotations.initMocks(this);
	commandChequier = new CommandChequier();
    }

    @Test
    public void testProcess_HistoryCmd_Success() throws Exception {

	try (
		// mock static classes
		MockedStatic<EaiLog> mockedEaiLog = mockStatic(EaiLog.class);
		MockedStatic<Parser> mockedParser = mockStatic(Parser.class);
		MockedStatic<WriteFlux> mockedWriteFlux = mockStatic(WriteFlux.class);

		// intercept new ICommandeService()
		MockedConstruction<ICommandeService> mockedCmdService =
			mockConstruction(ICommandeService.class, (mockService, context) -> {
			    when(mockService.getICommandeServiceHttpPort()).thenReturn(mockPort);
			})
	) {
	    // simulate service SOAP call
	    when(mockPort.suiviCommande2(anyString()))
		    .thenReturn("10/10/2025;ACC001;CHEQUIER;5;OK&09/10/2025;ACC001;CHEQUIER;3;KO");

	    // stub flux write calls
	    mockedWriteFlux.when(() -> WriteFlux.ecrireString(any(), anyString(), anyString(), anyString(), anyString()))
		    .thenAnswer(inv -> null);

	    // define input envelope
	    when(mockEnvelopeIn.getNodeAsString("flux/action")).thenReturn("historyCmd");
	    when(mockEnvelopeIn.getNodeAsInt("flux/nbrAccounts")).thenReturn(2);
	    when(mockEnvelopeIn.getNodeAsString("flux/accounts/numAccount,1")).thenReturn("ACC001");
	    when(mockEnvelopeIn.getNodeAsString("flux/accounts/numAccount,2")).thenReturn("ACC002");

	    // neutralize static calls
	    mockedParser.when(() -> Parser.unmarshall(anyString())).thenReturn(null);
	    mockedEaiLog.when(() -> EaiLog.info(anyString())).thenAnswer(inv -> null);
	    mockedEaiLog.when(EaiLog::setNewThreadId).thenAnswer(inv -> null);
	    mockedEaiLog.when(() -> EaiLog.setServiceName(anyString())).thenAnswer(inv -> null);
	    mockedEaiLog.when(() -> EaiLog.initLogTraceInfos(any())).thenAnswer(inv -> null);

	    // run process
	    Envelope result = commandChequier.process(mockEnvelopeIn);

	    // assertions
	    verify(mockPort, atLeastOnce()).suiviCommande2(anyString());
	    mockedWriteFlux.verify(() ->
		    WriteFlux.ecrireString(any(), eq(Constants.FLUX), eq("code"), eq("000"), anyString())
	    );
	    mockedWriteFlux.verify(() ->
		    WriteFlux.ecrireString(any(), eq(Constants.FLUX), eq("message"), eq("OK"), anyString())
	    );

	    	}
    }

    @Test
    public void testProcess_HistoryCmd_WithException() throws Exception {

	try (
		MockedStatic<EaiLog> mockedEaiLog = mockStatic(EaiLog.class);
		MockedStatic<Parser> mockedParser = mockStatic(Parser.class);
		MockedStatic<WriteFlux> mockedWriteFlux = mockStatic(WriteFlux.class);
		MockedConstruction<ICommandeService> mockedCmdService =
			mockConstruction(ICommandeService.class, (mockService, context) -> {
			    when(mockService.getICommandeServiceHttpPort()).thenReturn(mockPort);
			})
	) {
	    // simulate exception in suiviCommande2
	    when(mockPort.suiviCommande2(anyString())).thenThrow(new RuntimeException("Simulated error"));
	    mockedWriteFlux.when(() -> WriteFlux.writeFluxMsg(anyString(), anyString()))
		    .thenReturn(mockEnvelopeOut);

	    when(mockEnvelopeIn.getNodeAsString("flux/action")).thenReturn("historyCmd");
	    when(mockEnvelopeIn.getNodeAsInt("flux/nbrAccounts")).thenReturn(1);
	    when(mockEnvelopeIn.getNodeAsString("flux/accounts/numAccount,1")).thenReturn("ACC001");

	    mockedEaiLog.when(() -> EaiLog.error(anyString())).thenAnswer(inv -> null);
	    mockedEaiLog.when(() -> EaiLog.initLogTraceInfos(any())).thenAnswer(inv -> null);
	    mockedEaiLog.when(() -> EaiLog.setServiceName(anyString())).thenAnswer(inv -> null);
	    mockedEaiLog.when(EaiLog::setNewThreadId).thenAnswer(inv -> null);
	    mockedParser.when(() -> Parser.unmarshall(anyString())).thenReturn(null);

	    // execute
	    Envelope result = commandChequier.process(mockEnvelopeIn);

	    // verify fallback path triggered
	    mockedWriteFlux.verify(() -> WriteFlux.writeFluxMsg(eq("003"), anyString()));
	    mockedEaiLog.verify(() -> EaiLog.error(contains("Simulated error")), atLeastOnce());

	}
    }
}
