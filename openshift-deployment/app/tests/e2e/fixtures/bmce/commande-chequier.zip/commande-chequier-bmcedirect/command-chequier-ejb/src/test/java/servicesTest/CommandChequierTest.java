package servicesTest;

import ma.eai.boa.xbanking.SendNotifcationCommand;
import ma.eai.boa.xbanking.dao.CommandChequierDao;
import ma.eai.boa.xbanking.icommandeservice.ICommandeService;
import ma.eai.boa.xbanking.icommandeservice.ICommandeServicePortType;
import ma.eai.boa.xbanking.models.CommandChequierEntity;
import ma.eai.boa.xbanking.services.CommandChequier;
import ma.eai.boa.xbanking.util.DateUtil;
import ma.eai.boa.xbanking.util.FileUtils;
import ma.eai.boa.xbanking.util.Mailer;
import ma.eai.boa.xbanking.util.WriteFlux;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.Parser;
import ma.eai.commons.services.parsing.ParsingException;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;

import javax.sql.DataSource;

import java.lang.reflect.Field;
import java.sql.Connection;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class CommandChequierTest {
    @Mock private DataSource mockDataSource;
    @Mock private Envelope mockEnvelopeIn;
    @Mock private Connection mockConnection;
    @Mock private Envelope mockEnvelopeOut;
    @Mock private ICommandeService mockICommandeService;
    //@Mock private ICommandeServicePortType mockICommandeServicePortType;
    private CommandChequier commandChequier;


    @Before
    public void setup(){
	MockitoAnnotations.initMocks(this);
	commandChequier = new CommandChequier();
    }

    @Test
    public void processEnrgCommande(){
	try(MockedStatic<EaiLog> mockedEailLog = mockStatic(EaiLog.class);
		MockedStatic<Parser> mockedParser = mockStatic(Parser.class);
		MockedStatic<WriteFlux> mockedWriteFlux = mockStatic(WriteFlux.class);
		MockedStatic<CommandChequierDao> mockedCommandChequierDao = mockStatic(CommandChequierDao.class);
		MockedConstruction<ICommandeService> mocked =
			mockConstruction(ICommandeService.class, (mock, context) -> {
			    // for each new ICommandeService()
			    ICommandeServicePortType portMock = mock(ICommandeServicePortType.class);
			    when(portMock.nbrCommandeCanal1(any(), any()))
				    .thenReturn("A:a-1;G:a-1;I:a-1;M:a-1;");
			    when(mock.getICommandeServiceHttpPort()).thenReturn(portMock);
			});
		MockedConstruction<CommandChequierEntity> mockedcmdChequierEntity =
			mockConstruction(CommandChequierEntity.class, (mock, context) -> {
			    // for each new CommandChequierEntity()
			    doNothing().when(mock).setCreationDate(any());
			    doNothing().when(mock).setTypeCommand(anyString());
			    doNothing().when(mock).setNbVignettes(anyString());
			    doNothing().when(mock).setNumAccount(anyString());
			    doNothing().when(mock).setOrigin(anyString());
			    doNothing().when(mock).setQuantite(anyString());
			    doNothing().when(mock).setCodeEtat(anyString());
			    doNothing().when(mock).setIdOrdonnateur(anyString());
			    doNothing().when(mock).setTiers(anyString());
			    doNothing().when(mock).setEmail(anyString());
			    doNothing().when(mock).setTelephone(anyString());
			});

	){
	    when(mockEnvelopeIn.getNodeAsString("flux/action"))
		    .thenReturn("enrgCommande");
	    mockedCommandChequierDao.when(() -> CommandChequierDao.save(any(),any())).thenAnswer(invocation -> null);
	    mockedParser.when(() -> Parser.unmarshall(mockEnvelopeIn.toString()))
		    .thenAnswer(invocation -> null);
	    mockedEailLog.when(() -> EaiLog.initLogTraceInfos(mockEnvelopeIn))
		    .thenAnswer(invocation -> null);
	    mockedEailLog.when(() -> EaiLog.setServiceName(anyString()))
		    .thenAnswer(invocation -> null);
	    mockedEailLog.when(EaiLog::setNewThreadId)
		    .thenAnswer(invocation -> null);
	    mockedEailLog.when(() -> EaiLog.info(anyString()))
		    .thenAnswer(invocation -> null);
	    when(mockEnvelopeIn.getNodeAsString("flux/confirmation"))
		    .thenReturn("true");
	    when(mockEnvelopeIn.getNodeAsString("flux/typeCommand")).thenReturn("CMD001");
	    when(mockEnvelopeIn.getNodeAsString("flux/nbVignettes")).thenReturn("5");
	    when(mockEnvelopeIn.getNodeAsString("flux/quantite")).thenReturn("10");
	    when(mockEnvelopeIn.getNodeAsString("flux/origin")).thenReturn("Mobile");
	    when(mockEnvelopeIn.getNodeAsString("flux/tiers")).thenReturn("T12345");
	    when(mockEnvelopeIn.getNodeAsString("flux/idClient")).thenReturn("C98765");
	    when(mockEnvelopeIn.getNodeAsString("flux/email")).thenReturn("client@test.com");
	    when(mockEnvelopeIn.getNodeAsString("flux/telephone")).thenReturn("0612345678");
	    when(mockEnvelopeIn.getNodeAsString("flux/libCompte")).thenReturn("Compte Épargne");
	    when(mockEnvelopeIn.getNodeAsString("flux/typeCommandStr")).thenReturn("Commande Vignettes");
	    when(mockEnvelopeIn.getNodeAsString("flux/lang")).thenReturn("FR");
	    when(mockDataSource.getConnection()).thenReturn(mockConnection);
	    Field dsField = CommandChequier.class.getDeclaredField("ebankdirectXA");
	    dsField.setAccessible(true);
	    dsField.set(commandChequier, mockDataSource);
	    mockedWriteFlux.when(() -> WriteFlux.writeFluxMsg(anyString(), anyString()))
		    .thenReturn(mockEnvelopeOut);
	    mockedWriteFlux.when(() -> WriteFlux.ecrireString(any(),
			    anyString(),anyString(),anyString(),anyString()))
		    .thenAnswer(invocation -> null);
	    mockEnvelopeOut = commandChequier.process(mockEnvelopeIn);
	    assertNotNull(mockEnvelopeOut);
	} catch (Exception e) {
	    throw new RuntimeException(e);
	}
    }

    @Test
    public void processEnrgCommandeNotRejected(){
	try(MockedStatic<EaiLog> mockedEailLog = mockStatic(EaiLog.class);
		MockedStatic<Parser> mockedParser = mockStatic(Parser.class);
		MockedStatic<WriteFlux> mockedWriteFlux = mockStatic(WriteFlux.class);
		MockedStatic<FileUtils> mockedFileUtils = mockStatic(FileUtils.class);
		MockedStatic<Mailer> mockedMailer = mockStatic(Mailer.class);
		MockedStatic<CommandChequierDao> mockedCommandChequierDao = mockStatic(CommandChequierDao.class);
		MockedConstruction<ICommandeService> mocked =
			mockConstruction(ICommandeService.class, (mock, context) -> {
			    // for each new ICommandeService()
			    ICommandeServicePortType portMock = mock(ICommandeServicePortType.class);
			    when(portMock.nbrCommandeCanal1(any(), any()))
				    .thenReturn("A:a-1;G:a-1;R:a-1;C:a-1;");
			    when(mock.getICommandeServiceHttpPort()).thenReturn(portMock);
			    when(portMock.enrgCommande(any(),anyString(),anyString()
				    ,anyString(),anyString(),anyBoolean())).thenReturn("M01");
			});
		MockedConstruction<CommandChequierEntity> mockedcmdChequierEntity =
			mockConstruction(CommandChequierEntity.class, (mock, context) -> {
			    // for each new CommandChequierEntity()
			    doNothing().when(mock).setCreationDate(any());
			    doNothing().when(mock).setTypeCommand(anyString());
			    doNothing().when(mock).setNbVignettes(anyString());
			    doNothing().when(mock).setNumAccount(anyString());
			    doNothing().when(mock).setOrigin(anyString());
			    doNothing().when(mock).setQuantite(anyString());
			    doNothing().when(mock).setCodeEtat(anyString());
			    doNothing().when(mock).setIdOrdonnateur(anyString());
			    doNothing().when(mock).setTiers(anyString());
			    doNothing().when(mock).setEmail(anyString());
			    doNothing().when(mock).setTelephone(anyString());
			});
		MockedConstruction<SendNotifcationCommand> mockedSendNotifcationCommand =
			mockConstruction(SendNotifcationCommand.class, (mock, context) -> {
			    doNothing().when(mock).execute();
			});

	){
	    when(mockEnvelopeIn.getNodeAsString("flux/action"))
		    .thenReturn("enrgCommande");
	    mockedCommandChequierDao.when(() -> CommandChequierDao.save(any(),any())).thenAnswer(invocation -> null);
	    mockedParser.when(() -> Parser.unmarshall(mockEnvelopeIn.toString()))
		    .thenAnswer(invocation -> null);
	    mockedEailLog.when(() -> EaiLog.initLogTraceInfos(mockEnvelopeIn))
		    .thenAnswer(invocation -> null);
	    mockedEailLog.when(() -> EaiLog.setServiceName(anyString()))
		    .thenAnswer(invocation -> null);
	    mockedEailLog.when(EaiLog::setNewThreadId)
		    .thenAnswer(invocation -> null);
	    mockedEailLog.when(() -> EaiLog.info(anyString()))
		    .thenAnswer(invocation -> null);
	    when(mockEnvelopeIn.getNodeAsString("flux/confirmation"))
		    .thenReturn("true");
	    when(mockEnvelopeIn.getNodeAsString("flux/numAccount")).thenReturn("6516526157612");
	    when(mockEnvelopeIn.getNodeAsString("flux/typeCommand")).thenReturn("CMD001");
	    when(mockEnvelopeIn.getNodeAsString("flux/nbVignettes")).thenReturn("5");
	    when(mockEnvelopeIn.getNodeAsString("flux/quantite")).thenReturn("10");
	    when(mockEnvelopeIn.getNodeAsString("flux/origin")).thenReturn("Mobile");
	    when(mockEnvelopeIn.getNodeAsString("flux/tiers")).thenReturn("T12345");
	    when(mockEnvelopeIn.getNodeAsString("flux/idClient")).thenReturn("C98765");
	    when(mockEnvelopeIn.getNodeAsString("flux/email")).thenReturn("client@test.com");
	    when(mockEnvelopeIn.getNodeAsString("flux/telephone")).thenReturn("0612345678");
	    when(mockEnvelopeIn.getNodeAsString("flux/libCompte")).thenReturn("Compte Épargne");
	    when(mockEnvelopeIn.getNodeAsString("flux/typeCommandStr")).thenReturn("Commande Vignettes");
	    when(mockEnvelopeIn.getNodeAsString("flux/lang")).thenReturn("FR");
	    when(mockDataSource.getConnection()).thenReturn(mockConnection);
	    Field dsField = CommandChequier.class.getDeclaredField("ebankdirectXA");
	    dsField.setAccessible(true);
	    dsField.set(commandChequier, mockDataSource);
	    mockedWriteFlux.when(() -> WriteFlux.writeFluxMsg(anyString(), anyString()))
		    .thenReturn(mockEnvelopeOut);
	    mockedWriteFlux.when(() -> WriteFlux.ecrireString(any(),
			    anyString(),anyString(),anyString(),anyString()))
		    .thenAnswer(invocation -> null);
	    mockedFileUtils.when(() -> FileUtils.fileReader(anyString()))
		    .thenReturn("Date_  heure_  TypeChequier_  nbrCheques_  NumCompte_  LibCompte_");
	    mockedMailer.when(() -> Mailer.send(anyString(), anyString(), anyString()))
		    .thenReturn(true);
	    mockEnvelopeOut = commandChequier.process(mockEnvelopeIn);
	    assertNotNull(mockEnvelopeOut);
	} catch (Exception e) {
	    throw new RuntimeException(e);
	}
    }
}
