package ma.eai.boa.xbanking.util;



import ma.eai.ingdev.fwk.logging.EaiLog;

import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.text.ParsePosition;

import java.util.Date;
import java.sql.Timestamp;
import java.text.ParseException;



public class DateUtil {
	
	public final static String DEFAULT_FORMAT = "dd/MM/yyyy"; 
	protected static final char[] DATE_CHARS = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '/' };
		
	public static String getFormattedDate(Calendar cDate) {

		String lDate = null;
		if (cDate != null) {
			try {
				String year  = String.valueOf(cDate.get(Calendar.YEAR));
				String month = String.valueOf(cDate.get(Calendar.MONTH) + 1);
				String day   = String.valueOf(cDate.get(Calendar.DAY_OF_MONTH));
				
				if (month.length() == 1) {
					month = "0" + month;
				}
				if (day.length() == 1) {
					day = "0" + day;
				}
				
				lDate = year  + month  + day;
				
			} catch (Exception e) {
				//e.printStackTrace();
			    EaiLog.info(e);
			}			
		}
		return lDate;

	}
	
	public static java.util.Date getDate(String format,String fDate){
        SimpleDateFormat formatter = new SimpleDateFormat (format);
        formatter.setTimeZone(TimeZone.getTimeZone("GMT"));
        ParsePosition pos = new ParsePosition(0);
        Date lDate = formatter.parse(fDate, pos);
        return lDate;
    }

    public static java.sql.Date getSqlDate(String format, String fDate) {
        return new java.sql.Date(getDate(format, fDate).getTime());
    }

    public static java.sql.Timestamp getTimestamp(String format, String fDate) {
        return new Timestamp(getDate(format, fDate).getTime());
    }

    public static java.util.Calendar getCalendar(String format, String fDate){
        Calendar calendar = Calendar.getInstance(TimeZone.getDefault(),Locale.getDefault());
        SimpleDateFormat formatter = new SimpleDateFormat (format);
        ParsePosition pos = new ParsePosition(0);
        Date lDate = formatter.parse(fDate, pos);
        Date dateHeure = new Date(lDate.getTime());
        calendar.setTime(dateHeure);
        return calendar;
    }


    public static String dateToString(String format, java.util.Date fDate){
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        String lDate  = formatter.format(fDate);
        return lDate;
    }

    public static String sqlDateToString(String format, java.sql.Date fDate){
    SimpleDateFormat formatter = new SimpleDateFormat(format);
    String lDate  = formatter.format(fDate);
    return lDate;
   }

   public static String calendarToString(String format, Calendar fDate){
     SimpleDateFormat formatter = new SimpleDateFormat(format);
     String lDate  = formatter.format(fDate.getTime());
     return lDate;
   }

   public static String timeStampToString(String format, java.sql.Timestamp fDate){
       String lDate =null;
     if (fDate!=null){
   SimpleDateFormat formatter = new SimpleDateFormat(format);
 lDate  = formatter.format(fDate);}
   return lDate;


  }
  /*public static boolean dateCompare(java.sql.Timestamp lDate, java.sql.Timestamp fDate){

    if (fDate!=null && lDate!=null){
  return(lDate.equals(fDate));
    }else if (fDate==null || lDate==null){
      return false;
    }
    else{
      return(lDate==fDate);
    }
  }*/

    public static boolean dateCompare(java.sql.Timestamp lDate, java.sql.Timestamp fDate) {
        if (lDate == null || fDate == null) {
            return false; // Return false if either date is null
        }
        return lDate.equals(fDate); // Use equals for value comparison
    }


    /**
     * renvoie la date courante
     *
     * @since 1.0
     */

        public static java.util.Calendar dateCalendarCourante()
        {
         Calendar cal=Calendar.getInstance(TimeZone.getDefault(),Locale.getDefault());
         cal.set(Calendar.SECOND,0);

         return cal;
        }
        /**
         * Calculer la difference entre deux calendars
         * et renvoyer le resultat format selon le
         * format precis en parametre
         *
         */
        public static String differenceCalendar(Calendar debut, Calendar fin, String format){
                Date date1 = debut.getTime();
                Date date2 = fin.getTime();
                long difference = Math.abs(date2.getTime() - date1.getTime());
              SimpleDateFormat sdf = new SimpleDateFormat(format);
            String lDate  = sdf.format(new java.sql.Date(difference));
            return lDate;

        }

        /**
         * Calculer la difference entre deux calendars
         * et renvoie  le resultat en milliseconds
         *
         */
        public static long differenceCalendar(Calendar debut, Calendar fin) {
          Date date1 = debut.getTime();
          Date date2 = fin.getTime();
          return Math.abs(date2.getTime() - date1.getTime());
        }

        /**
         * Calculer la difference entre deux timestamp
         * et renvoie  le resultat en milliseconds
         *
         */
        public static long differenceTimestamp(Timestamp debut, Timestamp fin) {
          return (debut.getTime() - fin.getTime());
        }

         /**
          * renvoie la date courante
          *
          * @return java.sql.date
          * @since 1.0
          */

             public static java.sql.Date dateCourante()
             {
              return (new java.sql.Date(System.currentTimeMillis()));
             }
         /**
         * renvoie la date courante
         *
         * @return java.util.date
         * @since 1.0
         */

        public static java.util.Date dateUtilCourante() {
          return (new java.util.Date(System.currentTimeMillis()));
        }

        /**
         * renvoie la date courante
         *
         * @return java.sql.Timestamp
         * @since 1.0
         */

        public static java.sql.Timestamp timestampCourante() {
          return (new java.sql.Timestamp(System.currentTimeMillis()));
        }

        /**
         * calcule du nombre du jours a partire du milliseconde
         * @return String
         * @since 1.0
         */

        public static String calcHMS(int timeInSeconds, String format, String langue) {
            int jours,hours;
            double dJours;
            String res;
            if ("J.H".equals(format)){
                             	
            	dJours=(double)timeInSeconds /(double)86400000;
            	DecimalFormat df = new DecimalFormat("########.00");
            	DecimalFormatSymbols dfs = new DecimalFormatSymbols();
            	dfs.setDecimalSeparator('.');
            	df.setDecimalFormatSymbols(dfs);
            	res = df.format(dJours);
            	if (".00".equals(res)) {res="0";}
            }
            else{
            	jours = timeInSeconds /86400000;
                timeInSeconds = timeInSeconds - (jours * 86400000);
                hours = timeInSeconds / 3600000;            	
            	if (langue.equals("Ar")) {
            		res = hours + " - " + jours;            		
            	} else {
            		res = jours + " - " + hours;
            	}                
            }
            
            return res;
         }
        
        public static boolean isDate(String data) {
    		if (data==null) {
    			return true;
    		}

    		return StringToDate(data) != null;
    	}
    	
//    	public static String DateToString(Date d, String frt) throws ParseException {
//
//    		DateFormat formatter;
//    		formatter = new SimpleDateFormat(frt);
//    		String s = formatter.format(d);
//
//    		return s;
//    	}
    	
    	public static Date StringToDate(String SDate) {
           
            if ((SDate.length() != 0) && (SDate.length()< 10)){
                return null;
            }
            Date date = null;
            DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
            formatter.setLenient(false);
            try {
                date = formatter.parse(SDate);
            } catch (Exception e) {
                //EaiLog.info(e);
                return null;
            }
            return date;
        }
    	public static Date getDateJplus(int j){
    		Date datej;
    		Calendar calendar = new java.util.GregorianCalendar();
    		calendar.add(Calendar.DATE, +j);
    		datej=calendar.getTime();
    		return datej;	
    	}
    	public static Date getDateJmoins(int j){
    		Date datej;
    		Calendar calendar = new java.util.GregorianCalendar();
    		calendar.add(Calendar.DATE, -j);
    		datej=calendar.getTime();
    		return datej;	
    	}
}
