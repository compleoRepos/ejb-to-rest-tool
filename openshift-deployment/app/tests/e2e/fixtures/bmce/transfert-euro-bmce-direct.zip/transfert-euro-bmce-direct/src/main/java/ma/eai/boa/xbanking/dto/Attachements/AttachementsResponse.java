package ma.eai.boa.xbanking.dto.Attachements;

import ma.eai.boa.xbanking.vo.Retour;

public class AttachementsResponse extends Retour {

    private String documentType;

    private String iban;

    private String reference;

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getIban() {
        return iban;
    }

    public void setIban(String iban) {
        this.iban = iban;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }
}
