package ma.eai.boa.xbanking.util;

import java.security.SecureRandom;

public class PasswordUtil {

    private static final String UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String LOWER = "abcdefghijklmnopqrstuvwxyz";
    private static final String DIGIT = "0123456789";
    private static final String SPECIAL = "!@#$%^&*";
    private static final String ALL = UPPER + LOWER + DIGIT + SPECIAL;

    private static final SecureRandom random = new SecureRandom();

    public static String generatePassword(int length) {

	StringBuilder password = new StringBuilder();

	// garantir chaque type
	password.append(UPPER.charAt(random.nextInt(UPPER.length())));
	password.append(LOWER.charAt(random.nextInt(LOWER.length())));
	password.append(DIGIT.charAt(random.nextInt(DIGIT.length())));
	password.append(SPECIAL.charAt(random.nextInt(SPECIAL.length())));

	for (int i = 4; i < length; i++) {
	    password.append(ALL.charAt(random.nextInt(ALL.length())));
	}

	return password.toString();
    }
}