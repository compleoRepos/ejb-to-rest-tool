package ma.eai.boa.xbanking.service.parameters;

import com.fasterxml.jackson.databind.ObjectMapper;
import ma.eai.boa.xbanking.entities.GeneralParameters;
import ma.eai.boa.xbanking.entities.Parameters;
import ma.eai.boa.xbanking.repository.GeneralParametersRepository;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.util.ParamType;
import ma.eai.boa.xbanking.vo.PersonalInformation.PersonalInfoIn;
import ma.eai.boa.xbanking.vo.PersonalInformation.PersonalInfoOut;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class GeneralParameterImpl implements GeneralParameter{
    @Value("${api.url}")
    public String urlApi;
    @Autowired
    RestTemplate restTemplate;
    @Autowired
    ObjectMapper objectMapper;
	@Autowired
	private GeneralParametersRepository generalParametersRepository;
    @Override
    public PersonalInfoOut fetchGeneralParameters(PersonalInfoIn personalInfoIn){
	EaiLog.info("contradBad: {}"+personalInfoIn.getCtrBad());
	PersonalInfoOut personalInfoOut=new PersonalInfoOut();
	try {
	    EaiLog.info("BEGIN FETCHGENRALPARAMS:");
	    String url = new StringBuilder(urlApi)
		    .append("parameters/general")
		    .toString();
	    String jsonResponse = restTemplate.getForObject(url, String.class);
	    Parameters parameters=objectMapper.readValue(jsonResponse, Parameters.class);
		addLabelEn(parameters);
		personalInfoOut.setParameters(parameters);
	    personalInfoOut.setCode(Constants.CODE_SUCCESS);
	    personalInfoOut.setMessage("OK");
	} catch (Exception e) {
	    EaiLog.error("Erreur lors de la récupération des paramètres généraux: {}:"+e);
	    personalInfoOut.setCode(Constants.CODE_ERROR);
	    personalInfoOut.setMessage("ERR_TECHNICAL");
	}
	EaiLog.info("FIN FETCHGENRAL_PARAMS:");
	return personalInfoOut;
    }

	private void addLabelEn(Parameters parameters) {
		// Activity Areas
			if (parameters.getActivityAreas() != null) {
				parameters.getActivityAreas().forEach(item -> {
					// Null check for item.getUuid() might also be necessary depending on data origin
					GeneralParameters generalParameters = generalParametersRepository.
							findGeneralParametersByUuidAndParamTypeAndCode(item.getUuid(), ParamType.ACTIVITY_AREAS.name(),item.getCode())
							.orElse(new GeneralParameters());
					item.setLabelEN(generalParameters.getLabelEn());
				});
			}
			// Banks
			if (parameters.getBanks() != null) {
				parameters.getBanks().forEach(item -> {
					GeneralParameters generalParameters = generalParametersRepository.
							findGeneralParametersByUuidAndParamTypeAndCode(item.getUuid(), ParamType.BANKS.name(),item.getCode())
							.orElse(new GeneralParameters());
					item.setLabelEN(generalParameters.getLabelEn());
				});
			}
			// Countries
			if (parameters.getCountries() != null) {
				parameters.getCountries().forEach(item ->{
					GeneralParameters generalParameters = generalParametersRepository.
							findGeneralParametersByUuidAndParamTypeAndCode(item.getUuid(), ParamType.COUNTRIES.name(),item.getCode())
							.orElse(new GeneralParameters());
					item.setLabelEN(generalParameters.getLabelEn());
				});
			}
			// Professions
			if (parameters.getProfessions() != null) {
				parameters.getProfessions().forEach(item ->{
					GeneralParameters generalParameters = generalParametersRepository.
							findGeneralParametersByUuidAndParamTypeAndCode(item.getUuid(), ParamType.PROFESSIONS.name(),item.getCode())
							.orElse(new GeneralParameters());
					item.setLabelEN(generalParameters.getLabelEn());
				});
			}
			// Nationalities
			if (parameters.getNationalities() != null) {
				parameters.getNationalities().forEach(item ->{
					GeneralParameters generalParameters = generalParametersRepository.
							findGeneralParametersByUuidAndParamTypeAndCode(item.getUuid(), ParamType.NATIONALITIES.name(),item.getCode())
							.orElse(new GeneralParameters());
					item.setLabelEN(generalParameters.getLabelEn());
				});
			}
			// Periodicities
			if (parameters.getPeriodicities() != null) {
				parameters.getPeriodicities().forEach(item ->{
					GeneralParameters generalParameters = generalParametersRepository.
							findGeneralParametersByUuidAndParamTypeAndCode(item.getUuid(), ParamType.PERIODICITIES.name(),item.getCode())
							.orElse(new GeneralParameters());
					item.setLabelEN(generalParameters.getLabelEn());
				});
			}
			// Funds Sources
			if (parameters.getFundsSources() != null) {
				parameters.getFundsSources().forEach(item ->{
					GeneralParameters generalParameters = generalParametersRepository.
							findGeneralParametersByUuidAndParamTypeAndCode(item.getUuid(), ParamType.FUNDS_SOURCES.name(),item.getCode())
							.orElse(new GeneralParameters());
					item.setLabelEN(generalParameters.getLabelEn());
				});
			}
			// Relations Ship
			if (parameters.getRelationsShip() != null) {
				parameters.getRelationsShip().forEach(item ->{
					GeneralParameters generalParameters = generalParametersRepository.
							findGeneralParametersByUuidAndParamTypeAndCode(item.getUuid(), ParamType.RELATIONSSHIP.name(),item.getCode())
							.orElse(new GeneralParameters());
					item.setLabelEN(generalParameters.getLabelEn());
				});
			}
			// Doc Types
			if (parameters.getDocTypes() != null) {
				parameters.getDocTypes().forEach(item ->{
					GeneralParameters generalParameters = generalParametersRepository.
							findGeneralParametersByUuidAndParamTypeAndCode(item.getUuid(), ParamType.DOC_TYPES.name(),item.getCode())
							.orElse(new GeneralParameters());
					item.setLabelEN(generalParameters.getLabelEn());
				});
			}
			// Transfert Motifs
			if (parameters.getTransfertMotifs() != null) {
				EaiLog.info("Transfert Motifs: {}");
				parameters.getTransfertMotifs().forEach(item ->{
					GeneralParameters generalParameters = generalParametersRepository.
							findGeneralParametersByUuidAndParamTypeAndCode(item.getUuid(), ParamType.TRANSFERT_MOTIFS.name(),item.getCode())
							.orElse(new GeneralParameters());
					item.setLabelEN(generalParameters.getLabelEn());
				});
			}
			// Frequencies
			if (parameters.getFrequencies() != null) {
				parameters.getFrequencies().forEach(item ->{
					GeneralParameters generalParameters = generalParametersRepository.
							findGeneralParametersByUuidAndParamTypeAndCode(item.getUuid(), ParamType.FREQUENCIES.name(),item.getCode())
							.orElse(new GeneralParameters());
					item.setLabelEN(generalParameters.getLabelEn());
				});
			}
			// Tranches
			if (parameters.getTranches() != null) {
				parameters.getTranches().forEach(item ->{
					GeneralParameters generalParameters = generalParametersRepository.
							findGeneralParametersByUuidAndParamTypeAndCode(item.getUuid(), ParamType.TRANCHES.name(),item.getCode())
							.orElse(new GeneralParameters());
					item.setLabelEN(generalParameters.getLabelEn());
				});
			}
	}
}
