package ma.eai.boa.xbanking.service.PhoneNumber;

import com.fasterxml.jackson.databind.ObjectMapper;

import ma.eai.boa.xbanking.dto.createaccountphonenumber.PhoneNumberRequest;
import ma.eai.boa.xbanking.dto.createaccountphonenumber.PhoneNumberResponse;
import ma.eai.boa.xbanking.entities.User;
import ma.eai.boa.xbanking.repository.UserRepository;

import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.util.PasswordUtil;
import ma.eai.boa.xbanking.vo.PhoneNumber.PhoneNumberIn;
import ma.eai.boa.xbanking.vo.PhoneNumber.PhoneNumberOut;

import ma.eai.ingdev.fwk.logging.EaiLog;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.http.ResponseEntity;
import org.springframework.http.MediaType;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.UUID;

@Service
public class PhoneNumberImpl implements PhoneNumber{

    @Value("${api.url}")
    public String urlApi;

    private final RestTemplate restTemplate;

    private final UserRepository userRepository;


    @Autowired
	public PhoneNumberImpl(RestTemplate restTemplate, UserRepository userRepository) {
		this.restTemplate = restTemplate;
		this.userRepository = userRepository;
	}

    public PhoneNumberOut validePhoneNumber(PhoneNumberIn phoneNumberIn) {
	PhoneNumberOut phoneNumberOut=new PhoneNumberOut();
	try{
	    if(userRepository.findByContratBadAndStepIsNotNull(phoneNumberIn.getContratBad()) != null) {
		EaiLog.info("User already exist: {}", phoneNumberIn.getContratBad());
		phoneNumberOut.setCode(Constants.CODE_ERROR);
		phoneNumberOut.setMessage("USER_EXIST");
		return phoneNumberOut;
	    }
	    PhoneNumberRequest phoneNumberRequest = new PhoneNumberRequest();
	    phoneNumberRequest.setPhoneNumber(phoneNumberIn.getPhoneNumber());
	    phoneNumberRequest.setDeviceId(phoneNumberIn.getDeviceId());
	    phoneNumberRequest.setEmail(phoneNumberIn.getEmail());
	    phoneNumberRequest.setCallingCode(phoneNumberIn.getCallingCode());
	    String password = PasswordUtil.generatePassword(10);
	    phoneNumberRequest.setMotdepasse(password);
	    phoneNumberRequest.setCountryCode(phoneNumberIn.getCountryCode());

	    String url = new StringBuilder(urlApi)
		    .append("prospect/validatPhone")
		    .toString();
	    EaiLog.info("called url : {}",url);
	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.set(Constants.CANAL_HEADER, Constants.CANAL);
	    ObjectMapper objectMapper = new ObjectMapper();
	    String jsonRequest = objectMapper.writeValueAsString(phoneNumberRequest);

	    HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, headers);
	    EaiLog.info("--------- requestEntity------- : {}", requestEntity);
	    ResponseEntity<PhoneNumberResponse> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
		    PhoneNumberResponse.class);
	    PhoneNumberResponse body =response.getBody();
	    EaiLog.info("returned response : {} ",response);

	    if(body != null && "SUCCESS_CODE".equals(body.getCode())) {
		EaiLog.info("Response OK : {}", body.toString());
		phoneNumberOut.setUuid(String.valueOf(body.getUuid()));
		phoneNumberOut.setNexusUuid(String.valueOf(body.getNexusUuid()));
		phoneNumberOut.setCode(Constants.CODE_SUCCESS);
		phoneNumberOut.setMessage("OK");

		User user = new User();
		user.setContratBad(phoneNumberIn.getContratBad());
		user.setUuid(phoneNumberOut.getUuid());
		user.setEmail(phoneNumberIn.getEmail());
		user.setPhone(phoneNumberIn.getPhoneNumber());
		user.setCountryCode(phoneNumberIn.getCountryCode());
		userRepository.save(user);
	    }else {
		phoneNumberOut.setCode(Constants.CODE_ERROR);
		phoneNumberOut.setMessage(body != null ? body.getCode() : Constants.RESPONSE_EMPTY);
	    }
	} catch (Exception e) {
	    EaiLog.info("Technical Error: {} " , e);
	    phoneNumberOut.setCode(Constants.CODE_ERROR);
	    phoneNumberOut.setMessage(Constants.TECHNICAL_ERROR);
	}
	EaiLog.info("Fin service validePhoneNumber");
	return phoneNumberOut;
    }
}
