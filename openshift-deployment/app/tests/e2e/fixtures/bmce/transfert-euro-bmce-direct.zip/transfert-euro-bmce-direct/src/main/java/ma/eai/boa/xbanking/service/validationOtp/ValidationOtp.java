package ma.eai.boa.xbanking.service.validationOtp;

import ma.eai.boa.xbanking.vo.validationOtp.ValidationOtpIn;
import ma.eai.boa.xbanking.vo.validationOtp.ValidationOtpOut;

public interface ValidationOtp {
    ValidationOtpOut validateOtp(ValidationOtpIn validationOtpIn);
}
