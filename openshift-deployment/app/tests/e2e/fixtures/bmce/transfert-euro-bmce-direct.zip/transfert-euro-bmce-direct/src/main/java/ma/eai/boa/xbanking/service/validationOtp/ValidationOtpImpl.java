package ma.eai.boa.xbanking.service.validationOtp;

import ma.eai.boa.xbanking.dto.authentication.TokenRequest;
import ma.eai.boa.xbanking.dto.validateOtp.ValidateOtpRequest;
import ma.eai.boa.xbanking.dto.validateOtp.ValidateOtpResponse;
import ma.eai.boa.xbanking.entities.User;
import ma.eai.boa.xbanking.repository.UserRepository;
import ma.eai.boa.xbanking.service.authentification.AuthentificationImpl;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.util.UserStep;
import ma.eai.boa.xbanking.vo.User.UserIn;
import ma.eai.boa.xbanking.vo.validationOtp.ValidationOtpIn;
import ma.eai.boa.xbanking.vo.validationOtp.ValidationOtpOut;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import javax.persistence.EntityNotFoundException;

@Service
public class ValidationOtpImpl implements ValidationOtp{
    @Value("${api.url}")
    public String urlApi;

    private final RestTemplate restTemplate;

	private final UserRepository userRepository;

	private final AuthentificationImpl authenticationService;

	public ValidationOtpImpl(RestTemplate restTemplate, UserRepository userRepository, AuthentificationImpl authenticationService) {
		this.restTemplate = restTemplate;
		this.userRepository = userRepository;
		this.authenticationService = authenticationService;
	}
    public ValidationOtpOut validateOtp(ValidationOtpIn validationOtpIn) {
	EaiLog.info("Début du service validateOTP");
	ValidationOtpOut validationOtpOut = new ValidationOtpOut();

	try {

	    if (validationOtpIn == null || validationOtpIn.getOtpValue() == null ||
		    validationOtpIn.getUuid() == null || validationOtpIn.getOtpId() == null) {
		EaiLog.error("Paramètres d'entrée invalides");
		return buildErrorResponse(validationOtpOut, Constants.CODE_ERROR, "ERR_INVALID_INPUT");
	    }


	    ValidateOtpRequest otpRequest = new ValidateOtpRequest();
	    otpRequest.setOtp(validationOtpIn.getOtpValue());
	    otpRequest.setDeviceId(validationOtpIn.getDeviceId());
	    otpRequest.setUuidNexus(validationOtpIn.getOtpId());
	    otpRequest.setUuid(validationOtpIn.getUuid());


	    String url = urlApi + "prospect/validateOTP";
	    EaiLog.info("Appel API : {}", url);


	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.set(Constants.CANAL_HEADER, Constants.CANAL);

	    HttpEntity<ValidateOtpRequest> requestEntity = new HttpEntity<>(otpRequest, headers);


	    ResponseEntity<ValidateOtpResponse> response = restTemplate.exchange(
		    url,
		    HttpMethod.POST,
		    requestEntity,
		    ValidateOtpResponse.class
	    );


	    if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
		ValidateOtpResponse otpResponse = response.getBody();
		EaiLog.info("Réponse API reçue : {}", otpResponse);

		if ("SUCCESS_CODE".equals(otpResponse.getCode())) {

		    User user = userRepository.findById(validationOtpIn.getUuid())
			    .orElseThrow(() -> new EntityNotFoundException("Utilisateur non trouvé pour UUID : " + validationOtpIn.getUuid()));

		    EaiLog.info("Utilisateur trouvé, email : {}", user.getEmail());


		    UserIn userIn = new UserIn();
		    userIn.setEmail(user.getEmail());
		    userIn.setUuid(user.getUuid());
		    String token = authenticationService.generateToken(userIn);
		    generateAndSendToken(token, user, validationOtpOut);
		    user.setStep(UserStep.ETAPE1);
		    userRepository.save(user);

		    return buildSuccessResponse(validationOtpOut);
		} else {
		    return buildErrorResponse(validationOtpOut, Constants.CODE_ERROR,
			    otpResponse.getCode() != null ? otpResponse.getCode() : "EMPTY_RESPONSE_BES");
		}
	    } else {
		EaiLog.error("Réponse API invalide ou erreur HTTP");
		return buildErrorResponse(validationOtpOut, Constants.CODE_ERROR, "ERR_API_RESPONSE");
	    }

	} catch (HttpClientErrorException | HttpServerErrorException e) {
	    EaiLog.error("Erreur HTTP lors de l'appel API : {}", e.getMessage());
	    return buildErrorResponse(validationOtpOut, Constants.CODE_ERROR, "ERR_API_CALL");
	} catch (EntityNotFoundException e) {
	    EaiLog.error("Utilisateur non trouvé : {}", e.getMessage());
	    return buildErrorResponse(validationOtpOut, Constants.CODE_ERROR, "ERR_USER_NOT_FOUND");
	} catch (Exception e) {
	    EaiLog.error("Erreur inattendue lors de la validation OTP : {}", e);
	    return buildErrorResponse(validationOtpOut, Constants.CODE_ERROR, "ERR_TECHNICAL");
	} finally {
	    EaiLog.info("Fin service validateOTP");
	}
    }

    private ValidationOtpOut buildSuccessResponse(ValidationOtpOut out) {
	out.setCode(Constants.CODE_SUCCESS);
	out.setMessage("OK");
	return out;
    }

    private ValidationOtpOut buildErrorResponse(ValidationOtpOut out, String code, String message) {
	out.setCode(code);
	out.setMessage(message);
	return out;
    }

	private void generateAndSendToken(String token, User user, ValidationOtpOut validationOtpOut) {
		if(token != null) {
			TokenRequest tokenRequest = new TokenRequest();
			tokenRequest.setToken(token);
			tokenRequest.setLogin(user.getEmail());
			if(authenticationService.sendToken(tokenRequest)){
				validationOtpOut.setToken(token);
				validationOtpOut.setCode(Constants.CODE_SUCCESS);
				validationOtpOut.setMessage("OK");
			} else {
				validationOtpOut.setCode(Constants.CODE_ERROR);
				validationOtpOut.setMessage("Error BES in receiving token");
			}
		} else {
			EaiLog.info("Token was generated null");
			validationOtpOut.setCode(Constants.CODE_ERROR);
			validationOtpOut.setMessage("Token generated is null");
		}
	}
}
