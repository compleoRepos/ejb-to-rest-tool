package ma.eai.boa.xbanking.dto.createaccountphonenumber;

import com.fasterxml.jackson.annotation.JsonProperty;
import ma.eai.boa.xbanking.entities.Retour;

public class PhoneNumberResponse extends Retour {
    private static final long serialVersionUID = 4571487287266103310L;

    private String uuid;

    @JsonProperty("otpID")
    private String nexusUuid;

    private boolean completed;

    private boolean client;

    private String lang;

    private String phone;

    private long nombreNotifs;

    private String uuidKey;

    public String getUuid() {
	return uuid;
    }

    public void setUuid(String uuid) {
	this.uuid = uuid;
    }

    public String getNexusUuid() {
	return nexusUuid;
    }

    public void setNexusUuid(String nexusUuid) {
	this.nexusUuid = nexusUuid;
    }

    public boolean isCompleted() {
	return completed;
    }

    public void setCompleted(boolean completed) {
	this.completed = completed;
    }

    public boolean isClient() {
	return client;
    }

    public void setClient(boolean client) {
	this.client = client;
    }

    public String getLang() {
	return lang;
    }

    public void setLang(String lang) {
	this.lang = lang;
    }

    public String getPhone() {
	return phone;
    }

    public void setPhone(String phone) {
	this.phone = phone;
    }

    public long getNombreNotifs() {
	return nombreNotifs;
    }

    public void setNombreNotifs(long nombreNotifs) {
	this.nombreNotifs = nombreNotifs;
    }

    public String getUuidKey() {
	return uuidKey;
    }

    public void setUuidKey(String uuidKey) {
	this.uuidKey = uuidKey;
    }

    @Override
    public String toString() {
        return "PhoneNumberResponse{" +
                "uuid='" + uuid + '\'' +
                ", nexusUuid='" + nexusUuid + '\'' +
                ", completed=" + completed +
                ", client=" + client +
                ", lang='" + lang + '\'' +
                ", phone='" + phone + '\'' +
                ", nombreNotifs=" + nombreNotifs +
                ", uuidKey='" + uuidKey + '\'' +
                '}';
    }
}
