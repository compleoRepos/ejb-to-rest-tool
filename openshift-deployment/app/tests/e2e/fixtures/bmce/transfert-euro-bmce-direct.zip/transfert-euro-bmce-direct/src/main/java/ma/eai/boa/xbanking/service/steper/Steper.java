package ma.eai.boa.xbanking.service.steper;

import ma.eai.boa.xbanking.vo.FirstStep.FirstStepIn;
import ma.eai.boa.xbanking.vo.FirstStep.FirstStepOut;
import ma.eai.boa.xbanking.vo.Retour;
import ma.eai.boa.xbanking.vo.Step.StepIn;
import ma.eai.boa.xbanking.vo.Step.StepOut;
import ma.eai.boa.xbanking.vo.ThirdStep.ThirdStepIn;
import ma.eai.boa.xbanking.vo.ThirdStep.ThirdStepOut;

public interface Steper {

    FirstStepOut valideFirstStep(FirstStepIn firstStepIn);
    StepOut getStep(StepIn stepIn);
    ThirdStepOut valideThirdStep(ThirdStepIn thirdStepIn);

}
