package ma.eai.boa.xbanking.vo.enrollement;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class CheckInfoIn {
    private String firstName;

    private String lastName;

    private String phoneNumber;

    private String countryCode;

    private String callingCode;

    @JsonFormat(pattern="yyyy-MM-dd")
    private Date birthDate;

    private String deviceId;

    private String token;

    public String getToken() {
	return token;
    }

    public void setToken(String token) {
	this.token = token;
    }

    public String getFirstName() {
	return firstName;
    }

    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }

    public String getLastName() {
	return lastName;
    }

    public void setLastName(String lastName) {
	this.lastName = lastName;
    }

    public String getPhoneNumber() {
	return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
    }

    public String getCountryCode() {
	return countryCode;
    }

    public void setCountryCode(String countryCode) {
	this.countryCode = countryCode;
    }

    public String getCallingCode() {
	return callingCode;
    }

    public void setCallingCode(String callingCode) {
	this.callingCode = callingCode;
    }

    public Date getBirthDate() {
	return birthDate;
    }

    public void setBirthDate(Date birthDate) {
	this.birthDate = birthDate;
    }

    public String getDeviceId() {
	return deviceId;
    }

    public void setDeviceId(String deviceId) {
	this.deviceId = deviceId;
    }
}
