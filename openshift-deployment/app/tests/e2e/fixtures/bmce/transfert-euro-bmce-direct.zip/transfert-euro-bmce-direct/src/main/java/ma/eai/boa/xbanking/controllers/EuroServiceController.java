package ma.eai.boa.xbanking.controllers;

import ma.eai.boa.xbanking.service.PhoneNumber.PhoneNumberImpl;
import ma.eai.boa.xbanking.service.attachements.AttachementsImpl;
import ma.eai.boa.xbanking.service.beneficiaire.BeneficiaireImpl;
import ma.eai.boa.xbanking.service.authentification.Authentification;
import ma.eai.boa.xbanking.service.callGRC.CallGRC;
import ma.eai.boa.xbanking.service.customer.Customer;
import ma.eai.boa.xbanking.service.enrollement.EnrollementService;
import ma.eai.boa.xbanking.service.resendOtp.ResendOtpService;
import ma.eai.boa.xbanking.service.signContrat.GenerateIbanServiceImpl;
import ma.eai.boa.xbanking.service.parameters.GeneralParameterImpl;
import ma.eai.boa.xbanking.service.signContrat.SignContrat;
import ma.eai.boa.xbanking.service.steper.SteperImpl;
import ma.eai.boa.xbanking.service.tauxChange.TauxChangeService;
import ma.eai.boa.xbanking.service.transfert.Transfert;
import ma.eai.boa.xbanking.service.validationOtp.ValidationOtpImpl;
import ma.eai.boa.xbanking.util.ActionWeb;
import ma.eai.boa.xbanking.util.BuildResponse;
import ma.eai.boa.xbanking.util.Utils;
import ma.eai.boa.xbanking.util.XmlUtil;
import ma.eai.boa.xbanking.vo.Authentication.CheckUserIn;
import ma.eai.boa.xbanking.vo.Authentication.CheckUserOut;
import ma.eai.boa.xbanking.vo.Attachements.AttachementsIn;
import ma.eai.boa.xbanking.vo.Attachements.AttachementsOut;
import ma.eai.boa.xbanking.vo.Beneficiaire.BeneficiaireIn;
import ma.eai.boa.xbanking.vo.Beneficiaire.BeneficiaireOut;
import ma.eai.boa.xbanking.vo.Beneficiaire.ListBeneficiaireOut;
import ma.eai.boa.xbanking.vo.Beneficiaire.ListBeneficiaireIn;
import ma.eai.boa.xbanking.vo.FirstStep.FirstStepIn;
import ma.eai.boa.xbanking.vo.FirstStep.FirstStepOut;
import ma.eai.boa.xbanking.vo.Flux;
import ma.eai.boa.xbanking.vo.PersonalInformation.PersonalInfoIn;
import ma.eai.boa.xbanking.vo.PersonalInformation.PersonalInfoOut;
import ma.eai.boa.xbanking.vo.PhoneNumber.PhoneNumberIn;
import ma.eai.boa.xbanking.vo.PhoneNumber.PhoneNumberOut;
import ma.eai.boa.xbanking.vo.PhoneNumber.ResencOtpEerIn;
import ma.eai.boa.xbanking.vo.Retour;
import ma.eai.boa.xbanking.vo.SignContrat.GetContratIn;
import ma.eai.boa.xbanking.vo.SignContrat.GetContratOut;
import ma.eai.boa.xbanking.vo.SignContrat.SignContratIn;
import ma.eai.boa.xbanking.vo.SignContrat.SignContratOut;
import ma.eai.boa.xbanking.vo.SignContrat.IbanResponseOut;
import ma.eai.boa.xbanking.vo.SignContrat.GenerateIbanIn;
import ma.eai.boa.xbanking.vo.SignContrat.ValidateOtpSignContratOut;
import ma.eai.boa.xbanking.vo.SignContrat.ValidateOtpSigneContratIn;
import ma.eai.boa.xbanking.vo.Step.StepIn;
import ma.eai.boa.xbanking.vo.Step.StepOut;
import ma.eai.boa.xbanking.vo.TauxChange.TauxChangeIn;
import ma.eai.boa.xbanking.vo.TauxChange.TauxChangeOut;
import ma.eai.boa.xbanking.vo.ThirdStep.ThirdStepIn;
import ma.eai.boa.xbanking.vo.ThirdStep.ThirdStepOut;
import ma.eai.boa.xbanking.vo.User.UserIn;
import ma.eai.boa.xbanking.vo.User.UserOut;
import ma.eai.boa.xbanking.vo.callGRC.CallGrcIn;
import ma.eai.boa.xbanking.vo.callGRC.CallGrcOut;
import ma.eai.boa.xbanking.vo.customer.DetailsCustomerIn;
import ma.eai.boa.xbanking.vo.customer.DetailsCustomerOut;
import ma.eai.boa.xbanking.vo.enrollement.CheckIbanOut;
import ma.eai.boa.xbanking.vo.enrollement.CheckIbenIn;
import ma.eai.boa.xbanking.vo.enrollement.CheckInfoIn;
import ma.eai.boa.xbanking.vo.enrollement.CheckInfoOut;
import ma.eai.boa.xbanking.vo.enrollement.EnrollementValidationIn;
import ma.eai.boa.xbanking.vo.enrollement.EnrollementValidationOut;
import ma.eai.boa.xbanking.vo.transfert.DetailTransferIn;
import ma.eai.boa.xbanking.vo.transfert.DetailTransferOut;
import ma.eai.boa.xbanking.vo.historiqueTransfert.HistoriqueIn;
import ma.eai.boa.xbanking.vo.historiqueTransfert.HistoriqueOut;
import ma.eai.boa.xbanking.vo.transfert.TransfertIn;
import ma.eai.boa.xbanking.vo.transfert.TransfertOut;
import ma.eai.boa.xbanking.vo.validationOtp.ResendOtpIn;
import ma.eai.boa.xbanking.vo.validationOtp.ResendOtpOut;
import ma.eai.boa.xbanking.vo.validationOtp.ValidationOtpIn;
import ma.eai.boa.xbanking.vo.validationOtp.ValidationOtpOut;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EuroServiceController {
    @Autowired
    TauxChangeService tauxChangeService;

    @Autowired
    PhoneNumberImpl phoneNumberService;

    @Autowired
    ValidationOtpImpl validationOtp;

    @Autowired
    BeneficiaireImpl beneficiaireService;


    @Autowired
    GeneralParameterImpl generalParameter;

    @Autowired
    SteperImpl steper;

    @Autowired
    private Authentification authenticationService;

    @Autowired
    private SignContrat signContratService;

	@Autowired
	private GenerateIbanServiceImpl generateIbanService;

    @Autowired
    private AttachementsImpl attachements;



    @Autowired
    private Transfert transfert;

    @Autowired
    private EnrollementService enrollementService;

    @Autowired
    private CallGRC callGRC;

	@Autowired
	private ResendOtpService resendOtpService;
    @Autowired
    private Customer customer;

    @PostMapping(value = "/apitransfertcontroller", produces = {"text/xml;charset=ISO-8859-1"})
    public ResponseEntity<String> handleSoapRequest(@RequestBody String decodedSoapRequest) throws Throwable {
	EaiLog.info("================ BEGIN TransfertEuroService ======================");
	byte[] bytes = decodedSoapRequest.getBytes("ISO-8859-1");
	String soapRequest = new String(bytes, "ISO-8859-1");
	EaiLog.info("FLUX décodé : " + decodedSoapRequest);
	String functionName = XmlUtil.extractFunctionName(soapRequest);
	EaiLog.info("functionName:"+functionName);
	ActionWeb action = ActionWeb.valueOf(functionName);
	String responseXml="";
	Flux flux = XmlUtil.unmarshalSoapBody(soapRequest, Flux.class);
	switch (action) {
	case GENERATETOKEN:
	    EaiLog.info("================== BEGIN GENERATETOKEN CONTROLER ================== ");
	    UserIn userIn=flux.getUserIn();
	    String token = authenticationService.generateToken(userIn);
	    UserOut userOut= new UserOut();
	    userOut.setToken(token);
	    responseXml= BuildResponse.buildSoapResponse(userOut);
	    EaiLog.info("==================  FIN GENERATETOKEN with Response:"+responseXml);
	    break;
	case TAUXCHANGE:
	    EaiLog.info("================== BEGIN TauxChange CONTROLER:================== ");
	    TauxChangeIn tauxChangeIn=flux.getTauxChangeIn();
	    TauxChangeOut tauxChangeOut=tauxChangeService.getTauxChange(tauxChangeIn);
	    responseXml= BuildResponse.buildSoapResponse(tauxChangeOut);
	    EaiLog.info("================== FIN TauxChange with Response:"+responseXml);
	    break;
	case CREATEACCOUNT:
	    EaiLog.info("================== BEGIN CreateAccount CONTROLER:================== ");
	    PhoneNumberIn phoneNumberIn=flux.getPhoneNumberIn();
	    PhoneNumberOut phoneNumberOut=phoneNumberService.validePhoneNumber(phoneNumberIn);
	    responseXml= BuildResponse.buildSoapResponse(phoneNumberOut);
	    EaiLog.info("================== FIIN CreateAccount with Response:"+responseXml);
	    break;
	case VALIDATEOTP:
	    EaiLog.info("================== BEGIN VALIDATEOTP CONTROLER:================== ");
	    ValidationOtpIn otpIn=flux.getValidationOtpIn();
	    ValidationOtpOut otpOut=validationOtp.validateOtp(otpIn);
	    responseXml=BuildResponse.buildSoapResponse(otpOut);
	    EaiLog.info("================== FIIN VALIDATEOTP with Response:"+responseXml);

	    break;
	case CREATEBENEF:
	    EaiLog.info("==================BEGIN CreateBeneficiare CONTROLER:==================");
	    BeneficiaireIn beneficiaireIn=flux.getBeneficiaireIn();
	    Retour CreateBeneficiare =beneficiaireService.addBeneficiaire(beneficiaireIn);
	    responseXml= BuildResponse.buildSoapResponse(CreateBeneficiare);
	    EaiLog.info("==================FIIN CreateBeneficiare with Response:"+responseXml);
	    break;
	case PERSONALINFORMATION:
	    EaiLog.info("==================BEGIN PERSONALINFORMATION CONTROLER:==================");
	    PersonalInfoIn personalInfoIn= flux.getPersonalInfoIn();
	    PersonalInfoOut personalInfoOut=generalParameter.fetchGeneralParameters(personalInfoIn);
	    responseXml=BuildResponse.buildSoapResponse(personalInfoOut);
	    break;
	case VALIDATEFIRSTSTEP:
	    EaiLog.info("==================BEGIN VALIDATEFIRSTSTEP CONTROLER:==================");
	    FirstStepIn firstStepIn= flux.getFirstStepIn();
	    FirstStepOut retourFirstStep=steper.valideFirstStep(firstStepIn);
	    responseXml=BuildResponse.buildSoapResponse(retourFirstStep);
	    EaiLog.info("==================FIIN VALIDATEFIRSTSTEP with Response:"+responseXml);
	    break;
	case GETSTEP:
	    EaiLog.info("==================BEGIN GETSTEP CONTROLER:==================");
	    StepIn getStepIn= flux.getGetStep();
	    StepOut stepOut=steper.getStep(getStepIn);
	    responseXml=BuildResponse.buildSoapResponse(stepOut);
	    EaiLog.info("==================FIIN GETSTEP with Response:"+responseXml);
	    break;
	case VALIDATETHIRDSTEP:
	    EaiLog.info("==================BEGIN VALIDATETHIRDSTEP CONTROLER:==================");
	    ThirdStepIn thirdStepIn= flux.getThirdStepIn();
	    ThirdStepOut retourThirdStep=steper.valideThirdStep(thirdStepIn);
	    responseXml=BuildResponse.buildSoapResponse(retourThirdStep);
	    EaiLog.info("==================FIIN VALIDATETHIRDSTEP with Response:"+responseXml);
	    break;
	case SIGNCONTRAT:
	    EaiLog.info("==================BEGIN SIGNCONTRAT CONTROLER:==================");
	    SignContratIn signContratIn= flux.getSignContratIn();
	    SignContratOut signContratOut =signContratService.signContrat(signContratIn);
	    responseXml=BuildResponse.buildSoapResponse(signContratOut);
	    EaiLog.info("==================FIIN SIGNCONTRAT with Response:"+responseXml);
	    break;
	case GETCONTRAT:
	    EaiLog.info("==================BEGIN GETCONTRAT CONTROLER:==================");
	    GetContratIn getContratIn= flux.getGetContratIn();
	    GetContratOut getContratOut = signContratService.getContrat(getContratIn);
	    responseXml=BuildResponse.buildSoapResponse(getContratOut);
	    EaiLog.info("==================FIIN GETCONTRAT with Response:"+responseXml);
	    break;
	case GET_CONTRAT_GESTION:
	    EaiLog.info("==================BEGIN GETCONTRAT CONTROLER:==================");
	    GetContratIn getContratGestionIn= flux.getGetContratIn();
	    GetContratOut getContratGestionOut = signContratService.getContratGestion(getContratGestionIn);
	    responseXml=BuildResponse.buildSoapResponse(getContratGestionOut);
	    EaiLog.info("==================FIIN GETCONTRAT with Response:"+responseXml);
	    break;
	case VALIDATEOTPSIGNCONTRAT:
	    EaiLog.info("==================BEGIN VALIDATEOTPSIGNCONTRAT CONTROLER:==================");
	    ValidateOtpSigneContratIn validateOtpSigneContratIn= flux.getValidateOtpSigneContratIn();
	    ValidateOtpSignContratOut validateOtpSignContratOut = signContratService.validateOtpSigneContrat(validateOtpSigneContratIn);
	    responseXml=BuildResponse.buildSoapResponse(validateOtpSignContratOut);
	    EaiLog.info("==================FIIN VALIDATEOTPSIGNCONTRAT with Response:"+responseXml);
	    break;
	case UPLOADFILES:
	    EaiLog.info("==================BEGIN UPLOADFILES CONTROLER:==================");
	    AttachementsIn attachementsIn= flux.getAttachementsIn();
	    AttachementsOut attachementsOut = attachements.uploadFiles(attachementsIn);
	    responseXml=BuildResponse.buildSoapResponse(attachementsOut);
	    EaiLog.info("==================FIIN UPLOADFILES with Response:"+responseXml);
	    break;
	case CHECK_USER:
		EaiLog.info("==================BEGIN CHECK USER CONTROLLER:==================");
		CheckUserIn checkUserIn = flux.getCheckUserIn();
		CheckUserOut checkUserOut = authenticationService.checkUser(checkUserIn.getContratBad(),
				checkUserIn.getDeviceId());
		responseXml = BuildResponse.buildSoapResponse(checkUserOut);
		EaiLog.info("==================FIN CHECK USER with Response: {}",responseXml);
		break;

	case GENERATE_IBAN:
		EaiLog.info("==================BEGIN GENERATE IBAN CONTROLLER==================");
		GenerateIbanIn generateIbanIn = flux.getGenerateIbanIn();
		IbanResponseOut ibanResponseOut = generateIbanService.generateIban(generateIbanIn.getToken());
		responseXml = BuildResponse.buildSoapResponse(ibanResponseOut);
		EaiLog.info("==================FIN GENERATE IBAN with Response: {}",responseXml);
		break;
	case GETINFOSCLIENT:
	    EaiLog.info("==================BEGIN GETINFOSCLIENT CONTROLLER==================");
	    EaiLog.info("flux===========>",flux.getCallGrcIn());
	    CallGrcIn callGrcIn = flux.getCallGrcIn();
	    CallGrcOut callGrcOut = callGRC.getInfosClient(callGrcIn);
	    responseXml = BuildResponse.buildSoapResponse(callGrcOut);
	    EaiLog.info("==================FIN GETINFOSCLIENT with Response: {}",responseXml);
	    break;
	case VALIDATE_TRANSFERT:
	    EaiLog.info("==================BEGIN VALIDATE_TRANSFERT CONTROLLER==================");
	    TransfertIn transfertIn = flux.getTransfertIn();
	    TransfertOut transfertOut = transfert.validatTransfert(transfertIn);
	    responseXml = BuildResponse.buildSoapResponse(transfertOut);
	    EaiLog.info("==================FIN VALIDATE_TRANSFERT with Response: {}",responseXml);
	    break;

	case GET_LIST_BENEFICIARY:
		EaiLog.info("==================BEGIN GET LIST BENEFICIARY CONTROLLER==================");
		ListBeneficiaireIn in = flux.getListBeneficiaireIn();
		ListBeneficiaireOut response = beneficiaireService.getRecipients(in.getToken());
		responseXml = BuildResponse.buildSoapResponse(response);
		EaiLog.info("==================FIN GET list Beneficiary with Response: {}",responseXml);
		break;

	case GET_TRANSFER_DETAIL:
		EaiLog.info("==================BEGIN GET TRANSFER DETAIL CONTROLLER==================");
		DetailTransferIn detailTransferIn = flux.getDetailTransferIn();
		DetailTransferOut detailTransferOut = transfert.getTransferDetail(detailTransferIn.getUuid(), detailTransferIn.getToken());
		responseXml = BuildResponse.buildSoapResponse(detailTransferOut);
		EaiLog.info("==================FIN GET TRANSFER DETAIL CONTROLLER: {}", responseXml);
		break;
	case GET_HISTORIQUE_TRANSFERT:
	    EaiLog.info("==================BEGIN GET HISTORIQUE TRANSFERT CONTROLLER==================");
	    HistoriqueIn historiqueIn = flux.getHistoriqueIn();
	    HistoriqueOut historiqueOut = transfert.getHistoryTransfert(historiqueIn.getToken());
	    responseXml = BuildResponse.buildSoapResponse(historiqueOut);
	    EaiLog.info("==================FIN GET HISTORIQUE TRANSFERT with Response: {}",responseXml);
	    break;

	case CHECK_INFO_ENROLLEMENT:
	    EaiLog.info("==================BEGIN CHECK_INFO_ENROLLEMENT CONTROLLER==================");
	    EaiLog.info("Flux in CHECK_INFO_ENROLLEMENT: {}",flux.getCheckInfoIn());
	    CheckInfoIn checkInfoIn = flux.getCheckInfoIn();
	    CheckInfoOut checkInfoOut = enrollementService.checkInfos(checkInfoIn);
	    responseXml = BuildResponse.buildSoapResponse(checkInfoOut);
	    EaiLog.info("==================FIN CHECK_INFO_ENROLLEMENT with Response: {}",responseXml);
	    break;
	case CHECK_IBAN_ENROLLEMENT:
	    EaiLog.info("==================BEGIN CHECK_IBAN_ENROLLEMENT CONTROLLER==================");
	    EaiLog.info("Flux in CHECK_IBAN_ENROLLEMENT: {}",flux.getCheckIbenIn());
	    CheckIbenIn checkIbenIn = flux.getCheckIbenIn();
	    CheckIbanOut checkIbanOut = enrollementService.checkIban(checkIbenIn);
	    responseXml = BuildResponse.buildSoapResponse(checkIbanOut);
	    EaiLog.info("==================FIN CHECK_IBAN_ENROLLEMENT with Response: {}",responseXml);
	    break;

	case ENROLLEMENT_ACTIVATION:
		EaiLog.info("==================BEGIN ACTIVATION ENROLLEMENT CONTROLLER==================");
		EnrollementValidationIn enrollementValidationIn = flux.getEnrollementValidationIn();
		EnrollementValidationOut enrollementValidationOut = enrollementService.activateUser(enrollementValidationIn);
		responseXml = BuildResponse.buildSoapResponse(enrollementValidationOut);
		EaiLog.info("==================FIN ACTIVATION ENROLLEMENT with Response: {}",responseXml);
		break;
	case ADD_CLIENT_BENEF:
		EaiLog.info("==================BEGIN ADD BENEFICIARY FOR CLIENT==================");
		BeneficiaireIn input = flux.getBeneficiaireIn();
		BeneficiaireOut beneficiaryResponse = beneficiaireService.addBeneficiareForClient(input);
		responseXml = BuildResponse.buildSoapResponse(beneficiaryResponse);
        	EaiLog.info("==================FIN ADD BENEFICIARY FOR CLIENT");
		break;
	case RESEND_OTP:
	    EaiLog.info("==================BEGIN RESEND OTP==================");
	    ResendOtpIn resendOtpIn = flux.getResendOtpIn();
	    ResendOtpOut resendOtpOut = resendOtpService.resendOtp(resendOtpIn.getToken());
	    responseXml = BuildResponse.buildSoapResponse(resendOtpOut);
	    EaiLog.info("==================FIN RESEND OTP",responseXml);
	    break;
	case RESEND_OTP_EER:
	    EaiLog.info("==================responseXmlBEGIN RESEND OTPresponseXml==================");
	    ResencOtpEerIn resencOtpEerIn = flux.getResencOtpEerIn();
	    Retour resendOtpEerOut = resendOtpService.resendOtpEer(resencOtpEerIn.getOtpID());
	    responseXml = BuildResponse.buildSoapResponse(resendOtpEerOut);
	    EaiLog.info("==================FIN RESEND OTP",responseXml);
	    break;
	case GET_CUSTOMER_DETAILS:
	    EaiLog.info("================== responseXmlBEGIN GET_CUSTOMER_DETAILS ==================");
	    DetailsCustomerIn detailsCustomerIn = flux.getDetailsCustomerIn();
	    DetailsCustomerOut detailsCustomerOut = customer.getDetailsCustomer(detailsCustomerIn.getToken());
	    responseXml = BuildResponse.buildSoapResponse(detailsCustomerOut);
	    EaiLog.info("================== FIN GET_CUSTOMER_DETAILS ",responseXml);
	    break;
	default:
	    break;
	}
	return ResponseEntity.ok(responseXml);
    }
}
