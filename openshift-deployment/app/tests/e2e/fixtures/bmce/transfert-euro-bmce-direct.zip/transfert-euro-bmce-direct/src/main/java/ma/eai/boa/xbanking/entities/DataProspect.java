package ma.eai.boa.xbanking.entities;

import com.fasterxml.jackson.annotation.JsonFormat;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Column;

import java.io.Serializable;
import java.util.Date;
import java.sql.Timestamp;

@Entity
@Table(name = "BES_PROSPECT_DATA")
public class DataProspect implements Serializable {

    private static final long serialVersionUID = -2282317895027174329L;
	@Id
    	private String uuid;

	private String civility;
	
	private String lastname;
	
	private String firstname;
	
	private String address;
	
	private String codePostale;
	
	private String city;

	@Column(name = "CLIENT_BOA",columnDefinition="tinyint(1) default 0")
	private String clientBOA;

	private String country;
	
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date birthday;

	private String nationality;

	private String profession;

	private String activityArea;
	

	private boolean politicallyExposed;

    public String getUuid() {
	return uuid;
    }

    public void setUuid(String uuid) {
	this.uuid = uuid;
    }

    @JsonProperty("clientBOA")
    @Column(name = "CLIENT_BOA_STATUS")
	private String clientBOAStatus;


	@Column(name = "politically_exposed_desc")
	private String politicallyexposedStr;

	private String agence;

	@OneToOne
	private User user;
	
	private String birthCity;

	private String birthCountry;
	
    @Column(name = "PPE_VALIDATION_DATE")
	private Timestamp ppeValidationDate;
	

	private String civiliteStr;

	@Column(name = "LUI_MEME_PPE",columnDefinition="tinyint(1) default 0")
	private boolean luiMemePPE;

    @Column(name = "FONCTION_PPE")
	private String fonctionPPE;
	
    @Column(name = "FULLNAME_PPE")
	private String fullNamePPE;
	
    @Column(name = "LIEN_PPE")
	private String lienPPE;

	private double income;

	private String funds;


	private String transfertMotif;


	private String periodicity;


	private String frequency;


	private String incomeBracket;


	private String nationalIdentifier;


	private double transferVolume;

    @Column(name = "FUNCTION_PPE")
	private String functionPPE;


    @Column(name = "RELATIONSHIP_PPE")
	private String relationshipPPE;

    public String getCivility() {
	return civility;
    }

    public void setCivility(String civility) {
	this.civility = civility;
    }

    public String getLastname() {
	return lastname;
    }

    public void setLastname(String lastname) {
	this.lastname = lastname;
    }

    public String getFirstname() {
	return firstname;
    }

    public void setFirstname(String firstname) {
	this.firstname = firstname;
    }

    public String getAddress() {
	return address;
    }

    public void setAddress(String address) {
	this.address = address;
    }

    public String getCodePostale() {
	return codePostale;
    }

    public void setCodePostale(String codePostale) {
	this.codePostale = codePostale;
    }

    public String getCity() {
	return city;
    }

    public void setCity(String city) {
	this.city = city;
    }

    public String getClientBOA() {
	return clientBOA;
    }

    public void setClientBOA(String clientBOA) {
	this.clientBOA = clientBOA;
    }

    public String getCountry() {
	return country;
    }

    public void setCountry(String country) {
	this.country = country;
    }

    public Date getBirthday() {
	return birthday;
    }

    public void setBirthday(Date birthday) {
	this.birthday = birthday;
    }

    public String getNationality() {
	return nationality;
    }

    public void setNationality(String nationality) {
	this.nationality = nationality;
    }

    public String getProfession() {
	return profession;
    }

    public void setProfession(String profession) {
	this.profession = profession;
    }

    public String getActivityArea() {
	return activityArea;
    }

    public void setActivityArea(String activityArea) {
	this.activityArea = activityArea;
    }

    public boolean isPoliticallyExposed() {
	return politicallyExposed;
    }

    public void setPoliticallyExposed(boolean politicallyExposed) {
	this.politicallyExposed = politicallyExposed;
    }

    public String getClientBOAStatus() {
	return clientBOAStatus;
    }

    public void setClientBOAStatus(String clientBOAStatus) {
	this.clientBOAStatus = clientBOAStatus;
    }

    public String getPoliticallyexposedStr() {
	return politicallyexposedStr;
    }

    public void setPoliticallyexposedStr(String politicallyexposedStr) {
	this.politicallyexposedStr = politicallyexposedStr;
    }

    public String getAgence() {
	return agence;
    }

    public void setAgence(String agence) {
	this.agence = agence;
    }

    public User getUser() {
	return user;
    }

    public void setUser(User user) {
	this.user = user;
    }

    public String getBirthCity() {
	return birthCity;
    }

    public void setBirthCity(String birthCity) {
	this.birthCity = birthCity;
    }

    public String getBirthCountry() {
	return birthCountry;
    }

    public void setBirthCountry(String birthCountry) {
	this.birthCountry = birthCountry;
    }

    public Timestamp getPpeValidationDate() {
	return ppeValidationDate;
    }

    public void setPpeValidationDate(Timestamp ppeValidationDate) {
	this.ppeValidationDate = ppeValidationDate;
    }

    public String getCiviliteStr() {
	return civiliteStr;
    }

    public void setCiviliteStr(String civiliteStr) {
	this.civiliteStr = civiliteStr;
    }

    public boolean isLuiMemePPE() {
	return luiMemePPE;
    }

    public void setLuiMemePPE(boolean luiMemePPE) {
	this.luiMemePPE = luiMemePPE;
    }

    public String getFonctionPPE() {
	return fonctionPPE;
    }

    public void setFonctionPPE(String fonctionPPE) {
	this.fonctionPPE = fonctionPPE;
    }

    public String getFullNamePPE() {
	return fullNamePPE;
    }

    public void setFullNamePPE(String fullNamePPE) {
	this.fullNamePPE = fullNamePPE;
    }

    public String getLienPPE() {
	return lienPPE;
    }

    public void setLienPPE(String lienPPE) {
	this.lienPPE = lienPPE;
    }

    public double getIncome() {
	return income;
    }

    public void setIncome(double income) {
	this.income = income;
    }

    public String getFunds() {
	return funds;
    }

    public void setFunds(String funds) {
	this.funds = funds;
    }

    public String getTransfertMotif() {
	return transfertMotif;
    }

    public void setTransfertMotif(String transfertMotif) {
	this.transfertMotif = transfertMotif;
    }

    public String getPeriodicity() {
	return periodicity;
    }

    public void setPeriodicity(String periodicity) {
	this.periodicity = periodicity;
    }

    public String getFrequency() {
	return frequency;
    }

    public void setFrequency(String frequency) {
	this.frequency = frequency;
    }

    public String getIncomeBracket() {
	return incomeBracket;
    }

    public void setIncomeBracket(String incomeBracket) {
	this.incomeBracket = incomeBracket;
    }

    public String getNationalIdentifier() {
	return nationalIdentifier;
    }

    public void setNationalIdentifier(String nationalIdentifier) {
	this.nationalIdentifier = nationalIdentifier;
    }

    public double getTransferVolume() {
        return transferVolume;
    }

    public void setTransferVolume(double transferVolume) {
        this.transferVolume = transferVolume;
    }

    public String getFunctionPPE() {
	return functionPPE;
    }

    public void setFunctionPPE(String functionPPE) {
	this.functionPPE = functionPPE;
    }

    public String getRelationshipPPE() {
	return relationshipPPE;
    }

    public void setRelationshipPPE(String relationshipPPE) {
	this.relationshipPPE = relationshipPPE;
    }
}
