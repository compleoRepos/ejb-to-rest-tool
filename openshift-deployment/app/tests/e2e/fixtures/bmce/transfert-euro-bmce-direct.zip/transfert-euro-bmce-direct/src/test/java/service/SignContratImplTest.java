package service;

import ma.eai.boa.xbanking.dto.SignContrat.SignContratResponse;
import ma.eai.boa.xbanking.dto.SignContrat.ValidateOtpSignContratResponse;
import ma.eai.boa.xbanking.dto.nexus.SendOtpResponse;
import ma.eai.boa.xbanking.service.signContrat.SignContratImpl;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.vo.SignContrat.*;
import ma.eai.boa.xbanking.vo.SignContrat.GetContratIn;
import ma.eai.boa.xbanking.vo.SignContrat.GetContratOut;
import ma.eai.boa.xbanking.vo.SignContrat.SignContratIn;
import ma.eai.boa.xbanking.vo.SignContrat.SignContratOut;
import org.apache.http.HttpException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

public class SignContratImplTest {

    @Mock
    private RestTemplate restTemplate;
    @InjectMocks
    private SignContratImpl signContratService;

  //  private String urlApi = "http://test-api/"; // Example base URL

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        signContratService.urlApi = "http://example.com/";
    }

    @Test
    public void testSignContratSuccess() {
        SignContratIn input = new SignContratIn();
        input.setToken("Bearer test-token");

        SignContratResponse mockResponse = new SignContratResponse();
        mockResponse.setCode("SUCCESS_CODE");
        mockResponse.setStatus("SUCCESS");
        mockResponse.setTransactionId("txn123");
        mockResponse.setMessage("Contract signed successfully");

        String expectedUrl = "http://example.com/prospect/signContrat";

        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", "*/*");
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.set(HttpHeaders.AUTHORIZATION, "Bearer test-token");
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<SignContratResponse> responseEntity =new ResponseEntity<>(mockResponse, HttpStatus.OK);

        SignContratIn signContratIn = new SignContratIn();
        signContratIn.setToken("token");


        //When
        when(restTemplate.exchange(
                eq(expectedUrl),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(SignContratResponse.class)))
                .thenReturn(responseEntity);

        SignContratOut result = signContratService.signContrat(input);

        assertEquals(Constants.CODE_SUCCESS, result.getCode()); // Expecting "SUCCESS_CODE"
        assertEquals("OK", result.getMessage());
        assertEquals("SUCCESS", result.getStatus());
        assertEquals("txn123", result.getTransactionId());
    }

    @Test
    public void signContratTest_Failed() {
        //Given
        SendOtpResponse sendOtpMockResponse = new SendOtpResponse();
        sendOtpMockResponse.setCode("ERROR_CODE");
        sendOtpMockResponse.setMessage("OK");
        sendOtpMockResponse.setStatus("status");
        sendOtpMockResponse.setTransactionId("transactionId");
        SignContratIn signContratIn = new SignContratIn();
        signContratIn.setToken("token");
        ResponseEntity<SendOtpResponse> responseEntity = ResponseEntity.ok(sendOtpMockResponse);
        //When
        when(restTemplate.exchange(
                eq("http://example.com/prospect/signContrat"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(SendOtpResponse.class)
        )).thenReturn(responseEntity);

        //Then
        SignContratOut response = signContratService.signContrat(signContratIn);
        assertEquals(Constants.CODE_ERROR, response.getCode());

    }

    @Test
    public void signContratTest_BadRequest() {
        //Given
        SendOtpResponse sendOtpMockResponse = new SendOtpResponse();
        sendOtpMockResponse.setCode("ERROR_CODE");
        sendOtpMockResponse.setMessage("OK");
        sendOtpMockResponse.setStatus("status");
        sendOtpMockResponse.setTransactionId("transactionId");
        SignContratIn signContratIn = new SignContratIn();
        signContratIn.setToken("token");
        ResponseEntity<SendOtpResponse> responseEntity = ResponseEntity.badRequest().body(null);
        //When
        when(restTemplate.exchange(
                eq("http://example.com/prospect/signContrat"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(SendOtpResponse.class)
        )).thenThrow(new RuntimeException());

        //Then
        SignContratOut response = signContratService.signContrat(signContratIn);
        assertEquals(Constants.CODE_ERROR, response.getCode());

    }

    @Test
    public void getContratTest_Success() {

        //Given
        GetContratIn getContratIn = new GetContratIn();
        getContratIn.setToken("token");


        ResponseEntity<byte[]> responseEntity = ResponseEntity.ok("Contract".getBytes());
        //When
        when(restTemplate.exchange(
                eq("http://example.com/prospect/contratToSign"),
                eq(HttpMethod.GET),
                any(HttpEntity.class),
                eq(byte[].class)
        )).thenReturn(responseEntity);

        //Then
        GetContratOut response = signContratService.getContrat(getContratIn);
        assertEquals(Constants.CODE_SUCCESS, response.getCode());
        assertEquals(Base64.getEncoder().encodeToString("Contract".getBytes()), response.getBase64());

    }

    @Test
    public void getContratTest_Failed() {

        //Given
        GetContratIn getContratIn = new GetContratIn();
        getContratIn.setToken("token");


        ResponseEntity<byte[]> responseEntity = ResponseEntity.badRequest().body(null);
        //When
        when(restTemplate.exchange(
                eq("http://example.com/prospect/contratToSign"),
                eq(HttpMethod.GET),
                any(HttpEntity.class),
                eq(byte[].class)
        )).thenReturn(responseEntity);

        //Then
        GetContratOut response = signContratService.getContrat(getContratIn);
        assertEquals(Constants.CODE_ERROR, response.getCode());

    }

    @Test
    public void getContratTest_Exception() {

        //Given
        GetContratIn getContratIn = new GetContratIn();
        getContratIn.setToken("token");


        ResponseEntity<byte[]> responseEntity = ResponseEntity.badRequest().body(null);
        //When
        when(restTemplate.exchange(
                eq("http://example.com/prospect/contratToSign"),
                eq(HttpMethod.GET),
                any(HttpEntity.class),
                eq(byte[].class)
        )).thenThrow(new RuntimeException());

        //Then
        GetContratOut response = signContratService.getContrat(getContratIn);
        assertEquals(Constants.CODE_ERROR, response.getCode());

    }
    @Test
    public void validateOtpSignContratTest_Success() {

        //Given
        ValidateOtpSignContratResponse validateOtpSignContratResponse = new ValidateOtpSignContratResponse();
        validateOtpSignContratResponse.setCode("SUCCESS_CODE");
        validateOtpSignContratResponse.setMessage("OK");
        ValidateOtpSigneContratIn validateOtpSigneContratIn = new ValidateOtpSigneContratIn();
        validateOtpSigneContratIn.setToken("token");


        ResponseEntity<ValidateOtpSignContratResponse> responseEntity = ResponseEntity.ok(validateOtpSignContratResponse);
        //When
        when(restTemplate.exchange(
                eq("http://example.com/prospect/validateOtpContrat"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(ValidateOtpSignContratResponse.class)
        )).thenReturn(responseEntity);

        //Then
        ValidateOtpSignContratOut response = signContratService.validateOtpSigneContrat(validateOtpSigneContratIn);
        assertEquals("000", response.getCode());

    }

    @Test
    public void validateOtpSignContratTest_Failed() {
        //Given
        ValidateOtpSignContratResponse validateOtpSignContratResponse = new ValidateOtpSignContratResponse();
        validateOtpSignContratResponse.setCode("ERROR_CODE");
        validateOtpSignContratResponse.setMessage("OK");
        ValidateOtpSigneContratIn validateOtpSigneContratIn = new ValidateOtpSigneContratIn();
        validateOtpSigneContratIn.setToken("token");
        ResponseEntity<ValidateOtpSignContratResponse> responseEntity = ResponseEntity.ok(validateOtpSignContratResponse);
        //When
        when(restTemplate.exchange(
                eq("http://example.com/prospect/validateOtpContrat"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(ValidateOtpSignContratResponse.class)
        )).thenReturn(responseEntity);

        //Then
        ValidateOtpSignContratOut response = signContratService.validateOtpSigneContrat(validateOtpSigneContratIn);
        assertEquals(Constants.CODE_ERROR, response.getCode());

    }

    @Test
    public void validateOtpSignContratTest_BadRequest() {
        //Given
        ValidateOtpSignContratResponse validateOtpSignContratResponse = new ValidateOtpSignContratResponse();
        validateOtpSignContratResponse.setCode("ERROR_CODE");
        validateOtpSignContratResponse.setMessage("OK");
        ValidateOtpSigneContratIn validateOtpSigneContratIn = new ValidateOtpSigneContratIn();
        validateOtpSigneContratIn.setToken("token");
        ResponseEntity<ValidateOtpSignContratResponse> responseEntity = ResponseEntity.badRequest().body(null);
        //When
        when(restTemplate.exchange(
                eq("http://example.com/prospect/validateOtpContrat"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(ValidateOtpSignContratResponse.class)
        )).thenThrow(new RuntimeException());

        //Then
        ValidateOtpSignContratOut response = signContratService.validateOtpSigneContrat(validateOtpSigneContratIn);
        assertEquals(Constants.CODE_ERROR, response.getCode());

    }

}
