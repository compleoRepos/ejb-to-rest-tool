package ma.eai.boa.xbanking.dto.SignContrat;

import ma.eai.boa.xbanking.vo.Retour;

public class SignContratResponse extends Retour {
    private String transactionId;


    private String status;

    public String getTransactionId() {
	return transactionId;
    }

    public void setTransactionId(String transactionId) {
	this.transactionId = transactionId;
    }

    public String getStatus() {
	return status;
    }

    public void setStatus(String status) {
	this.status = status;
    }
}
