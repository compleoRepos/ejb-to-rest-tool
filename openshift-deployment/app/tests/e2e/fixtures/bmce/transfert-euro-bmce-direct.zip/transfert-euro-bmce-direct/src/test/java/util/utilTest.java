package util;

import ma.eai.boa.xbanking.util.BuildResponse;
import ma.eai.boa.xbanking.vo.TauxChange.TauxChangeOut;
import org.junit.Test;

import javax.xml.bind.JAXBException;

import static org.junit.Assert.assertNotNull;

public class utilTest {
    @Test
    public void testBuildSoapResponse() throws JAXBException {
	// Préparer l'objet de test
	TauxChangeOut testObject = new TauxChangeOut();
	testObject.setCode("0");
	// Appeler la méthode à tester
	String xmlResponse = BuildResponse.buildSoapResponse(testObject);
	// Vérifier que la réponse XML contient les bonnes valeurs
	assertNotNull("La réponse XML ne doit pas être null", xmlResponse);
    }
}
