package ma.eai.boa.xbanking.service.customer;

import ma.eai.boa.xbanking.dto.customer.DetailsCustomerResponse;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.vo.customer.DetailsCustomerOut;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class CustomerImpl implements Customer{
    @Value("${api.url}")
    public String urlApi;

    private final RestTemplate restTemplate;
    private static final String SUCCESS_CODE = "SUCCESS_CODE";


    public CustomerImpl(RestTemplate restTemplate) {
	this.restTemplate = restTemplate;
    }

    @Override
    public DetailsCustomerOut getDetailsCustomer(String token) {
	EaiLog.info("Start service get customer details by token : {}",token);

	DetailsCustomerOut detailsCustomerOut = new DetailsCustomerOut();
	try {
	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.set(HttpHeaders.AUTHORIZATION,token);
	    headers.set(Constants.CANAL_HEADER, Constants.CANAL);
	    HttpEntity<String> requestEntity = new HttpEntity<>(headers);

	    String url = urlApi + "customer/customerDetails";
	    EaiLog.info("Appel API : {}", url);

	    EaiLog.info("Calling url to get customer detail: {}", url);
	    ResponseEntity<DetailsCustomerResponse> response = restTemplate.exchange(
		    url,
		    HttpMethod.GET,
		    requestEntity,
		    DetailsCustomerResponse.class
	    );
	    EaiLog.info("Detail customer response : {}", response);
	    if(response.getBody() != null && response.getStatusCode().is2xxSuccessful() &&
		    SUCCESS_CODE.equals(response.getBody().getCode())) {
		EaiLog.info("detail customer body : {}", response.getBody());
		detailsCustomerOut.setAgence(response.getBody().getAgence());
		detailsCustomerOut.setDesignation(response.getBody().getDesignation());
		detailsCustomerOut.setFirstName(response.getBody().getFirstName());
		detailsCustomerOut.setLastName(response.getBody().getLastName());
		detailsCustomerOut.setAdress(response.getBody().getAdress());
		detailsCustomerOut.setEmail(response.getBody().getEmail());
		detailsCustomerOut.setPhone(response.getBody().getPhone());
		detailsCustomerOut.setProfile(response.getBody().getProfile());
		detailsCustomerOut.setDateNaissance(response.getBody().getDateNaissance());
		detailsCustomerOut.setNationality(response.getBody().getNationality());
		detailsCustomerOut.setCodePostal(response.getBody().getCodePostal());
		detailsCustomerOut.setVille(response.getBody().getVille());
		detailsCustomerOut.setDocType(response.getBody().getDocType());
		detailsCustomerOut.setDocValue(response.getBody().getDocValue());
		detailsCustomerOut.setDocCountry(response.getBody().getDocCountry());
		detailsCustomerOut.setCountry(response.getBody().getCountry());
		detailsCustomerOut.setPhoneContact(response.getBody().getPhoneContact());
		detailsCustomerOut.setIdentityValidityDate(response.getBody().getIdentityValidityDate());
		detailsCustomerOut.setIdentityDeliveryDate(response.getBody().getIdentityDeliveryDate());

		detailsCustomerOut.setCode(Constants.CODE_SUCCESS);
		detailsCustomerOut.setMessage("OK");
	    } else {
		EaiLog.info("call detail customer KO ");
		detailsCustomerOut.setCode(Constants.CODE_ERROR);
		detailsCustomerOut.setMessage(response.getBody() != null ? response.getBody().getCode() : Constants.RESPONSE_EMPTY);
	    }
	} catch(Exception e) {
	    EaiLog.info("Error in calling Detail customer WS : {}",e);
	    detailsCustomerOut.setCode(Constants.CODE_ERROR);
	    detailsCustomerOut.setMessage(Constants.TECHNICAL_ERROR);
	}
	return detailsCustomerOut;
    }
}
