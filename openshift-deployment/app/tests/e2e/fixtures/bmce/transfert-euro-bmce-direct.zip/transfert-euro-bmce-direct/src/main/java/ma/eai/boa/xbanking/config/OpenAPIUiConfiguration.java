package ma.eai.boa.xbanking.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;

@Configuration
public class OpenAPIUiConfiguration {
	@Bean
	public OpenAPI openAPI() {
		return new OpenAPI().info(new Info().title("Open API Documentation")
				.description("This is an example of documentation.").version("v1.0.0"));
	}
}
