package ma.eai.boa.xbanking.vo.PhoneNumber;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PhoneNumberIn {

    private String countryCode;

    private String phoneNumber;

    private String callingCode;

    private String deviceId;

    private String email;

    private String contratBad;

    @JsonProperty("motdepasse")
    private String password;

    public String getCountryCode() {
	return countryCode;
    }

    public void setCountryCode(String countryCode) {
	this.countryCode = countryCode;
    }

    public String getPhoneNumber() {
	return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
    }

    public String getCallingCode() {
	return callingCode;
    }

    public void setCallingCode(String callingCode) {
	this.callingCode = callingCode;
    }

    public String getDeviceId() {
	return deviceId;
    }

    public void setDeviceId(String deviceId) {
	this.deviceId = deviceId;
    }

    public String getEmail() {
	return email;
    }

    public void setEmail(String email) {
	this.email = email;
    }

    public String getContratBad() {
        return contratBad;
    }
    public void setContratBad(String contratBad) {
        this.contratBad = contratBad;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
