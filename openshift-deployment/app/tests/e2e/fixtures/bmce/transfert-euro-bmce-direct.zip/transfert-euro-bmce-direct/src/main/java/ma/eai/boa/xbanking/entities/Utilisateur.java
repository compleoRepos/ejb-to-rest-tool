package ma.eai.boa.xbanking.entities;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import ma.eai.boa.xbanking.util.UserStep;

@Entity
@Table(name = "Utilisateur")
public class Utilisateur extends Identified {

    private static final long serialVersionUID = -3274052712095163149L;

    @Column(unique = true)
    private String login;

    @JsonIgnore
    private String password;

    private boolean disabled;

    private Timestamp passwordDateReset;

    private int nbrAuthenticationError;

    private int nbrValidationAuthForteError;

    private boolean client;

    private String idAmplitude;

    private String phone;

    @JsonIgnore
    private Timestamp phoneValidationDate;

    @OneToOne
    private Country country;

    private boolean oldClient;

    @JsonIgnore
    @Column(columnDefinition="tinyint(1) default 0")
    private boolean valide;

    @JsonIgnore
    @Column(columnDefinition="tinyint(1) default 0")
    private boolean completed;

    @JsonIgnore
    private String uuidNexus;

    @JsonIgnore
    @Column(columnDefinition="tinyint(1) default 0")
    private boolean blocageAuthForte;

    @JsonIgnore
    private String deviceId;

    @JsonIgnore
    @Column(columnDefinition="tinyint(1) default 0")
    private boolean toEnrolle;

    @JsonIgnore
    private Timestamp signContratValidationDate;

    private UserStep step;

    @Column(columnDefinition="tinyint(1) default 0")
    private boolean changed;

    private Timestamp lastStepDate;

    @Column(columnDefinition="tinyint(1) default 0")
    private boolean disabledFromClient;

    private Timestamp dateDisabledFromClient;

    @Column(columnDefinition="tinyint(1) default 0")
    private boolean ignoreCheckDevice;

    @Column(columnDefinition="tinyint(1) default 0")
    private boolean ibangenerated;

    @Column(length = 2000)
    private String comment;

    @Column(columnDefinition="tinyint(1) default 0")
    private boolean validatOtpResetPwd;

    public String getLogin() {
	return login;
    }

    public void setLogin(String login) {
	this.login = login;
    }

    public String getPassword() {
	return password;
    }

    public void setPassword(String password) {
	this.password = password;
    }

    public boolean isDisabled() {
	return disabled;
    }

    public void setDisabled(boolean disabled) {
	this.disabled = disabled;
    }

    public Timestamp getPasswordDateReset() {
	return passwordDateReset;
    }

    public void setPasswordDateReset(Timestamp passwordDateReset) {
	this.passwordDateReset = passwordDateReset;
    }

    public int getNbrAuthenticationError() {
	return nbrAuthenticationError;
    }

    public void setNbrAuthenticationError(int nbrAuthenticationError) {
	this.nbrAuthenticationError = nbrAuthenticationError;
    }

    public boolean isClient() {
	return client;
    }

    public void setClient(boolean client) {
	this.client = client;
    }


    public String getPhone() {
	return phone;
    }

    public void setPhone(String phone) {
	this.phone = phone;
    }

    public Country getCountry() {
	return country;
    }

    public void setCountry(Country country) {
	this.country = country;
    }

    public boolean isOldClient() {
	return oldClient;
    }

    public void setOldClient(boolean oldClient) {
	this.oldClient = oldClient;
    }

    public String getIdAmplitude() {
	return idAmplitude;
    }

    public void setIdAmplitude(String idAmplitude) {
	this.idAmplitude = idAmplitude;
    }

    public boolean isValide() {
	return valide;
    }

    public void setValide(boolean valide) {
	this.valide = valide;
    }

    public boolean isCompleted() {
	return completed;
    }

    public void setCompleted(boolean completed) {
	this.completed = completed;
    }

    public String getUuidNexus() {
	return uuidNexus;
    }

    public void setUuidNexus(String uuidNexus) {
	this.uuidNexus = uuidNexus;
    }

    public Timestamp getPhoneValidationDate() {
	return phoneValidationDate;
    }

    public void setPhoneValidationDate(Timestamp phoneValidationDate) {
	this.phoneValidationDate = phoneValidationDate;
    }

    public boolean isBlocageAuthForte() {
	return blocageAuthForte;
    }

    public void setBlocageAuthForte(boolean blocageAuthForte) {
	this.blocageAuthForte = blocageAuthForte;
    }

    public int getNbrValidationAuthForteError() {
	return nbrValidationAuthForteError;
    }

    public void setNbrValidationAuthForteError(int nbrValidationAuthForteError) {
	this.nbrValidationAuthForteError = nbrValidationAuthForteError;
    }

    public String getDeviceId() {
	return deviceId;
    }

    public void setDeviceId(String deviceId) {
	this.deviceId = deviceId;
    }

    public boolean isToEnrolle() {
	return toEnrolle;
    }

    public void setToEnrolle(boolean toEnrolle) {
	this.toEnrolle = toEnrolle;
    }

    public UserStep getStep() {
	return step;
    }

    public void setStep(UserStep step) {
	this.step = step;
    }

    public Timestamp getSignContratValidationDate() {
	return signContratValidationDate;
    }

    public void setSignContratValidationDate(Timestamp signContratValidationDate) {
	this.signContratValidationDate = signContratValidationDate;
    }

    public boolean isChanged() {
	return changed;
    }

    public void setChanged(boolean changed) {
	this.changed = changed;
    }

    public Timestamp getLastStepDate() {
	return lastStepDate;
    }

    public void setLastStepDate(Timestamp lastStepDate) {
	this.lastStepDate = lastStepDate;
    }

    public boolean isDisabledFromClient() {
	return disabledFromClient;
    }

    public void setDisabledFromClient(boolean disabledFromClient) {
	this.disabledFromClient = disabledFromClient;
    }

    public Timestamp getDateDisabledFromClient() {
	return dateDisabledFromClient;
    }

    public void setDateDisabledFromClient(Timestamp dateDisabledFromClient) {
	this.dateDisabledFromClient = dateDisabledFromClient;
    }

    public boolean isIgnoreCheckDevice() {
	return ignoreCheckDevice;
    }

    public void setIgnoreCheckDevice(boolean ignoreCheckDevice) {
	this.ignoreCheckDevice = ignoreCheckDevice;
    }

    public boolean isIbangenerated() {
	return ibangenerated;
    }

    public void setIbangenerated(boolean ibangenerated) {
	this.ibangenerated = ibangenerated;
    }

    public String getComment() {
	return comment;
    }

    public void setComment(String comment) {
	this.comment = comment;
    }

    public boolean isValidatOtpResetPwd() {
	return validatOtpResetPwd;
    }

    public void setValidatOtpResetPwd(boolean validatOtpResetPwd) {
	this.validatOtpResetPwd = validatOtpResetPwd;
    }


}

