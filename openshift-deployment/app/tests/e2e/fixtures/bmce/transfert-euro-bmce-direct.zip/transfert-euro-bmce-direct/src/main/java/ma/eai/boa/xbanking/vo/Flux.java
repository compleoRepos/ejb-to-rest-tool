package ma.eai.boa.xbanking.vo;

import ma.eai.boa.xbanking.vo.Authentication.CheckUserIn;
import ma.eai.boa.xbanking.vo.Attachements.AttachementsIn;
import ma.eai.boa.xbanking.vo.Beneficiaire.ListBeneficiaireIn;
import ma.eai.boa.xbanking.vo.FirstStep.FirstStepIn;
import ma.eai.boa.xbanking.vo.PersonalInformation.PersonalInfoIn;
import ma.eai.boa.xbanking.vo.Beneficiaire.BeneficiaireIn;
import ma.eai.boa.xbanking.vo.PhoneNumber.PhoneNumberIn;
import ma.eai.boa.xbanking.vo.PhoneNumber.ResencOtpEerIn;
import ma.eai.boa.xbanking.vo.SignContrat.GenerateIbanIn;
import ma.eai.boa.xbanking.vo.SignContrat.GetContratIn;
import ma.eai.boa.xbanking.vo.SignContrat.SignContratIn;
import ma.eai.boa.xbanking.vo.SignContrat.ValidateOtpSigneContratIn;
import ma.eai.boa.xbanking.vo.Step.StepIn;
import ma.eai.boa.xbanking.vo.TauxChange.TauxChangeIn;
import ma.eai.boa.xbanking.vo.ThirdStep.ThirdStepIn;
import ma.eai.boa.xbanking.vo.User.UserIn;
import ma.eai.boa.xbanking.vo.callGRC.CallGrcIn;
import ma.eai.boa.xbanking.vo.customer.DetailsCustomerIn;
import ma.eai.boa.xbanking.vo.enrollement.CheckIbenIn;
import ma.eai.boa.xbanking.vo.enrollement.CheckInfoIn;
import ma.eai.boa.xbanking.vo.enrollement.EnrollementValidationIn;
import ma.eai.boa.xbanking.vo.transfert.DetailTransferIn;
import ma.eai.boa.xbanking.vo.historiqueTransfert.HistoriqueIn;
import ma.eai.boa.xbanking.vo.transfert.TransfertIn;
import ma.eai.boa.xbanking.vo.validationOtp.ResendOtpIn;
import ma.eai.boa.xbanking.vo.validationOtp.ValidationOtpIn;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "flux")
public class Flux {
    private TauxChangeIn tauxChangeIn;
    private ValidationOtpIn validationOtpIn;
    private PhoneNumberIn phoneNumberIn;
    private BeneficiaireIn beneficiaireIn;


    private PersonalInfoIn personalInfoIn;
    private FirstStepIn firstStepIn;
    private StepIn getStep;
    private ThirdStepIn thirdStepIn;
    private UserIn userIn;
    private SignContratIn signContratIn;
    private GetContratIn getContratIn;
    private ValidateOtpSigneContratIn validateOtpSigneContratIn;

    private AttachementsIn attachementsIn;

    private CallGrcIn callGrcIn;
    
    private ListBeneficiaireIn listBeneficiaireIn;

    private TransfertIn transfertIn;
    private HistoriqueIn historiqueIn;


    private CheckInfoIn checkInfoIn;
    private CheckIbenIn checkIbenIn;

    private ResendOtpIn resendOtpIn;

    private ResencOtpEerIn resencOtpEerIn;

    private DetailsCustomerIn detailsCustomerIn;

    @XmlElement(name = "detailsCustomerIn")
    public DetailsCustomerIn getDetailsCustomerIn() {
        return detailsCustomerIn;
    }

    public void setDetailsCustomerIn(DetailsCustomerIn detailsCustomerIn) {
        this.detailsCustomerIn = detailsCustomerIn;
    }

    @XmlElement(name = "checkIbenIn")
    public CheckIbenIn getCheckIbenIn() {
	return checkIbenIn;
    }

    public void setCheckIbenIn(CheckIbenIn checkIbenIn) {
	this.checkIbenIn = checkIbenIn;
    }

    private EnrollementValidationIn enrollementValidationIn;

    @XmlElement(name = "checkInfoIn")
    public CheckInfoIn getCheckInfoIn() {
	return checkInfoIn;
    }

    public void setCheckInfoIn(CheckInfoIn checkInfoIn) {
	this.checkInfoIn = checkInfoIn;
    }

    @XmlElement(name = "historiqueIn")
    public HistoriqueIn getHistoriqueIn() {
	return historiqueIn;
    }

    public void setHistoriqueIn(HistoriqueIn historiqueIn) {
	this.historiqueIn = historiqueIn;
    }

    private DetailTransferIn detailTransferIn;

    @XmlElement(name = "transfertIn")
    public TransfertIn getTransfertIn() {
	return transfertIn;
    }

    public void setTransfertIn(TransfertIn transfertIn) {
	this.transfertIn = transfertIn;
    }

    @XmlElement(name = "callGrcIn")
    public CallGrcIn getCallGrcIn() {
	return callGrcIn;
    }

    public void setCallGrcIn(CallGrcIn callGrcIn) {
	this.callGrcIn = callGrcIn;
    }

    @XmlElement(name = "attachementsIn")
    public AttachementsIn getAttachementsIn() {
	return attachementsIn;
    }

    public void setAttachementsIn(AttachementsIn attachementsIn) {
	this.attachementsIn = attachementsIn;
    }

    @XmlElement(name = "validateOtpSigneContratIn")
    public ValidateOtpSigneContratIn getValidateOtpSigneContratIn() {
	return validateOtpSigneContratIn;
    }

    public void setValidateOtpSigneContratIn(ValidateOtpSigneContratIn validateOtpSigneContratIn) {
	this.validateOtpSigneContratIn = validateOtpSigneContratIn;
    }

    private CheckUserIn checkUserIn;

    private GenerateIbanIn generateIbanIn;

    @XmlElement(name = "getContratIn")
    public GetContratIn getGetContratIn() {
	return getContratIn;
    }

    public void setGetContratIn(GetContratIn getContratIn) {
	this.getContratIn = getContratIn;
    }

    @XmlElement(name = "signContratIn")
    public SignContratIn getSignContratIn() {
	return signContratIn;
    }

    public void setSignContratIn(SignContratIn signContratIn) {
	this.signContratIn = signContratIn;
    }

    @XmlElement(name = "userIn")
    public UserIn getUserIn() {
	return userIn;
    }

    public void setUserIn(UserIn userIn) {
	this.userIn = userIn;
    }

    @XmlElement(name = "thirdStepIn")
    public ThirdStepIn getThirdStepIn() {
	return thirdStepIn;
    }

    public void setThirdStepIn(ThirdStepIn thirdStepIn) {
	this.thirdStepIn = thirdStepIn;
    }

    @XmlElement(name = "getStep")
    public StepIn getGetStep() {
	return getStep;
    }

    public void setGetStep(StepIn getStep) {
	this.getStep = getStep;
    }

    @XmlElement(name = "firstStepIn")
    public FirstStepIn getFirstStepIn() {
	return firstStepIn;
    }

    public void setFirstStepIn(FirstStepIn firstStepIn) {
	this.firstStepIn = firstStepIn;
    }

    @XmlElement(name = "personalInfoIn")
    public PersonalInfoIn getPersonalInfoIn() {
	return personalInfoIn;
    }

    public void setPersonalInfoIn(PersonalInfoIn personalInfoIn) {
	this.personalInfoIn = personalInfoIn;
    }

    @XmlElement(name = "validationOtpIn")
    public ValidationOtpIn getValidationOtpIn() {
	return validationOtpIn;
    }
    public void setValidationOtpIn(ValidationOtpIn validationOtpIn) {
	this.validationOtpIn = validationOtpIn;
    }

    @XmlElement(name = "phoneNumberIn")
    public PhoneNumberIn getPhoneNumberIn() {
	return phoneNumberIn;
    }
    public void setPhoneNumberIn(PhoneNumberIn phoneNumberIn) {
	this.phoneNumberIn = phoneNumberIn;
    }

    @XmlElement(name = "tauxChangeIn")
    public TauxChangeIn getTauxChangeIn() {
	return tauxChangeIn;
    }
    public void setTauxChangeIn(TauxChangeIn tauxChangeIn) {
	this.tauxChangeIn = tauxChangeIn;
    }

    @XmlElement(name = "beneficiaireIn")
    public BeneficiaireIn getBeneficiaireIn() {
	return beneficiaireIn;
    }
    public void setBeneficiaireIn(BeneficiaireIn beneficiaireIn) {
	this.beneficiaireIn = beneficiaireIn;
    }

    @XmlElement(name = "checkUserIn")
    public CheckUserIn getCheckUserIn() {
        return checkUserIn;
    }
    public void setCheckUserIn(CheckUserIn checkUserIn) {
        this.checkUserIn = checkUserIn;
    }
    @XmlElement(name = "GenerateIbanIn")
    public GenerateIbanIn getGenerateIbanIn() {
        return generateIbanIn;
    }

    public void setGenerateIbanIn(GenerateIbanIn generateIbanIn) {
        this.generateIbanIn = generateIbanIn;
    }

    @XmlElement(name = "listBeneficiaireIn")
    public ListBeneficiaireIn getListBeneficiaireIn() {
        return listBeneficiaireIn;
    }

    public void setListBeneficiaireIn(ListBeneficiaireIn listBeneficiaireIn) {
        this.listBeneficiaireIn = listBeneficiaireIn;
    }
    @XmlElement(name = "detailTransferIn")
    public DetailTransferIn getDetailTransferIn() {
        return detailTransferIn;
    }

    public void setDetailTransferIn(DetailTransferIn detailTransferIn) {
        this.detailTransferIn = detailTransferIn;
    }

    @XmlElement(name = "enrollementValidationIn")
    public EnrollementValidationIn getEnrollementValidationIn() {
        return enrollementValidationIn;
    }

    public void setEnrollementValidationIn(EnrollementValidationIn enrollementValidationIn) {
        this.enrollementValidationIn = enrollementValidationIn;

    }
    @XmlElement(name = "resendOtpIn")
    public ResendOtpIn getResendOtpIn() {
        return resendOtpIn;
    }
    
    @XmlElement(name = "resencOtpEerIn")
    public ResencOtpEerIn getResencOtpEerIn() {
        return resencOtpEerIn;
    }

    public void setResencOtpEerIn(ResencOtpEerIn resencOtpEerIn) {
        this.resencOtpEerIn = resencOtpEerIn;
    }

    public void setResendOtpIn(ResendOtpIn resendOtpIn) {
        this.resendOtpIn = resendOtpIn;
    }
}
