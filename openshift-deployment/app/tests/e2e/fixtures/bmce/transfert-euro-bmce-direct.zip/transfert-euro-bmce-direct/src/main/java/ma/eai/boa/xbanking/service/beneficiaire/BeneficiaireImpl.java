package ma.eai.boa.xbanking.service.beneficiaire;

import com.fasterxml.jackson.databind.ObjectMapper;
import ma.eai.boa.xbanking.dto.Beneficiaire.BeneficiaireRequest;

import ma.eai.boa.xbanking.dto.Beneficiaire.BeneficiaireResponse;
import ma.eai.boa.xbanking.dto.Beneficiaire.ListBeneficiaire;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.vo.Beneficiaire.BeneficiaireIn;
import ma.eai.boa.xbanking.vo.Beneficiaire.BeneficiaireOut;
import ma.eai.boa.xbanking.vo.Beneficiaire.ListBeneficiaireOut;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
@Service
public class BeneficiaireImpl implements Beneficiaire{

    @Value("${api.url}")
    public String urlApi;
    @Autowired
    private RestTemplate restTemplate;
    private static final String SUCCESS_CODE ="SUCCESS_CODE";
    private static final String EMPTY_RESP = "RESPONSE_EMPTY";
    private static final String ERR_TECHNICAL = "ERR_TECHNICAL";
    public BeneficiaireOut addBeneficiaire(BeneficiaireIn beneficiaireIn) {
		EaiLog.info("Start service add beneficiary prospect");
	BeneficiaireOut beneficiareOut=new BeneficiaireOut();
	try{
	    BeneficiaireRequest beneficiaireRequest = new BeneficiaireRequest();
	    beneficiaireRequest.setBank(beneficiaireIn.getBank());
	    beneficiaireRequest.setFirstName(beneficiaireIn.getFirstName());
	    beneficiaireRequest.setAttestationRib(beneficiaireIn.getAttestationRib());
	    beneficiaireRequest.setCountry(beneficiaireIn.getCountry());
	    beneficiaireRequest.setLastName(beneficiaireIn.getLastName());
	    beneficiaireRequest.setRib(beneficiaireIn.getRib());
	    beneficiaireRequest.setRelationFamiliale(beneficiaireIn.getRelationFamiliale());

	    String url = new StringBuilder(urlApi)
		    .append("prospect/benef/add ")
		    .toString();
	    EaiLog.info("url appel: {}"+url);
	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.set(HttpHeaders.AUTHORIZATION,beneficiaireIn.getToken());
	    headers.set(Constants.CANAL_HEADER, Constants.CANAL);
	    ObjectMapper objectMapper = new ObjectMapper();

	    String jsonRequest = objectMapper.writeValueAsString(beneficiaireRequest);
	    EaiLog.info("jsonRequest==================>: {}"+jsonRequest);
	    EaiLog.info("headers==================>: {}"+headers);
	    HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, headers);
	    ResponseEntity<BeneficiaireResponse> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
		    BeneficiaireResponse.class);
	    BeneficiaireResponse responseDTO=response.getBody();
	    EaiLog.info("responseDTO success=====: {}",responseDTO);
	    if(responseDTO != null && SUCCESS_CODE.equals(responseDTO.getCode())) {
		EaiLog.info("Appel success=====");
		beneficiareOut.setCode(Constants.CODE_SUCCESS);
		beneficiareOut.setMessage("OK");
	    }else {
			EaiLog.info("Appel ERREUR=====");
		beneficiareOut.setCode(Constants.CODE_ERROR);
		beneficiareOut.setMessage((responseDTO != null ? responseDTO.getCode(): EMPTY_RESP));
	    }
	    EaiLog.info("-----------------Fin service validePhoneNumber--------------------");
	} catch (Exception e) {
	    EaiLog.info("Une erreur inconnue est survenue : {} " + e);
	    beneficiareOut.setCode(Constants.CODE_ERROR);
	    beneficiareOut.setMessage(ERR_TECHNICAL);
	}
	return beneficiareOut;
    }


	@Override
	public ListBeneficiaireOut getRecipients(String token) {
		EaiLog.info("Start Service get list beneficiary");
		ListBeneficiaireOut listBeneficiaireOut = new ListBeneficiaireOut();
		try {
		 String url = urlApi.concat("gestion/benificiaires");
		 EaiLog.info("calling url: {}",url);
		 HttpHeaders headers = new HttpHeaders();
		 headers.setContentType(MediaType.APPLICATION_JSON);
		 headers.set(HttpHeaders.AUTHORIZATION,token);
		 headers.set(Constants.CANAL_HEADER, Constants.CANAL);
		 HttpEntity<String> requestEntity = new HttpEntity<>(headers);

		 ResponseEntity<ListBeneficiaire> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					ListBeneficiaire.class);
		 ListBeneficiaire bodyResponse = response.getBody();
         EaiLog.info("BES get beneficiary response : {}", bodyResponse);
		 if(bodyResponse != null && SUCCESS_CODE.equals(bodyResponse.getCode())) {
			 listBeneficiaireOut.setListeBenef(bodyResponse.getListeBenef());
			 listBeneficiaireOut.setCommission(bodyResponse.getCommission());
			 listBeneficiaireOut.setCode(Constants.CODE_SUCCESS);
			 listBeneficiaireOut.setMessage("OK");
		 } else {
			 listBeneficiaireOut.setCode(Constants.CODE_ERROR);
			 listBeneficiaireOut.setMessage((bodyResponse != null ? bodyResponse.getCode(): EMPTY_RESP));
		 }
		} catch(Exception e) {
			EaiLog.info("Technical Error : {}", e);
			listBeneficiaireOut.setCode(Constants.CODE_ERROR);
			listBeneficiaireOut.setMessage(ERR_TECHNICAL);
		}
		EaiLog.info("End Service get list beneficiary");
		return listBeneficiaireOut;
	}

	@Override
	public BeneficiaireOut addBeneficiareForClient(BeneficiaireIn beneficiaireIn) {
		EaiLog.info("Start service add beneficiaire for Client");
		BeneficiaireOut beneficiareOut=new BeneficiaireOut();
		try{
			BeneficiaireRequest beneficiaireRequest = new BeneficiaireRequest();
			beneficiaireRequest.setBank(beneficiaireIn.getBank());
			beneficiaireRequest.setFirstName(beneficiaireIn.getFirstName());
			beneficiaireRequest.setAttestationRib(beneficiaireIn.getAttestationRib());
			beneficiaireRequest.setCountry(beneficiaireIn.getCountry());
			beneficiaireRequest.setLastName(beneficiaireIn.getLastName());
			beneficiaireRequest.setRib(beneficiaireIn.getRib());
			beneficiaireRequest.setRelationFamiliale(beneficiaireIn.getRelationFamiliale());

			String url = new StringBuilder(urlApi)
					.append("gestion/addbenef")
					.toString();
			EaiLog.info("url call: {}", url);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(HttpHeaders.AUTHORIZATION,beneficiaireIn.getToken());
		    	headers.set(Constants.CANAL_HEADER, Constants.CANAL);
			ObjectMapper objectMapper = new ObjectMapper();

			String jsonRequest = objectMapper.writeValueAsString(beneficiaireRequest);
			EaiLog.info("jsonRequest==================> : {}",jsonRequest);
			EaiLog.info("headers==================> : {}",headers);
			HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, headers);
			ResponseEntity<BeneficiaireResponse> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
					BeneficiaireResponse.class);
			BeneficiaireResponse responseDTO=response.getBody();
			EaiLog.info("response : {}",responseDTO);
			if(responseDTO != null && SUCCESS_CODE.equals(responseDTO.getCode())) {
				EaiLog.info("calling BES with success");
				beneficiareOut.setCode(Constants.CODE_SUCCESS);
				beneficiareOut.setMessage("OK");
			}else {
				EaiLog.info("Error calling BES add benef WS");
				beneficiareOut.setCode(Constants.CODE_ERROR);
				beneficiareOut.setMessage(responseDTO != null ?responseDTO.getCode(): EMPTY_RESP);
			}
			EaiLog.info("Fin service add beneficiary for client");
		} catch (Exception e) {
			EaiLog.info("Technical Error : {}" , e);
			beneficiareOut.setCode(Constants.CODE_ERROR);
			beneficiareOut.setMessage(ERR_TECHNICAL);
		}
		return beneficiareOut;
	}
}
