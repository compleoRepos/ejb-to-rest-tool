package ma.eai.boa.xbanking.dto.enrollement;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class IbanRequest implements Serializable {

    private static final long serialVersionUID = 810136851892000535L;


    @JsonProperty("iban")
    private String iban;

    private CheckInfoRequest checkInfoRequest;

    private String deviceId;

    public String getIban() {
	return iban;
    }

    public void setIban(String iban) {
	this.iban = iban;
    }

    public CheckInfoRequest getCheckInfoRequest() {
	return checkInfoRequest;
    }

    public void setCheckInfoRequest(CheckInfoRequest checkInfoRequest) {
	this.checkInfoRequest = checkInfoRequest;
    }

    public String getDeviceId() {
	return deviceId;
    }

    public void setDeviceId(String deviceId) {
	this.deviceId = deviceId;
    }
}
