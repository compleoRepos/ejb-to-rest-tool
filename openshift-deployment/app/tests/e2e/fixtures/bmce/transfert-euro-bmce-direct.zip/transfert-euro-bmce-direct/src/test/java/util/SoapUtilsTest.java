package util;

import ma.eai.boa.xbanking.util.XmlUtil;
import ma.eai.boa.xbanking.vo.Flux;
import org.junit.Assert;
import org.junit.Test;

import javax.xml.bind.JAXBException;

public class SoapUtilsTest {
    	    String xml = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>\n" + "<soap:Envelope\n"
		+ "        xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n"
		+ "        xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"\n"
		+ "        xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\">\n" + "    <soap:Header>\n"
		+ "        <x:MidwHeader xmlns:x=\"urn:midw\">\n"
		+ "            <x:Method>recharge-compte-damancash</x:Method>\n"
		+ "            <x:Origin>MNC</x:Origin>\n" + "            <x:PWKType>2</x:PWKType>\n"
		+ "            <x:Service>recharge-compte-damancash</x:Service>\n"
		+ "            <x:Timeout>30000</x:Timeout>\n"
		+ "            <x:Timestamp>20190116101441582</x:Timestamp>\n"
		+ "            <x:Version>1</x:Version>\n" + "            <x:WO>WWFSYD42+AC155D01++++</x:WO>\n"
		+ "            <x:Crypt>false</x:Crypt>\n" + "        </x:MidwHeader>\n" + "    </soap:Header>\n"
		+ "    <soap:Body>\n" + "        <flux>\n" + "            <entete>\n"
		+ "                <fonction>VALIDATEOTP</fonction>\n" + "            </entete>\n"
		+ "            <validationOtpIn>\n" + "                <uuid>0a7c81cfe2fb44a392bf884efdc67d97</uuid>\n"
		+ "                <otpId>44b6c741-e858-11ef-82ba-0050568aa089</otpId>\n"
		+ "                <otpValue>663682</otpValue>\n"
		+ "                <deviceId>16974B9D-77E5-4EB2-9D65-7EFA72014E98</deviceId>\n"
		+ "            </validationOtpIn>\n" + "        </flux>\n" + "    </soap:Body>\n" + "</soap:Envelope>";

	@Test
	public void testUnmarshalSoapBody() throws JAXBException {
	    Flux flux = XmlUtil.unmarshalSoapBody(xml, Flux.class);
	    Assert.assertNotNull(flux);
	}

	@Test
	public void testExtractBodyContent() {
	    String bodyContent = XmlUtil.extractBodyContent(xml);
	    Assert.assertEquals("<flux>\n" + "            <entete>\n"
		    + "                <fonction>VALIDATEOTP</fonction>\n" + "            </entete>\n"
		    + "            <validationOtpIn>\n"
		    + "                <uuid>0a7c81cfe2fb44a392bf884efdc67d97</uuid>\n"
		    + "                <otpId>44b6c741-e858-11ef-82ba-0050568aa089</otpId>\n"
		    + "                <otpValue>663682</otpValue>\n"
		    + "                <deviceId>16974B9D-77E5-4EB2-9D65-7EFA72014E98</deviceId>\n"
		    + "            </validationOtpIn>\n" + "        </flux>", bodyContent);
	}

	@Test
	public void testExtractFunctionName() throws Exception {
	    String soapRequest = xml;
	    String functionName = XmlUtil.extractFunctionName(soapRequest);
	    Assert.assertEquals("VALIDATEOTP", functionName);
	}

	@Test
	public void testExtractFunctionNameWithUnknownFunction() {
	    String soapRequest = "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" +
		    "<soap:Body>" +
		    "<request><unknownFunction>testFunction</unknownFunction></request>" +
		    "</soap:Body>" +
		    "</soap:Envelope>";
	    String functionName = XmlUtil.extractFunctionName(soapRequest);
	    Assert.assertEquals("Unknown fonction", functionName);
	}
}
