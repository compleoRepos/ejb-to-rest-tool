package ma.eai.boa.xbanking.dto.Beneficiaire;


import com.fasterxml.jackson.annotation.JsonProperty;
import ma.eai.boa.xbanking.entities.Nationality;
import javax.persistence.Column;
import javax.persistence.Lob;
import java.io.Serializable;

public class BeneficiaireRequest implements Serializable {

    private static final long serialVersionUID = 5579127704481858758L;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("firstName")
    private String firstName;

    private String iban;

    private String bank;

    private String relationFamiliale;

    private String rib;

    private String country;

    @Column(columnDefinition = "TEXT")
    @Lob  // Large Object annotation
    private String attestationRib;

    public String getLastName() {
	return lastName;
    }

    public void setLastName(String lastName) {
	this.lastName = lastName;
    }

    public String getFirstName() {
	return firstName;
    }

    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }

    public String getIban() {
	return iban;
    }

    public void setIban(String iban) {
	this.iban = iban;
    }

    public String getBank() {
	return bank;
    }

    public void setBank(String bank) {
	this.bank = bank;
    }

    public String getRelationFamiliale() {
	return relationFamiliale;
    }

    public void setRelationFamiliale(String relationFamiliale) {
	this.relationFamiliale = relationFamiliale;
    }

    public String getRib() {
	return rib;
    }

    public void setRib(String rib) {
	this.rib = rib;
    }

    public String getCountry() {
	return country;
    }

    public void setCountry(String country) {
	this.country = country;
    }

    public String getAttestationRib() {
	return attestationRib;
    }

    public void setAttestationRib(String attestationRib) {
	this.attestationRib = attestationRib;
    }
}
