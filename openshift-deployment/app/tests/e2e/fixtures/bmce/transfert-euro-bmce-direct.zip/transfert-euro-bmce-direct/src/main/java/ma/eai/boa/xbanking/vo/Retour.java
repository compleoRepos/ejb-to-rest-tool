package ma.eai.boa.xbanking.vo;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Retour")
public class Retour {
    private String code;

    private String message;

    @XmlElement
    public String getCode() {
	return code;
    }

    public void setCode(String code) {
	this.code = code;
    }
    @XmlElement
    public String getMessage() {
	return message;
    }

    public void setMessage(String message) {
	this.message = message;
    }

    @Override
    public String toString() {
	return "Retour{" + "code='" + code + '\'' + ", message='" + message + '\'' + '}';
    }
}
