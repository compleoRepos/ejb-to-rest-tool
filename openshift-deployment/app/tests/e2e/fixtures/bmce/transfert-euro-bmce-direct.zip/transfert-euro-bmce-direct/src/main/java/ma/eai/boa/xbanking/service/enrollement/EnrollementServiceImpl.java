package ma.eai.boa.xbanking.service.enrollement;

import com.fasterxml.jackson.databind.ObjectMapper;
import ma.eai.boa.xbanking.dto.enrollement.CheckInfoRequest;
import ma.eai.boa.xbanking.dto.enrollement.IbanRequest;
import ma.eai.boa.xbanking.dto.enrollement.EnrollementRequest;
import ma.eai.boa.xbanking.dto.enrollement.ValidatDataResponse;
import ma.eai.boa.xbanking.entities.IbanAttempt;
import ma.eai.boa.xbanking.entities.User;
import ma.eai.boa.xbanking.repository.UserRepository;
import ma.eai.boa.xbanking.repository.enrollement.IbanAttemptsRepository;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.util.JwtUtil;
import ma.eai.boa.xbanking.vo.enrollement.CheckIbanOut;
import ma.eai.boa.xbanking.vo.enrollement.CheckIbenIn;
import ma.eai.boa.xbanking.util.Utils;
import ma.eai.boa.xbanking.vo.enrollement.CheckInfoIn;
import ma.eai.boa.xbanking.vo.enrollement.CheckInfoOut;
import ma.eai.boa.xbanking.vo.enrollement.EnrollementValidationIn;
import ma.eai.boa.xbanking.vo.enrollement.EnrollementValidationOut;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.xml.bind.DatatypeConverter;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Calendar;

@Service
public class EnrollementServiceImpl implements EnrollementService {

    private static final String SUCCESS_CODE = "SUCCESS_CODE";
    private static final String IBAN_NEEDED = "IBAN_NEEDED";
    private static final String DATA_NOT_VALID = "DATA_NOT_VALID";
    private static final String USER_ALREADY_ACTIVATED = "USER_ALREADY_ACTIVATED";
    private static final String UNKNOWN_ERROR = "UNKNOWN_ERROR";
    private static final int MAX_ATTEMPTS = 3;
    private static final int BLOCKED_TIME_MINUTES = Constants.BLOCKED_TIME_MINUTES;
    private static final String TBAN_EXCEEDED = "TBAN_EXCEEDED";
    private static final String EXCEEDED_MESSAGE = "Check IBAN Exceeded";
    private static final List<String> TRACKED_ERROR_CODES = Arrays.asList(
	    "IBAN_NOT_FOUND",
	    "ERR_USER_NOT_FOUND",
	    DATA_NOT_VALID,
	    USER_ALREADY_ACTIVATED,
	    "ERR_USER_PHONE_EXIST",
	    "ERR_USER_EMAIL_EXIST"
    );

    @Value("${api.url}")
    public String urlApi;

    private final RestTemplate restTemplate;
    private final IbanAttemptsRepository ibanAttemptsRepository;
    private final UserRepository userRepository;

    public EnrollementServiceImpl(RestTemplate restTemplate, IbanAttemptsRepository ibanAttemptsRepository,
	    UserRepository userRepository) {
		this.restTemplate = restTemplate;
		this.ibanAttemptsRepository = ibanAttemptsRepository;
	this.userRepository = userRepository;
    }

    @Override
    public CheckInfoOut checkInfos(CheckInfoIn checkInfoIn) {
	CheckInfoOut checkInfoOut = new CheckInfoOut();
	try {

	    CheckInfoRequest checkInfoRequest = new CheckInfoRequest();
	    checkInfoRequest.setBirthDate(checkInfoIn.getBirthDate());
	    checkInfoRequest.setFirstName(checkInfoIn.getFirstName());
	    checkInfoRequest.setCallingCode(checkInfoIn.getCallingCode());
	    checkInfoRequest.setCountryCode(checkInfoIn.getCountryCode());
	    checkInfoRequest.setLastName(checkInfoIn.getLastName());
	    checkInfoRequest.setDeviceId(checkInfoIn.getDeviceId());
	    checkInfoRequest.setPhoneNumber(checkInfoIn.getPhoneNumber());
	    checkInfoRequest.setLastName(checkInfoIn.getLastName());

	    String url = new StringBuilder(urlApi)
		    .append("enrollement/checkInfo")
		    .toString();
	    EaiLog.info("url appel: {}" + url);

	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    //TO DO : verifier l'envoi de token !
	    headers.set(HttpHeaders.AUTHORIZATION, checkInfoIn.getToken());
	    headers.set(Constants.CANAL_HEADER, Constants.CANAL);
	    ObjectMapper objectMapper = new ObjectMapper();

	    String jsonRequest = objectMapper.writeValueAsString(checkInfoRequest);
	    EaiLog.info("jsonRequest==================>:{}" + jsonRequest);
	    EaiLog.info("headers==================>:{}" + headers);

	    HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, headers);
	    EaiLog.info("requestEntity==========>:{}", requestEntity);

	    ResponseEntity<ValidatDataResponse> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
		    ValidatDataResponse.class);
	    ValidatDataResponse responseDTO = response.getBody();
	    EaiLog.info("responseDTO =====:{}", responseDTO != null ? responseDTO.getCode() : "null");

	    if (responseDTO != null && SUCCESS_CODE.equals(responseDTO.getCode())) {
		EaiLog.info("=====Appel success=====");
		checkInfoOut.setCode(Constants.CODE_SUCCESS);
		checkInfoOut.setMessage("OK");
		checkInfoOut.setPhone(responseDTO.getPhone());
		checkInfoOut.setClient(responseDTO.isClient());
		checkInfoOut.setCompleted(responseDTO.isCompleted());
		checkInfoOut.setUuid(responseDTO.getUuid());
		checkInfoOut.setLang(responseDTO.getLang());
		checkInfoOut.setNombreNotifs(responseDTO.getNombreNotifs());
		checkInfoOut.setUuidKey(responseDTO.getUuidKey());
		checkInfoOut.setOtpID(responseDTO.getOtpID());
		checkInfoOut.setEmail(responseDTO.getEmail());
		
	    } else if (responseDTO != null && IBAN_NEEDED.equals(responseDTO.getCode())) {
		EaiLog.info("===== Appel success IBAN_NEEDED =====");
		checkInfoOut.setCode(IBAN_NEEDED);
		checkInfoOut.setMessage("Rediriger vers la page de check EBAN");
	    } else {
		EaiLog.info("=================Appel ERREUR================");
		String errorCode = (responseDTO != null && responseDTO.getCode() != null) ? responseDTO.getCode() : UNKNOWN_ERROR;
		EaiLog.info("==============Code Erreur =============: {}",errorCode);
		checkInfoOut.setCode(errorCode);
		checkInfoOut.setMessage(getErrorMessageCheckInfo(errorCode));
	    }
	    EaiLog.info("Fin service checkInfos");
	} catch (Exception e) {
	    EaiLog.info("Une erreur inconnue est survenue : {}" + e);
	    checkInfoOut.setCode(Constants.CODE_ERROR);
	    checkInfoOut.setMessage("Une erreur inconnue est survenue lors de l'appel à l'API BES.");
	}
	return checkInfoOut;
    }


    @Override
    public CheckIbanOut checkIban(CheckIbenIn checkIbenIn) {
	CheckIbanOut checkIbanOut = new CheckIbanOut();
	try {
	    // Récupérer les informations pour générer une clé unique
	    CheckInfoRequest checkInfo = checkIbenIn.getCheckInfoRequest();
	    String lastName = checkInfo.getLastName();
	    String firstName = checkInfo.getFirstName();
	    Date birthDate = checkInfo.getBirthDate();
	    String phoneNumber = checkInfo.getPhoneNumber();

	    if (lastName == null || firstName == null || birthDate == null || phoneNumber == null) {
		EaiLog.error("Missing required fields: lastName, firstName, birthDate, or phoneNumber");
		checkIbanOut.setCode(Constants.CODE_ERROR);
		checkIbanOut.setMessage("Required fields are missing");
		return checkIbanOut;
	    }

	    String attemptKey = generateAttemptKey(lastName, firstName, birthDate, phoneNumber);
	    EaiLog.info("Generated attempt key: {}", attemptKey);

	    IbanAttempt ibanAttempt = ibanAttemptsRepository.findById(attemptKey)
		    .orElseGet(() -> createFirstIbanAttempt(attemptKey));

	    if (isUserBlocked(ibanAttempt)) {
		EaiLog.info("User blocked after IBAN check attempts:{}", MAX_ATTEMPTS);
		checkIbanOut.setCode(TBAN_EXCEEDED);
		checkIbanOut.setMessage(EXCEEDED_MESSAGE);
		return checkIbanOut;
	    }

	    IbanRequest ibanRequest = new IbanRequest();
	    CheckInfoRequest checkInfoRequest = new CheckInfoRequest();
	    checkInfoRequest.setBirthDate(checkIbenIn.getCheckInfoRequest().getBirthDate());
	    checkInfoRequest.setFirstName(checkIbenIn.getCheckInfoRequest().getFirstName());
	    checkInfoRequest.setCallingCode(checkIbenIn.getCheckInfoRequest().getCallingCode());
	    checkInfoRequest.setCountryCode(checkIbenIn.getCheckInfoRequest().getCountryCode());
	    checkInfoRequest.setLastName(checkIbenIn.getCheckInfoRequest().getLastName());
	    checkInfoRequest.setDeviceId(checkIbenIn.getDeviceId());
	    checkInfoRequest.setPhoneNumber(checkIbenIn.getCheckInfoRequest().getPhoneNumber());
	    checkInfoRequest.setLastName(checkIbenIn.getCheckInfoRequest().getLastName());
	    ibanRequest.setCheckInfoRequest(checkInfoRequest);
	    ibanRequest.setIban(checkIbenIn.getIban());
	    ibanRequest.setDeviceId(checkIbenIn.getDeviceId());

	    String url = new StringBuilder(urlApi)
		    .append("enrollement/checkIban")
		    .toString();
	    EaiLog.info("url appel: {}" + url);

	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.set(HttpHeaders.AUTHORIZATION, checkIbenIn.getToken());
	    headers.set(Constants.CANAL_HEADER, Constants.CANAL);
	    ObjectMapper objectMapper = new ObjectMapper();
	    String jsonRequest = objectMapper.writeValueAsString(ibanRequest);
	    EaiLog.info("jsonRequest==================>:{}" + jsonRequest);
	    EaiLog.info("headers==================>:{}" + headers);

	    HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, headers);
	    EaiLog.info("requestEntity==========>:{}", requestEntity);

	    ResponseEntity<ValidatDataResponse> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
		    ValidatDataResponse.class);
	    ValidatDataResponse responseDTO = response.getBody();
	    EaiLog.info("responseDTO =====:{}", responseDTO != null ? responseDTO.getCode() : "null");

	    if (responseDTO != null && SUCCESS_CODE.equals(responseDTO.getCode())) {
		EaiLog.info("Appel success=====");
		checkIbanOut.setCode(responseDTO.getCode());
		checkIbanOut.setMessage("OK");
		checkIbanOut.setPhone(responseDTO.getPhone());
		checkIbanOut.setClient(responseDTO.isClient());
		checkIbanOut.setCompleted(responseDTO.isCompleted());
		checkIbanOut.setUuid(responseDTO.getUuid());
		checkIbanOut.setLang(responseDTO.getLang());
		checkIbanOut.setNombreNotifs(responseDTO.getNombreNotifs());
		checkIbanOut.setUuidKey(responseDTO.getUuidKey());
		checkIbanOut.setOtpID(responseDTO.getOtpID());
		checkIbanOut.setEmail(responseDTO.getEmail());
	    } else {
		EaiLog.info("======Appel ERREUR=====");
		String errorCode = (responseDTO != null && responseDTO.getCode() != null) ? responseDTO.getCode() : UNKNOWN_ERROR;
		EaiLog.info("======Appel ERREUR=====:{}",errorCode);
		checkIbanOut.setCode(errorCode); // Assigner le code d'erreur retourné
		checkIbanOut.setMessage(getErrorMessage(errorCode));
		if (TRACKED_ERROR_CODES.contains(errorCode)) {
		    EaiLog.info("Tracking attempt for error code: {}", errorCode);
		    updateIbanAttempt(ibanAttempt);
		    ibanAttemptsRepository.save(ibanAttempt);
		}
	    }
	    EaiLog.info("--------------Fin service checkIban-----------------");
	} catch (Exception e) {
	    EaiLog.info("Une erreur inconnue est survenue : {}" + e);
	    checkIbanOut.setCode(Constants.CODE_ERROR);
	    checkIbanOut.setMessage("Une erreur inconnue est survenue lors de l'appel à l'API BES.");
	}
	return checkIbanOut;
    }
    private String getErrorMessageCheckInfo(String errorCode) {
	Map<String, String> errorMessages = new HashMap<>();
	errorMessages.put("ERR_DATA_EMPTY", "Certains champs obligatoires sont vides.");
	errorMessages.put("ERR_TECHNICAL", "Une erreur technique est survenue.");
	errorMessages.put("SERVICE_UNAVAILABLE", "Ce service n’est pas disponible dans votre pays.");
	errorMessages.put(DATA_NOT_VALID, "Les informations saisies ne sont pas valides.");
	errorMessages.put(IBAN_NEEDED, "Rediriger vers la page de check EBAN");
	errorMessages.put(USER_ALREADY_ACTIVATED, "Cet utilisateur a déjà été activé.");
	errorMessages.put("ERR_USER_DISABLED", "Ce compte utilisateur a été désactivé.");
	errorMessages.put(UNKNOWN_ERROR, "Erreur inconnue survenue lors de l'appel à l'API.");

	return errorMessages.getOrDefault(errorCode, "ERREUR API BES: " + errorCode);
    }
    // Méthode pour mapper les codes d'erreur aux messages
    private String getErrorMessage(String errorCode) {
	Map<String, String> errorMessages = new HashMap<>();
	errorMessages.put("IBAN_NOT_FOUND", "L'IBAN saisi est introuvable.");
	errorMessages.put("ERR_USER_DISABLED", "Ce compte utilisateur a été désactivé.");
	errorMessages.put("ERR_USER_NOT_FOUND", "Aucun utilisateur ne correspond aux informations fournies.");
	errorMessages.put("ERR_TECHNICAL", "Une erreur technique est survenue.");
	errorMessages.put("SERVICE_UNAVAILABLE", "Ce service n’est pas disponible dans votre pays.");
	errorMessages.put(DATA_NOT_VALID, "Les données saisies sont invalides. Merci de les vérifier.");
	errorMessages.put("ERR_DATA_EMPTY", "Certains champs sont vides.");
	errorMessages.put(USER_ALREADY_ACTIVATED, "Cet utilisateur est déjà activé.");
	errorMessages.put("CARD_IDENTITY_EXPIRED", "La pièce d'identité est expirée.");
	errorMessages.put("ERR_USER_PHONE_EXIST", "Ce numéro de téléphone est déjà associé à un autre compte.");
	errorMessages.put("ERR_USER_EMAIL_EXIST", "Cette adresse email est déjà utilisée.");
	errorMessages.put(UNKNOWN_ERROR, "Erreur inconnue survenue lors de l'appel à l'API.");

	return errorMessages.getOrDefault(errorCode, "ERREUR API BES: " + errorCode);
    }
    @Override
    public EnrollementValidationOut activateUser(EnrollementValidationIn enrollementValidationIn) {
		EaiLog.info("Start service enrollement activation user : {}", enrollementValidationIn.toString());

		EnrollementValidationOut enrollementValidationOut = new EnrollementValidationOut();
		try {

        EnrollementRequest enrollementRequest = new EnrollementRequest();
		enrollementRequest.setEmail(enrollementValidationIn.getEmail());
		enrollementRequest.setUuid(enrollementValidationIn.getUuid());
		enrollementRequest.setPassword(Utils.generateRandomString());

		String url = new StringBuilder(urlApi)
					 .append("enrollement/validate")
					 .toString();
		EaiLog.info("url appel: {} ",url);
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		httpHeaders.set(Constants.CANAL_HEADER, Constants.CANAL);
		HttpEntity<EnrollementRequest> httpEntity = new HttpEntity<>(enrollementRequest, httpHeaders);
		EaiLog.info("Request body : {}", enrollementRequest.toString());

		ResponseEntity<ValidatDataResponse> response = restTemplate.exchange(url, HttpMethod.POST, httpEntity,
					ValidatDataResponse.class);
		EaiLog.info("Response Status : {}", response.getStatusCodeValue());
		EaiLog.info("Response : {}", response);
		ValidatDataResponse body = response.getBody();

		    if (response.getBody() != null && SUCCESS_CODE.equals(response.getBody().getCode())) {
			EaiLog.info("Success call, Response body : {}", response.getBody());
			enrollementValidationOut.setClient(body.isClient());
			enrollementValidationOut.setCompleted(body.isCompleted());
			enrollementValidationOut.setUuid(body.getUuid());
			enrollementValidationOut.setOtpID(body.getOtpID());

			User existingUser = userRepository.findByContratBad(enrollementValidationIn.getContratBad());

			if (existingUser != null) {
			    EaiLog.info("User already exists for this contratBad: {} or email: {}",
				    enrollementValidationIn.getContratBad(), enrollementValidationIn.getEmail());
			    existingUser.setContratBad("___" + existingUser.getContratBad());
			    existingUser.setEmail("___" + existingUser.getEmail());
			    userRepository.save(existingUser);
			    EaiLog.info("Updated existing user: contratBad={}, email={}",
				    existingUser.getContratBad(), existingUser.getEmail());

			    User user = new User();
			    user.setEmail(enrollementValidationIn.getEmail());
			    user.setUuid(body.getUuid());
			    user.setContratBad(enrollementValidationIn.getContratBad());
			    user.setStep(existingUser.getStep());
			    user.setPhone(existingUser.getPhone());
                user.setCountryCode(body.getLang());
			    userRepository.save(user);
			    enrollementValidationOut.setCode(Constants.CODE_SUCCESS);
			    enrollementValidationOut.setMessage("OK");
			    EaiLog.info("User saved with success: {}", enrollementValidationIn.getEmail());
			} else {
			    User user = new User();
			    user.setEmail(enrollementValidationIn.getEmail());
			    user.setUuid(body.getUuid());
			    user.setContratBad(enrollementValidationIn.getContratBad());
				user.setPhone(body.getPhone());
				user.setCountryCode(body.getLang());
			    userRepository.save(user);
			    enrollementValidationOut.setCode(Constants.CODE_SUCCESS);
			    enrollementValidationOut.setMessage("OK");
			    EaiLog.info("User saved with success: {}", enrollementValidationIn.getEmail());
			}
		    } else {
			EaiLog.info("Error calling activation enrollement , email : {}",enrollementRequest.getEmail());
			enrollementValidationOut.setCode(Constants.CODE_ERROR);
			enrollementValidationOut.setMessage(body != null ? body.getCode() : Constants.RESPONSE_EMPTY);
		}
	} catch (Exception e) {
		EaiLog.info("Error calling WS BES enrollement activation : {}", e);
		enrollementValidationOut.setCode(Constants.CODE_ERROR);
		enrollementValidationOut.setMessage(Constants.TECHNICAL_ERROR);
	}
		EaiLog.info("End service enrollement activation user : {}",enrollementValidationIn.getEmail());
		return enrollementValidationOut;
	}

    private IbanAttempt createFirstIbanAttempt(String attemptKey) {
	EaiLog.info("First IBAN check attempt for key: {}", attemptKey);
	IbanAttempt ibanAttempt = new IbanAttempt();
	ibanAttempt.setAttemptKey(attemptKey);
	ibanAttempt.setIbanAttemptNumber(0);
	ibanAttempt.setLastIbanAttemptDate(new Date());
	return ibanAttempt;
    }

    private boolean isUserBlocked(IbanAttempt ibanAttempt) {
	if (ibanAttempt.getIbanAttemptNumber() < MAX_ATTEMPTS) {
	    return false;
	}

	Calendar cal = Calendar.getInstance();
	cal.setTime(ibanAttempt.getLastIbanAttemptDate());
	cal.add(Calendar.MINUTE, BLOCKED_TIME_MINUTES);
	Date now = new Date();

	EaiLog.info("Number of IBAN attempts: {}, before authorized break: {}",
		ibanAttempt.getIbanAttemptNumber(), now.before(cal.getTime()));

	return now.before(cal.getTime());
    }

    private void updateIbanAttempt(IbanAttempt ibanAttempt) {
	EaiLog.info("==========updateIbanAttempt==========");
	ibanAttempt.setLastIbanAttemptDate(new Date());
	ibanAttempt.setIbanAttemptNumber(
		ibanAttempt.getIbanAttemptNumber() < MAX_ATTEMPTS
			? ibanAttempt.getIbanAttemptNumber() + 1
			: 1
	);
    }

    public String generateAttemptKey(String lastName, String firstName, Date birthDate, String phoneNumber) {
	try {
	    String input = lastName.toLowerCase() + "|" + firstName.toLowerCase() + "|" + birthDate + "|" + phoneNumber;
	    MessageDigest digest = MessageDigest.getInstance("SHA-256");
	    byte[] hash = digest.digest(input.getBytes("UTF-8"));
	    return DatatypeConverter.printHexBinary(hash).toLowerCase();
	} catch (Exception e) {
	    EaiLog.error("Error generating attempt key: {}", e.getMessage());
	    throw new RuntimeException("Failed to generate attempt key: {}", e);
	}
    }


}
