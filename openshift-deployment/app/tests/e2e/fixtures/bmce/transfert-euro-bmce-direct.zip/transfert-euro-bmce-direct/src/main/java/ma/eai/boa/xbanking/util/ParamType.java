package ma.eai.boa.xbanking.util;

public enum ParamType {

    ACTIVITY_AREAS,
    BANKS,
    COUNTRIES,
    PROFESSIONS,
    NATIONALITIES,
    PERIODICITIES,
    FUNDS_SOURCES,
    RELATIONSSHIP,
    DOC_TYPES,
    TRANSFERT_MOTIFS,
    FREQUENCIES,
    TRANCHES
    }
