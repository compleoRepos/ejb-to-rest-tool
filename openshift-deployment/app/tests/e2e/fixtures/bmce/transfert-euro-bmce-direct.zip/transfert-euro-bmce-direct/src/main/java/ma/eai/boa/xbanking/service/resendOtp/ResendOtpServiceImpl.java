package ma.eai.boa.xbanking.service.resendOtp;

import com.fasterxml.jackson.databind.ObjectMapper;
import ma.eai.boa.xbanking.dto.createaccountphonenumber.PhoneNumberRequest;
import ma.eai.boa.xbanking.dto.validateOtp.ResendOtpEerRequest;
import ma.eai.boa.xbanking.dto.validateOtp.ResendOtpResponse;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.util.JwtUtil;
import ma.eai.boa.xbanking.vo.Retour;
import ma.eai.boa.xbanking.vo.validationOtp.ResendOtpOut;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.ws.rs.core.Request;

@Service
public class ResendOtpServiceImpl implements ResendOtpService {


    private static final String SUCCESS_CODE = "SUCCESS_CODE";
    private final JwtUtil jwtUtil;

    private final RestTemplate restTemplate;

    @Value("${api.url}")
    public String urlApi;

    public ResendOtpServiceImpl(JwtUtil jwtUtil, RestTemplate restTemplate) {
        this.jwtUtil = jwtUtil;
        this.restTemplate = restTemplate;
    }

    @Override
    public ResendOtpOut resendOtp(String token) {
        EaiLog.info("Start Service resend Otp for : {}", jwtUtil.getUsernameFromToken(token));

        ResendOtpOut resendOtpOut = new ResendOtpOut();

        try {


            String url = urlApi.concat("reset/resendOtp");

            EaiLog.info("called url : {}", url);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set(HttpHeaders.AUTHORIZATION,token);
            headers.set(Constants.CANAL_HEADER, Constants.CANAL);

            HttpEntity requestEntity = new HttpEntity<>(null,headers);

            ResponseEntity<ResendOtpResponse> response = restTemplate.exchange(url, HttpMethod.POST,
                    requestEntity,ResendOtpResponse.class);
            EaiLog.info("Response Status : {}", response.getStatusCodeValue());
            EaiLog.info("Response : {}", response);

            ResendOtpResponse body = response.getBody();
                if(body != null && SUCCESS_CODE.equals(response.getBody().getCode())) {
                    EaiLog.info("Success call , Response body : {}", response.getBody());
                    resendOtpOut.setTransactionId(body.getTransactionId());
                    resendOtpOut.setStatus(body.getStatus());
                    resendOtpOut.setCode(Constants.CODE_SUCCESS);
                    resendOtpOut.setMessage("OK");
                } else {
                    EaiLog.info("Error calling resend Otp, username : {}",jwtUtil.getUsernameFromToken(token));
                    resendOtpOut.setCode(Constants.CODE_ERROR);
                    resendOtpOut.setMessage(body != null ? body.getCode() : "Empty response");
                }
            } catch (Exception e) {
            EaiLog.error("Error on calling BES WS : {}", e);
            resendOtpOut.setCode(Constants.CODE_ERROR);
            resendOtpOut.setMessage(Constants.TECHNICAL_ERROR);
        }
        EaiLog.info("End service resend OTP");
        return resendOtpOut;
    }

    @Override
    public Retour resendOtpEer(String otpID) {
        EaiLog.info("Start Service resend Otp for : {}", otpID);

        Retour resendOtpEerOut = new Retour();
        ResendOtpEerRequest resendOtpEerRequest = new ResendOtpEerRequest();
        resendOtpEerRequest.setOtpID(otpID);
        try {

            String url = urlApi.concat("reset/resend");

            EaiLog.info("called url : {}", url);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set(Constants.CANAL_HEADER, Constants.CANAL);
            ObjectMapper objectMapper = new ObjectMapper();

            String jsonRequest = objectMapper.writeValueAsString(resendOtpEerRequest);
            HttpEntity requestEntity = new HttpEntity<>(jsonRequest,headers);

            ResponseEntity<Retour> response = restTemplate.exchange(url, HttpMethod.POST,
                    requestEntity,Retour.class);
            EaiLog.info("Response Status : {}", response.getStatusCodeValue());
            EaiLog.info("Response : {}", response);
            Retour body = response.getBody();
            if(body != null && SUCCESS_CODE.equals(response.getBody().getCode())) {
                EaiLog.info("Success call , Response body : {}", response.getBody());
                resendOtpEerOut.setCode(Constants.CODE_SUCCESS);
                resendOtpEerOut.setMessage("OK");
            } else {
                EaiLog.info("Error calling resend Otp, username : {}",otpID);
                resendOtpEerOut.setCode(Constants.CODE_ERROR);
                resendOtpEerOut.setMessage(body != null ? body.getCode() : Constants.RESPONSE_EMPTY);
            }
        } catch (Exception e) {
            EaiLog.error("Error on calling BES WS : {}", e);
            resendOtpEerOut.setCode(Constants.CODE_ERROR);
            resendOtpEerOut.setMessage(Constants.TECHNICAL_ERROR);
        }
        EaiLog.info("End service resend OTP");
        return resendOtpEerOut;
    }
}
