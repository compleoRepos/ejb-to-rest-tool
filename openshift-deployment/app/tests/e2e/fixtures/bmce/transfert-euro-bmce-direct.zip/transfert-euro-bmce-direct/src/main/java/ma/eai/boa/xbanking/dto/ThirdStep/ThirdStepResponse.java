package ma.eai.boa.xbanking.dto.ThirdStep;

import ma.eai.boa.xbanking.vo.Retour;

public class ThirdStepResponse extends Retour {
}
