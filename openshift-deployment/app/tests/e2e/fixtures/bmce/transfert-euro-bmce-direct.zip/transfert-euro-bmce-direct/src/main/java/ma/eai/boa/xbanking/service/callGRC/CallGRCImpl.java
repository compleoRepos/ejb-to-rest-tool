package ma.eai.boa.xbanking.service.callGRC;

import grc.beans.SouscriptionMobilePayment;
import ma.eai.boa.xbanking.vo.callGRC.CallGrcIn;
import ma.eai.boa.xbanking.vo.callGRC.CallGrcOut;
import ma.eai.ingdev.fwk.logging.EaiLog;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Arrays;
import ma.eai.boa.xbanking.vo.callGRC.Account;
import java.util.ArrayList;
import java.util.List;

@Service
public class CallGRCImpl implements CallGRC {
    @Autowired
    GrcConnector grcConnector;

    public CallGrcOut getInfosClient(CallGrcIn callGrcIn) {

	validateInput(callGrcIn);

	CallGrcOut callGrcOut = new CallGrcOut();
	EaiLog.info("================>callGrcIn: {}", callGrcIn);

	try {
	    SouscriptionMobilePayment retourGrc = grcConnector.getInfoGrc(callGrcIn.getIdClient(), "T");
	    return processGrcResponse(retourGrc, callGrcIn.getIdClient(), callGrcOut);
	} catch (Exception e) {
	    EaiLog.info("Error while processing GRC request for client ID: {} " + callGrcIn.getIdClient(), e);
	   return createErrorResponse(callGrcOut, "ERR_TECHNICAL", "111");
	}
    }

    private CallGrcOut createErrorResponse(CallGrcOut callGrcOut, String message, String code) {
	callGrcOut.setMessage(message);
	callGrcOut.setCode(code);
	return callGrcOut;
    }

    private void validateInput(CallGrcIn callGrcIn) {
	if (callGrcIn == null || callGrcIn.getIdClient() == null || callGrcIn.getIdClient().isEmpty()) {
	    EaiLog.info("Input parameter callGrcIn or idClient is null or empty");
	    throw new IllegalArgumentException("L'identifiant client est requis");
	}
    }
    private CallGrcOut processGrcResponse(SouscriptionMobilePayment retourGrc, String clientId, CallGrcOut callGrcOut) {
	if (retourGrc == null) {
	    EaiLog.info("No response received from GRC connector");
	    return createErrorResponse(callGrcOut, "ERR_TECHNICAL", "111");
	}

	if (retourGrc.getCustomers() == null || retourGrc.getCustomers().length == 0) {
	    EaiLog.info("No customer data found for client ID: " + clientId);
	    return createErrorResponse(callGrcOut, "NO_CUSTOMER_DATA_FOUND", "111");
	}
	else {
	    callGrcOut.setNomClient(retourGrc.getCustomers()[0].getNomClient() != null ?
		    retourGrc.getCustomers()[0].getNomClient() : "");
	    callGrcOut.setPrenomClient(retourGrc.getCustomers()[0].getPrenomClient() != null ?
		    retourGrc.getCustomers()[0].getPrenomClient() : "");
	    callGrcOut.setAdresse(retourGrc.getCustomers()[0].getAddr2() != null ?
		    retourGrc.getCustomers()[0].getAddr2() : "");
	    callGrcOut.setDateNaissance(retourGrc.getCustomers()[0].getDateNaissance());
	    callGrcOut.setNatoinality(retourGrc.getCustomers()[0].getNATIONALITE());
	    callGrcOut.setCodePaysResid(retourGrc.getCustomers()[0].getCodePaysResid());
	    callGrcOut.setNumTelephone(retourGrc.getCustomers()[0].getNumGsm());
	    callGrcOut.setVille(retourGrc.getCustomers()[0].getVille());
	    callGrcOut.setPaysNaissance(retourGrc.getCustomers()[0].getLIEU_NAISSANCE());

	    Account account = new Account();
	    List<String> numComptes = new ArrayList<>();

	    if (retourGrc.getAccounts() != null && retourGrc.getAccounts().length > 0) {
		Arrays.stream(retourGrc.getAccounts())
			.filter(element -> element != null && element.getNumCpt() != null)
			.forEach(element -> numComptes.add(element.getNumCpt()));
	    }

	    account.setRib(numComptes);
	    callGrcOut.setAccount(account);
	    createErrorResponse(callGrcOut, "OK", "000");
	}
	callGrcOut.setMessage("OK");
	callGrcOut.setCode("000");
	return callGrcOut;
    }

}