package ma.eai.boa.xbanking.dto.transfert;

import com.fasterxml.jackson.annotation.JsonProperty;
import ma.eai.boa.xbanking.entities.User;
import ma.eai.boa.xbanking.util.Status;

import java.io.Serializable;
import java.sql.Timestamp;

public class Transfer implements Serializable {

    private static final long serialVersionUID = 6665824866726873992L;

    private String ibanBeneficiaire;

    @JsonProperty("beneficiaryLastName")
    private String nomBeneficiaire;

    @JsonProperty("beneficiaryFirstName")
    private String prenomBeneficiaire;

    private double amountToSend;

    private double amountNetToSend;

    private float tauxChange;

    private double amountToReceive;

    private int delaiToTransfert;

    private String bankName;

    @JsonProperty("numCompteBes")
    private String numCompteBes;

    private Status status;


    private User user;

    private float tauxChangeAmplitude;

    private String dateInsertedAmplitude;

    @JsonProperty("transferMode")
    private ModeTransfert modeTransfert;

    private float commission;

    @JsonProperty ("dateReceiveMoney")
    private String dateReceiveMoney;

    @JsonProperty ("dateSendMoney")
    private String dateSendMoney;

    @JsonProperty ("dateFinalStatus")
    private String dateFinalStatus;

    private String firstName;

    private String lastName;

    private String refBank;

    private String country;

    private boolean sentToAmplitude;

    private String ribBeneficiaire;

    private String signature;

    private String version;

    private String params;

    private String compteClient;

    private String urlReturned;

    private boolean cardPassed;

    private boolean cardGeneratedWebView;

    private String codTransaction;

    public String getIbanBeneficiaire() {
        return ibanBeneficiaire;
    }

    public void setIbanBeneficiaire(String ibanBeneficiaire) {
        this.ibanBeneficiaire = ibanBeneficiaire;
    }

    public String getNomBeneficiaire() {
        return nomBeneficiaire;
    }

    public void setNomBeneficiaire(String nomBeneficiaire) {
        this.nomBeneficiaire = nomBeneficiaire;
    }

    public String getPrenomBeneficiaire() {
        return prenomBeneficiaire;
    }

    public void setPrenomBeneficiaire(String prenomBeneficiaire) {
        this.prenomBeneficiaire = prenomBeneficiaire;
    }

    public double getAmountToSend() {
        return amountToSend;
    }

    public void setAmountToSend(double amountToSend) {
        this.amountToSend = amountToSend;
    }

    public double getAmountNetToSend() {
        return amountNetToSend;
    }

    public void setAmountNetToSend(double amountNetToSend) {
        this.amountNetToSend = amountNetToSend;
    }

    public float getTauxChange() {
        return tauxChange;
    }

    public void setTauxChange(float tauxChange) {
        this.tauxChange = tauxChange;
    }

    public double getAmountToReceive() {
        return amountToReceive;
    }

    public void setAmountToReceive(double amountToReceive) {
        this.amountToReceive = amountToReceive;
    }

    public int getDelaiToTransfert() {
        return delaiToTransfert;
    }

    public void setDelaiToTransfert(int delaiToTransfert) {
        this.delaiToTransfert = delaiToTransfert;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getNumCompteBes() {
        return numCompteBes;
    }

    public void setNumCompteBes(String numCompteBes) {
        this.numCompteBes = numCompteBes;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public float getTauxChangeAmplitude() {
        return tauxChangeAmplitude;
    }

    public void setTauxChangeAmplitude(float tauxChangeAmplitude) {
        this.tauxChangeAmplitude = tauxChangeAmplitude;
    }

    public String getDateInsertedAmplitude() {
        return dateInsertedAmplitude;
    }

    public void setDateInsertedAmplitude(String dateInsertedAmplitude) {
        this.dateInsertedAmplitude = dateInsertedAmplitude;
    }

    public ModeTransfert getModeTransfert() {
        return modeTransfert;
    }

    public void setModeTransfert(ModeTransfert modeTransfert) {
        this.modeTransfert = modeTransfert;
    }

    public float getCommission() {
        return commission;
    }

    public void setCommission(float commission) {
        this.commission = commission;
    }

    public String getDateReceiveMoney() {
        return dateReceiveMoney;
    }

    public void setDateReceiveMoney(String dateReceiveMoney) {
        this.dateReceiveMoney = dateReceiveMoney;
    }

    public String getDateSendMoney() {
        return dateSendMoney;
    }

    public void setDateSendMoney(String dateSendMoney) {
        this.dateSendMoney = dateSendMoney;
    }

    public String getDateFinalStatus() {
        return dateFinalStatus;
    }

    public void setDateFinalStatus(String dateFinalStatus) {
        this.dateFinalStatus = dateFinalStatus;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getRefBank() {
        return refBank;
    }

    public void setRefBank(String refBank) {
        this.refBank = refBank;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public boolean isSentToAmplitude() {
        return sentToAmplitude;
    }

    public void setSentToAmplitude(boolean sentToAmplitude) {
        this.sentToAmplitude = sentToAmplitude;
    }

    public String getRibBeneficiaire() {
        return ribBeneficiaire;
    }

    public void setRibBeneficiaire(String ribBeneficiaire) {
        this.ribBeneficiaire = ribBeneficiaire;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params;
    }

    public String getCompteClient() {
        return compteClient;
    }

    public void setCompteClient(String compteClient) {
        this.compteClient = compteClient;
    }

    public String getUrlReturned() {
        return urlReturned;
    }

    public void setUrlReturned(String urlReturned) {
        this.urlReturned = urlReturned;
    }

    public boolean isCardPassed() {
        return cardPassed;
    }

    public void setCardPassed(boolean cardPassed) {
        this.cardPassed = cardPassed;
    }

    public boolean isCardGeneratedWebView() {
        return cardGeneratedWebView;
    }

    public void setCardGeneratedWebView(boolean cardGeneratedWebView) {
        this.cardGeneratedWebView = cardGeneratedWebView;
    }

    public String getCodTransaction() {
        return codTransaction;
    }

    public void setCodTransaction(String codTransaction) {
        this.codTransaction = codTransaction;
    }

    @Override
    public String toString() {
        return "Transfer{" +
                "ibanBeneficiaire='" + ibanBeneficiaire + '\'' +
                ", nomBeneficiaire='" + nomBeneficiaire + '\'' +
                ", prenomBeneficiaire='" + prenomBeneficiaire + '\'' +
                ", amountToSend=" + amountToSend +
                ", amountNetToSend=" + amountNetToSend +
                ", tauxChange=" + tauxChange +
                ", amountToReceive=" + amountToReceive +
                ", delaiToTransfert=" + delaiToTransfert +
                ", bankName='" + bankName + '\'' +
                ", numCompteBes='" + numCompteBes + '\'' +
                ", status=" + status +
                ", tauxChangeAmplitude=" + tauxChangeAmplitude +
                ", dateInsertedAmplitude=" + dateInsertedAmplitude +
                ", modeTransfert=" + modeTransfert +
                ", commission=" + commission +
                ", dateReceiveMoney=" + dateReceiveMoney +
                ", dateSendMoney=" + dateSendMoney +
                ", dateFinalStatus=" + dateFinalStatus +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", refBank='" + refBank + '\'' +
                ", country='" + country + '\'' +
                ", sentToAmplitude=" + sentToAmplitude +
                ", ribBeneficiaire='" + ribBeneficiaire + '\'' +
                ", signature='" + signature + '\'' +
                ", version='" + version + '\'' +
                ", params='" + params + '\'' +
                ", compteClient='" + compteClient + '\'' +
                ", urlReturned='" + urlReturned + '\'' +
                ", cardPassed=" + cardPassed +
                ", cardGeneratedWebView=" + cardGeneratedWebView +
                ", codTransaction='" + codTransaction + '\'' +
                '}';
    }
}
