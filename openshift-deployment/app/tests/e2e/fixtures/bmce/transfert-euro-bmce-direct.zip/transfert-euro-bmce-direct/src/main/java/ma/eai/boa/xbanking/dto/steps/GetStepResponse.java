package ma.eai.boa.xbanking.dto.steps;


import ma.eai.boa.xbanking.entities.Retour;

import java.util.List;

public class GetStepResponse extends Retour {

    private static final long serialVersionUID = 1L;

    private DataProspectDTO dtProspect;

    private AdditionalDataProspectDTO addDataProspect;

    private List<BeneficiaireDTO> beneficiairesList;

    public DataProspectDTO getDtProspect() {
	return dtProspect;
    }

    public void setDtProspect(DataProspectDTO dtProspect) {
	this.dtProspect = dtProspect;
    }

    public AdditionalDataProspectDTO getAddDataProspect() {
	return addDataProspect;
    }

    public void setAddDataProspect(AdditionalDataProspectDTO addDataProspect) {
	this.addDataProspect = addDataProspect;
    }

    public List<BeneficiaireDTO> getBeneficiairesList() {
	return beneficiairesList;
    }

    public void setBeneficiairesList(List<BeneficiaireDTO> beneficiairesList) {
	this.beneficiairesList = beneficiairesList;
    }

    @Override
    public String toString() {
        return "GetStepResponse{" +
                "dtProspect=" + dtProspect +
                ", addDataProspect=" + addDataProspect +
                ", beneficiairesList=" + beneficiairesList +
                ", code=" + getCode()+
                '}';
    }
}
