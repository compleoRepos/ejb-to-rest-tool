package ma.eai.boa.xbanking.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.OneToOne;
import javax.persistence.ManyToOne;
import javax.persistence.Lob;

@Entity
public class Beneficiaire extends Identified {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4773915813784965261L;

	@JsonProperty("lastName")
	private String nom;
	
	@JsonProperty("firstName")
	private String prenom;
	
	private String iban;
	
	private String codeSwift;
		
	@OneToOne
	private Bank bank;
	
	@ManyToOne
	@JsonIgnore
	private Utilisateur user;
	
	@OneToOne
	private RelationFamiliale relationFamiliale;
	
	private String rib;
	
	@JsonProperty("country")
	@OneToOne
	private Nationality pays;
	
	private boolean sendToAmplitude;
	
	@Column(columnDefinition = "tinyint(1) default 0")
	private boolean client;

	@Column(columnDefinition = "TEXT")
	@Lob  // Large Object annotation
	private String attestationRib;

	@Column(columnDefinition = "tinyint(1) default 0")
	private boolean beneficiareVerify;

	/**
	 * 
	 */
	public Beneficiaire() {
	}

	/**
	 * @param civilite
	 * @param nom
	 * @param prenom
	 * @param iban
	 * @param user
	 */
	public Beneficiaire(String nom, String prenom, String iban, Utilisateur user) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.iban = iban;
		this.user = user;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getIban() {
		return iban;
	}

	public void setIban(String iban) {
		this.iban = iban;
	}

	public String getCodeSwift() {
		return codeSwift;
	}

	public void setCodeSwift(String codeSwift) {
		this.codeSwift = codeSwift;
	}

	public Utilisateur getUser() {
		return user;
	}

	public void setUser(Utilisateur user) {
		this.user = user;
	}

	public RelationFamiliale getRelationFamiliale() {
		return relationFamiliale;
	}

	public void setRelationFamiliale(RelationFamiliale relationFamiliale) {
		this.relationFamiliale = relationFamiliale;
	}

	public String getRib() {
		return rib;
	}

	public void setRib(String rib) {
		this.rib = rib;
	}

	public void setPays(Nationality pays) {
		this.pays = pays;
	}
	
	public boolean isSendToAmplitude() {
		return sendToAmplitude;
	}

	public void setSendToAmplitude(boolean sendToAmplitude) {
		this.sendToAmplitude = sendToAmplitude;
	}

	public Nationality getPays() {
		return pays;
	}

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public boolean isClient() {
		return client;
	}

	public void setClient(boolean client) {
		this.client = client;
	}

	public String getAttestationRib() {
		return attestationRib;
	}

	public void setAttestationRib(String attestationRib) {
		this.attestationRib = attestationRib;
	}

	public boolean isBeneficiareVerify() {
		return beneficiareVerify;
	}

	public void setBeneficiareVerify(boolean beneficiareVerify) {
		this.beneficiareVerify = beneficiareVerify;
	}

}
