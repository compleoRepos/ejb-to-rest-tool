package util;

import ma.eai.boa.xbanking.util.Constants;
import org.junit.Assert;
import org.junit.Test;

public class ConstantsTest {
    @Test
    public void testConstantsValues() {
	// Vérifier que les constantes ont les bonnes valeurs
	Assert.assertEquals("000", Constants.CODE_SUCCESS);
	Assert.assertEquals("111", Constants.CODE_ERROR);
    }
}
