package ma.eai.boa.xbanking.dto.tauxchange;



public class Commission {

    private String uuid;
    private int min;
    private int max;
    private float commission;
    private int canal;
    private float comissionConfrere;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public float getCommission() {
        return commission;
    }

    public void setCommission(float commission) {
        this.commission = commission;
    }

    public int getCanal() {
        return canal;
    }

    public void setCanal(int canal) {
        this.canal = canal;
    }

    public float getComissionConfrere() {
        return comissionConfrere;
    }

    public void setComissionConfrere(float comissionConfrere) {
        this.comissionConfrere = comissionConfrere;
    }

    @Override
    public String toString() {
        return "Commission{" +
                "uuid='" + uuid + '\'' +
                ", min=" + min +
                ", max=" + max +
                ", commission=" + commission +
                ", canal=" + canal +
                ", comissionConfrere=" + comissionConfrere +
                '}';
    }
}
