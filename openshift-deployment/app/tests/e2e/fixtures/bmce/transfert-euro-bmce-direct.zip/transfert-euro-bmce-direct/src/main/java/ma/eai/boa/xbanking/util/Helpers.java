package ma.eai.boa.xbanking.util;

import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.util.Formatter;

@Component
public class Helpers {

    private static final String HASH_ALGORITHM = "HmacSHA256";

    public String hashMac(String text, String secretKey) throws SignatureException {

        try {
            Key sk = new SecretKeySpec(secretKey.getBytes(), HASH_ALGORITHM);
            Mac mac = Mac.getInstance(sk.getAlgorithm());
            mac.init(sk);
            final byte[] hmac = mac.doFinal(text.getBytes());
            return toHexString(hmac);
        } catch (NoSuchAlgorithmException e) {
            EaiLog.error("NoSuchAlgorithmException : {}", e);
            throw new SignatureException("error building signature, no such algorithm in device " + HASH_ALGORITHM);
        } catch (InvalidKeyException e) {
            EaiLog.error("InvalidKeyException : {}", e);
            throw new SignatureException("error building signature, invalid key " + HASH_ALGORITHM);
        }
    }

    private static String toHexString(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);

        try (Formatter formatter = new Formatter(sb)) {
            for (byte b : bytes) {
                formatter.format("%02x", b);
            }
        } catch (Exception e) {
            EaiLog.error("Exception {}", e);
        }

        return sb.toString();
    }
}
