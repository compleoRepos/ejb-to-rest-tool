package ma.eai.boa.xbanking.service.PhoneNumber;

import ma.eai.boa.xbanking.vo.PhoneNumber.PhoneNumberIn;
import ma.eai.boa.xbanking.vo.PhoneNumber.PhoneNumberOut;

public interface PhoneNumber {
    PhoneNumberOut validePhoneNumber(PhoneNumberIn phoneNumberIn);
}
