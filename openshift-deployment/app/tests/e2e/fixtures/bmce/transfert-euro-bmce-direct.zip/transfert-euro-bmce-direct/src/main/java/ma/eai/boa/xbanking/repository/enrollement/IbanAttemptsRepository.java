package ma.eai.boa.xbanking.repository.enrollement;

import ma.eai.boa.xbanking.entities.IbanAttempt;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IbanAttemptsRepository extends JpaRepository<IbanAttempt, String> {
}
