package ma.eai.boa.xbanking.vo.historiqueTransfert;

import ma.eai.boa.xbanking.entities.History;
import ma.eai.boa.xbanking.vo.Retour;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "HistoriqueOut")
public class HistoriqueOut extends Retour {
	private Transferts transferts;

    public Transferts getTransferts() {
	return transferts;
    }

    public void setTransferts(Transferts transferts) {
	this.transferts = transferts;
    }
}
