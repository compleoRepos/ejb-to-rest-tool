package ma.eai.boa.xbanking.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;

@Entity
public class Bank extends NamedIdentified {
  private static final long serialVersionUID = 4358370893999141471L;



  @JsonIgnore
  @Column(columnDefinition="tinyint(1) default 0")
  private boolean visible;

  @Column(name="range_code",unique=false)
  @JsonProperty("code_range")
  private String rangeCode;

  @Column(name = "icon_base64", columnDefinition = "TEXT")  // Using TEXT for large strings
  @Lob  // Large Object annotation
  private String logo;  // This will store the base64 string

  // Existing getters and setters...

  // Add getter and setter for logo
  public String getLogo() {
    return logo;
  }

  public void setLogo(String logo) {
    this.logo = logo;
  }

  // Add getter and setter


  public boolean getVisible() {
    return visible;
  }

  public void setVisible(boolean visible) {
    this.visible = visible;
  }

public String getRangeCode() {
	return rangeCode;
}

public void setRangeCode(String rangeCode) {
	this.rangeCode = rangeCode;
}
}