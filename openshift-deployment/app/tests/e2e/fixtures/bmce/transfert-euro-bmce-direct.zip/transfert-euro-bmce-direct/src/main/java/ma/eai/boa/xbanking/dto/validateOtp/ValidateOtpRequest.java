package ma.eai.boa.xbanking.dto.validateOtp;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ValidateOtpRequest implements Serializable {
    private static final long serialVersionUID = -5890728848100778275L;

    private String uuid;

    @JsonProperty("otpID")
    private String uuidNexus;

    private String otp;

    private String deviceId;

    public boolean validatResetPayload() {
	return StringUtils.isNotBlank(uuidNexus) && StringUtils.isNotBlank(otp);
    }

    public boolean validat() {
	return StringUtils.isNotBlank(uuid) && StringUtils.isNotBlank(uuidNexus) && StringUtils.isNotBlank(otp);
    }

    public boolean validatWithDevice() {
	return StringUtils.isNotBlank(otp) && StringUtils.isNotBlank(deviceId);
    }

    public String getUuidNexus() {
	return uuidNexus;
    }

    public void setUuidNexus(String uuidNexus) {
	this.uuidNexus = uuidNexus;
    }

    public String getOtp() {
	return otp;
    }

    public void setOtp(String otp) {
	this.otp = otp;
    }

    public String getUuid() {
	return uuid;
    }

    public void setUuid(String uuid) {
	this.uuid = uuid;
    }

    public String getDeviceId() {
	return deviceId;
    }

    public void setDeviceId(String deviceId) {
	this.deviceId = deviceId;
    }

}

