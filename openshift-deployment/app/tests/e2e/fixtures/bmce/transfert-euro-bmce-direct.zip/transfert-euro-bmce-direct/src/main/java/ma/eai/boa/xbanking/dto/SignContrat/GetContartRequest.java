package ma.eai.boa.xbanking.dto.SignContrat;

public class GetContartRequest {
    private String token;

    public String getToken() {
	return token;
    }

    public void setToken(String token) {
	this.token = token;
    }
}
