package service;

import ma.eai.boa.xbanking.dto.tauxchange.TauxChangeResponse;
import ma.eai.boa.xbanking.service.tauxChange.TauxChangeService;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.vo.TauxChange.TauxChangeIn;
import ma.eai.boa.xbanking.vo.TauxChange.TauxChangeOut;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;

import static org.mockito.Mockito.when;
@RunWith(MockitoJUnitRunner.class)
public class tauxChangeServiceTest {
    @InjectMocks
    TauxChangeService tauxChangeService;
    @Mock
    RestTemplate restTemplate;
    @Before
    public void setUp(){
	MockitoAnnotations.initMocks(this);
        tauxChangeService.urlApi = "http://example.com/";
    }
    @Test
    public void tauxChangeSuccess(){
       TauxChangeResponse tauxChangeResponse = new TauxChangeResponse();
        tauxChangeResponse.setCode("SUCCESS_CODE");
        tauxChangeResponse.setTauxChange(new BigDecimal("10.5"));
        tauxChangeResponse.setDelaiToTransfert(new BigDecimal("2"));
        tauxChangeResponse.setFraisTransfertCB(new BigDecimal("5.0"));
        tauxChangeResponse.setFraisTransfertVirement(new BigDecimal("3.0"));

        ResponseEntity<TauxChangeResponse> mockResponseEntity = new ResponseEntity<>(tauxChangeResponse, HttpStatus.OK);
        String expectedUrl = "http://example.com/transfert/tauxChange/fr";

        when(restTemplate.getForEntity(expectedUrl, TauxChangeResponse.class))
                .thenReturn(mockResponseEntity);
        TauxChangeIn tauxChangeIn = new TauxChangeIn();
        tauxChangeIn.setLangue("fr");
        TauxChangeOut result = tauxChangeService.getTauxChange(tauxChangeIn);
        Assert.assertEquals("10.5", result.getTauxChange());
        Assert.assertEquals("2", result.getDelaiToTransfert());
        Assert.assertEquals("5.0", result.getFraisTransfertCB());
        Assert.assertEquals("3.0", result.getFraisTransfertVirement());

    }
    @Test
    public void tauxChangeFailure() {
        // Préparer une réponse avec un code d'échec
        TauxChangeResponse tauxChangeResponse = new TauxChangeResponse();
        tauxChangeResponse.setCode("ERROR_CODE");
        tauxChangeResponse.setMessage("Erreur API");

        ResponseEntity<TauxChangeResponse> mockResponseEntity =
                new ResponseEntity<>(tauxChangeResponse, HttpStatus.OK);

        String expectedUrl = "http://example.com/transfert/tauxChange/fr";

        when(restTemplate.getForEntity(expectedUrl, TauxChangeResponse.class))
                .thenReturn(mockResponseEntity);

        // Appel du service
        TauxChangeIn tauxChangeIn = new TauxChangeIn();
        tauxChangeIn.setLangue("fr");

        TauxChangeOut result = tauxChangeService.getTauxChange(tauxChangeIn);

        // Vérifications
        Assert.assertEquals(Constants.CODE_ERROR, result.getCode());
        Assert.assertEquals("ERROR_CODE", result.getMessage());
    }
    @Test
    public void tauxChangeException() {
        String expectedUrl = "http://example.com/transfert/tauxChange/fr";

        // Simuler une exception lors de l'appel REST
        when(restTemplate.getForEntity(expectedUrl, TauxChangeResponse.class))
                .thenThrow(new RuntimeException("Problème de connexion"));

        // Appel du service
        TauxChangeIn tauxChangeIn = new TauxChangeIn();
        tauxChangeIn.setLangue("fr");

        TauxChangeOut result = tauxChangeService.getTauxChange(tauxChangeIn);

        // Vérifications
        Assert.assertEquals(Constants.CODE_ERROR, result.getCode());
        Assert.assertEquals("ERR_TECHNICAL", result.getMessage());
    }
}
