package ma.eai.boa.xbanking.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.jta.WebSphereUowTransactionManager;

@Profile({"dyr", "syr"})
@Configuration
@EnableTransactionManagement
public class TransactionManagerConfig {
	
	@Bean
    public PlatformTransactionManager transactionManager() {
        return new WebSphereUowTransactionManager();
    }

}

