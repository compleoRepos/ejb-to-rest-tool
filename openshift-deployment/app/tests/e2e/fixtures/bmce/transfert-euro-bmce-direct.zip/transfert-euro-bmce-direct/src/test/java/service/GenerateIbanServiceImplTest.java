package service;

import ma.eai.boa.xbanking.dto.SignContrat.IbanResponse;
import ma.eai.boa.xbanking.service.signContrat.GenerateIbanServiceImpl;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.vo.SignContrat.IbanResponseOut;
import org.junit.Before;


import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

public class GenerateIbanServiceImplTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private GenerateIbanServiceImpl generateIbanService;

    @Before
    public void setUp(){
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(generateIbanService,"url","http://example.com/");
    }

    @Test
    public void generateIban_success() {

        //Given
        String token = "Eqhmkjfmkdjfoshdmlksnd";

        IbanResponse ibanResponse = new IbanResponse();
        ibanResponse.setReference("reference");
        ibanResponse.setCode("SUCCESS_CODE");
        ibanResponse.setBic("bic");

        ResponseEntity<IbanResponse> ibanResponseEntity =
                new ResponseEntity<>(ibanResponse, HttpStatus.OK);
        //When
        when(restTemplate.exchange(
                eq("http://example.com/prospect/generateIban"),
                eq(HttpMethod.GET),
                any(HttpEntity.class),
                eq(IbanResponse.class)
        )).thenReturn(ibanResponseEntity);

        //then
        IbanResponseOut response = generateIbanService.generateIban(token);

        assertEquals("reference",response.getReference());
        assertEquals("000", response.getCode());
        assertEquals("bic", response.getBic());

    }

    @Test
    public void generateIban_fail() {

        //Given
        String token = "Eqhmkjfmkdjfoshdmlksnd";

        IbanResponse ibanResponse = new IbanResponse();
        ibanResponse.setReference("reference");
        ibanResponse.setCode("001");
        ibanResponse.setBic("bic");

        ResponseEntity<IbanResponse> ibanResponseEntity =
                new ResponseEntity<>(ibanResponse, HttpStatus.OK);
        //When
        when(restTemplate.exchange(
                eq("http://example.com/prospect/generateIban"),
                eq(HttpMethod.GET),
                any(HttpEntity.class),
                eq(IbanResponse.class)
        )).thenReturn(ibanResponseEntity);

        //then
        IbanResponseOut response = generateIbanService.generateIban(token);

        assertEquals(Constants.CODE_ERROR, response.getCode());

    }
}