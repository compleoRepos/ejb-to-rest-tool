package ma.eai.boa.xbanking.vo.transfert;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TransfertIn {

    private double amountToSend;

    private double amountNetToSend;

    private double amountToReceive;

    @JsonProperty("transferMode")
    private String transferMode;

    @JsonProperty("iban")
    private String iban;

    @JsonProperty("numCompteBes")
    private String numCompteBes;

    @JsonProperty("rib")
    private String rib;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("firstName")
    private String firstName;

    private String bankName;

    private float tauxChange;

    private float commission;

    private String compteClient;

    private String uuid;

    @JsonProperty("callbackUrl")
    private String callbackUrl;

    @JsonProperty("url")
    private String url;

    private String token;


    public String getToken() {
	return token;
    }

    public void setToken(String token) {
	this.token = token;
    }

    public double getAmountToSend() {
	return amountToSend;
    }

    public void setAmountToSend(double amountToSend) {
	this.amountToSend = amountToSend;
    }

    public double getAmountNetToSend() {
	return amountNetToSend;
    }

    public void setAmountNetToSend(double amountNetToSend) {
	this.amountNetToSend = amountNetToSend;
    }

    public double getAmountToReceive() {
	return amountToReceive;
    }

    public void setAmountToReceive(double amountToReceive) {
	this.amountToReceive = amountToReceive;
    }

    public String getTransferMode() {
	return transferMode;
    }

    public void setTransferMode(String transferMode) {
	this.transferMode = transferMode;
    }

    public String getIban() {
	return iban;
    }

    public void setIban(String iban) {
	this.iban = iban;
    }

    public String getNumCompteBes() {
	return numCompteBes;
    }

    public void setNumCompteBes(String numCompteBes) {
	this.numCompteBes = numCompteBes;
    }

    public String getRib() {
	return rib;
    }

    public void setRib(String rib) {
	this.rib = rib;
    }

    public String getLastName() {
	return lastName;
    }

    public void setLastName(String lastName) {
	this.lastName = lastName;
    }

    public String getFirstName() {
	return firstName;
    }

    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }

    public String getBankName() {
	return bankName;
    }

    public void setBankName(String bankName) {
	this.bankName = bankName;
    }

    public float getTauxChange() {
	return tauxChange;
    }

    public void setTauxChange(float tauxChange) {
	this.tauxChange = tauxChange;
    }

    public float getCommission() {
	return commission;
    }

    public void setCommission(float commission) {
	this.commission = commission;
    }

    public String getCompteClient() {
	return compteClient;
    }

    public void setCompteClient(String compteClient) {
	this.compteClient = compteClient;
    }

    public String getUuid() {
	return uuid;
    }

    public void setUuid(String uuid) {
	this.uuid = uuid;
    }

    public String getCallbackUrl() {
	return callbackUrl;
    }

    public void setCallbackUrl(String callbackUrl) {
	this.callbackUrl = callbackUrl;
    }

    public String getUrl() {
	return url;
    }

    public void setUrl(String url) {
	this.url = url;
    }
}
