package ma.eai.boa.xbanking.dto.transfert;

public enum ModeTransfert {

    CARD("CARD"),
    TRANSFER("TRANSFER"),
    AGREAGTIONTRANSFER("AGREGATIONTRANSFER");


    private String value;

    ModeTransfert(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }
}
