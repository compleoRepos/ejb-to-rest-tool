package ma.eai.boa.xbanking.service.authentification;



import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Date;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import ma.eai.boa.xbanking.vo.User.UserIn;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import ma.eai.boa.xbanking.entities.User;
import ma.eai.ingdev.fwk.logging.EaiLog;


@Component
public class JwtTokenUtil {
    @Value("${privateKey}")
    String privateKey;

    // generate token for user
    public String generateToken(UserIn user) {
	try {
	    if (user != null) {
		EaiLog.info("avant token validty");
		long tokenValidity = 2888l * 60l;
		EaiLog.info("after token validty : {}",tokenValidity);
		return doGenerateToken(user, tokenValidity);
	    }
	} catch (Exception e) {
	    EaiLog.info("error while generate token: {}", e);
	}
	return null;
    }

    private String doGenerateToken(UserIn user, long tokenValidity)
	    throws NoSuchAlgorithmException, InvalidKeySpecException, JOSEException {
	Decoder decoder = Base64.getDecoder();
	/* Generate private key. */
	PKCS8EncodedKeySpec ks = new PKCS8EncodedKeySpec(decoder.decode(privateKey));
	KeyFactory kf = KeyFactory.getInstance("RSA");
	PrivateKey pvt = kf.generatePrivate(ks);

	JWSSigner signer = new RSASSASigner(pvt);

	// Prepare JWT with claims set
	JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()
		.subject(user.getUuid())
		.claim("admin", true)
		.claim("name", user.getEmail())
		.issuer("https://www.dabatransfer.com")
		.issueTime(new Date())
		.expirationTime(new Date(System.currentTimeMillis() + tokenValidity * 1000))

		.build();

	SignedJWT signedJWT = new SignedJWT(
		new JWSHeader.Builder(JWSAlgorithm.RS256).type(JOSEObjectType.JWT).build(),
		claimsSet);
	// Compute the RSA signature
	signedJWT.sign(signer);
	// To serialize to compact form, produces something like
	String token = signedJWT.serialize();
	return token;
    }
}
