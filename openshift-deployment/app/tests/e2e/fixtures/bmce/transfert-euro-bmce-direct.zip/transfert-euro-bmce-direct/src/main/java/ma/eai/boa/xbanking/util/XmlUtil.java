package ma.eai.boa.xbanking.util;

import ma.eai.ingdev.fwk.logging.EaiLog;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;

public class XmlUtil {
    public static <T> T unmarshalSoapBody(String xml, Class<T> clazz) throws JAXBException {
	JAXBContext jaxbContext = JAXBContext.newInstance(clazz);
	Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
	String bodyContent = extractBodyContent(xml);
	StringReader reader = new StringReader(bodyContent);
	return (T) unmarshaller.unmarshal(reader);
    }

    public static String extractBodyContent(String xml) {
	int bodyStart = xml.indexOf("<soap:Body>") + "<soap:Body>".length();
	int bodyEnd = xml.indexOf("</soap:Body>");
	return xml.substring(bodyStart, bodyEnd).trim();
    }
    public static String extractFunctionName(String soapRequest) {
	try {
	    EaiLog.info("BEGIN extractFunction Name:");
	    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    //disbale entities for security issue sonarqube
	    factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
	    factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
	    factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);

	    DocumentBuilder builder = factory.newDocumentBuilder();
	    Document document = builder.parse(new InputSource(new StringReader(soapRequest)));

	    // Accéder à l'élément <fonction>
	    Element fonctionElement = (Element) document.getElementsByTagName("fonction").item(0);
	    return fonctionElement.getTextContent(); // Renvoie le nom de la fonction
	} catch (Exception e) {
	    EaiLog.error("unkonw fonction");
	    return "Unknown fonction";
	}
    }
}

