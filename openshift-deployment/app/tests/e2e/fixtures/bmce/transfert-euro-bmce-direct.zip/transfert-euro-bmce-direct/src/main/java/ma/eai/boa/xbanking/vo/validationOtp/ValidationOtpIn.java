package ma.eai.boa.xbanking.vo.validationOtp;

public class ValidationOtpIn {
    private String uuid;

    private String otpId;

    private String otpValue;

    private String deviceId;

    public String getUuid() {
	return uuid;
    }

    public void setUuid(String uuid) {
	this.uuid = uuid;
    }

    public String getOtpId() {
	return otpId;
    }

    public void setOtpId(String otpId) {
	this.otpId = otpId;
    }

    public String getOtpValue() {
	return otpValue;
    }

    public void setOtpValue(String otpValue) {
	this.otpValue = otpValue;
    }

    public String getDeviceId() {
	return deviceId;
    }

    public void setDeviceId(String deviceId) {
	this.deviceId = deviceId;
    }
}
