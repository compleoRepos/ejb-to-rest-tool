package ma.eai.boa.xbanking.repository;

import ma.eai.boa.xbanking.entities.User;
import ma.eai.boa.xbanking.util.UserStep;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends CrudRepository<User,String> {


    User findByContratBadAndStepIsNotNull(String contratBad);

    User findByEmail(String email);

    User findByContratBad(String contratBad);
}
