package ma.eai.boa.xbanking.service.attachements;

import ma.eai.boa.xbanking.vo.Attachements.AttachementsIn;
import ma.eai.boa.xbanking.vo.Attachements.AttachementsOut;

public interface Attachements {
AttachementsOut uploadFiles(AttachementsIn attachementsIn);
}
