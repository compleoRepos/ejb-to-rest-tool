package ma.eai.boa.xbanking.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import java.sql.Timestamp;
import java.util.List;

@Entity
public class Country extends NamedIdentified {

	private static final long serialVersionUID = 4358370893999141471L;

	@JsonProperty("iso3Alpha")
	private String iso3Alpha;
	
	@JsonProperty("iso2Alpha")
	private String iso2Alpha;
	
	@JsonProperty("iso3Numeric")
	private int iso3Numeric;
	
	private String indicatif;
	
	@JsonIgnore
	private int nbrChiffre;
	
	@JsonIgnore
	private int portAmplitude;
	
	@JsonIgnore
	private String context;
	
	@JsonIgnore
	private int lenghtIban;
	
	@JsonIgnore
	private int portAmplitudeIntern;

	@JsonIgnore
	private String phoneTypeAmlitude;
	
	@JsonIgnore
	private String phoneFormatAmplitude;
	
	@JsonIgnore
	private String userAmplitude;
	
	@JsonIgnore
	private String langueAmplitude;
	
	@JsonIgnore
	private String profileProspect;
	
	@JsonIgnore
	private String agencePrelevement;
	
	@JsonIgnore
	private String defaultAgence;
	
	@JsonIgnore
	private String universalLanguage;
	
	@JsonIgnore
	private String ibanCollecteur;
	
	@JsonIgnore
	private String bic;
	
	@JsonIgnore
	private boolean ibanise;
	
	@JsonIgnore
	private String codeAgent;
	
	@JsonIgnore
	@Column(columnDefinition="tinyint(1) default 0")
	private boolean cardActived;
	
	@JsonIgnore
	@Column(columnDefinition="tinyint(1) default 0")
	private boolean connectionActivated;
	
	@JsonIgnore
	@ManyToMany (fetch = FetchType.EAGER)
	private List<DocumentType> documentTypes; 
	
	private double montantMaxCard;
	
	private double montantMaxVirement;
	
	@JsonIgnore
	private String nexiAlias;
	
	@JsonIgnore
	private String nexiMac;
	
	@JsonIgnore
	private String nexiUrlDispatcher;
	
	@JsonIgnore
	private int portAmplitudeHttp; 
	
	@JsonIgnore
	@Column(columnDefinition="tinyint(1) default 0")
	private boolean prelevementActived;
	
	@JsonIgnore
	@Column(columnDefinition="tinyint(1) default 0")
	private boolean aggregationActived;
	
	@JsonIgnore
	@Column(columnDefinition="tinyint(1) default 0")
	private boolean aggregationTransferActived;
	
	@JsonIgnore
	@Column(columnDefinition="tinyint(1) default 0")
	private boolean virementTransferActived;
	
	@JsonIgnore
	@Column(columnDefinition="tinyint(1) default 0")
	private boolean bordereauActived;
	
	@JsonIgnore
	@Column(columnDefinition="tinyint(1) default 0")
	private boolean createCompteActived;
	
	@JsonIgnore
	@Column(columnDefinition="tinyint(1) default 0")
	private boolean firstTransfertVirement;
	
	@JsonIgnore
	@Column(columnDefinition="tinyint(1) default 0")
	private boolean firstTransfertCard;
	
	@JsonIgnore
	private String nomBenefCollecteur;
	
	private int minFirstTransfert;
	
	@JsonIgnore
	private String stripKey;
	
	@JsonIgnore
	private String stripPublicKey;
	
	@JsonIgnore
	@Column(columnDefinition="tinyint(1) default 0")
	private boolean enrollementActived;
	
	@JsonIgnore
	@Column(columnDefinition="tinyint(1) default 0")
	private boolean ocrActive;
	
	private String capitale;
	
	private String aquereure;
	
	@JsonIgnore
	@Column(columnDefinition="tinyint(1) default 0")
	private boolean rejectDoubleRibBenef;
	
	private int montantMinCard;
	
	private int montantMinVirement;
	
	/**
	 * verifier si le client exist en appelant le service getCustomersByCriteria
	 */
	@JsonIgnore
	@Column(columnDefinition="tinyint(1) default 0")
	private boolean checkIfUserExistInAmplitude;
	
	/**
	 * 
	 */
	public Country() {
	}

	/**
	 * @param dateInserted
	 */
	public Country(Timestamp dateInserted) {
		super(dateInserted);
	}

	public String getIso3Alpha() {
		return iso3Alpha;
	}

	public void setIso3Alpha(String iso3Alpha) {
		this.iso3Alpha = iso3Alpha;
	}

	public String getIso2Alpha() {
		return iso2Alpha;
	}

	public void setIso2Alpha(String iso2Alpha) {
		this.iso2Alpha = iso2Alpha;
	}

	public int getIso3Numeric() {
		return iso3Numeric;
	}

	public void setIso3Numeric(int iso3Numeric) {
		this.iso3Numeric = iso3Numeric;
	}

	public String getIndicatif() {
		return indicatif;
	}

	public void setIndicatif(String indicatif) {
		this.indicatif = indicatif;
	}

	public int getNbrChiffre() {
		return nbrChiffre;
	}

	public void setNbrChiffre(int nbrChiffre) {
		this.nbrChiffre = nbrChiffre;
	}

	public String getPhoneTypeAmlitude() {
		return phoneTypeAmlitude;
	}

	public void setPhoneTypeAmlitude(String phoneTypeAmlitude) {
		this.phoneTypeAmlitude = phoneTypeAmlitude;
	}

	public String getPhoneFormatAmplitude() {
		return phoneFormatAmplitude;
	}

	public void setPhoneFormatAmplitude(String phoneFormatAmplitude) {
		this.phoneFormatAmplitude = phoneFormatAmplitude;
	}

	public String getUserAmplitude() {
		return userAmplitude;
	}

	public void setUserAmplitude(String userAmplitude) {
		this.userAmplitude = userAmplitude;
	}

	public String getLangueAmplitude() {
		return langueAmplitude;
	}

	public void setLangueAmplitude(String langueAmplitude) {
		this.langueAmplitude = langueAmplitude;
	}

	public String getProfileProspect() {
		return profileProspect;
	}

	public void setProfileProspect(String profileProspect) {
		this.profileProspect = profileProspect;
	}

	public String getAgencePrelevement() {
		return agencePrelevement;
	}

	public void setAgencePrelevement(String agencePrelevement) {
		this.agencePrelevement = agencePrelevement;
	}

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public int getPortAmplitude() {
		return portAmplitude;
	}

	public void setPortAmplitude(int portAmplitude) {
		this.portAmplitude = portAmplitude;
	}

	public int getPortAmplitudeIntern() {
		return portAmplitudeIntern;
	}

	public void setPortAmplitudeIntern(int portAmplitudeIntern) {
		this.portAmplitudeIntern = portAmplitudeIntern;
	}

	public String getDefaultAgence() {
		return defaultAgence;
	}

	public void setDefaultAgence(String defaultAgence) {
		this.defaultAgence = defaultAgence;
	}

	public String getUniversalLanguage() {
		return universalLanguage;
	}

	public void setUniversalLanguage(String universalLanguage) {
		this.universalLanguage = universalLanguage;
	}
	
	public String getIbanCollecteur() {
		return ibanCollecteur;
	}

	public void setIbanCollecteur(String ibanCollecteur) {
		this.ibanCollecteur = ibanCollecteur;
	}

	public boolean isIbanise() {
		return ibanise;
	}

	public void setIbanise(boolean ibanise) {
		this.ibanise = ibanise;
	}

	public String getBic() {
		return bic;
	}

	public void setBic(String bic) {
		this.bic = bic;
	}

	public int getLenghtIban() {
		return lenghtIban;
	}

	public void setLenghtIban(int lenghtIban) {
		this.lenghtIban = lenghtIban;
	}

	public String getCodeAgent() {
		return codeAgent;
	}

	public void setCodeAgent(String codeAgent) {
		this.codeAgent = codeAgent;
	}

	public boolean isCardActived() {
		return cardActived;
	}

	public void setCardActived(boolean cardActived) {
		this.cardActived = cardActived;
	}

	public boolean isConnectionActivated() {
		return connectionActivated;
	}

	public void setConnectionActivated(boolean connectionActivated) {
		this.connectionActivated = connectionActivated;
	}

	public List<DocumentType> getDocumentTypes() {
		return documentTypes;
	}

	public void setDocumentTypes(List<DocumentType> documentTypes) {
		this.documentTypes = documentTypes;
	}

	public double getMontantMaxCard() {
		return montantMaxCard;
	}

	public void setMontantMaxCard(double montantMaxCard) {
		this.montantMaxCard = montantMaxCard;
	}

	public double getMontantMaxVirement() {
		return montantMaxVirement;
	}

	public void setMontantMaxVirement(double montantMaxVirement) {
		this.montantMaxVirement = montantMaxVirement;
	}

	public String getNexiAlias() {
		return nexiAlias;
	}

	public void setNexiAlias(String nexiAlias) {
		this.nexiAlias = nexiAlias;
	}

	public String getNexiMac() {
		return nexiMac;
	}

	public void setNexiMac(String nexiMac) {
		this.nexiMac = nexiMac;
	}

	public String getNexiUrlDispatcher() {
		return nexiUrlDispatcher;
	}

	public void setNexiUrlDispatcher(String nexiUrlDispatcher) {
		this.nexiUrlDispatcher = nexiUrlDispatcher;
	}

	public int getPortAmplitudeHttp() {
		return portAmplitudeHttp;
	}

	public void setPortAmplitudeHttp(int portAmplitudeHttp) {
		this.portAmplitudeHttp = portAmplitudeHttp;
	}

	public boolean isPrelevementActived() {
		return prelevementActived;
	}

	public void setPrelevementActived(boolean prelevementActived) {
		this.prelevementActived = prelevementActived;
	}

	public boolean isAggregationActived() {
		return aggregationActived;
	}

	public void setAggregationActived(boolean aggregationActived) {
		this.aggregationActived = aggregationActived;
	}

	public boolean isAggregationTransferActived() {
		return aggregationTransferActived;
	}

	public void setAggregationTransferActived(boolean aggregationTransferActived) {
		this.aggregationTransferActived = aggregationTransferActived;
	}

	public boolean isVirementTransferActived() {
		return virementTransferActived;
	}

	public void setVirementTransferActived(boolean virementTransferActived) {
		this.virementTransferActived = virementTransferActived;
	}

	public boolean isBordereauActived() {
		return bordereauActived;
	}

	public void setBordereauActived(boolean bordereauActived) {
		this.bordereauActived = bordereauActived;
	}

	public boolean isCreateCompteActived() {
		return createCompteActived;
	}

	public void setCreateCompteActived(boolean createCompteActived) {
		this.createCompteActived = createCompteActived;
	}

	public boolean isFirstTransfertVirement() {
		return firstTransfertVirement;
	}

	public void setFirstTransfertVirement(boolean firstTransfertVirement) {
		this.firstTransfertVirement = firstTransfertVirement;
	}

	public boolean isFirstTransfertCard() {
		return firstTransfertCard;
	}

	public void setFirstTransfertCard(boolean firstTransfertCard) {
		this.firstTransfertCard = firstTransfertCard;
	}

	public String getNomBenefCollecteur() {
		return nomBenefCollecteur;
	}

	public void setNomBenefCollecteur(String nomBenefCollecteur) {
		this.nomBenefCollecteur = nomBenefCollecteur;
	}

	public int getMinFirstTransfert() {
		return minFirstTransfert;
	}

	public void setMinFirstTransfert(int minFirstTransfert) {
		this.minFirstTransfert = minFirstTransfert;
	}

	public String getStripKey() {
		return stripKey;
	}

	public void setStripKey(String stripKey) {
		this.stripKey = stripKey;
	}

	public String getStripPublicKey() {
		return stripPublicKey;
	}

	public void setStripPublicKey(String stripPublicKey) {
		this.stripPublicKey = stripPublicKey;
	}

	public boolean isEnrollementActived() {
		return enrollementActived;
	}

	public void setEnrollementActived(boolean enrollementActived) {
		this.enrollementActived = enrollementActived;
	}

	public boolean isOcrActive() {
		return ocrActive;
	}

	public void setOcrActive(boolean ocrActive) {
		this.ocrActive = ocrActive;
	}

	public String getCapitale() {
		return capitale;
	}

	public void setCapitale(String capitale) {
		this.capitale = capitale;
	}

	public String getAquereure() {
		return aquereure;
	}

	public void setAquereure(String aquereure) {
		this.aquereure = aquereure;
	}

	public boolean isRejectDoubleRibBenef() {
		return rejectDoubleRibBenef;
	}

	public void setRejectDoubleRibBenef(boolean rejectDoubleRibBenef) {
		this.rejectDoubleRibBenef = rejectDoubleRibBenef;
	}

	public int getMontantMinCard() {
		return montantMinCard;
	}

	public void setMontantMinCard(int montantMinCard) {
		this.montantMinCard = montantMinCard;
	}

	public int getMontantMinVirement() {
		return montantMinVirement;
	}

	public void setMontantMinVirement(int montantMinVirement) {
		this.montantMinVirement = montantMinVirement;
	}

	public boolean isCheckIfUserExistInAmplitude() {
		return checkIfUserExistInAmplitude;
	}

	public void setCheckIfUserExistInAmplitude(boolean checkIfUserExistInAmplitude) {
		this.checkIfUserExistInAmplitude = checkIfUserExistInAmplitude;
	}

}
