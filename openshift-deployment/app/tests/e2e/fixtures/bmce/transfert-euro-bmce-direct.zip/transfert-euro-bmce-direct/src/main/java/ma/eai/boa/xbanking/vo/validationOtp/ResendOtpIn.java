package ma.eai.boa.xbanking.vo.validationOtp;

public class ResendOtpIn {

    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
