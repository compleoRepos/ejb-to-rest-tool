package ma.eai.boa.xbanking.dto.transfert;

import ma.eai.boa.xbanking.entities.History;
import ma.eai.boa.xbanking.entities.Retour;

import java.util.List;

public class HistoriqueResponse extends Retour {

    private static final long serialVersionUID = -7158929059254849746L;

    private List<History> listHistory;

    public List<History> getListHistory() {
	return listHistory;
    }

    public void setListHistory(List<History> listHistory) {
	this.listHistory = listHistory;
    }
}
