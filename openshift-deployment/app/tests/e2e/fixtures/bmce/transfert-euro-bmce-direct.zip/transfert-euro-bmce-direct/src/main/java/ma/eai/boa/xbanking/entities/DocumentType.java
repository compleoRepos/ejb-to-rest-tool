package ma.eai.boa.xbanking.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.Entity;

@Entity
public class DocumentType extends NamedIdentified {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7675467537770987357L;

	private boolean recto;
	
	private boolean verso;
	
	@JsonIgnore
	private boolean sendToFront;

	public boolean isRecto() {
		return recto;
	}

	public void setRecto(boolean recto) {
		this.recto = recto;
	}

	public boolean isVerso() {
		return verso;
	}

	public void setVerso(boolean verso) {
		this.verso = verso;
	}

	public boolean isSendToFront() {
		return sendToFront;
	}

	public void setSendToFront(boolean sendToFront) {
		this.sendToFront = sendToFront;
	}
}
