package ma.eai.boa.xbanking.repository.transfert;

import ma.eai.boa.xbanking.entities.TransfertBES;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransfertRepository extends JpaRepository<TransfertBES, String> {
}
