package ma.eai.boa.xbanking.entities;

public enum Civilite {
	MR("01", "MR"),
	MME("02", "MME"),
	MLLE("03", "MLLE");
	
	private String code;
	private String value;
	
	Civilite(String code, String value) {
		this.code = code;
        this.value = value;
    }
	
	public String getCode() {
		return this.code;
	}
	
    public String getValue() {
        return this.value;
    }

}
