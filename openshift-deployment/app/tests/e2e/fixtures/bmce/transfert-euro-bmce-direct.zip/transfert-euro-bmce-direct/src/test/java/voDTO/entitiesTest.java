package voDTO;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;

import com.google.common.reflect.ClassPath;

import ma.eai.ingdev.fwk.logging.EaiLog;
import org.junit.Test;

/**
 * @author
 *
 */
public class entitiesTest {

    public void invokeSetter(Object obj, String propertyName, Object variableValue) {
	PropertyDescriptor propDescriptor;
	try {
	    propDescriptor = new PropertyDescriptor(propertyName, obj.getClass());
	    Method setter = propDescriptor.getWriteMethod();
	    try {
		setter.invoke(obj, variableValue);
	    } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
		EaiLog.info("error call setter", e);
	    }
	} catch (IntrospectionException e) {
	    EaiLog.info("error call setter", e);
	}

    }

    public Object invokeGetter(Object obj, String variableName) {
	Object returnValue = null;
	try {
	    PropertyDescriptor pd = new PropertyDescriptor(variableName, obj.getClass());
	    Method getter = pd.getReadMethod();
	    returnValue = getter.invoke(obj);
	} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException
		| IntrospectionException e) {
	    EaiLog.info("error call setter", e);
	}
	return returnValue;
    }

    private <T extends Object> void validateGettersSetters(List<T> objects) {
	for (T t : objects) {
	    EaiLog.info("bean tested : ".concat(t.toString()));
	    Class<?> aClass = t.getClass();
	    for (java.lang.reflect.Field field : aClass.getDeclaredFields()) {
		if (!Modifier.isFinal(field.getModifiers())) {
		    Class<?> c = field.getType();
		    if (c == String.class) {
			invokeSetter(t, field.getName(), "dummy");
			Assert.assertTrue("dummy".equalsIgnoreCase((String) (invokeGetter(t, field.getName()))));
		    } else if (c == Integer.class || c == int.class) {
			invokeSetter(t, field.getName(), 1);
			Assert.assertTrue(1 == (int) (invokeGetter(t, field.getName())));
		    } else if (c == Float.class || c == float.class) {
			invokeSetter(t, field.getName(), 1f);
			Assert.assertTrue(1f == (float) (invokeGetter(t, field.getName())));
		    } else if (c == Double.class || c == double.class) {
			invokeSetter(t, field.getName(), 1d);
			Assert.assertTrue(1d == (double) (invokeGetter(t, field.getName())));
		    } else if (c == Long.class || c == long.class) {
			invokeSetter(t, field.getName(), 1l);
			Assert.assertTrue(1l == (long) (invokeGetter(t, field.getName())));
		    } else if (c == Boolean.class || c == boolean.class) {
			invokeSetter(t, field.getName(), true);
			Assert.assertTrue((boolean) (invokeGetter(t, field.getName())));
		    } else if (c == Timestamp.class && !"dateIns".equalsIgnoreCase(field.getName())) {
			invokeSetter(t, field.getName(), new Timestamp(System.currentTimeMillis()));
			Assert.assertTrue(invokeGetter(t, field.getName()) != null);
		    } else if (c == LocalDateTime.class) {
			invokeSetter(t, field.getName(), LocalDateTime.now());
			Assert.assertTrue(invokeGetter(t, field.getName()) != null);
		    }
		  /*  else if (c == BeneficiaireIn.class) {
			invokeSetter(t, field.getName(), new BeneficiaireIn());
			Assert.assertTrue(invokeGetter(t, field.getName()) != null);
		    } */
		    else if (c == List.class) {
			// Now based on your bean and filed name
			//						switch (field.getName()) {
			//						case "neighbourCities":
			//							invokeSetter(t, field.getName(), new ArrayList<City>());
			//							assertTrue(invokeGetter(t, field.getName()) != null);
			//							break;
			//						}
		    }
		}

	    }
	}
    }

    @Test
    public void testBean() throws Throwable, IllegalAccessException, ClassNotFoundException {

	List<Object> objects = new ArrayList<>();
	final ClassLoader loader = Thread.currentThread().getContextClassLoader();

	for (final ClassPath.ClassInfo info : ClassPath.from(loader).getTopLevelClasses()) {
	    if (info.getName().startsWith("ma.eai.boa.xbanking.entities")) {
		final Class<?> clazz = info.load();
		if (!clazz.isEnum() && !Modifier.isAbstract(clazz.getModifiers())) {
		    objects.add(Class.forName(info.getName()).newInstance());
		}
		//		    objects.add(clazz);
	    }
	}

	validateGettersSetters(objects);

    }

}


