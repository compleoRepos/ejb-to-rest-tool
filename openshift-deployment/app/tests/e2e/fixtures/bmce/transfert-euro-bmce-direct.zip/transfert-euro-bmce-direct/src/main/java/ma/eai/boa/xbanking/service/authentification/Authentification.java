package ma.eai.boa.xbanking.service.authentification;

import ma.eai.boa.xbanking.dto.authentication.TokenRequest;
import ma.eai.boa.xbanking.entities.User;
import ma.eai.boa.xbanking.vo.Authentication.CheckUserBesOut;
import ma.eai.boa.xbanking.vo.Authentication.CheckUserOut;
import ma.eai.boa.xbanking.vo.User.UserIn;

public interface Authentification {
     String generateToken(UserIn user);

     CheckUserOut checkUser(String contratBad, String deviceId);

     boolean sendToken(TokenRequest tokenRequest);

     CheckUserBesOut checkUserBes(String token);
}
