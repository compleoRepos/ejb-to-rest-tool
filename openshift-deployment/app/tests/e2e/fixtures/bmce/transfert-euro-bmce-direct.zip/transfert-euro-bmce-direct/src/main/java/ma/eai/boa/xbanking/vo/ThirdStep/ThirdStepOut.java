package ma.eai.boa.xbanking.vo.ThirdStep;

import ma.eai.boa.xbanking.vo.Retour;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "ThirdStepOut")
public class ThirdStepOut extends Retour {
}
