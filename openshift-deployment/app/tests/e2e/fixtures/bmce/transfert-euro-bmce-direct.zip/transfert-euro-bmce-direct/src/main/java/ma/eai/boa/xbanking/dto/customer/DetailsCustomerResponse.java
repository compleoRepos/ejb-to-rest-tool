package ma.eai.boa.xbanking.dto.customer;

import com.fasterxml.jackson.annotation.JsonProperty;
import ma.eai.boa.xbanking.entities.Agence;
import ma.eai.boa.xbanking.entities.Retour;

import java.util.Date;

public class DetailsCustomerResponse extends Retour {

    private static final long serialVersionUID = -8146363692764769367L;

    private String designation;

    private String firstName;

    private String lastName;

    private String adress;

    private String email;

    private String phone;

    private String profile;

    private Agence agence;

    @JsonProperty("birthDate")
    private Date dateNaissance;

    private String nationality;

    private String codePostal;

    private String ville;

    private String docType;

    private String docValue;

    private String docCountry;

    private String country;

    private String phoneContact;

    private Date identityValidityDate;

    private Date identityDeliveryDate;

    public String getDesignation() {
	return designation;
    }

    public void setDesignation(String designation) {
	this.designation = designation;
    }

    public String getFirstName() {
	return firstName;
    }

    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }

    public String getLastName() {
	return lastName;
    }

    public void setLastName(String lastName) {
	this.lastName = lastName;
    }

    public String getAdress() {
	return adress;
    }

    public void setAdress(String adress) {
	this.adress = adress;
    }

    public String getEmail() {
	return email;
    }

    public void setEmail(String email) {
	this.email = email;
    }

    public String getPhone() {
	return phone;
    }

    public void setPhone(String phone) {
	this.phone = phone;
    }

    public String getProfile() {
	return profile;
    }

    public void setProfile(String profile) {
	this.profile = profile;
    }

    public Agence getAgence() {
	return agence;
    }

    public void setAgence(Agence agence) {
	this.agence = agence;
    }

    public Date getDateNaissance() {
	return dateNaissance;
    }

    public void setDateNaissance(Date dateNaissance) {
	this.dateNaissance = dateNaissance;
    }

    public String getNationality() {
	return nationality;
    }

    public void setNationality(String nationality) {
	this.nationality = nationality;
    }

    public String getCodePostal() {
	return codePostal;
    }

    public void setCodePostal(String codePostal) {
	this.codePostal = codePostal;
    }

    public String getVille() {
	return ville;
    }

    public void setVille(String ville) {
	this.ville = ville;
    }

    public String getDocType() {
	return docType;
    }

    public void setDocType(String docType) {
	this.docType = docType;
    }

    public String getDocValue() {
	return docValue;
    }

    public void setDocValue(String docValue) {
	this.docValue = docValue;
    }

    public String getDocCountry() {
	return docCountry;
    }

    public void setDocCountry(String docCountry) {
	this.docCountry = docCountry;
    }

    public String getCountry() {
	return country;
    }

    public void setCountry(String country) {
	this.country = country;
    }

    public String getPhoneContact() {
	return phoneContact;
    }

    public void setPhoneContact(String phoneContact) {
	this.phoneContact = phoneContact;
    }

    public Date getIdentityValidityDate() {
	return identityValidityDate;
    }

    public void setIdentityValidityDate(Date identityValidityDate) {
	this.identityValidityDate = identityValidityDate;
    }

    public Date getIdentityDeliveryDate() {
	return identityDeliveryDate;
    }

    public void setIdentityDeliveryDate(Date identityDeliveryDate) {
	this.identityDeliveryDate = identityDeliveryDate;
    }
}
