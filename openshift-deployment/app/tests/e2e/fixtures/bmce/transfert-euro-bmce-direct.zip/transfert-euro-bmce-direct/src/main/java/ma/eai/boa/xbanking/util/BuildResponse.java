package ma.eai.boa.xbanking.util;
import ma.eai.ingdev.fwk.logging.EaiLog;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.StringWriter;
public class BuildResponse {
    public static String buildSoapResponse(Object outputObject) throws JAXBException {
	EaiLog.info("BEGIN buildSoapResponse ===");

	// Initialiser le JAXBContext
	JAXBContext jaxbContext = JAXBContext.newInstance(outputObject.getClass());

	// Créer un Marshaller
	Marshaller marshaller = jaxbContext.createMarshaller();
	marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true); // Indenter le XML
	marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8"); // Encodage UTF-8
	marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true); // Supprimer l'entête XML standalone

	// Marshalling l'objet en chaîne XML
	StringWriter writer = new StringWriter();
	marshaller.marshal(outputObject, writer);

	// Retourner le XML généré
	return writer.toString();
    }
}

