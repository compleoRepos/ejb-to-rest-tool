package ma.eai.boa.xbanking.service.customer;

import ma.eai.boa.xbanking.vo.customer.DetailsCustomerIn;
import ma.eai.boa.xbanking.vo.customer.DetailsCustomerOut;

public interface Customer {
    DetailsCustomerOut getDetailsCustomer(String token);
}
