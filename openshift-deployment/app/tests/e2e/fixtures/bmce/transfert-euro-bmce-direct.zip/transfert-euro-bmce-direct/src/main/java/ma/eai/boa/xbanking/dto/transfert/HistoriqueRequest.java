package ma.eai.boa.xbanking.dto.transfert;

public class HistoriqueRequest {
    private String token;

    public String getToken() {
	return token;
    }

    public void setToken(String token) {
	this.token = token;
    }
}
