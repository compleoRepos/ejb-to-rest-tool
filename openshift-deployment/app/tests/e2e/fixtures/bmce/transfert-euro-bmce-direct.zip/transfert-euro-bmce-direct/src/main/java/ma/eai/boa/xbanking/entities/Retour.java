package ma.eai.boa.xbanking.entities;

import java.io.Serializable;

public class Retour implements Serializable {
    private static final long serialVersionUID = -6370822625760369530L;

    private String code;

    private String message;

    public String getCode() {
	return code;
    }

    public void setCode(String code) {
	this.code = code;
    }

    public String getMessage() {
	return message;
    }

    public void setMessage(String message) {
	this.message = message;
    }

    /**
     *
     */
    public Retour() {
	// Auto-generated constructor stub
    }

    /**
     * @param code
     * @param message
     */
    public Retour(String code, String message) {
	super();
	this.code = code;
	this.message = message;
    }

    @Override
    public String toString() {
        return "Retour{" +
                "code='" + code + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
