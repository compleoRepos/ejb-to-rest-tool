package ma.eai.boa.xbanking.handlers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import ma.eai.ingdev.fwk.logging.EaiLog;

public class RequestInterceptor extends HandlerInterceptorAdapter {
	
	private final static String PROJECT_NAME = "transfert-euro-service-bmce-direct";
	private final static String START_TIME_ATTRIBUTE = "startTime";
	private final static String RESPONSE_TIME_LABEL = "Temps de réponse(ms): ";

	@Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        long startTime = System.currentTimeMillis();
        request.setAttribute(START_TIME_ATTRIBUTE, startTime);
        EaiLog.initLogTraceInfos(request, PROJECT_NAME);
        return true;
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, 
			Object handler, Exception ex) throws Exception {

		long startTime = (Long) request.getAttribute(START_TIME_ATTRIBUTE);
		long endTime = System.currentTimeMillis();

		EaiLog.info(RESPONSE_TIME_LABEL + (endTime - startTime));

	}

}
