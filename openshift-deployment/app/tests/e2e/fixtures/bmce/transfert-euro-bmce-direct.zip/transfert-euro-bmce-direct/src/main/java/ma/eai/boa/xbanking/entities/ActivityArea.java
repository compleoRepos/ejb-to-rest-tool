package ma.eai.boa.xbanking.entities;

import javax.persistence.Entity;

@Entity
public class ActivityArea extends NamedIdentified {

	private static final long serialVersionUID = 4358370893999141471L;

	

}
