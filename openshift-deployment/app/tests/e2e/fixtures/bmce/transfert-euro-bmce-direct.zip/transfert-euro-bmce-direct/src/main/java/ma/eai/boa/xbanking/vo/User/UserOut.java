package ma.eai.boa.xbanking.vo.User;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "UserOut")
public class UserOut {

    private String email;
    private String uuid;
    private String token;

    public String getEmail() {
	return email;
    }

    public void setEmail(String email) {
	this.email = email;
    }

    public String getToken() {
	return token;
    }

    public void setToken(String token) {
	this.token = token;
    }

    public String getUuid() {
	return uuid;
    }

    public void setUuid(String uuid) {
	this.uuid = uuid;
    }
}
