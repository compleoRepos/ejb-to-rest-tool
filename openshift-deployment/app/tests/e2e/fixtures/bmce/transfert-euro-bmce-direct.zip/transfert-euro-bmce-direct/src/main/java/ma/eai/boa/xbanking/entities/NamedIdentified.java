package ma.eai.boa.xbanking.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.StringUtils;

import javax.persistence.MappedSuperclass;
import java.sql.Timestamp;

@MappedSuperclass
public abstract class NamedIdentified extends Identified {

	private static final long serialVersionUID = -2203472135623909820L;
	
	private String code;
	private String uuid;
	
	@JsonIgnore
	private String label;
	
	@JsonProperty("label_es")
	private String labelEs;
	
	@JsonProperty("label_it")
	private String labelIt;
	
	@JsonProperty("label_fr")
	private String labelFr;
	
	@JsonProperty("label_be")
	private String labelBe;
	
	@JsonProperty("label_de")
	private String labelDe;
	
	@JsonProperty("label_nl")
	private String labelNl;

	private String labelEN;
	
	/**
	 * 
	 * fonction pour supprimer les espace des libelle
	 */
	public void trimLabels() {
		if (StringUtils.isNotBlank(label)) {
			label = label.trim();
		}
		if (StringUtils.isNotBlank(labelFr)) {
			labelFr = labelFr.trim();
		}
		if (StringUtils.isNotBlank(labelEs)) {
			labelEs = labelEs.trim();
		}
		if (StringUtils.isNotBlank(labelIt)) {
			labelIt = labelIt.trim();
		}
		if (StringUtils.isNotBlank(labelBe)) {
			labelBe = labelBe.trim();
		}
		if (StringUtils.isNotBlank(labelDe)) {
			labelDe = labelDe.trim();
		}
		if (StringUtils.isNotBlank(labelNl)) {
			labelNl = labelNl.trim();
		}
	}
	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	/**
	 * 
	 */
	public NamedIdentified() {
	}

	/**
	 * @param dateInserted
	 */
	public NamedIdentified(Timestamp dateInserted) {
		super(dateInserted);
	}

	/**
	 * @param dateInserted
	 * @param code
	 * @param label
	 */
	public NamedIdentified(Timestamp dateInserted, String code, String label) {
		super(dateInserted);
		this.code = code;
		this.label = label;
	}

	public String getLabelEs() {
		return labelEs;
	}

	public void setLabelEs(String labelEs) {
		this.labelEs = labelEs;
	}

	public String getLabelIt() {
		return labelIt;
	}

	public void setLabelIt(String labelIt) {
		this.labelIt = labelIt;
	}

	public String getLabelFr() {
		return labelFr;
	}

	public void setLabelFr(String labelFr) {
		this.labelFr = labelFr;
	}


	public String getLabelBe() {
		return labelBe;
	}


	public void setLabelBe(String labelBe) {
		this.labelBe = labelBe;
	}


	public String getLabelDe() {
		return labelDe;
	}


	public void setLabelDe(String labelDe) {
		this.labelDe = labelDe;
	}


	public String getLabelNl() {
		return labelNl;
	}


	public void setLabelNl(String labelNl) {
		this.labelNl = labelNl;
	}

	public String getLabelEN() {
		return labelEN;
	}

	public void setLabelEN(String labelEN) {
		this.labelEN = labelEN;
	}
}
