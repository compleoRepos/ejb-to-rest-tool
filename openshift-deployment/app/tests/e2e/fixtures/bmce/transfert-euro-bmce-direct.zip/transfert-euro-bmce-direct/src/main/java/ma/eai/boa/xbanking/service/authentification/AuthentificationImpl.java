package ma.eai.boa.xbanking.service.authentification;

import com.fasterxml.jackson.databind.ObjectMapper;
import ma.eai.boa.xbanking.dto.authentication.CheckUserResponse;
import ma.eai.boa.xbanking.dto.authentication.TokenRequest;
import ma.eai.boa.xbanking.dto.authentication.UserStatusResponse;
import ma.eai.boa.xbanking.dto.createaccountphonenumber.PhoneNumberRequest;
import ma.eai.boa.xbanking.dto.createaccountphonenumber.PhoneNumberResponse;
import ma.eai.boa.xbanking.entities.User;
import ma.eai.boa.xbanking.repository.UserRepository;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.util.UserStep;
import ma.eai.boa.xbanking.vo.Authentication.CheckUserBesOut;
import ma.eai.boa.xbanking.vo.Authentication.CheckUserOut;
import ma.eai.boa.xbanking.vo.PhoneNumber.PhoneNumberIn;
import ma.eai.boa.xbanking.vo.PhoneNumber.PhoneNumberOut;
import ma.eai.boa.xbanking.vo.Retour;
import ma.eai.boa.xbanking.vo.User.UserIn;
import ma.eai.boa.xbanking.vo.validationOtp.ValidationOtpOut;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class AuthentificationImpl implements Authentification{

    private static final String USER_DISABLED = "ERR_USER_DISABLED";
    private final JwtTokenUtil jwtTokenUtil;
    private final UserRepository userRepository;
    private final RestTemplate restTemplate;

    @Value("${api.url}")
    private String url;


    @Autowired
    public AuthentificationImpl(JwtTokenUtil jwtTokenUtil, UserRepository userRepository, RestTemplate restTemplate) {
        this.jwtTokenUtil = jwtTokenUtil;
        this.userRepository = userRepository;
        this.restTemplate = restTemplate;
    }

    @Override
    public String generateToken(UserIn user) {
	EaiLog.info("user: {}",user.getEmail());
	String token = jwtTokenUtil.generateToken(user);
	EaiLog.info("token: {}", token);
	return StringUtils.isNotBlank(token) ? token : null;
    }

    @Override
    public CheckUserOut checkUser(String contratBad, String deviceId) {
        EaiLog.info("Start check user with contratBad : {}", contratBad);
        CheckUserOut checkUserOut = new CheckUserOut();
        try {
            User user = userRepository.findByContratBadAndStepIsNotNull(contratBad);
            if (user == null) {
                EaiLog.info("User not Found");
                checkUserOut.setUserFound(false);
                checkUserOut.setCode("111");
                checkUserOut.setMessage("USER_NOT_FOUND");
                EaiLog.info("End check User");
                return checkUserOut;
            }
            EaiLog.info("user found : {}", user.toString());
            UserIn userIn = new UserIn();
            userIn.setUuid(user.getUuid());
            userIn.setEmail(user.getEmail());

            String token = jwtTokenUtil.generateToken(userIn);
            generateAndSendToken(token, user.getEmail(), deviceId,checkUserOut);
            CheckUserBesOut checkUserBesOut= checkUserBes(token);
            EaiLog.info(checkUserBesOut.getCode());
            if(Constants.CODE_SUCCESS.equals(checkUserOut.getCode()) && !Constants.CODE_ERROR
                    .equals(checkUserBesOut.getCode())) {
                if(USER_DISABLED.equals(checkUserBesOut.getCode())) {
                    EaiLog.info("user disabled : {}", user.getEmail());
                    user.setContratBad("___" + user.getContratBad());
                    user.setEmail("___" + user.getEmail());
                    userRepository.save(user);
                    checkUserOut.setUserFound(false);
                    checkUserOut.setMessage(USER_DISABLED);
                    return checkUserOut;
                }
                checkUserOut.setUserFound(true);
                checkUserOut.setToken(token);
                checkUserOut.setLang(user.getCountryCode());
                checkUserOut.setClient(checkUserBesOut.isClient());
                checkUserOut.setMessage(checkUserBesOut.getCode());
            }else {
                checkUserOut.setMessage(checkUserBesOut.getCode());
                checkUserOut.setCode(Constants.CODE_ERROR);
            }
        }  catch(Exception e) {
            EaiLog.info("Error in checking user: {}", e);
            checkUserOut.setCode(Constants.CODE_ERROR);
            checkUserOut.setMessage("ERR_TECHNICAL");
         }
         
        EaiLog.info("End check User with contratbad : {}", contratBad);
        return checkUserOut;
    }
    public CheckUserBesOut checkUserBes(String token) {
        CheckUserBesOut checkUserBesOut=new CheckUserBesOut();
        try{
            String urlApi = new StringBuilder(url)
                    .append("customer/checkUser")
                    .toString();
            EaiLog.info("called url : {}",urlApi);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set(Constants.CANAL_HEADER, Constants.CANAL);
            EaiLog.info("Token utilisé : {}", token);
            headers.set("Authorization", token);
            HttpEntity<String> requestEntity = new HttpEntity<>(headers);
            EaiLog.info("--------- requestEntity------- : {}", requestEntity);
            ResponseEntity<UserStatusResponse> response = restTemplate.exchange(urlApi, HttpMethod.GET, requestEntity,
                    UserStatusResponse.class);
            UserStatusResponse body =response.getBody();
            EaiLog.info("returned response : {} ",response);
            if(body != null) {
                EaiLog.info("Response OK : {}", body.toString());
                checkUserBesOut.setCode(body.getCode());
                checkUserBesOut.setClient(body.isClient());
                checkUserBesOut.setDisabled(body.isDisabled());
            }
        } catch (Exception e) {
            EaiLog.info("Technical Error: {} " , e);
            checkUserBesOut.setCode(Constants.CODE_ERROR);
            checkUserBesOut.setMessage(Constants.TECHNICAL_ERROR);
        }
        EaiLog.info("Fin service checkUserBesOut");
        return checkUserBesOut;
    }

    @Override
    public boolean sendToken(TokenRequest tokenRequest) {
        EaiLog.info("Start service send token to BES for login : {}", tokenRequest.getLogin());

        String urlApi = url.concat("users/boa/token");

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(Constants.CANAL_HEADER, Constants.CANAL);

        HttpEntity<TokenRequest> httpEntity = new HttpEntity<>(tokenRequest, httpHeaders);
        EaiLog.info("request : {}", httpEntity.getBody());
        ResponseEntity<Retour> response = restTemplate.exchange(urlApi, HttpMethod.POST, httpEntity, Retour.class);
        String messageResponse  = response.getBody() != null ? response.getBody().getMessage() : null;
        EaiLog.info("End send token for login : {}",tokenRequest.getLogin());
        return (response.getStatusCode().is2xxSuccessful() && "SUCCESS_CODE".equals(messageResponse));
    }

    private void generateAndSendToken(String token, String email, String deviceId, CheckUserOut checkUserOut) {
        if(token != null) {
            TokenRequest tokenRequest = new TokenRequest();
            tokenRequest.setToken(token);
            tokenRequest.setLogin(email);
            tokenRequest.setDeviceId(deviceId);
            if(sendToken(tokenRequest)){
                checkUserOut.setCode(Constants.CODE_SUCCESS);
                checkUserOut.setMessage("OK");
            } else {
                checkUserOut.setCode(Constants.CODE_ERROR);
                checkUserOut.setMessage("Error BES in sending token");
            }
        } else {
            EaiLog.info("Token was generated null");
            checkUserOut.setCode(Constants.CODE_ERROR);
            checkUserOut.setMessage("Token generated is null");
        }
    }
}
