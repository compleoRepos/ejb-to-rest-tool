package ma.eai.boa.xbanking.dto.createaccountphonenumber;


import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class PhoneNumberRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("countryCode")
    private String countryCode;

    @JsonProperty("phoneNumber")
    private String phoneNumber;

    @JsonProperty("callingCode")
    private String callingCode;

    @JsonProperty("deviceId")
    private String deviceId;

    @JsonProperty("email")
    private String email;

    @JsonProperty("motdepasse")
    private String motdepasse;

    @Override
    public String toString() {
	return "PhoneNumberRequest{" + "countryCode='" + countryCode + '\'' + ", phoneNumber='" + phoneNumber + '\''
		+ ", callingCode='" + callingCode + '\'' + ", deviceId='" + deviceId + '\'' + ", email='" + email + '\''
		+ ", motdepasse='" + motdepasse + '\'' + '}';
    }

    public String getCountryCode() {
	return countryCode;
    }

    public void setCountryCode(String countryCode) {
	this.countryCode = countryCode;
    }

    public String getPhoneNumber() {
	return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
    }

    public String getCallingCode() {
	return callingCode;
    }

    public void setCallingCode(String callingCode) {
	this.callingCode = callingCode;
    }

    public String getDeviceId() {
	return deviceId;
    }

    public void setDeviceId(String deviceId) {
	this.deviceId = deviceId;
    }

    public String getEmail() {
	return email;
    }

    public void setEmail(String email) {
	this.email = email;
    }

    public String getMotdepasse() {
	return motdepasse;
    }

    public void setMotdepasse(String motdepasse) {
	this.motdepasse = motdepasse;
    }
}
