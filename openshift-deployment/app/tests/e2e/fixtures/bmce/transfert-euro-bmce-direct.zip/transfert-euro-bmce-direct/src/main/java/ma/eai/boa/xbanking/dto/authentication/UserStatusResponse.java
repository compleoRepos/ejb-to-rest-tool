package ma.eai.boa.xbanking.dto.authentication;

public class UserStatusResponse {

    private String code;

    private String message;

    private boolean client;

    private boolean disabled;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isClient() {
        return client;
    }

    public void setClient(boolean client) {
        this.client = client;
    }

    public boolean isDisabled() {
        return disabled;
    }

    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }

    @Override
    public String toString() {
        return "UserStatusResponse{" +
                "code='" + code + '\'' +
                ", message='" + message + '\'' +
                ", client=" + client + '\'' +
                ", disabled=" + disabled +
                '}';
    }
}
