package ma.eai.boa.xbanking.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.MappedSuperclass;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.SequenceGenerator;
import javax.persistence.GenerationType;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.UUID;

@MappedSuperclass
public abstract class Identified implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = -8778416725766243130L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "identified_seq")
	@SequenceGenerator(name = "identified_seq", sequenceName = "identified_sequence", allocationSize = 1)
	@Column(name = "id", nullable = false)
	@JsonIgnore
	private long id;
	
	@Column(nullable = false, updatable = false)
	@CreationTimestamp
	@JsonIgnore
	private Timestamp dateInserted;
	
	@Column(unique = true, nullable = false)
	private String uuid;
	
	public void setDateInserted() {

		Timestamp dateins = new Timestamp(System.currentTimeMillis());
		this.setDateInserted(dateins);
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Timestamp getDateInserted() {
		return dateInserted;
	}

	public void setDateInserted(Timestamp dateInserted) {
		this.dateInserted = dateInserted;
	}

	/**
	 * 
	 */
	public Identified() {
		setUuid();
	}
	

	/**
	 * @param id
	 * @param dateInserted
	 */
	public Identified(Timestamp dateInserted) {
		super();
		setUuid();
		this.dateInserted = dateInserted;
	}

	public String getUuid() {
		return uuid;
	}

	public final void setUuid() {
		final String uid = UUID.randomUUID().toString().replace("-", "");
		this.uuid = uid;
	}
	

}
