package util;

import ma.eai.boa.xbanking.util.UserStep;
import org.junit.Test;
import static org.junit.Assert.*;

public class StepperTest {

    @Test
    public void testEnumValues() {
	// Vérifie que toutes les valeurs de l'enum existent
	assertEquals("ETAPE1", UserStep.ETAPE1.getValue());
	assertEquals("ETAPE2", UserStep.ETAPE2.getValue());
	assertEquals("ETAPE3", UserStep.ETAPE3.getValue());
	assertEquals("ETAPE4", UserStep.ETAPE4.getValue());
	assertEquals("ETAPE5", UserStep.ETAPE5.getValue());
	assertEquals("ETAPE6", UserStep.ETAPE6.getValue());
	assertEquals("COMPLETED", UserStep.COMPLETED.getValue());
    }

    @Test
    public void testGetUserStepByValue() {
	// Test avec des valeurs valides
	assertEquals(UserStep.ETAPE1, UserStep.getUserStepByValue("ETAPE1"));
	assertEquals(UserStep.ETAPE2, UserStep.getUserStepByValue("ETAPE2"));
	assertEquals(UserStep.COMPLETED, UserStep.getUserStepByValue("COMPLETED"));
    }

    @Test
    public void testGetUserStepByValueCaseInsensitive() {
	// Test avec différentes casses
	assertEquals(UserStep.ETAPE1, UserStep.getUserStepByValue("etape1"));
	assertEquals(UserStep.ETAPE1, UserStep.getUserStepByValue("Etape1"));
	assertEquals(UserStep.ETAPE1, UserStep.getUserStepByValue("ETAPE1"));
    }

    @Test
    public void testGetUserStepByValueWithNull() {
	// Test avec une valeur null
	assertNull(UserStep.getUserStepByValue(null));
    }

    @Test
    public void testGetUserStepByValueWithInvalidValue() {
	// Test avec une valeur invalide
	assertNull(UserStep.getUserStepByValue("INVALID"));
	assertNull(UserStep.getUserStepByValue(""));
    }

    @Test
    public void testEnumValuesCount() {
	// Vérifie le nombre total de valeurs dans l'enum
	assertEquals(7, UserStep.values().length);
    }

    @Test
    public void testGetValue() {
	// Test de la méthode getValue pour chaque instance
	assertEquals("ETAPE1", UserStep.ETAPE1.getValue());
	assertEquals("ETAPE2", UserStep.ETAPE2.getValue());
	assertEquals("ETAPE3", UserStep.ETAPE3.getValue());
	assertEquals("ETAPE4", UserStep.ETAPE4.getValue());
	assertEquals("ETAPE5", UserStep.ETAPE5.getValue());
	assertEquals("ETAPE6", UserStep.ETAPE6.getValue());
	assertEquals("COMPLETED", UserStep.COMPLETED.getValue());
    }
}