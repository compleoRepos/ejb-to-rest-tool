package ma.eai.boa.xbanking.vo.SignContrat;

import ma.eai.boa.xbanking.vo.Retour;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "ValidateOtpSignContratOut")
public class ValidateOtpSignContratOut extends Retour {
}
