package ma.eai.boa.xbanking.service.signContrat;


import ma.eai.boa.xbanking.vo.SignContrat.GetContratIn;
import ma.eai.boa.xbanking.vo.SignContrat.GetContratOut;
import ma.eai.boa.xbanking.vo.SignContrat.SignContratIn;
import ma.eai.boa.xbanking.vo.SignContrat.SignContratOut;
import ma.eai.boa.xbanking.vo.SignContrat.ValidateOtpSignContratOut;
import ma.eai.boa.xbanking.vo.SignContrat.ValidateOtpSigneContratIn;

public interface SignContrat {
    SignContratOut signContrat(SignContratIn signContratIn);
    GetContratOut getContrat(GetContratIn getContratIn);
    ValidateOtpSignContratOut validateOtpSigneContrat(ValidateOtpSigneContratIn validateOtpSigneContratIn);
    GetContratOut getContratGestion(GetContratIn getContratIn);

}
