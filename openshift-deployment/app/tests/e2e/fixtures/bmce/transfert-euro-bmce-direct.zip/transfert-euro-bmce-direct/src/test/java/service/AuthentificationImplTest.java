package service;


import ma.eai.boa.xbanking.entities.User;
import ma.eai.boa.xbanking.repository.UserRepository;
import ma.eai.boa.xbanking.service.authentification.AuthentificationImpl;
import ma.eai.boa.xbanking.service.authentification.JwtTokenUtil;
import ma.eai.boa.xbanking.vo.Authentication.CheckUserOut;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

public class AuthentificationImplTest {

    @Mock
    private JwtTokenUtil jwtTokenUtil;

    @Mock
    private UserRepository userRepository;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private AuthentificationImpl authentificationService;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(authentificationService,"url","http://example.com/");

    }

    @Test
    public void checkUserTest_ShouldNotFindUser() {
        //Given
        String contratBad = "987654";
        String token = "bG9uZyB0b2tlbg==";
        String deviceId = "Kldkld==";
        // When
        when(userRepository.findByContratBadAndStepIsNotNull(anyString()))
                .thenReturn(null);
        when(jwtTokenUtil.generateToken(any())).thenReturn(token);

        //Then
        CheckUserOut response = authentificationService.checkUser(contratBad, deviceId);

        assertFalse(response.isUserFound());

    }

    @Test
    public void checkUserTest_ShouldGenerateToken() {
        //Given
        String contratBad = "987654";
        String token = "bG9uZyB0b2tlbg==";
        String deviceId = "ERKOLJF__sdg";

        User user = new User();

        user.setUuid("0957KUPMMKP63957");
        user.setEmail("adnaneharti2509@gmail.com");
        // When
        when(userRepository.findByContratBadAndStepIsNotNull(anyString()))
                .thenReturn(user);
        when(jwtTokenUtil.generateToken(any())).thenReturn(token);

        //Then
        CheckUserOut response = authentificationService.checkUser(contratBad, deviceId);

        assertFalse(response.isUserFound());

    }


}

