package ma.eai.boa.xbanking.dto.Attachements;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class AttachementObject {
    private List<AttachementsRequest> attachementRequests;

    @JsonProperty("attemptsCount")
    private int nbrTentative;

    public List<AttachementsRequest> getAttachementRequests() {
	return attachementRequests;
    }

    public void setAttachementRequests(List<AttachementsRequest> attachementRequests) {
	this.attachementRequests = attachementRequests;
    }

    public int getNbrTentative() {
	return nbrTentative;
    }

    public void setNbrTentative(int nbrTentative) {
	this.nbrTentative = nbrTentative;
    }
}
