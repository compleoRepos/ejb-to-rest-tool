package ma.eai.boa.xbanking.dto.SignContrat;

import ma.eai.boa.xbanking.entities.Retour;

import java.io.Serializable;

public class IbanResponse  extends Retour implements Serializable {

    private static final long serialVersionUID = -63708226257603695L;


    private String iban;

    private String reference;

    private String bic;

    public String getIban() {
        return iban;
    }

    public String getReference() {
        return reference;
    }

    public String getBic() {
        return bic;
    }

    public void setIban(String iban) {
        this.iban = iban;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public void setBic(String bic) {
        this.bic = bic;
    }

    @Override
    public String toString() {
        return "IbanResponse{" +
                "iban='" + iban + '\'' +
                ", reference='" + reference + '\'' +
                ", bic='" + bic + '\'' +
                '}';
    }
}
