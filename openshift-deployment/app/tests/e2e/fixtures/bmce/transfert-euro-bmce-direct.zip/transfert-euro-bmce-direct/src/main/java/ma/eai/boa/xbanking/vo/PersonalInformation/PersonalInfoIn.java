package ma.eai.boa.xbanking.vo.PersonalInformation;

public class PersonalInfoIn {
    private String ctrBad;

    public String getCtrBad() {
	return ctrBad;
    }

    public void setCtrBad(String ctrBad) {
	this.ctrBad = ctrBad;
    }
}
