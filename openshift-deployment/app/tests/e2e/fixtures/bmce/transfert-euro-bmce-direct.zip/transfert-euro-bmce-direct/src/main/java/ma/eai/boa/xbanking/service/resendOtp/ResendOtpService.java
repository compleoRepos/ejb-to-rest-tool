package ma.eai.boa.xbanking.service.resendOtp;

import ma.eai.boa.xbanking.dto.validateOtp.ResendOtpResponse;
import ma.eai.boa.xbanking.vo.Retour;
import ma.eai.boa.xbanking.vo.validationOtp.ResendOtpOut;

public interface ResendOtpService {

  ResendOtpOut resendOtp(String token);
  Retour resendOtpEer(String otpID);

}
