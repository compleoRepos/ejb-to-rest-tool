package util;

import ma.eai.boa.xbanking.util.Helpers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.security.SignatureException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class HelpersTest {

    @InjectMocks
    private Helpers helpers;

    @Test
    public void testHashMac_Success() throws SignatureException, SignatureException {
        // Arrange
        String text = "testData";
        String key = "testKey";

        // Act
        String result = helpers.hashMac(text, key);

        // Assert
        assertNotNull(result);
        assertEquals(64, result.length()); // SHA-256 produces 64 hex characters
    }


}
