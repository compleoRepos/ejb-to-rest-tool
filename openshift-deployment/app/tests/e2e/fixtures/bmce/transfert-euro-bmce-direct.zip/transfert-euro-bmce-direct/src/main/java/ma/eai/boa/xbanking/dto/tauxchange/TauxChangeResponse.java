package ma.eai.boa.xbanking.dto.tauxchange;

import java.math.BigDecimal;
import java.util.List;

public class TauxChangeResponse {
    private String code;
    private String message;
    private BigDecimal delaiToTransfert;
    private BigDecimal tauxChange;
    private BigDecimal fraisTransfertVirement;
    private BigDecimal fraisTransfertCB;
    private List<Commission> commissions;

    public String getCode() {
	return code;
    }

    public void setCode(String code) {
	this.code = code;
    }

    public String getMessage() {
	return message;
    }

    public void setMessage(String message) {
	this.message = message;
    }

    public BigDecimal getDelaiToTransfert() {
	return delaiToTransfert;
    }

    public void setDelaiToTransfert(BigDecimal delaiToTransfert) {
	this.delaiToTransfert = delaiToTransfert;
    }

    public BigDecimal getTauxChange() {
	return tauxChange;
    }

    public void setTauxChange(BigDecimal tauxChange) {
	this.tauxChange = tauxChange;
    }

    public BigDecimal getFraisTransfertVirement() {
	return fraisTransfertVirement;
    }

    public void setFraisTransfertVirement(BigDecimal fraisTransfertVirement) {
	this.fraisTransfertVirement = fraisTransfertVirement;
    }

    public BigDecimal getFraisTransfertCB() {
	return fraisTransfertCB;
    }

    public void setFraisTransfertCB(BigDecimal fraisTransfertCB) {
	this.fraisTransfertCB = fraisTransfertCB;
    }

    public List<Commission> getCommissions() {
	return commissions;
    }

    public void setCommissions(List<Commission> commissions) {
	this.commissions = commissions;
    }

    @Override
    public String toString() {
        return "TauxChangeResponse{" +
                "code='" + code + '\'' +
                ", message='" + message + '\'' +
                ", delaiToTransfert=" + delaiToTransfert +
                ", tauxChange=" + tauxChange +
                ", fraisTransfertVirement=" + fraisTransfertVirement +
                ", fraisTransfertCB=" + fraisTransfertCB +
                ", commissions=" + commissions +
                '}';
    }
}
