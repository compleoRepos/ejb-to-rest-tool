package ma.eai.boa.xbanking.vo.SignContrat;

import ma.eai.boa.xbanking.vo.Retour;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "GetContratOut")
public class GetContratOut extends Retour {
    private String base64;

    public String getBase64() {
	return base64;
    }

    public void setBase64(String base64) {
	this.base64 = base64;
    }
}
