package ma.eai.boa.xbanking.vo.FirstStep;

import ma.eai.boa.xbanking.vo.Retour;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "FirstStepOut")
public class FirstStepOut extends Retour {
}
