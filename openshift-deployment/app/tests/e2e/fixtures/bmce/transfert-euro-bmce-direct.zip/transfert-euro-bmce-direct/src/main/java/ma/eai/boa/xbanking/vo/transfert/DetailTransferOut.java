package ma.eai.boa.xbanking.vo.transfert;

import ma.eai.boa.xbanking.dto.transfert.DetailTransfer;
import ma.eai.boa.xbanking.vo.Retour;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "DetailTransferOut")
public class DetailTransferOut extends Retour {

    private DetailTransfer detailTransfer;

    public DetailTransfer getDetailTransfer() {
        return detailTransfer;
    }

    public void setDetailTransfer(DetailTransfer detailTransfer) {
        this.detailTransfer = detailTransfer;
    }
}
