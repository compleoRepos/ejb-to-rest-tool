package ma.eai.boa.xbanking.dto.transfert;

import ma.eai.boa.xbanking.vo.Retour;

public class TransfertResponse extends Retour {
    private String uuid;
    public String getUuid() {
	return uuid;
    }

    public void setUuid(String uuid) {
	this.uuid = uuid;
    }
}
