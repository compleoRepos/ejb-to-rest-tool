package ma.eai.boa.xbanking.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Parameters implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6335882707808930850L;

	private List<Country> countries;
	
	private List<RelationFamiliale> relationsShip;
	
	private List<ActivityArea> activityAreas;
	
	@JsonIgnore
	private List<Comission> comissions;
		
	private List<FundsSource> fundsSources;
	
	private List<Nationality> nationalities;
	
	private List<Periodicity> periodicities;
	
	private List<Profession> professions;
	
	private List<TransfertMotif> transfertMotifs;
	
	private List<DocumentType> docTypes;
	
	@JsonProperty("incomeBrackets")
	private List<RevenuTranche> tranches;
	
	private List<Frequency> frequencies;
	
	//@JsonIgnore
	private List<Bank> banks;
	
	private String minVersion;
	
	private List<String> creditCard;
	
	private int nbrSecTimer;
	
	public Parameters() {
		//comment
	}

	public List<Country> getCountries() {
		return countries;
	}

	public void setCountries(List<Country> countries) {
		this.countries = countries;
	}

	public List<RelationFamiliale> getRelationsShip() {
		return relationsShip;
	}

	public void setRelationsShip(List<RelationFamiliale> relationsShip) {
		this.relationsShip = relationsShip;
	}

	public List<ActivityArea> getActivityAreas() {
		return activityAreas;
	}

	public void setActivityAreas(List<ActivityArea> activityAreas) {
		this.activityAreas = activityAreas;
	}

	public List<FundsSource> getFundsSources() {
		return fundsSources;
	}

	public void setFundsSources(List<FundsSource> fundsSources) {
		this.fundsSources = fundsSources;
	}

	public List<Nationality> getNationalities() {
		return nationalities;
	}

	public void setNationalities(List<Nationality> nationalities) {
		this.nationalities = nationalities;
	}

	public List<Periodicity> getPeriodicities() {
		return periodicities;
	}

	public void setPeriodicities(List<Periodicity> periodicities) {
		this.periodicities = periodicities;
	}

	public List<Profession> getProfessions() {
		return professions;
	}

	public void setProfessions(List<Profession> professions) {
		this.professions = professions;
	}

	public List<TransfertMotif> getTransfertMotifs() {
		return transfertMotifs;
	}

	public void setTransfertMotifs(List<TransfertMotif> transfertMotifs) {
		this.transfertMotifs = transfertMotifs;
	}

	public List<DocumentType> getDocTypes() {
		return docTypes;
	}

	public void setDocTypes(List<DocumentType> docTypes) {
		this.docTypes = docTypes;
	}

	public List<RevenuTranche> getTranches() {
		return tranches;
	}

	public void setTranches(List<RevenuTranche> tranches) {
		this.tranches = tranches;
	}

	public List<Frequency> getFrequencies() {
		return frequencies;
	}

	public void setFrequencies(List<Frequency> frequencies) {
		this.frequencies = frequencies;
	}
	
	public List<Comission> getComissions() {
		return comissions;
	}

	public void setComissions(List<Comission> comissions) {
		this.comissions = comissions;
	}

	public List<Bank> getBanks() {
		return banks;
	}

	public void setBanks(List<Bank> banks) {
		this.banks = banks;
	}

	public String getMinVersion() {
		return minVersion;
	}

	public void setMinVersion(String minVersion) {
		this.minVersion = minVersion;
	}

	public List<String> getCreditCard() {
		return new ArrayList<>(creditCard);
	}

	public void setCreditCard(List<String> creditCard) {
		this.creditCard = Collections.unmodifiableList(creditCard);
	}

	public int getNbrSecTimer() {
		return nbrSecTimer;
	}

	public void setNbrSecTimer(int nbrSecTimer) {
		this.nbrSecTimer = nbrSecTimer;
	}


}
