package ma.eai.boa.xbanking.util;

public enum Status {
	SAVED,
	WAITING_TO_RECEIVE,
	SENT,
	CANCELLED,
	DONE,
	;

}

