package ma.eai.boa.xbanking.repository;

import ma.eai.boa.xbanking.entities.GeneralParameters;
import ma.eai.boa.xbanking.util.ParamType;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;


@Repository
public interface GeneralParametersRepository extends CrudRepository<GeneralParameters, String> {

    Optional<GeneralParameters> findGeneralParametersByUuidAndParamTypeAndCode(String uuid, String type,String code);
    GeneralParameters findGeneralParametersByCode(String code);
}
