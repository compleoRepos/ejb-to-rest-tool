package ma.eai.boa.xbanking.service.steper;


import com.fasterxml.jackson.databind.ObjectMapper;
import ma.eai.boa.xbanking.dto.ThirdStep.ThirdStepRequest;
import ma.eai.boa.xbanking.dto.ThirdStep.ThirdStepResponse;
import ma.eai.boa.xbanking.dto.createaccountphonenumber.PhoneNumberRequest;
import ma.eai.boa.xbanking.dto.createaccountphonenumber.PhoneNumberResponse;
import ma.eai.boa.xbanking.dto.firstStep.FirstStepRequest;
import ma.eai.boa.xbanking.dto.firstStep.FistStepResponse;
import ma.eai.boa.xbanking.dto.steps.GetStepResponse;
import ma.eai.boa.xbanking.dto.tauxchange.TauxChangeResponse;
import ma.eai.boa.xbanking.entities.DataProspect;
import ma.eai.boa.xbanking.entities.User;
import ma.eai.boa.xbanking.repository.DataProspect.DataProspectRepository;
import ma.eai.boa.xbanking.repository.UserRepository;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.util.JwtUtil;
import ma.eai.boa.xbanking.util.UserStep;
import ma.eai.boa.xbanking.vo.FirstStep.FirstStepIn;
import ma.eai.boa.xbanking.vo.FirstStep.FirstStepOut;
import ma.eai.boa.xbanking.vo.PhoneNumber.PhoneNumberOut;
import ma.eai.boa.xbanking.vo.Retour;
import ma.eai.boa.xbanking.vo.Step.StepIn;
import ma.eai.boa.xbanking.vo.Step.StepOut;
import ma.eai.boa.xbanking.vo.ThirdStep.ThirdStepIn;
import ma.eai.boa.xbanking.vo.ThirdStep.ThirdStepOut;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class SteperImpl implements Steper{

	private static final String SUCCESS_CODE = "SUCCESS_CODE";
	private static final String ERROR_CALL_BES = "Error calling BES API : {}";
	private static final String TECHNICAL_ERROR = "TECHNICAL ERROR";
    	private static final String RESPONSE_EMPTY = "RESPONSE_EMPTY";


    @Value("${api.url}")
    public String urlApi;

    private final RestTemplate restTemplate;

	private final UserRepository userRepository;

	private final DataProspectRepository dataProspectRepository;

	private final JwtUtil jwtTokenUtil;

	public SteperImpl(RestTemplate restTemplate, UserRepository userRepository, DataProspectRepository dataProspectRepository, JwtUtil jwtTokenUtil) {
		this.restTemplate = restTemplate;
		this.userRepository = userRepository;
		this.dataProspectRepository = dataProspectRepository;
		this.jwtTokenUtil = jwtTokenUtil;
	}

	@Override
    public FirstStepOut valideFirstStep(FirstStepIn firstStepIn) {
	FirstStepOut retourFirstStep=new FirstStepOut();
	try{
	    EaiLog.info("firstStepIn---------------->: {}"+firstStepIn.toString());
	    FirstStepRequest firstStepRequest = getFirstStepRequest(firstStepIn);
	    EaiLog.info("firstStepRequest----------->: {}"+firstStepRequest.toString());
	    String url = new StringBuilder(urlApi)
		    .append("prospect/validatFirstForm")
		    .toString();
	    EaiLog.info("url appel: {}",url);
	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.set(HttpHeaders.AUTHORIZATION,firstStepIn.getToken());
	    headers.set(Constants.CANAL_HEADER, Constants.CANAL);
	    ObjectMapper objectMapper = new ObjectMapper();

	    String jsonRequest = objectMapper.writeValueAsString(firstStepRequest);
	    EaiLog.info("jsonRequest==================>: {}"+jsonRequest);
	    EaiLog.info("headers==================>: {}"+headers);
	    HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, headers);
	    ResponseEntity<FistStepResponse> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
		    FistStepResponse.class);
	    FistStepResponse body=response.getBody();
	    if(body != null && SUCCESS_CODE.equals(body.getCode())) {
		EaiLog.info("Response OK : {}", response);
		retourFirstStep.setCode(Constants.CODE_SUCCESS);
		retourFirstStep.setMessage("OK");
		saveInRepo(firstStepIn);

	    }else {
		EaiLog.info("Response KO : {}", response);
		retourFirstStep.setCode(Constants.CODE_ERROR);
		retourFirstStep.setMessage((body != null ? body.getCode() : RESPONSE_EMPTY));
	    }
	    EaiLog.info("Fin service valideFirstStep");
	} catch (Exception e) {
	    EaiLog.error(ERROR_CALL_BES,  e);
	    retourFirstStep.setCode(Constants.CODE_ERROR);
	    retourFirstStep.setMessage(TECHNICAL_ERROR);
	}
	return retourFirstStep;
    }

    @Override
    public StepOut getStep(StepIn stepIn) {
	StepOut stepOut=new StepOut();
	try{
	    String url = new StringBuilder(urlApi)
		    .append("prospect/getStep")
		    .toString();
	    EaiLog.info("url appel: {}",url);
	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.set(HttpHeaders.AUTHORIZATION,stepIn.getToken());
	    headers.set(Constants.CANAL_HEADER, Constants.CANAL);
	    HttpEntity<String> requestEntity = new HttpEntity<>(headers);
	    ResponseEntity<GetStepResponse> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
		    GetStepResponse.class);
	    GetStepResponse body = response.getBody();
	    if(body != null && response.getStatusCode().is2xxSuccessful()) {
		EaiLog.info("Response OK : {}", response);
		stepOut.setDtProspect(body.getDtProspect());
		stepOut.setBeneficiairesList(body.getBeneficiairesList());
		stepOut.setAddDataProspect(body.getAddDataProspect());
		stepOut.setStep(body.getCode());
		stepOut.setCode(Constants.CODE_SUCCESS);
		stepOut.setMessage("OK");
	    }else {
		EaiLog.info("Error calling BES ws : {}", response);
		stepOut.setCode(Constants.CODE_ERROR);
		stepOut.setMessage((body != null ? body.getCode() : RESPONSE_EMPTY));
	    }
	} catch (Exception e) {
	    EaiLog.error(ERROR_CALL_BES , e);
	    stepOut.setCode(Constants.CODE_ERROR);
	    stepOut.setMessage("ERR_TECHNICAL");
	}
	return stepOut;
    }

    @Override
    public ThirdStepOut valideThirdStep(ThirdStepIn thirdStepIn) {
	ThirdStepOut retourThirdStep=new ThirdStepOut();
	String email = jwtTokenUtil.getUsernameFromToken(thirdStepIn.getToken());
	if (email == null) {
		EaiLog.info("email not found in token");
		retourThirdStep.setCode("111");
		retourThirdStep.setMessage("email null in token");
		return retourThirdStep;
	}
	EaiLog.info("Start service validate third step by email :{}", email);
	try{
	    ThirdStepRequest thirdStepRequest = getThirdStepRequest(thirdStepIn);

	    String url = new StringBuilder(urlApi)
		    .append("prospect/validatThirdForm")
		    .toString();
	    EaiLog.info("url appel prospect/validatThirdForm: {}",url);

	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.set(HttpHeaders.AUTHORIZATION,thirdStepIn.getToken());
	    headers.set(Constants.CANAL_HEADER, Constants.CANAL);
	    EaiLog.info("AUTHORIZATION===========> : {}",thirdStepIn.getToken());
	    ObjectMapper objectMapper = new ObjectMapper();

	    String jsonRequest = objectMapper.writeValueAsString(thirdStepRequest);
	    EaiLog.info("jsonRequest==================> :{}",jsonRequest);
	    HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, headers);
	    ResponseEntity<ThirdStepResponse> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
		    ThirdStepResponse.class);
	    ThirdStepResponse body=response.getBody();
	    EaiLog.info("response status : {}",response.getStatusCodeValue());
		EaiLog.info("response body : {}", response);
	    if(body != null  && SUCCESS_CODE.equals(body.getCode())) {
		EaiLog.info("Response OK BES Validating Form : {}", body);
		User user = userRepository.findByEmail(email);
		user.setStep(UserStep.ETAPE3);
		userRepository.save(user);
		saveDataProspect(thirdStepIn,user);
		retourThirdStep.setCode(Constants.CODE_SUCCESS);
		retourThirdStep.setMessage("OK");
	    }else {
		EaiLog.info("Error Response BES validating form service");
		retourThirdStep.setCode(Constants.CODE_ERROR);
		retourThirdStep.setMessage((body != null ? body.getCode() : RESPONSE_EMPTY));
	    }
	} catch (Exception e) {
	    EaiLog.error(ERROR_CALL_BES , e);
	    retourThirdStep.setCode(Constants.CODE_ERROR);
	    retourThirdStep.setMessage("ERR_TECHNICAL");
	}
	EaiLog.info("Fin service valideThirdStep");
	return retourThirdStep;
    }

	private void saveDataProspect(ThirdStepIn thirdStepIn, User user) {
	    DataProspect dataProspect = dataProspectRepository.findById(user.getUuid())
		    .orElseThrow(() -> new RuntimeException("User not found for UUID: {}" + user.getUuid()));
		dataProspect.setUuid(user.getUuid());
		dataProspect.setIncome(thirdStepIn.getAmountofincome());
		dataProspect.setFunds(thirdStepIn.getSourceoffunds());
		dataProspect.setTransfertMotif(thirdStepIn.getTransfertMotif());
		dataProspect.setPeriodicity(thirdStepIn.getPeriodicity());
		dataProspect.setIncomeBracket(thirdStepIn.getIncomeBracket());
		dataProspect.setProfession(thirdStepIn.getProfession());
		dataProspect.setActivityArea(thirdStepIn.getActivityArea());
		dataProspect.setTransferVolume(thirdStepIn.getTransfervolume());
		dataProspect.setNationalIdentifier(thirdStepIn.getNationalIdentifier());
		dataProspect.setPoliticallyExposed(thirdStepIn.isPoliticallyexposed());
		dataProspect.setLuiMemePPE(thirdStepIn.isLuiMemePPE());
		dataProspect.setFullNamePPE(thirdStepIn.getFullNamePPE());
		dataProspect.setFunctionPPE(thirdStepIn.getFunctionPPE());
		dataProspect.setRelationshipPPE(thirdStepIn.getRelationshipPPE());

		dataProspect.setUser(user);

		dataProspectRepository.save(dataProspect);
	}

    private static FirstStepRequest getFirstStepRequest(FirstStepIn firstStepIn) {
	FirstStepRequest firstStepRequest = new FirstStepRequest();
	firstStepRequest.setBirthCity(firstStepIn.getBirthCity());
	firstStepRequest.setNationality(firstStepIn.getNationality());
	firstStepRequest.setAddress(firstStepIn.getAddress());
	firstStepRequest.setBirthCountry(firstStepIn.getBirthCountry());
	firstStepRequest.setCivilite(firstStepIn.getCivilite());
	firstStepRequest.setClientBOA(firstStepIn.getClientBOA());
	firstStepRequest.setZipCode(firstStepIn.getZipCode());
	firstStepRequest.setFirstname(firstStepIn.getFirstname());
	firstStepRequest.setLastname(firstStepIn.getLastname());
	firstStepRequest.setCity(firstStepIn.getCity());
	firstStepRequest.setDatedenaissance(firstStepIn.getDatedenaissance());
	firstStepRequest.setClientBOA(firstStepIn.getClientBOA());
	return firstStepRequest;
    }

    private static ThirdStepRequest getThirdStepRequest(ThirdStepIn thirdStepIn) {
	ThirdStepRequest thirdStepRequest = new ThirdStepRequest();
	thirdStepRequest.setAmountofincome(thirdStepIn.getAmountofincome());
	thirdStepRequest.setSourceoffunds(thirdStepIn.getSourceoffunds());
	thirdStepRequest.setTransfertMotif(thirdStepIn.getTransfertMotif());
	thirdStepRequest.setPeriodicity(thirdStepIn.getPeriodicity());
	thirdStepRequest.setFrequency(thirdStepIn.getFrequency());
	thirdStepRequest.setIncomeBracket(thirdStepIn.getIncomeBracket());
	thirdStepRequest.setNationalIdentifier(thirdStepIn.getNationalIdentifier());
	thirdStepRequest.setPoliticallyexposed(thirdStepIn.isPoliticallyexposed());
	thirdStepRequest.setProfession(thirdStepIn.getProfession());
	thirdStepRequest.setActivityArea(thirdStepIn.getActivityArea());
	thirdStepRequest.setTransfervolume(thirdStepIn.getTransfervolume());
	thirdStepRequest.setLuiMemePPE(thirdStepIn.isLuiMemePPE());
	thirdStepRequest.setFunctionPPE(thirdStepIn.getFunctionPPE());
	thirdStepRequest.setFullNamePPE(thirdStepIn.getFullNamePPE());
	thirdStepRequest.setRelationshipPPE(thirdStepIn.getRelationshipPPE());
	return thirdStepRequest;
    }

    private void saveInRepo(FirstStepIn firstStepIn){
	EaiLog.info("<------------------------save data start ------------------------>");
	String token = firstStepIn.getToken();
	EaiLog.info("token : {}",token);
	String name= jwtTokenUtil.getUsernameFromToken(token);
	EaiLog.info("name : {}",name);
	User user = userRepository.findByEmail(name);
	EaiLog.info("user : {}",user.getUuid());
	user.setStep(UserStep.ETAPE2);
	userRepository.save(user);
	DataProspect dataProspect = getDataProspect(firstStepIn, user);
	EaiLog.info("dataProspect : {}",dataProspect.getFirstname());
	dataProspectRepository.save(dataProspect);
    }

    private static DataProspect getDataProspect(FirstStepIn firstStepIn, User user) {
	DataProspect dataProspect = new DataProspect();
	dataProspect.setUuid(user.getUuid());
	dataProspect.setNationality(firstStepIn.getNationality());
	dataProspect.setBirthCity(firstStepIn.getBirthCity());
	dataProspect.setAddress(firstStepIn.getAddress());
	dataProspect.setBirthCountry(firstStepIn.getBirthCountry());
	dataProspect.setCivility(firstStepIn.getCivilite());
	dataProspect.setClientBOA(firstStepIn.getClientBOA());
	dataProspect.setCodePostale(firstStepIn.getZipCode());
	dataProspect.setFirstname(firstStepIn.getFirstname());
	dataProspect.setLastname(firstStepIn.getLastname());
	dataProspect.setCity(firstStepIn.getCity());
	dataProspect.setBirthday(firstStepIn.getDatedenaissance());
	dataProspect.setUser(user);
	return dataProspect;
    }

}
