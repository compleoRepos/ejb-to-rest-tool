package ma.eai.boa.xbanking.repository.DataProspect;

import ma.eai.boa.xbanking.entities.DataProspect;
import org.springframework.data.repository.CrudRepository;

public interface DataProspectRepository  extends CrudRepository<DataProspect, String> {
}
