package ma.eai.boa.xbanking.vo.SignContrat;


public class ValidateOtpSigneContratIn {
    private String uuid;

    private String otpID;

    private String otp;

    private String deviceId;

    private String token;

    public String getUuid() {
	return uuid;
    }

    public void setUuid(String uuid) {
	this.uuid = uuid;
    }

    public String getOtpID() {
	return otpID;
    }

    public void setOtpID(String otpID) {
	this.otpID = otpID;
    }

    public String getOtp() {
	return otp;
    }

    public void setOtp(String otp) {
	this.otp = otp;
    }

    public String getDeviceId() {
	return deviceId;
    }

    public void setDeviceId(String deviceId) {
	this.deviceId = deviceId;
    }

    public String getToken() {
	return token;
    }

    public void setToken(String token) {
	this.token = token;
    }
}
