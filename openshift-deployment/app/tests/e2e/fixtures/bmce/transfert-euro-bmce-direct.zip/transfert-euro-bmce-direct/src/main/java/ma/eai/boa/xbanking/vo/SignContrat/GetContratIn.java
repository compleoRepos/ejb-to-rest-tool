package ma.eai.boa.xbanking.vo.SignContrat;

public class GetContratIn {
    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
