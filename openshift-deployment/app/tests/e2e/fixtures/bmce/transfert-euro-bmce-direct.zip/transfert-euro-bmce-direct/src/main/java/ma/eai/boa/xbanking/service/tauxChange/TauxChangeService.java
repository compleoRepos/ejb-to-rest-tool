package ma.eai.boa.xbanking.service.tauxChange;

import ma.eai.boa.xbanking.dto.tauxchange.Commission;
import ma.eai.boa.xbanking.dto.tauxchange.TauxChangeResponse;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.vo.TauxChange.TauxChangeIn;
import ma.eai.boa.xbanking.vo.TauxChange.TauxChangeOut;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TauxChangeService {
    @Value("${api.url}")
    public String urlApi;
    @Autowired
    RestTemplate restTemplate;
    public TauxChangeOut getTauxChange(TauxChangeIn tauxChangeIn) {
	TauxChangeOut tauxChangeOut=new TauxChangeOut();
	try{
	    String url = new StringBuilder(urlApi)
		    .append("transfert/tauxChange/")
		    .append(tauxChangeIn.getLangue())
		    .toString();
	    EaiLog.info("url appel: {}", url);
	    ResponseEntity<TauxChangeResponse> response = restTemplate.getForEntity(url, TauxChangeResponse.class);
	    TauxChangeResponse responseDTO=response.getBody();
	    if(responseDTO != null && "SUCCESS_CODE".equals(responseDTO.getCode())) {
		EaiLog.info("calling BES  successfully : {}" , responseDTO.toString());
		tauxChangeOut.setTauxChange(String.valueOf(responseDTO.getTauxChange()));
		tauxChangeOut.setDelaiToTransfert(String.valueOf(responseDTO.getDelaiToTransfert()));
		tauxChangeOut.setFraisTransfertCB(String.valueOf(responseDTO.getFraisTransfertCB()));
		tauxChangeOut.setFraisTransfertVirement(String.valueOf(responseDTO.getFraisTransfertVirement()));
		//Return only tranfers per card
		List<Commission> commissions = responseDTO.getCommissions().stream().filter( item ->
				item.getCanal() == 1).collect(Collectors.toList());
        	tauxChangeOut.setCommissions(commissions);
		tauxChangeOut.setCode(Constants.CODE_SUCCESS);
		tauxChangeOut.setMessage("OK");
	    }else {
		tauxChangeOut.setCode(Constants.CODE_ERROR);
		tauxChangeOut.setMessage((responseDTO != null ? responseDTO.getCode(): "RESPONSE_EMPTY"));
	    }
	} catch (Exception e) {
	    EaiLog.error("Une erreur inconnue est survenue : {}" + e);
	    tauxChangeOut.setCode(Constants.CODE_ERROR);
	    tauxChangeOut.setMessage(Constants.TECHNICAL_ERROR);
	}
	return tauxChangeOut;
    }
}
