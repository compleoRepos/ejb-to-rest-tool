package ma.eai.boa.xbanking.vo.Step;

public class StepIn {
    private String token;

    public String getToken() {
	return token;
    }

    public void setToken(String token) {
	this.token = token;
    }
}
