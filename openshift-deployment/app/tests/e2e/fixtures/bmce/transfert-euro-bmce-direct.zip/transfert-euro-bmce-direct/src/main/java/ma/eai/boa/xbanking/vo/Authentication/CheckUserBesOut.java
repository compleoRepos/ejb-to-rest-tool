package ma.eai.boa.xbanking.vo.Authentication;

import ma.eai.boa.xbanking.vo.Retour;

public class CheckUserBesOut extends Retour {

    private boolean client;

    private boolean disabled;

    public boolean isClient() {
        return client;
    }

    public void setClient(boolean client) {
        this.client = client;
    }

    public boolean isDisabled() {
        return disabled;
    }

    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }
}
