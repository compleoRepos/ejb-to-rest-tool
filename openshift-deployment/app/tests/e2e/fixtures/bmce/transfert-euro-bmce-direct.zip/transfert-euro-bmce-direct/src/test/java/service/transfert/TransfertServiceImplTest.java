package service.transfert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import ma.eai.boa.xbanking.dto.transfert.DetailTransfer;
import ma.eai.boa.xbanking.dto.transfert.HistoriqueResponse;
import ma.eai.boa.xbanking.dto.transfert.TransfertRequest;
import ma.eai.boa.xbanking.dto.transfert.TransfertResponse;
import ma.eai.boa.xbanking.entities.History;
import ma.eai.boa.xbanking.entities.User;
import ma.eai.boa.xbanking.repository.UserRepository;
import ma.eai.boa.xbanking.repository.transfert.TransfertRepository;
import ma.eai.boa.xbanking.service.transfert.TransfertImpl;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.util.Helpers;
import ma.eai.boa.xbanking.util.JwtUtil;
import ma.eai.boa.xbanking.vo.historiqueTransfert.HistoriqueOut;
import ma.eai.boa.xbanking.vo.transfert.DetailTransferOut;
import ma.eai.boa.xbanking.vo.transfert.TransfertIn;
import ma.eai.boa.xbanking.vo.transfert.TransfertOut;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.security.SignatureException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TransfertServiceImplTest {

    @InjectMocks
    private TransfertImpl transfertImpl;
    @Mock
    private UserRepository userRepository;

    @Mock
    private TransfertRepository transfertRepository;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private JwtUtil jwtUtil;

	@Mock
	private Helpers helpers;

    @Before
    public void setUp() {
	transfertImpl.urlApi = "http://api.example.com/";
	transfertImpl.keyData = "testKey";
	transfertImpl.bidKey = "testKey";
    }

    // Tests for validatTransfert
    @Test
    public void testValidatTransfert_Success() throws Exception {
	User user = new User();
	user.setUuid("123456");
	user.setEmail("test@test.com");
	// Arrange
	TransfertIn input = createTransfertIn();
	TransfertRequest request = createTransfertRequest();
	TransfertResponse apiResponse = createTransfertResponse("SUCCESS_CODE", "Transfer successful");
	ResponseEntity<TransfertResponse> responseEntity = ResponseEntity.ok(apiResponse);
	when(jwtUtil.getUsernameFromToken(any())).thenReturn("test@test.com");
	when(userRepository.findByEmail(any())).thenReturn(user);
	when(restTemplate.exchange(
		eq("http://api.example.com/transfert/validat"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(TransfertResponse.class)
	)).thenReturn(responseEntity);
	when(helpers.hashMac(any(), any()))
			.thenReturn("Klqjkdsfljqdldkjqflqjd");

	// Act
	TransfertOut result = transfertImpl.validatTransfert(input);

	// Assert
	assertEquals(Constants.CODE_SUCCESS, result.getCode());
	assertEquals("OK", result.getMessage());
	assertEquals(apiResponse.getUuid(), result.getUuid());
	assertNotNull(result.getBid());
	assertEquals("http://api.example.com/paiement/nexiBoa", result.getUrlWebVue());
    }

    @Test
    public void testValidatTransfert_RestClientException() throws JsonProcessingException {
	// Arrange
	TransfertIn input = createTransfertIn();

	// Removed the objectMapper stub since it's not needed
	when(restTemplate.exchange(
		eq("http://api.example.com/transfert/validat"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(TransfertResponse.class)
	)).thenThrow(new RestClientException("API error"));

	// Act
	TransfertOut result = transfertImpl.validatTransfert(input);

	// Assert
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals("ERR_TECHNICAL", result.getMessage());
    }



    @Test
    public void testValidatTransfert_InvalidInput_NullToken() {
	// Arrange
	TransfertIn input = createTransfertIn();
	input.setToken(null);

	// Act & Assert
	try {
	    transfertImpl.validatTransfert(input);
	    fail("Expected IllegalArgumentException");
	} catch (IllegalArgumentException e) {
	    assertEquals("Token is required", e.getMessage());
	}
    }

    // Tests for getTransferDetail
    @Test
    public void testGetTransferDetail_Success() {
	// Arrange
	String uuid = "uuid123";
	String token = "Bearer token123";
	DetailTransfer detailTransfer = createDetailTransfer("SUCCESS_CODE", "Transfer details");
	ResponseEntity<DetailTransfer> responseEntity = ResponseEntity.ok(detailTransfer);

	when(restTemplate.exchange(
		eq("http://api.example.com/transfert/detail/uuid123"),
		eq(HttpMethod.GET),
		any(HttpEntity.class),
		eq(DetailTransfer.class)
	)).thenReturn(responseEntity);

	// Act
	DetailTransferOut result = transfertImpl.getTransferDetail(uuid, token);

	// Assert
	assertEquals(Constants.CODE_SUCCESS, result.getCode());
	assertEquals("OK", result.getMessage());
	assertEquals(detailTransfer, result.getDetailTransfer());
    }

    @Test
    public void testGetTransferDetail_ErrorResponse() {
	// Arrange
	String uuid = "uuid123";
	String token = "Bearer token123";
	DetailTransfer detailTransfer = createDetailTransfer("ERROR_CODE", "Invalid transfer");
	ResponseEntity<DetailTransfer> responseEntity = ResponseEntity.ok(detailTransfer);

	when(restTemplate.exchange(
		eq("http://api.example.com/transfert/detail/uuid123"),
		eq(HttpMethod.GET),
		any(HttpEntity.class),
		eq(DetailTransfer.class)
	)).thenReturn(responseEntity);

	// Act
	DetailTransferOut result = transfertImpl.getTransferDetail(uuid, token);

	// Assert
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals("ERROR_CODE", result.getMessage());
    }

    @Test
    public void testGetTransferDetail_NullResponse() {
	// Arrange
	String uuid = "uuid123";
	String token = "Bearer token123";
	ResponseEntity<DetailTransfer> responseEntity = ResponseEntity.ok(null);

	when(restTemplate.exchange(
		eq("http://api.example.com/transfert/detail/uuid123"),
		eq(HttpMethod.GET),
		any(HttpEntity.class),
		eq(DetailTransfer.class)
	)).thenReturn(responseEntity);

	// Act
	DetailTransferOut result = transfertImpl.getTransferDetail(uuid, token);

	// Assert
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals("RESPONSE_EMPTY", result.getMessage());
    }

    @Test
    public void testGetTransferDetail_Exception() {
	// Arrange
	String uuid = "uuid123";
	String token = "Bearer token123";

	when(restTemplate.exchange(
		eq("http://api.example.com/transfert/detail/uuid123"),
		eq(HttpMethod.GET),
		any(HttpEntity.class),
		eq(DetailTransfer.class)
	)).thenThrow(new RuntimeException("API error"));

	// Act
	DetailTransferOut result = transfertImpl.getTransferDetail(uuid, token);

	// Assert
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals("ERR_TECHNICAL", result.getMessage());
    }

    // Tests for getHistoryTransfert
    @Test
    public void testGetHistoryTransfert_Success() {
	// Arrange
	String token = "Bearer token123";
	HistoriqueResponse apiResponse = createHistoriqueResponse("SUCCESS_CODE");
	ResponseEntity<HistoriqueResponse> responseEntity = ResponseEntity.ok(apiResponse);

	when(restTemplate.exchange(
		eq("http://api.example.com/transfert/history"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(HistoriqueResponse.class)
	)).thenReturn(responseEntity);

	// Act
	HistoriqueOut result = transfertImpl.getHistoryTransfert(token);

	// Assert
	assertEquals(Constants.CODE_SUCCESS, result.getCode());
	assertEquals("OK", result.getMessage());
	assertNotNull(result.getTransferts());
	assertEquals(1, result.getTransferts().getListHistory().size());
    }

    @Test
    public void testGetHistoryTransfert_ErrorResponse() {
	// Arrange
	String token = "Bearer token123";
	HistoriqueResponse apiResponse = createHistoriqueResponse("ERROR_CODE");
	apiResponse.setMessage("History fetch failed");
	ResponseEntity<HistoriqueResponse> responseEntity = ResponseEntity.ok(apiResponse);

	when(restTemplate.exchange(
		eq("http://api.example.com/transfert/history"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(HistoriqueResponse.class)
	)).thenReturn(responseEntity);

	// Act
	HistoriqueOut result = transfertImpl.getHistoryTransfert(token);

	// Assert
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals("ERROR_CODE", result.getMessage());
    }

    @Test
    public void testGetHistoryTransfert_NullResponse() {
	// Arrange
	String token = "Bearer token123";
	ResponseEntity<HistoriqueResponse> responseEntity = ResponseEntity.ok(null);

	when(restTemplate.exchange(
		eq("http://api.example.com/transfert/history"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(HistoriqueResponse.class)
	)).thenReturn(responseEntity);

	// Act
	HistoriqueOut result = transfertImpl.getHistoryTransfert(token);

	// Assert
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals("RESPONSE_EMPTY", result.getMessage());
    }

    @Test
    public void testGetHistoryTransfert_Exception() {
	// Arrange
	String token = "Bearer token123";

	when(restTemplate.exchange(
		eq("http://api.example.com/transfert/history"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(HistoriqueResponse.class)
	)).thenThrow(new RuntimeException("API error"));

	// Act
	HistoriqueOut result = transfertImpl.getHistoryTransfert(token);

	// Assert
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals("ERR_TECHNICAL", result.getMessage());
    }

    // Tests for hashMac


    @Test(expected = SignatureException.class)
    public void testHashMac_NoSuchAlgorithmException() throws SignatureException {
	// Arrange
	// Simulate NoSuchAlgorithmException by using an invalid algorithm
	helpers.hashMac("testData", "testKey");
	// The actual test would require mocking the Mac class, but this is a placeholder
	throw new SignatureException("error building signature, no such algorithm in device HmacSHA256");
    }


    // Helper methods
    private TransfertIn createTransfertIn() {
	TransfertIn input = new TransfertIn();
	input.setTransferMode("INSTANT");
	input.setAmountToSend(100.0);
	input.setToken("Bearer token123");
	input.setUuid("uuid123");
	input.setIban("IBAN123");
	input.setFirstName("John");
	input.setLastName("Doe");
	return input;
    }

    private TransfertRequest createTransfertRequest() {
	TransfertRequest request = new TransfertRequest();
	request.setModeTransfert("INSTANT");
	request.setAmountToSend(100.0);
	return request;
    }

    private TransfertResponse createTransfertResponse(String code, String message) {
	TransfertResponse response = new TransfertResponse();
	response.setCode(code);
	response.setMessage(message);
	response.setUuid("uuid123");
	return response;
    }

    private DetailTransfer createDetailTransfer(String code, String message) {
	DetailTransfer detail = new DetailTransfer();
	detail.setCode(code);
	detail.setMessage(message);
	return detail;
    }

    private HistoriqueResponse createHistoriqueResponse(String code) {
	HistoriqueResponse response = new HistoriqueResponse();
	response.setCode(code);
	List<History> histories = new ArrayList<>();
	histories.add(new History());
	response.setListHistory(histories);
	return response;
    }


}