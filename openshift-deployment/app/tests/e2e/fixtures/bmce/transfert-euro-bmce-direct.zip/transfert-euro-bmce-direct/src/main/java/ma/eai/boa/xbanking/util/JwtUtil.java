package ma.eai.boa.xbanking.util;


import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.text.ParseException;
import java.util.Base64;
import java.util.function.Function;

@Component
public class JwtUtil {

    @Value("${publicKey}")
    private String publicKey;


    // retrieve username from jwt token
    public String getUsernameFromToken(String token) {
        try {
            return getClaimFromToken(token, claimsSet -> claimsSet.getClaim("name")).toString();
        } catch (NoSuchAlgorithmException | InvalidKeySpecException | ParseException | JOSEException e) {
            EaiLog.info("error while getting data from token", e);
        }
        return null;
    }

    public <T> T getClaimFromToken(String token, Function<JWTClaimsSet, T> claimsResolver) throws NoSuchAlgorithmException, InvalidKeySpecException, ParseException, JOSEException {

        //////////////////////////////////////////////
        Base64.Decoder decoder = Base64.getDecoder();
        X509EncodedKeySpec ksPub = new X509EncodedKeySpec(decoder.decode(publicKey));
        KeyFactory kfPub = KeyFactory.getInstance("RSA");
        RSAPublicKey pubPub = (RSAPublicKey) kfPub.generatePublic(ksPub);
        // On the consumer side, parse the JWS and verify its RSA signature
        SignedJWT signedJWT = SignedJWT.parse(token);
        JWSVerifier verifier = new RSASSAVerifier(pubPub);
        signedJWT.verify(verifier);
        return claimsResolver.apply(signedJWT.getJWTClaimsSet());
    }



}
