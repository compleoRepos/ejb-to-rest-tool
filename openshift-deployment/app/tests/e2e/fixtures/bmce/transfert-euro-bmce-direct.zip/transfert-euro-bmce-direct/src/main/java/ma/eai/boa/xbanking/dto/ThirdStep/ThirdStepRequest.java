package ma.eai.boa.xbanking.dto.ThirdStep;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class ThirdStepRequest implements Serializable {

    private static final long serialVersionUID = -5081988885485892430L;

    
    @JsonProperty("amountofincome")
    private double amountofincome;

    @JsonProperty("sourceoffunds")
    private String sourceoffunds;

    @JsonProperty("transfertMotif")
    private String transfertMotif;

    @JsonProperty("periodicity")
    private String periodicity;

    @JsonProperty("frequency")
    private String frequency;

    @JsonProperty("incomeBracket")
    private String incomeBracket;

    @JsonProperty("nationalIdentifier")
    private String nationalIdentifier;

    private boolean politicallyexposed;

    @JsonProperty("profession")
    private String profession;

    @JsonProperty("activityArea")
    private String activityArea;

    @JsonProperty("transfervolume")
    private double transfervolume;

    @JsonProperty("luiMemePPE")
    private boolean luiMemePPE;

    @JsonProperty("functionPPE")
    private String functionPPE;

    @JsonProperty("fullNamePPE")
    private String fullNamePPE;

    @JsonProperty("relationshipPPE")
    private String relationshipPPE;
    
    


	public double getAmountofincome() {
		return amountofincome;
	}

	public void setAmountofincome(double amountofincome) {
		this.amountofincome = amountofincome;
	}

	public String getSourceoffunds() {
		return sourceoffunds;
	}

	public void setSourceoffunds(String sourceoffunds) {
		this.sourceoffunds = sourceoffunds;
	}

	public String getTransfertMotif() {
		return transfertMotif;
	}

	public void setTransfertMotif(String transfertMotif) {
		this.transfertMotif = transfertMotif;
	}

	public String getPeriodicity() {
		return periodicity;
	}

	public void setPeriodicity(String periodicity) {
		this.periodicity = periodicity;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getIncomeBracket() {
		return incomeBracket;
	}

	public void setIncomeBracket(String incomeBracket) {
		this.incomeBracket = incomeBracket;
	}

	public String getNationalIdentifier() {
		return nationalIdentifier;
	}

	public void setNationalIdentifier(String nationalIdentifier) {
		this.nationalIdentifier = nationalIdentifier;
	}

	public boolean isPoliticallyexposed() {
		return politicallyexposed;
	}

	public void setPoliticallyexposed(boolean politicallyexposed) {
		this.politicallyexposed = politicallyexposed;
	}

	public String getProfession() {
		return profession;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}

	public String getActivityArea() {
		return activityArea;
	}

	public void setActivityArea(String activityArea) {
		this.activityArea = activityArea;
	}

	public double getTransfervolume() {
		return transfervolume;
	}

	public void setTransfervolume(double transfervolume) {
		this.transfervolume = transfervolume;
	}

	public boolean isLuiMemePPE() {
		return luiMemePPE;
	}

	public void setLuiMemePPE(boolean luiMemePPE) {
		this.luiMemePPE = luiMemePPE;
	}

    public String getFunctionPPE() {
	return functionPPE;
    }

    public void setFunctionPPE(String functionPPE) {
	this.functionPPE = functionPPE;
    }

    public String getFullNamePPE() {
		return fullNamePPE;
	}

	public void setFullNamePPE(String fullNamePPE) {
		this.fullNamePPE = fullNamePPE;
	}

	public String getRelationshipPPE() {
		return relationshipPPE;
	}

	public void setRelationshipPPE(String relationshipPPE) {
		this.relationshipPPE = relationshipPPE;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

   
}
