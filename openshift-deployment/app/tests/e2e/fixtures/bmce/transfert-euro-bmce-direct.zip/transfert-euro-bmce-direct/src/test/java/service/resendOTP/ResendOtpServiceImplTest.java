package ma.eai.boa.xbanking.service.resendOtp;

import ma.eai.boa.xbanking.dto.validateOtp.ResendOtpResponse;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.util.JwtUtil;
import ma.eai.boa.xbanking.vo.Retour;
import ma.eai.boa.xbanking.vo.validationOtp.ResendOtpOut;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ResendOtpServiceImplTest {

    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private ResendOtpServiceImpl resendOtpService;

    private static final String TOKEN = "test-token";
    private static final String OTP_ID = "test-otp-id";
    private static final String API_URL = "http://test-api/";
    private static final String SUCCESS_CODE = "SUCCESS_CODE";

    @Before
    public void setUp() {
	resendOtpService.urlApi = API_URL;
	when(jwtUtil.getUsernameFromToken(TOKEN)).thenReturn("test-user");
    }

    @Test
    public void testResendOtp_Success() {
	// Arrange
	ResendOtpResponse responseBody = new ResendOtpResponse();
	responseBody.setCode(SUCCESS_CODE);
	responseBody.setStatus("SUCCESS");
	responseBody.setTransactionId("trans123");

	ResponseEntity<ResendOtpResponse> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.OK);
	when(restTemplate.exchange(
		eq(API_URL.concat("reset/resendOtp")),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(ResendOtpResponse.class)
	)).thenReturn(responseEntity);

	// Act
	ResendOtpOut result = resendOtpService.resendOtp(TOKEN);

	// Assert
	assertNotNull(result);
	assertEquals(Constants.CODE_SUCCESS, result.getCode());
	assertEquals("OK", result.getMessage());
	assertEquals("trans123", result.getTransactionId());
	assertEquals("SUCCESS", result.getStatus());
    }

    @Test
    public void testResendOtp_ErrorResponse() {
	// Arrange
	ResendOtpResponse responseBody = new ResendOtpResponse();
	responseBody.setCode("ERROR_CODE");

	ResponseEntity<ResendOtpResponse> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.OK);
	when(restTemplate.exchange(
		eq(API_URL.concat("reset/resendOtp")),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(ResendOtpResponse.class)
	)).thenReturn(responseEntity);

	// Act
	ResendOtpOut result = resendOtpService.resendOtp(TOKEN);

	// Assert
	assertNotNull(result);
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals("ERROR_CODE", result.getMessage());
    }

    @Test
    public void testResendOtp_NullResponseBody() {
	// Arrange
	ResponseEntity<ResendOtpResponse> responseEntity = new ResponseEntity<>(null, HttpStatus.OK);
	when(restTemplate.exchange(
		eq(API_URL.concat("reset/resendOtp")),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(ResendOtpResponse.class)
	)).thenReturn(responseEntity);

	// Act
	ResendOtpOut result = resendOtpService.resendOtp(TOKEN);

	// Assert
	assertNotNull(result);
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals("Empty response", result.getMessage());
    }

    @Test
    public void testResendOtp_Exception() {
	// Arrange
	when(restTemplate.exchange(
		eq(API_URL.concat("reset/resendOtp")),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(ResendOtpResponse.class)
	)).thenThrow(new RestClientException("API error"));

	// Act
	ResendOtpOut result = resendOtpService.resendOtp(TOKEN);

	// Assert
	assertNotNull(result);
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals(Constants.TECHNICAL_ERROR, result.getMessage());
    }

    @Test
    public void testResendOtpEer_Success() {
	// Arrange
	Retour responseBody = new Retour();
	responseBody.setCode(SUCCESS_CODE);

	ResponseEntity<Retour> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.OK);
	when(restTemplate.exchange(
		eq(API_URL.concat("reset/resend")),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(Retour.class)
	)).thenReturn(responseEntity);

	// Act
	Retour result = resendOtpService.resendOtpEer(OTP_ID);

	// Assert
	assertNotNull(result);
	assertEquals(Constants.CODE_SUCCESS, result.getCode());
	assertEquals("OK", result.getMessage());
    }

    @Test
    public void testResendOtpEer_ErrorResponse() {
	// Arrange
	Retour responseBody = new Retour();
	responseBody.setCode("ERROR_CODE");

	ResponseEntity<Retour> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.OK);
	when(restTemplate.exchange(
		eq(API_URL.concat("reset/resend")),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(Retour.class)
	)).thenReturn(responseEntity);

	// Act
	Retour result = resendOtpService.resendOtpEer(OTP_ID);

	// Assert
	assertNotNull(result);
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals("ERROR_CODE", result.getMessage());
    }

    @Test
    public void testResendOtpEer_NullResponseBody() {
	// Arrange
	ResponseEntity<Retour> responseEntity = new ResponseEntity<>(null, HttpStatus.OK);
	when(restTemplate.exchange(
		eq(API_URL.concat("reset/resend")),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(Retour.class)
	)).thenReturn(responseEntity);

	// Act
	Retour result = resendOtpService.resendOtpEer(OTP_ID);

	// Assert
	assertNotNull(result);
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals(Constants.RESPONSE_EMPTY, result.getMessage());
    }

    @Test
    public void testResendOtpEer_Exception() {
	// Arrange
	when(restTemplate.exchange(
		eq(API_URL.concat("reset/resend")),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(Retour.class)
	)).thenThrow(new RestClientException("API error"));

	// Act
	Retour result = resendOtpService.resendOtpEer(OTP_ID);

	// Assert
	assertNotNull(result);
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals(Constants.TECHNICAL_ERROR, result.getMessage());
    }
}