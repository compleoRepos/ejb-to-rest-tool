package ma.eai.boa.xbanking.vo.SignContrat;

import ma.eai.boa.xbanking.entities.Retour;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@XmlRootElement(name = "SignContratOut")
public class SignContratOut extends Retour implements Serializable {

    private static final long serialVersionUID = -1979649753611936791L;


    private String transactionId;


    private String status;

    public String getTransactionId() {
	return transactionId;
    }

    public void setTransactionId(String transactionId) {
	this.transactionId = transactionId;
    }

    public String getStatus() {
	return status;
    }

    public void setStatus(String status) {
	this.status = status;
    }
}
