package ma.eai.boa.xbanking.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.io.Serializable;

@Entity
@Table(name = "prospectDataplus")
public class AdditionalDataProspect extends Identified implements Serializable {

	private static final long serialVersionUID = -6371886305772566433L;
	
	private double amountofincome;
	
	@OneToOne
	private FundsSource sourceoffunds;
	
	private double transfervolume;
	
	@OneToOne
	private TransfertMotif transfertMotif;
	
	@OneToOne
	private Periodicity periodicity;
	
	@OneToOne
	private Frequency frequency;
	
	private String nationalIdentifier;
	
	@OneToOne
	private RevenuTranche revenuTranche;
	
	@JsonIgnore
	@OneToOne
	private Utilisateur user;
	
	@Transient
	private Profession profession;

	@Transient
	private boolean politicallyexposed;
	
	@Transient
	@JsonProperty("luiMemePPE")
	private boolean luiMemePPE;
	
	@Transient
	@JsonProperty("functionPPE")
	private String fonctionPPE;
	
	@Transient
	@JsonProperty("fullNamePPE")
	private String fullNamePPE;
	
	@Transient
	@JsonProperty("relationshipPPE")
	private String lienPPE;
	
	@JsonProperty("activityArea")
	private ActivityArea activityArea;
	
	public FundsSource getSourceoffunds() {
		return sourceoffunds;
	}

	public void setSourceoffunds(FundsSource sourceoffunds) {
		this.sourceoffunds = sourceoffunds;
	}

	public TransfertMotif getTransfertMotif() {
		return transfertMotif;
	}

	public void setTransfertMotif(TransfertMotif transfertMotif) {
		this.transfertMotif = transfertMotif;
	}

	public Periodicity getPeriodicity() {
		return periodicity;
	}

	public void setPeriodicity(Periodicity periodicity) {
		this.periodicity = periodicity;
	}
	
	
	public Utilisateur getUser() {
		return user;
	}

	public void setUser(Utilisateur user) {
		this.user = user;
	}

	public Frequency getFrequency() {
		return frequency;
	}

	public void setFrequency(Frequency frequency) {
		this.frequency = frequency;
	}

	public RevenuTranche getRevenuTranche() {
		return revenuTranche;
	}

	public void setRevenuTranche(RevenuTranche revenuTranche) {
		this.revenuTranche = revenuTranche;
	}

//	public String getIbanClient() {
//		return ibanClient;
//	}
//
//	public void setIbanClient(String ibanClient) {
//		this.ibanClient = ibanClient;
//	}
	
	public String getNationalIdentifier() {
		return nationalIdentifier;
	}

	public void setNationalIdentifier(String nationalIdentifier) {
		this.nationalIdentifier = nationalIdentifier;
	}

	public double getAmountofincome() {
		return amountofincome;
	}

	public void setAmountofincome(double amountofincome) {
		this.amountofincome = amountofincome;
	}

	public double getTransfervolume() {
		return transfervolume;
	}

	public void setTransfervolume(double transfervolume) {
		this.transfervolume = transfervolume;
	}

	public Profession getProfession() {
		return profession;
	}

	public void setProfession(Profession profession) {
		this.profession = profession;
	}

	public boolean isPoliticallyexposed() {
		return politicallyexposed;
	}

	public void setPoliticallyexposed(boolean politicallyexposed) {
		this.politicallyexposed = politicallyexposed;
	}

	public ActivityArea getActivityArea() {
		return activityArea;
	}

	public void setActivityArea(ActivityArea activityArea) {
		this.activityArea = activityArea;
	}

	public boolean isLuiMemePPE() {
		return luiMemePPE;
	}

	public void setLuiMemePPE(boolean luiMemePPE) {
		this.luiMemePPE = luiMemePPE;
	}

	public String getFonctionPPE() {
		return fonctionPPE;
	}

	public void setFonctionPPE(String fonctionPPE) {
		this.fonctionPPE = fonctionPPE;
	}

	public String getLienPPE() {
		return lienPPE;
	}

	public void setLienPPE(String lienPPE) {
		this.lienPPE = lienPPE;
	}

	public String getFullNamePPE() {
		return fullNamePPE;
	}

	public void setFullNamePPE(String fullNamePPE) {
		this.fullNamePPE = fullNamePPE;
	}

}
