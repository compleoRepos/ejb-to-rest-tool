package ma.eai.boa.xbanking.service.callGRC;


import grc.beans.SouscriptionMobilePayment;
import grc.ws.WsMobilePayement;
import grc.ws.WsMobilePayementServiceLocator;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class GrcConnector {


    @Value("${interface.grc.adria.soap}")
    private String grcAdriaInterface;

    public SouscriptionMobilePayment getInfoGrc(String idClient, String natureId) {
        EaiLog.info("getInfoGrc start");
        SouscriptionMobilePayment smp = new SouscriptionMobilePayment();
        try {
            WsMobilePayementServiceLocator locator = new WsMobilePayementServiceLocator();
            locator.setWsMobilePayementPortEndpointAddress(grcAdriaInterface);
            WsMobilePayement service = locator.getWsMobilePayementPort();
            smp = service.souscriptionMobilePayment(idClient, natureId);
            EaiLog.info("=========> smp: {}",smp);
        } catch (Exception e) {

            smp.setCodeRetour(4);
            smp.setMessageRetour("Erreur appel service grc");
            EaiLog.error("Erreur appel service grc: {}", e);
        }
        EaiLog.info("getInfoGrc end");
        return smp;

    }

}
