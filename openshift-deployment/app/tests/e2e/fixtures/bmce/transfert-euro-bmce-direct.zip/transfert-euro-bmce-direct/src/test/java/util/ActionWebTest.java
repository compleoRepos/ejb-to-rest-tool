package util;

import ma.eai.boa.xbanking.util.ActionWeb;
import org.junit.Assert;
import org.junit.Test;

public class ActionWebTest {
    @Test
    public void testEnumValues() {
	// Vérifier que l'énumération contient bien les valeurs attendues
	Assert.assertEquals("TAUXCHANGE", ActionWeb.TAUXCHANGE.name());
	Assert.assertEquals("VALIDATEOTP", ActionWeb.VALIDATEOTP.name());
    }
}
