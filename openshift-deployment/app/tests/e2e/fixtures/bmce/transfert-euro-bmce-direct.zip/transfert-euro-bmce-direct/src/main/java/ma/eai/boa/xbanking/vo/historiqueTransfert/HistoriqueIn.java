package ma.eai.boa.xbanking.vo.historiqueTransfert;

public class HistoriqueIn {
    private String token;

    public String getToken() {
	return token;
    }

    public void setToken(String token) {
	this.token = token;
    }
}
