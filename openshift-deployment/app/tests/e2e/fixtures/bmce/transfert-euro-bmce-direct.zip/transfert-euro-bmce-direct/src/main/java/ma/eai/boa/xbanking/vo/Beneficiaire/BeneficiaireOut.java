package ma.eai.boa.xbanking.vo.Beneficiaire;

import ma.eai.boa.xbanking.vo.Retour;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "BeneficiaireOut")
public class BeneficiaireOut extends Retour {
}
