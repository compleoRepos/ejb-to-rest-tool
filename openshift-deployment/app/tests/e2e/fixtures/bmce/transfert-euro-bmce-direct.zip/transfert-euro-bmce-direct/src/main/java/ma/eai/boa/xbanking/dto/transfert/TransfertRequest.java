package ma.eai.boa.xbanking.dto.transfert;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class TransfertRequest implements Serializable {

    private static final long serialVersionUID = -815976548913582114L;

    private double amountToSend;

    private double amountNetToSend;

    private double amountToReceive;

    @JsonProperty("transferMode")
    private String modeTransfert;

    @JsonProperty("iban")
    private String ibanBeneficiaire;

    @JsonProperty("numCompteBes")
    private String numCompteBes;

    @JsonProperty("rib")
    private String ribBenef;

    @JsonProperty("lastName")
    private String nomBeneficiaire;

    @JsonProperty("firstName")
    private String prenomBeneficiaire;

    private String bankName;

    private float tauxChange;

    private float commission;

    private String compteClient;

    private String uuid;

    @JsonProperty("callbackUrl")
    private String urlReturned;

    @JsonProperty("url")
    private String urlPaiement;

    public double getAmountToSend() {
	return amountToSend;
    }

    public void setAmountToSend(double amountToSend) {
	this.amountToSend = amountToSend;
    }

    public double getAmountNetToSend() {
	return amountNetToSend;
    }

    public void setAmountNetToSend(double amountNetToSend) {
	this.amountNetToSend = amountNetToSend;
    }

    public double getAmountToReceive() {
	return amountToReceive;
    }

    public void setAmountToReceive(double amountToReceive) {
	this.amountToReceive = amountToReceive;
    }

    public String getModeTransfert() {
	return modeTransfert;
    }

    public void setModeTransfert(String modeTransfert) {
	this.modeTransfert = modeTransfert;
    }

    public String getIbanBeneficiaire() {
	return ibanBeneficiaire;
    }

    public void setIbanBeneficiaire(String ibanBeneficiaire) {
	this.ibanBeneficiaire = ibanBeneficiaire;
    }

    public String getNumCompteBes() {
	return numCompteBes;
    }

    public void setNumCompteBes(String numCompteBes) {
	this.numCompteBes = numCompteBes;
    }

    public String getRibBenef() {
	return ribBenef;
    }

    public void setRibBenef(String ribBenef) {
	this.ribBenef = ribBenef;
    }

    public String getNomBeneficiaire() {
	return nomBeneficiaire;
    }

    public void setNomBeneficiaire(String nomBeneficiaire) {
	this.nomBeneficiaire = nomBeneficiaire;
    }

    public String getPrenomBeneficiaire() {
	return prenomBeneficiaire;
    }

    public void setPrenomBeneficiaire(String prenomBeneficiaire) {
	this.prenomBeneficiaire = prenomBeneficiaire;
    }

    public String getBankName() {
	return bankName;
    }

    public void setBankName(String bankName) {
	this.bankName = bankName;
    }

    public float getTauxChange() {
	return tauxChange;
    }

    public void setTauxChange(float tauxChange) {
	this.tauxChange = tauxChange;
    }

    public float getCommission() {
	return commission;
    }

    public void setCommission(float commission) {
	this.commission = commission;
    }

    public String getCompteClient() {
	return compteClient;
    }

    public void setCompteClient(String compteClient) {
	this.compteClient = compteClient;
    }

    public String getUuid() {
	return uuid;
    }

    public void setUuid(String uuid) {
	this.uuid = uuid;
    }

    public String getUrlReturned() {
	return urlReturned;
    }

    public void setUrlReturned(String urlReturned) {
	this.urlReturned = urlReturned;
    }

    public String getUrlPaiement() {
	return urlPaiement;
    }

    public void setUrlPaiement(String urlPaiement) {
	this.urlPaiement = urlPaiement;
    }
}
