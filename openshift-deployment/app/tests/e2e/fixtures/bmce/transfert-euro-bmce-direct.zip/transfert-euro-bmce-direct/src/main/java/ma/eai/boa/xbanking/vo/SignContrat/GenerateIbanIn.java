package ma.eai.boa.xbanking.vo.SignContrat;

import javax.xml.bind.annotation.XmlRootElement;

public class GenerateIbanIn {

    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
