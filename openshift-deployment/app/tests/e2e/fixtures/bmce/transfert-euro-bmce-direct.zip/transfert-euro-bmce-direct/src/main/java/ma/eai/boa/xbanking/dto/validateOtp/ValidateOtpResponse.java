package ma.eai.boa.xbanking.dto.validateOtp;

import java.io.Serializable;

public class ValidateOtpResponse implements Serializable {
    private static final long serialVersionUID = -6370822625760369530L;

    private String code;
    private String message;
    private String uuid;
    private boolean completed;
    private boolean client;
    private String lang;
    private String phone;
    private int nombreNotifs;
    private String uuidKey;
    private String otpID;

    // Champs pour la réponse en cas d'échec
    private String transactionId;
    private String status;

    public String getTransactionId() {
	return transactionId;
    }

    public void setTransactionId(String transactionId) {
	this.transactionId = transactionId;
    }

    public String getStatus() {
	return status;
    }

    public void setStatus(String status) {
	this.status = status;
    }

    public String getUuid() {
	return uuid;
    }

    public void setUuid(String uuid) {
	this.uuid = uuid;
    }

    public boolean isCompleted() {
	return completed;
    }

    public void setCompleted(boolean completed) {
	this.completed = completed;
    }

    public boolean isClient() {
	return client;
    }

    public void setClient(boolean client) {
	this.client = client;
    }

    public String getLang() {
	return lang;
    }

    public void setLang(String lang) {
	this.lang = lang;
    }

    public String getPhone() {
	return phone;
    }

    public void setPhone(String phone) {
	this.phone = phone;
    }

    public int getNombreNotifs() {
	return nombreNotifs;
    }

    public void setNombreNotifs(int nombreNotifs) {
	this.nombreNotifs = nombreNotifs;
    }

    public String getUuidKey() {
	return uuidKey;
    }

    public void setUuidKey(String uuidKey) {
	this.uuidKey = uuidKey;
    }

    public String getOtpID() {
	return otpID;
    }

    public void setOtpID(String otpID) {
	this.otpID = otpID;
    }

    public String getCode() {
	return code;
    }

    public void setCode(String code) {
	this.code = code;
    }

    public String getMessage() {
	return message;
    }

    public void setMessage(String message) {
	this.message = message;
    }
}
