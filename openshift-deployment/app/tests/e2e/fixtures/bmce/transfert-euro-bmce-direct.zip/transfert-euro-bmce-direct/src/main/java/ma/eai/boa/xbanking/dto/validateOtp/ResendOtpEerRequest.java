package ma.eai.boa.xbanking.dto.validateOtp;

public class ResendOtpEerRequest {
    private String otpID;

    public String getOtpID() {
	return otpID;
    }

    public void setOtpID(String otpID) {
	this.otpID = otpID;
    }
}
