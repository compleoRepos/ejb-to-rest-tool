package ma.eai.boa.xbanking.dto.SignContrat;

import ma.eai.boa.xbanking.vo.Retour;

public class ValidateOtpSignContratResponse extends Retour {
}
