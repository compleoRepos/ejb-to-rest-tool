package ma.eai.boa.xbanking.util;


import javax.xml.XMLConstants;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.StringReader;
import java.io.StringWriter;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;



public class Utils {

    public static String generateRandomString() throws NoSuchAlgorithmException {
        SecureRandom random = SecureRandom.getInstanceStrong();
        String upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String lower = "abcdefghijklmnopqrstuvwxyz";
        String digits = "0123456789";
        String allChars = upper + lower + digits;
        List<Character> result = new ArrayList<>();
        // Ensure at least one of each
        result.add(upper.charAt(random.nextInt(upper.length())));
        result.add(lower.charAt(random.nextInt(lower.length())));
        result.add(digits.charAt(random.nextInt(digits.length())));
        // Fill the rest randomly
        for (int i = 3; i < 8; i++) {
            result.add(allChars.charAt(random.nextInt(allChars.length())));
        }
        // Shuffle to avoid predictable positions
        Collections.shuffle(result);
        // Build final string
        StringBuilder sb = new StringBuilder();
        for (char c : result) {
            sb.append(c);
        }
        return sb.toString();
    }
//    public static String formatXml(String xml) {
//        try {
//            // Secure TransformerFactory instance
//            TransformerFactory transformerFactory = TransformerFactory.newInstance();
//            transformerFactory.setAttribute("indent-number", 2);
//
//            // Prevent XXE
//            transformerFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
//
//            Transformer transformer = transformerFactory.newTransformer();
//            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
//
//            // Safe XML source
//            StreamSource xmlInput = new StreamSource(new StringReader(xml));
//
//            StringWriter stringWriter = new StringWriter();
//            StreamResult xmlOutput = new StreamResult(stringWriter);
//
//            transformer.transform(xmlInput, xmlOutput);
//            return stringWriter.toString();
//        } catch (Exception e) {
//            return "Invalid XML:\n" + xml;
//        }
//    }
}
