package ma.eai.boa.xbanking.vo.PersonalInformation;

import ma.eai.boa.xbanking.entities.Parameters;
import ma.eai.boa.xbanking.vo.Retour;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "PersonalInfoOut")
public class PersonalInfoOut extends Retour {
   private Parameters parameters;

    public Parameters getParameters() {
        return parameters;
    }

    public void setParameters(Parameters parameters) {
        this.parameters = parameters;
    }
}
