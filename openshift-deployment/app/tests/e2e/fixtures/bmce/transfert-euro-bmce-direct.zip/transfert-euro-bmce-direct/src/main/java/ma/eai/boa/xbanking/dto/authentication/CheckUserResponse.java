package ma.eai.boa.xbanking.dto.authentication;

import ma.eai.boa.xbanking.vo.Retour;

public class CheckUserResponse extends Retour {
}
