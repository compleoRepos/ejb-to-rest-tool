package ma.eai.boa.xbanking.service.enrollement;

import ma.eai.boa.xbanking.vo.enrollement.CheckIbanOut;
import ma.eai.boa.xbanking.vo.enrollement.CheckInfoIn;
import ma.eai.boa.xbanking.vo.enrollement.CheckInfoOut;
import ma.eai.boa.xbanking.vo.enrollement.EnrollementValidationOut;
import ma.eai.boa.xbanking.vo.enrollement.CheckIbenIn;
import ma.eai.boa.xbanking.vo.enrollement.EnrollementValidationIn;
public interface EnrollementService {
    CheckInfoOut checkInfos(CheckInfoIn checkInfoIn);
    CheckIbanOut checkIban(CheckIbenIn checkIbenIn);
    EnrollementValidationOut activateUser(EnrollementValidationIn enrollementValidationIn);
}
