package ma.eai.boa.xbanking.dto.nexus;


public class SendOtpRequest {




}