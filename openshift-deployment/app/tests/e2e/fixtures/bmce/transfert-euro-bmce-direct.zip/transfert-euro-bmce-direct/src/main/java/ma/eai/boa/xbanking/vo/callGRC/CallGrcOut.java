package ma.eai.boa.xbanking.vo.callGRC;

import ma.eai.boa.xbanking.vo.Retour;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "CallGrcOut")
public class CallGrcOut extends Retour {

	private String prenomClient;
    private String nomClient;
	private String adresse;
	private String dateNaissance;
	private String Natoinality;
	private String CodePaysResid;
	private String NumTelephone;
    private Account account;
    private String paysNaissance;
    private String ville;

    public String getPaysNaissance() {
	return paysNaissance;
    }

    public void setPaysNaissance(String paysNaissance) {
	this.paysNaissance = paysNaissance;
    }

    public String getVille() {
	return ville;
    }

    public void setVille(String ville) {
	this.ville = ville;
    }

    public Account getAccount() {
	return account;
    }

    public void setAccount(Account account) {
	this.account = account;
    }

    public String getNumTelephone() {
	return NumTelephone;
    }

    public void setNumTelephone(String numTelephone) {
	NumTelephone = numTelephone;
    }

    public String getCodePaysResid() {
	return CodePaysResid;
    }

    public void setCodePaysResid(String codePaysResid) {
	CodePaysResid = codePaysResid;
    }

    public String getNatoinality() {
	return Natoinality;
    }

    public void setNatoinality(String natoinality) {
	Natoinality = natoinality;
    }


    public String getAdresse() {
	return adresse;
    }

    public void setAdresse(String adresse) {
	this.adresse = adresse;
    }

    public String getDateNaissance() {
	return dateNaissance;
    }

    public void setDateNaissance(String dateNaissance) {
	this.dateNaissance = dateNaissance;
    }

    public String getPrenomClient() {
	return prenomClient;
    }

    public void setPrenomClient(String prenomClient) {
	this.prenomClient = prenomClient;
    }

    public String getNomClient() {
	return nomClient;
    }

    public void setNomClient(String nomClient) {
	this.nomClient = nomClient;
    }
}
