package ma.eai.boa.xbanking.vo.enrollement;

import ma.eai.boa.xbanking.dto.enrollement.CheckInfoRequest;

public class CheckIbenIn {
    private String iban;

    private CheckInfoRequest checkInfoRequest;

    private String deviceId;

    private String token;

    public String getToken() {
	return token;
    }

    public void setToken(String token) {
	this.token = token;
    }

    public String getIban() {
	return iban;
    }

    public void setIban(String iban) {
	this.iban = iban;
    }

    public CheckInfoRequest getCheckInfoRequest() {
	return checkInfoRequest;
    }

    public void setCheckInfoRequest(CheckInfoRequest checkInfoRequest) {
	this.checkInfoRequest = checkInfoRequest;
    }

    public String getDeviceId() {
	return deviceId;
    }

    public void setDeviceId(String deviceId) {
	this.deviceId = deviceId;
    }
}
