package ma.eai.boa.xbanking.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="comission")
public class Comission extends Identified {
	
	private static final long serialVersionUID = 9136337213593766337L;

	private int min;
	
	private int max;
	
	@JsonProperty("commission")
	private float value;
	
	private int canal;
	
	@JsonIgnore
	private boolean oldClient;
	
	@JsonIgnore
	@ManyToOne
	private Country country;

	@Column(name = "comission_confrere")
	private float comissionConfrere;  // Default value set in Java

	// Add getter and setter
	public float getComissionConfrere() {
		return comissionConfrere;
	}

	public void setComissionConfrere(float comissionConfrere) {
		this.comissionConfrere = comissionConfrere;
	}


	public int getMin() {
		return min;
	}

	public void setMin(int min) {
		this.min = min;
	}

	public int getMax() {
		return max;
	}

	public void setMax(int max) {
		this.max = max;
	}

	public int getCanal() {
		return canal;
	}

	public void setCanal(int canal) {
		this.canal = canal;
	}

	public float getValue() {
		return value;
	}

	public void setValue(float value) {
		this.value = value;
	}

	public boolean isOldClient() {
		return oldClient;
	}

	public void setOldClient(boolean oldClient) {
		this.oldClient = oldClient;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}
	
	

}
