package util;

import ma.eai.boa.xbanking.handlers.RequestInterceptor;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

public class RequestInterceptorTest {
	@Mock
	private HttpServletRequest request;

	@Mock
	private HttpServletResponse response;

	private HandlerInterceptor interceptor;

	@Before
	public void setUp() {
	    MockitoAnnotations.initMocks(this);
	    interceptor = new RequestInterceptor();
	}

	@Test
	public void testPreHandle() throws Exception {
	    // Simuler l'appel de la méthode preHandle
	    when(request.getAttribute("startTime")).thenReturn(null); // Aucun attribut 'startTime' avant l'exécution

	    boolean result = interceptor.preHandle(request, response, new Object());

	    // Vérification du résultat
	    assertTrue(result);

	    // Vérification de l'appel à la méthode initLogTraceInfos
	    //verify(eaiLog, times(1)).initLogTraceInfos(request, "recharge-compte-damancash");

	    // Vérification que l'attribut 'startTime' est bien ajouté à la requête
	    //verify(request).setAttribute(eq("startTime"), anyLong());
	}

	@Test
	public void testAfterCompletion() throws Exception {
	    // Simuler l'attribut 'startTime' dans la requête
	    when(request.getAttribute("startTime")).thenReturn(1000L);

	    // Simuler l'appel de la méthode afterCompletion
	    interceptor.afterCompletion(request, response, new Object(), null);
	    verify(request, times(1)).getAttribute("startTime");

	}
}
