package ma.eai.boa.xbanking.dto.SignContrat;

public class SignContratRequest {

}
