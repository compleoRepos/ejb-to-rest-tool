package ma.eai.boa.xbanking.service.attachements;

import com.fasterxml.jackson.databind.ObjectMapper;
import ma.eai.boa.xbanking.dto.Attachements.AttachementObject;
import ma.eai.boa.xbanking.dto.Attachements.AttachementsResponse;
import ma.eai.boa.xbanking.dto.Beneficiaire.BeneficiaireResponse;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.vo.Attachements.AttachementsIn;
import ma.eai.boa.xbanking.vo.Attachements.AttachementsOut;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

@Service
public class AttachementsImpl implements Attachements{
    @Value("${api.url}")
    public String urlApi;

    @Autowired
    public RestTemplate restTemplate;


    @Override
    public AttachementsOut uploadFiles(AttachementsIn attachementsIn) {
	AttachementsOut attachementsOut = new AttachementsOut();


	if (attachementsIn == null) {
	    EaiLog.error("Input parameter attachementsIn is null");
	    return createErrorResponse(Constants.CODE_ERROR, Constants.TECHNICAL_ERROR);
	}

	try {
	    EaiLog.info("Processing attachementsIn: {}", attachementsIn);


	    if (!StringUtils.hasText(attachementsIn.getToken())) {
		EaiLog.error("Token is missing in attachementsIn");
		return createErrorResponse(Constants.CODE_ERROR, "Token is required");
	    }

	    AttachementObject attachementsRequest = buildAttachementRequest(attachementsIn);
	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.set(HttpHeaders.AUTHORIZATION,attachementsIn.getToken());
	    headers.set(Constants.CANAL_HEADER, Constants.CANAL);
	    ObjectMapper objectMapper = new ObjectMapper();

	    String jsonRequest = objectMapper.writeValueAsString(attachementsRequest);
	    EaiLog.info("jsonRequest==================> : {}",jsonRequest);
	    EaiLog.info("headers==================> : {}",headers);
	    HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, headers);
	    String url = buildApiUrl();
	    ResponseEntity<AttachementsResponse> response = restTemplate.exchange(
		    url,
		    HttpMethod.POST,
		    requestEntity,
		    AttachementsResponse.class
	    );

	    processResponse(response, attachementsOut);

	} catch (Exception e) {
	    EaiLog.error(Constants.ERROR_CALL_BES, e);
	    attachementsOut.setCode(Constants.CODE_ERROR);
	    attachementsOut.setMessage("ERR_TECHNICAL");
	}

	EaiLog.info("Completed uploadFiles service");
	return attachementsOut;
    }

    private AttachementObject buildAttachementRequest(AttachementsIn attachementsIn) {
	AttachementObject request = new AttachementObject();
	request.setAttachementRequests(attachementsIn.getAttachementRequests());
	request.setNbrTentative(attachementsIn.getNbrTentative());
	EaiLog.info("Built attachementsRequest: {}", request);
	return request;
    }

    private String buildApiUrl() {
	if (!StringUtils.hasText(urlApi)) {
	    throw new IllegalStateException("API URL is not configured");
	}
	return new StringBuilder(urlApi)
		.append("documents/upload")
		.toString();
    }

    public HttpEntity<String> createRequestEntity(AttachementObject attachementsRequest, String token)
	    throws Exception {
	HttpHeaders headers = new HttpHeaders();
	ObjectMapper objectMapper = new ObjectMapper();
	headers.setContentType(MediaType.APPLICATION_JSON);
	headers.set(HttpHeaders.AUTHORIZATION, token);
	headers.set(Constants.CANAL_HEADER, Constants.CANAL);
	String jsonRequest = objectMapper.writeValueAsString(attachementsRequest);
	EaiLog.info("Request JSON: {}", jsonRequest);
	EaiLog.info("Request headers: {}", headers);

	return new HttpEntity<>(jsonRequest, headers);
    }

    private void processResponse(ResponseEntity<AttachementsResponse> response, AttachementsOut attachementsOut) {
	AttachementsResponse body = response.getBody();
	EaiLog.info("Response received: {}", response);

	if(body != null && "SUCCESS_CODE".equals(body.getCode())) {
	    EaiLog.info("Successful response: {}", body);
	    attachementsOut.setCode(Constants.CODE_SUCCESS);
	    attachementsOut.setMessage("OK");
		attachementsOut.setIban(body.getIban());
		attachementsOut.setReference(body.getReference());
		attachementsOut.setDocumentType(body.getDocumentType());
	} else {
	    String errorMessage = body != null
		    ? body.getCode() + "/" + body.getMessage()
		    : Constants.RESPONSE_EMPTY;
	    EaiLog.info(Constants.ERROR_API_BES+errorMessage);
	    attachementsOut.setCode(Constants.CODE_ERROR);
	    attachementsOut.setMessage(body != null? body.getCode(): "RESPONSE_EMPTY");
	}
    }

    private AttachementsOut createErrorResponse(String code, String message) {
	AttachementsOut errorResponse = new AttachementsOut();
	errorResponse.setCode(code);
	errorResponse.setMessage(message);
	return errorResponse;
    }

}
