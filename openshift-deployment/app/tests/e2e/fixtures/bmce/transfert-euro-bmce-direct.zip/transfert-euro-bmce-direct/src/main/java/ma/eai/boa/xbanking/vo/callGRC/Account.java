package ma.eai.boa.xbanking.vo.callGRC;

import java.util.List;

public class Account {

    private List<String> rib ;

    public List<String> getRib() {
	return rib;
    }

    public void setRib(List<String> rib) {
	this.rib = rib;
    }
}
