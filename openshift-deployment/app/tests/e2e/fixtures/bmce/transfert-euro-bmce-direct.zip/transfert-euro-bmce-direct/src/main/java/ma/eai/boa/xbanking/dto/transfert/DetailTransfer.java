package ma.eai.boa.xbanking.dto.transfert;

import ma.eai.boa.xbanking.vo.Retour;

public class DetailTransfer extends Retour {

    private Transfer transfer;

    public Transfer getTransfer() {
        return transfer;
    }

    public void setTransfer(Transfer transfer) {
        this.transfer = transfer;
    }

    @Override
    public String toString() {
        return "DetailTransfer{" +
                "transfer=" + transfer +
                '}';
    }
}
