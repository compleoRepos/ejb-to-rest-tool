package ma.eai.boa.xbanking.dto.Beneficiaire;

public class Beneficiaire {

    private String id;

    private String firstName;

    private String lastName;

    private String holderSex;

    private String iban;

    private String rib;

    private String paysResidence;

    private String codeSwift;

    private String numCompteBes;

    private String bankCode;

    private String relationFamiliale;

    private boolean rejected;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getHolderSex() {
        return holderSex;
    }

    public void setHolderSex(String holderSex) {
        this.holderSex = holderSex;
    }

    public String getIban() {
        return iban;
    }

    public void setIban(String iban) {
        this.iban = iban;
    }

    public String getRib() {
        return rib;
    }

    public void setRib(String rib) {
        this.rib = rib;
    }

    public String getPaysResidence() {
        return paysResidence;
    }

    public void setPaysResidence(String paysResidence) {
        this.paysResidence = paysResidence;
    }

    public String getCodeSwift() {
        return codeSwift;
    }

    public void setCodeSwift(String codeSwift) {
        this.codeSwift = codeSwift;
    }

    public String getNumCompteBes() {
        return numCompteBes;
    }

    public void setNumCompteBes(String numCompteBes) {
        this.numCompteBes = numCompteBes;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getRelationFamiliale() {
        return relationFamiliale;
    }

    public void setRelationFamiliale(String relationFamiliale) {
        this.relationFamiliale = relationFamiliale;
    }

    public boolean isRejected() {
        return rejected;
    }

    public void setRejected(boolean rejected) {
        this.rejected = rejected;
    }

    @Override
    public String toString() {
        return "Beneficiaire{" +
                "id='" + id + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", holderSex='" + holderSex + '\'' +
                ", iban='" + iban + '\'' +
                ", rib='" + rib + '\'' +
                ", paysResidence='" + paysResidence + '\'' +
                ", codeSwift='" + codeSwift + '\'' +
                ", numCompteBes='" + numCompteBes + '\'' +
                ", bankCode='" + bankCode + '\'' +
                ", relationFamiliale='" + relationFamiliale + '\'' +
                ", rejected=" + rejected +
                '}';
    }
}
