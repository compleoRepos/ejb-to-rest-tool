package ma.eai.boa.xbanking.util;

public enum UserStep {
    ETAPE1("ETAPE1"),
    ETAPE2("ETAPE2"),
    ETAPE3("ETAPE3"),
    ETAPE4("ETAPE4"),
    ETAPE5("ETAPE5"),
    ETAPE6("ETAPE6"),
    COMPLETED("COMPLETED");

    private String value;

    UserStep(String value) {
	this.value = value;
    }

    public static UserStep getUserStepByValue(String value) {
	for (UserStep c : UserStep.values()) {
	    if (c.getValue().equalsIgnoreCase(value)) {
		return c;
	    }
	}
	return null;
    }

    public String getValue() {
	return value;
    }
}

