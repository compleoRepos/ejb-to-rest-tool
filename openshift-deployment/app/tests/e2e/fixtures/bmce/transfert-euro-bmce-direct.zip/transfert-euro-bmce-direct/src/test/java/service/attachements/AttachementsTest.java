package service.attachements;


import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

import ma.eai.boa.xbanking.dto.Attachements.AttachementObject;
import ma.eai.boa.xbanking.dto.Attachements.AttachementsResponse;
import ma.eai.boa.xbanking.service.attachements.AttachementsImpl;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.vo.Attachements.AttachementsIn;
import ma.eai.boa.xbanking.vo.Attachements.AttachementsOut;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

@RunWith(MockitoJUnitRunner.class)
public class AttachementsTest {

    @InjectMocks
    private AttachementsImpl attachementsService;

    @Mock
    private RestTemplate restTemplate;

    private static final String API_URL = "http://test-api.com/";
    private static final String TOKEN = "Bearer test-token";

    @Before
    public void setUp() {
	// Injecter la valeur de urlApi via réflexion ou setter si disponible
	attachementsService = new AttachementsImpl();
	attachementsService.urlApi = API_URL;
	attachementsService.restTemplate = restTemplate;
    }

    @Test
    public void testUploadFiles_NullInput_ReturnsError() {
	// Act
	AttachementsOut result = attachementsService.uploadFiles(null);

	// Assert
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals(Constants.TECHNICAL_ERROR, result.getMessage());
    }

    @Test
    public void testUploadFiles_MissingToken_ReturnsError() {
	// Arrange
	AttachementsIn input = new AttachementsIn();
	input.setToken(""); // Token vide

	// Act
	AttachementsOut result = attachementsService.uploadFiles(input);

	// Assert
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals("Token is required", result.getMessage());
    }

    @Test
    public void testUploadFiles_SuccessfulResponse() throws Exception {
	// Arrange
	AttachementsIn input = new AttachementsIn();
	input.setToken(TOKEN);
	input.setNbrTentative(1);

	AttachementsResponse apiResponse = new AttachementsResponse();
	apiResponse.setCode("SUCCESS_CODE");
	apiResponse.setMessage("Success");
	apiResponse.setIban("iban");
	apiResponse.setReference("reference");

	ResponseEntity<AttachementsResponse> responseEntity = ResponseEntity.ok(apiResponse);

	when(restTemplate.exchange(
		eq(API_URL + "documents/upload"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(AttachementsResponse.class)))
		.thenReturn(responseEntity);

	// Act
	AttachementsOut result = attachementsService.uploadFiles(input);

	// Assert
	assertEquals(Constants.CODE_SUCCESS, result.getCode());
	assertEquals("OK", result.getMessage());
	assertEquals("iban", result.getIban());
	assertEquals("reference", result.getReference());
	verify(restTemplate, times(1)).exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(AttachementsResponse.class));
    }

    @Test
    public void testUploadFiles_ApiError_ReturnsError() throws Exception {
	// Arrange
	AttachementsIn input = new AttachementsIn();
	input.setToken(TOKEN);
	input.setNbrTentative(1);

	AttachementsResponse apiResponse = new AttachementsResponse();
	apiResponse.setCode("111");
	apiResponse.setMessage("ERR_TECHNICAL");

	ResponseEntity<AttachementsResponse> responseEntity = ResponseEntity.ok(apiResponse);

	when(restTemplate.exchange(
		eq(API_URL + "documents/upload"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(AttachementsResponse.class)))
		.thenReturn(responseEntity);

	// Act
	AttachementsOut result = attachementsService.uploadFiles(input);

	// Assert
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals("111", result.getMessage());
    }

    @Test
    public void testUploadFiles_ExceptionThrown_ReturnsTechnicalError() {
	// Arrange
	AttachementsIn input = new AttachementsIn();
	input.setToken(TOKEN);
	input.setNbrTentative(1);

	when(restTemplate.exchange(
		eq(API_URL + "documents/upload"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(AttachementsResponse.class)))
		.thenThrow(new RuntimeException("Network error"));

	// Act
	AttachementsOut result = attachementsService.uploadFiles(input);

	// Assert
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals("ERR_TECHNICAL", result.getMessage());
    }

    @Test
    public void testCreateRequestEntity_ValidInput() throws Exception {
	// Arrange
	AttachementObject request = new AttachementObject();
	request.setNbrTentative(1);

	// Act
	HttpEntity<String> entity = attachementsService.createRequestEntity(request, TOKEN);

	// Assert
	HttpHeaders headers = entity.getHeaders();
	assertEquals(MediaType.APPLICATION_JSON, headers.getContentType());
	assertEquals(TOKEN, headers.getFirst(HttpHeaders.AUTHORIZATION));
	assertEquals("{\"attachementRequests\":null,\"attemptsCount\":1}", entity.getBody());
    }
}
