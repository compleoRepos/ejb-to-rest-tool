package ma.eai.boa.xbanking.vo.Attachements;

import com.fasterxml.jackson.annotation.JsonProperty;
import ma.eai.boa.xbanking.dto.Attachements.AttachementsRequest;

import java.util.List;

public class AttachementsIn {

    private List<AttachementsRequest> attachementRequests;

    @JsonProperty("attemptsCount")
    private int nbrTentative;

    private String token;

    public List<AttachementsRequest> getAttachementRequests() {
	return attachementRequests;
    }

    public void setAttachementRequests(List<AttachementsRequest> attachementRequests) {
	this.attachementRequests = attachementRequests;
    }

    public int getNbrTentative() {
	return nbrTentative;
    }

    public void setNbrTentative(int nbrTentative) {
	this.nbrTentative = nbrTentative;
    }

    public String getToken() {
	return token;
    }

    public void setToken(String token) {
	this.token = token;
    }

    @Override
    public String toString() {
	return "AttachementsIn{" + "token='" + token + '\'' + ", nbrTentative=" + nbrTentative
		+ ", attachementRequests=" + attachementRequests + '}';
    }
}
