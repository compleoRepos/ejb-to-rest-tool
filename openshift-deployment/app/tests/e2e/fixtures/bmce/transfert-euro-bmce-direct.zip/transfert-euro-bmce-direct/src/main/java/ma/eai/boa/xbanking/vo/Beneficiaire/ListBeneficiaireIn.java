package ma.eai.boa.xbanking.vo.Beneficiaire;

public class ListBeneficiaireIn {

    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
