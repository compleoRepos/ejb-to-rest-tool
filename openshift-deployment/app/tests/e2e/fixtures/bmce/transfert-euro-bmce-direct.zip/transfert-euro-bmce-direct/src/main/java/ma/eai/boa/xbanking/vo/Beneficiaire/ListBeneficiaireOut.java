package ma.eai.boa.xbanking.vo.Beneficiaire;

import ma.eai.boa.xbanking.dto.Beneficiaire.Beneficiaire;
import ma.eai.boa.xbanking.vo.Retour;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "listBeneficiaireOut")
public class ListBeneficiaireOut extends Retour {

    private List<Beneficiaire> listeBenef;

    private float commission;

    public List<Beneficiaire> getListeBenef() {
        return listeBenef;
    }

    public void setListeBenef(List<Beneficiaire> listeBenef) {
        this.listeBenef = listeBenef;
    }

    public float getCommission() {
        return commission;
    }

    public void setCommission(float commission) {
        this.commission = commission;
    }
}
