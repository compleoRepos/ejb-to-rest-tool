package ma.eai.boa.xbanking.dto.SignContrat;

public class GetContratResponse {
}
