package service.enrollement;


import ma.eai.boa.xbanking.dto.enrollement.CheckInfoRequest;
import ma.eai.boa.xbanking.dto.enrollement.ValidatDataResponse;
import ma.eai.boa.xbanking.entities.IbanAttempt;
import ma.eai.boa.xbanking.repository.enrollement.IbanAttemptsRepository;
import ma.eai.boa.xbanking.service.enrollement.EnrollementServiceImpl;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.vo.enrollement.CheckIbanOut;
import ma.eai.boa.xbanking.vo.enrollement.CheckIbenIn;
import ma.eai.boa.xbanking.vo.enrollement.CheckInfoIn;
import ma.eai.boa.xbanking.vo.enrollement.CheckInfoOut;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.RestTemplate;


import java.util.Date;
import java.util.Optional;

public class EnrollementImplTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private IbanAttemptsRepository ibanAttemptsRepository;

    @InjectMocks
    private EnrollementServiceImpl enrollementImpl;

    private CheckInfoIn checkInfoIn;
    private ValidatDataResponse successResponse;
    private ValidatDataResponse ibanNeededResponse;
    private ValidatDataResponse errorResponse;
    private CheckIbenIn checkIbenIn;
    private CheckInfoRequest checkInfoRequest;

    @Before
    public void setUp() {
	MockitoAnnotations.initMocks(this);
	enrollementImpl.urlApi = "http://test-api/";
	checkInfoIn = new CheckInfoIn();
	checkInfoIn.setFirstName("John");
	checkInfoIn.setLastName("Doe");
	checkInfoIn.setBirthDate(new Date());
	checkInfoIn.setPhoneNumber("123456789");
	checkInfoIn.setCallingCode("+33");
	checkInfoIn.setCountryCode("FR");
	checkInfoIn.setDeviceId("device123");
	checkInfoIn.setToken("Bearer xyz");

	checkInfoRequest = new CheckInfoRequest();
	checkInfoRequest.setFirstName("John");
	checkInfoRequest.setLastName("Doe");
	checkInfoRequest.setPhoneNumber("123456789");

	successResponse = new ValidatDataResponse();
	successResponse.setCode("SUCCESS_CODE");
	successResponse.setClient(true);
	successResponse.setCompleted(true);
	successResponse.setPhone("123456789");
	successResponse.setUuid("uuid-123");
	successResponse.setLang("FR");
	successResponse.setNombreNotifs(3);
	successResponse.setUuidKey("uuidKey123");
	successResponse.setOtpID("otpId123");

	checkIbenIn = new CheckIbenIn();
	CheckInfoRequest checkInfoRequest = new CheckInfoRequest();
	checkInfoRequest.setBirthDate(new Date());
	checkInfoRequest.setFirstName("John");
	checkInfoRequest.setLastName("Doe");
	checkInfoRequest.setCallingCode("+212");
	checkInfoRequest.setCountryCode("MA");
	checkInfoRequest.setPhoneNumber("123456789");
	checkIbenIn.setCheckInfoRequest(checkInfoRequest);
	checkIbenIn.setIban("MA123456789");
	checkIbenIn.setDeviceId("device123");
	checkIbenIn.setToken("Bearer test-token");

	successResponse = new ValidatDataResponse();
	successResponse.setCode("SUCCESS_CODE");
	successResponse.setPhone("123456789");
	successResponse.setClient(true);
	successResponse.setCompleted(true);
	successResponse.setUuid("uuid123");
	successResponse.setLang("fr");
	successResponse.setNombreNotifs(5);
	successResponse.setUuidKey("key123");
	successResponse.setOtpID("otp123");

	ibanNeededResponse = new ValidatDataResponse();
	ibanNeededResponse.setCode("IBAN_NEEDED");

	errorResponse = new ValidatDataResponse();
	errorResponse.setCode("ERROR_CODE");
	errorResponse.setMessage("Error occurred");
    }


    @Test
    public void testCheckInfos_Exception() {
	Mockito.when(restTemplate.exchange(
		Mockito.anyString(),
		Mockito.eq(HttpMethod.POST),
		Mockito.any(HttpEntity.class),
		Mockito.eq(ValidatDataResponse.class)
	)).thenThrow(new RuntimeException("Test exception"));

	CheckInfoOut result = enrollementImpl.checkInfos(checkInfoIn);
	Assert.assertEquals(Constants.CODE_ERROR, result.getCode());
	Assert.assertTrue(result.getMessage().contains("erreur inconnue"));
    }

    @Test
    public void testCheckIban_UserBlocked() {
	CheckIbenIn checkIbenIn = new CheckIbenIn();
	CheckInfoRequest checkInfo = new CheckInfoRequest();
	checkInfo.setBirthDate(new Date());
	checkInfo.setFirstName("John");
	checkInfo.setLastName("Doe");
	checkInfo.setPhoneNumber("0600000000");
	checkIbenIn.setCheckInfoRequest(checkInfo);
	checkIbenIn.setIban("IBANTEST");
	checkIbenIn.setDeviceId("device-123");
	checkIbenIn.setToken("Bearer token");

	IbanAttempt attempt = new IbanAttempt();
	attempt.setIbanAttemptNumber(3);
	attempt.setLastIbanAttemptDate(new Date());

	Mockito.when(ibanAttemptsRepository.findById(Mockito.anyString()))
		.thenReturn(Optional.of(attempt));

	CheckIbanOut result = enrollementImpl.checkIban(checkIbenIn);
	Assert.assertEquals("TBAN_EXCEEDED", result.getCode());
	Assert.assertEquals("Check IBAN Exceeded", result.getMessage());
    }
}