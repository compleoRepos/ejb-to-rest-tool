package ma.eai.boa.xbanking.vo.historiqueTransfert;

import ma.eai.boa.xbanking.entities.History;

import java.util.List;

public class Transferts {
    private List<History> listHistory;

    public List<History> getListHistory() {
	return listHistory;
    }
    public void setListHistory(List<History> listHistory) {
	this.listHistory = listHistory;
    }
}
