package ma.eai.boa.xbanking.vo.enrollement;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class EnrollementValidationIn {


    private String token;

    @JsonProperty("email")
    private String email;

    @JsonProperty("uuid")
    private String uuid;

    private String contratBad;

    public String getContratBad() {
        return contratBad;
    }

    public void setContratBad(String contratBad) {
        this.contratBad = contratBad;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public String toString() {
        return "EnrollementValidationIn{" +
                "email='" + email + '\'' +
                ", uuid='" + uuid + '\'' +
                '}';
    }
}
