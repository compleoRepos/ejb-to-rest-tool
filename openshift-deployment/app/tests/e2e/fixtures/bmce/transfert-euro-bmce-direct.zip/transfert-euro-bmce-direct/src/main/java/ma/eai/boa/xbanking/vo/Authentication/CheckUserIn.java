package ma.eai.boa.xbanking.vo.Authentication;

public class CheckUserIn {

    private String contratBad;

    private String deviceId;

    public String getContratBad() {
        return contratBad;
    }

    public void setContratBad(String contratBad) {
        this.contratBad = contratBad;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }
}
