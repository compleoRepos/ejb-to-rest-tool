package ma.eai.boa.xbanking.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;

import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import java.io.Serializable;
import java.sql.Timestamp;

@Table(name = "BES_TRANSFERT")
@Entity
public class TransfertBES implements Serializable {


    private static final long serialVersionUID = -8778416725766243130L;

    @Id
    @Column(unique = true, nullable = false)
    private String uuid;

    @Column(nullable = false, updatable = false)
    @CreationTimestamp
    @JsonIgnore
    private Timestamp dateInserted;

    @ManyToOne
    @JsonIgnore
    private User user;

    private double amountToSend;

    private double amountNetToSend;

    private double amountToReceive;

    private String transferMode;

    private String iban;

    private String numCompteBes;

    private String rib;

    private String lastName;

    private String firstName;

    private String bankName;

    private float tauxChange;

    private float commission;

    private String compteClient;

    private String callbackUrl;

    private String url;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public Timestamp getDateInserted() {
        return dateInserted;
    }

    public void setDateInserted(Timestamp dateInserted) {
        this.dateInserted = dateInserted;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public double getAmountToSend() {
        return amountToSend;
    }

    public void setAmountToSend(double amountToSend) {
        this.amountToSend = amountToSend;
    }

    public double getAmountNetToSend() {
        return amountNetToSend;
    }

    public void setAmountNetToSend(double amountNetToSend) {
        this.amountNetToSend = amountNetToSend;
    }

    public double getAmountToReceive() {
        return amountToReceive;
    }

    public void setAmountToReceive(double amountToReceive) {
        this.amountToReceive = amountToReceive;
    }

    public String getTransferMode() {
        return transferMode;
    }

    public void setTransferMode(String transferMode) {
        this.transferMode = transferMode;
    }

    public String getIban() {
        return iban;
    }

    public void setIban(String iban) {
        this.iban = iban;
    }

    public String getNumCompteBes() {
        return numCompteBes;
    }

    public void setNumCompteBes(String numCompteBes) {
        this.numCompteBes = numCompteBes;
    }

    public String getRib() {
        return rib;
    }

    public void setRib(String rib) {
        this.rib = rib;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public float getTauxChange() {
        return tauxChange;
    }

    public void setTauxChange(float tauxChange) {
        this.tauxChange = tauxChange;
    }

    public float getCommission() {
        return commission;
    }

    public void setCommission(float commission) {
        this.commission = commission;
    }

    public String getCompteClient() {
        return compteClient;
    }

    public void setCompteClient(String compteClient) {
        this.compteClient = compteClient;
    }

    public String getCallbackUrl() {
        return callbackUrl;
    }

    public void setCallbackUrl(String callbackUrl) {
        this.callbackUrl = callbackUrl;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
