package service.enrollement;

import ma.eai.boa.xbanking.dto.enrollement.EnrollementRequest;
import ma.eai.boa.xbanking.dto.enrollement.ValidatDataResponse;
import ma.eai.boa.xbanking.repository.UserRepository;
import ma.eai.boa.xbanking.service.enrollement.EnrollementServiceImpl;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.util.Utils;
import ma.eai.boa.xbanking.vo.enrollement.EnrollementValidationIn;
import ma.eai.boa.xbanking.vo.enrollement.EnrollementValidationOut;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.security.NoSuchAlgorithmException;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.when;

public class EnrollmentServiceImplTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private EnrollementServiceImpl enrollementService;

    @Mock
    private UserRepository userRepository;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        enrollementService.urlApi = "http://example.com/";
    }


    @Test
    public void activateUserTest() throws NoSuchAlgorithmException {
        //Given
        EnrollementValidationIn in = new EnrollementValidationIn();
        in.setEmail("email");
        in.setUuid("uuid");
        in.setToken("token");

        EnrollementRequest enrollementRequest = new EnrollementRequest();

        enrollementRequest.setPassword(Utils.generateRandomString());
        enrollementRequest.setUuid(in.getUuid());
        enrollementRequest.setEmail(in.getEmail());

        ValidatDataResponse validatDataResponse = new ValidatDataResponse();
        validatDataResponse.setLang("FR");
        validatDataResponse.setCompleted(true);
        validatDataResponse.setCode("SUCCESS_CODE");

        ResponseEntity<ValidatDataResponse> mockResponseEntity =
                new ResponseEntity<>(validatDataResponse, HttpStatus.OK);

        when(restTemplate.exchange(
                eq("http://example.com/enrollement/validate"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(ValidatDataResponse.class)
        )).thenReturn(mockResponseEntity);

        EnrollementValidationOut resp = enrollementService.activateUser(in);

        assertEquals(Constants.CODE_SUCCESS, resp.getCode());

    }


    @Test
    public void activateUserTest_shouldReturnError() throws NoSuchAlgorithmException {
        //Given
        EnrollementValidationIn in = new EnrollementValidationIn();
        in.setEmail("email");
        in.setUuid("uuid");
        in.setToken("token");

        EnrollementRequest enrollementRequest = new EnrollementRequest();

        enrollementRequest.setPassword(Utils.generateRandomString());
        enrollementRequest.setUuid(in.getUuid());
        enrollementRequest.setEmail(in.getEmail());

        ValidatDataResponse validatDataResponse = new ValidatDataResponse();
        validatDataResponse.setLang("FR");
        validatDataResponse.setCompleted(true);
        validatDataResponse.setCode("ERROR");

        ResponseEntity<ValidatDataResponse> mockResponseEntity =
                new ResponseEntity<>(validatDataResponse, HttpStatus.OK);

        when(restTemplate.exchange(
                eq("http://example.com/enrollement/validate"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(ValidatDataResponse.class)
        )).thenReturn(mockResponseEntity);

        EnrollementValidationOut resp = enrollementService.activateUser(in);

        assertEquals(Constants.CODE_ERROR, resp.getCode());

    }

    @Test
    public void activateUserTest_Error_when_ThrowingException() throws NoSuchAlgorithmException {
        //Given
        EnrollementValidationIn in = new EnrollementValidationIn();
        in.setEmail("email");
        in.setUuid("uuid");
        in.setToken("token");

        EnrollementRequest enrollementRequest = new EnrollementRequest();

        enrollementRequest.setPassword(Utils.generateRandomString());
        enrollementRequest.setUuid(in.getUuid());
        enrollementRequest.setEmail(in.getEmail());

        ValidatDataResponse validatDataResponse = new ValidatDataResponse();
        validatDataResponse.setLang("FR");
        validatDataResponse.setCompleted(true);
        validatDataResponse.setCode("SUCCESS_CODE");

        ResponseEntity<ValidatDataResponse> mockResponseEntity =
                new ResponseEntity<>(validatDataResponse, HttpStatus.OK);

        when(restTemplate.exchange(
                eq("http://example.com/enrollement/validate"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(ValidatDataResponse.class)
        )).thenThrow(new RuntimeException());

        EnrollementValidationOut resp = enrollementService.activateUser(in);

        assertEquals(Constants.CODE_ERROR, resp.getCode());

    }

}
