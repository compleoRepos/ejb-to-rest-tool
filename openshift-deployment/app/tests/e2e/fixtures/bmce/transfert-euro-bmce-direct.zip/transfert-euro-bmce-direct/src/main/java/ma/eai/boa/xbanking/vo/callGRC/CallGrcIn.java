package ma.eai.boa.xbanking.vo.callGRC;

public class CallGrcIn {

    private String idClient;

    public String getIdClient() {
        return idClient;
    }

    public void setIdClient(String idClient) {
        this.idClient = idClient;
    }

    @Override
    public String toString() {
        return "CallGrcIn{" + "idClient='" + idClient + '\'' + '}';
    }
}
