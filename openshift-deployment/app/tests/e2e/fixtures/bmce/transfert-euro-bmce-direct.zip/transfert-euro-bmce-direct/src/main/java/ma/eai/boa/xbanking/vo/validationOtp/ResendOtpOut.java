package ma.eai.boa.xbanking.vo.validationOtp;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "ResendOtpOut")
public class ResendOtpOut {

    private String transactionId;

    private String status;

    private String code;

    private String message;

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
