package ma.eai.boa.xbanking.dto.Beneficiaire;

import ma.eai.boa.xbanking.vo.Retour;

import java.util.List;

public class ListBeneficiaire extends Retour {

    private List<Beneficiaire> listeBenef;

    private float commission;

    public List<Beneficiaire> getListeBenef() {
        return listeBenef;
    }

    public void setListeBenef(List<Beneficiaire> listeBenef) {
        this.listeBenef = listeBenef;
    }

    public float getCommission() {
        return commission;
    }

    public void setCommission(float commission) {
        this.commission = commission;
    }

    @Override
    public String toString() {
        return "ListBeneficiare{" +
                "listeBenef=" + listeBenef +
                ", commission=" + commission +
                '}';
    }
}
