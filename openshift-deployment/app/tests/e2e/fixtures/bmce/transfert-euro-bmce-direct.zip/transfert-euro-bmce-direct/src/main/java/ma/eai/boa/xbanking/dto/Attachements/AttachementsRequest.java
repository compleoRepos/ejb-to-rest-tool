package ma.eai.boa.xbanking.dto.Attachements;

import ma.eai.boa.xbanking.vo.Retour;

public class AttachementsRequest {
    private String documentName;

    private String documentType;

    private String face;

    private String data;

    public String getDocumentName() {
	return documentName;
    }

    public void setDocumentName(String documentName) {
	this.documentName = documentName;
    }

    public String getDocumentType() {
	return documentType;
    }

    public void setDocumentType(String documentType) {
	this.documentType = documentType;
    }

    public String getFace() {
	return face;
    }

    public void setFace(String face) {
	this.face = face;
    }

    public String getData() {
	return data;
    }

    public void setData(String data) {
	this.data = data;
    }
}
