package ma.eai.boa.xbanking.service.signContrat;

import ma.eai.boa.xbanking.dto.SignContrat.IbanResponse;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.vo.SignContrat.IbanResponseOut;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class GenerateIbanServiceImpl implements GenerateIbanService {

    @Value("${api.url}")
    private String url;

    private final RestTemplate restTemplate;

    public GenerateIbanServiceImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public IbanResponseOut generateIban(String token) {
        EaiLog.info("Start generate iban service");

        IbanResponseOut ibanResponseOut = new IbanResponseOut();
        try {
            String urlApi = new StringBuilder(url)
                    .append("prospect/generateIban")
                    .toString();
            EaiLog.info("url call generate Iban: {}", urlApi);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set(HttpHeaders.AUTHORIZATION, token);
            headers.set(Constants.CANAL_HEADER, Constants.CANAL);
            HttpEntity requestEntity = new HttpEntity<>(headers);

            ResponseEntity<IbanResponse> response = restTemplate.exchange(urlApi, HttpMethod.GET, requestEntity,
                    IbanResponse.class);
            IbanResponse body = response.getBody();
            if (body != null && "SUCCESS_CODE".equals(body.getCode())) {
                 EaiLog.info("Calling API BES OK , response : {}",body.toString());
                 ibanResponseOut.setCode(Constants.CODE_SUCCESS);
                 ibanResponseOut.setIban(body.getIban());
                 ibanResponseOut.setBic(body.getBic());
                 ibanResponseOut.setReference(body.getReference());
            } else {
                EaiLog.info("returned Code not OK");
                ibanResponseOut.setCode(Constants.CODE_ERROR);
                ibanResponseOut.setMessage(body != null ? body.getCode() : "RESPONSE_EMPTY");
            }
        } catch(Exception e) {
            EaiLog.info("Error calling API BES : {} " , e);
            ibanResponseOut.setCode(Constants.CODE_ERROR);
            ibanResponseOut.setMessage("");
        }
        EaiLog.info("-----------Fin service generate iban------------");
        return ibanResponseOut;
    }


}
