package ma.eai.boa.xbanking.entities;

import ma.eai.boa.xbanking.util.Status;

import java.io.Serializable;
import java.sql.Timestamp;

public class History implements Serializable {
    private static final long serialVersionUID = -6711297756518200802L;

    private String beneficiaryLastName;

    private String beneficiaryFirstName;

    private double amountToSend;

    private Status status;

    private String uuid;

    private float commission;

    private double amountNetToSend;

    private double amountToReceive;

    private float tauxChange;

    private String savedDate;

    private String dateReceiveMoney;

    private String dateSendMoney;

    private String dateFinalStatus;

    private boolean force;

    private String transferMode;

    public String getBeneficiaryLastName() {
	return beneficiaryLastName;
    }

    public void setBeneficiaryLastName(String beneficiaryLastName) {
	this.beneficiaryLastName = beneficiaryLastName;
    }

    public String getBeneficiaryFirstName() {
	return beneficiaryFirstName;
    }

    public void setBeneficiaryFirstName(String beneficiaryFirstName) {
	this.beneficiaryFirstName = beneficiaryFirstName;
    }

    public double getAmountToSend() {
	return amountToSend;
    }

    public void setAmountToSend(double amountToSend) {
	this.amountToSend = amountToSend;
    }

    public Status getStatus() {
	return status;
    }

    public void setStatus(Status status) {
	this.status = status;
    }

    public String getUuid() {
	return uuid;
    }

    public void setUuid(String uuid) {
	this.uuid = uuid;
    }

    public float getCommission() {
	return commission;
    }

    public void setCommission(float commission) {
	this.commission = commission;
    }

    public double getAmountNetToSend() {
	return amountNetToSend;
    }

    public void setAmountNetToSend(double amountNetToSend) {
	this.amountNetToSend = amountNetToSend;
    }

    public double getAmountToReceive() {
	return amountToReceive;
    }

    public void setAmountToReceive(double amountToReceive) {
	this.amountToReceive = amountToReceive;
    }

    public float getTauxChange() {
	return tauxChange;
    }

    public void setTauxChange(float tauxChange) {
	this.tauxChange = tauxChange;
    }

    public String getSavedDate() {
	return savedDate;
    }

    public void setSavedDate(String savedDate) {
	this.savedDate = savedDate;
    }

    public String getDateReceiveMoney() {
	return dateReceiveMoney;
    }

    public void setDateReceiveMoney(String dateReceiveMoney) {
	this.dateReceiveMoney = dateReceiveMoney;
    }

    public String getDateSendMoney() {
	return dateSendMoney;
    }

    public void setDateSendMoney(String dateSendMoney) {
	this.dateSendMoney = dateSendMoney;
    }

    public String getDateFinalStatus() {
	return dateFinalStatus;
    }

    public void setDateFinalStatus(String dateFinalStatus) {
	this.dateFinalStatus = dateFinalStatus;
    }

    public boolean isForce() {
	return force;
    }

    public void setForce(boolean force) {
	this.force = force;
    }

    public String getTransferMode() {
	return transferMode;
    }

    public void setTransferMode(String transferMode) {
	this.transferMode = transferMode;
    }
}
