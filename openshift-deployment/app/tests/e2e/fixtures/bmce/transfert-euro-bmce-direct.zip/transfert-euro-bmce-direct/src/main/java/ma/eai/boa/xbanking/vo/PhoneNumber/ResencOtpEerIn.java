package ma.eai.boa.xbanking.vo.PhoneNumber;

public class ResencOtpEerIn {
    private String otpID;

    public String getOtpID() {
	return otpID;
    }

    public void setOtpID(String otpID) {
	this.otpID = otpID;
    }
}
