package ma.eai.boa.xbanking.vo.Step;

import ma.eai.boa.xbanking.dto.steps.AdditionalDataProspectDTO;
import ma.eai.boa.xbanking.dto.steps.BeneficiaireDTO;
import ma.eai.boa.xbanking.dto.steps.DataProspectDTO;
import ma.eai.boa.xbanking.vo.Retour;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
@XmlRootElement(name = "StepOut")
public class StepOut extends Retour {

    private DataProspectDTO dtProspect;

    private AdditionalDataProspectDTO addDataProspect;

    private List<BeneficiaireDTO> beneficiairesList;

    private String step;

    public DataProspectDTO getDtProspect() {
	return dtProspect;
    }

    public void setDtProspect(DataProspectDTO dtProspect) {
	this.dtProspect = dtProspect;
    }

    public List<BeneficiaireDTO> getBeneficiairesList() {
	return beneficiairesList;
    }

    public void setBeneficiairesList(List<BeneficiaireDTO> beneficiairesList) {
	this.beneficiairesList = beneficiairesList;
    }

    public AdditionalDataProspectDTO getAddDataProspect() {
	return addDataProspect;
    }

    public void setAddDataProspect(AdditionalDataProspectDTO addDataProspect) {
	this.addDataProspect = addDataProspect;
    }

    public String getStep() {
        return step;
    }

    public void setStep(String step) {
        this.step = step;
    }
}
