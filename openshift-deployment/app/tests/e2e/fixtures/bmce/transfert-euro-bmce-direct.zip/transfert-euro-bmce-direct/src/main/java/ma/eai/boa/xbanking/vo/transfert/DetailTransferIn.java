package ma.eai.boa.xbanking.vo.transfert;

public class DetailTransferIn {

    private String uuid;

    private String token;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
