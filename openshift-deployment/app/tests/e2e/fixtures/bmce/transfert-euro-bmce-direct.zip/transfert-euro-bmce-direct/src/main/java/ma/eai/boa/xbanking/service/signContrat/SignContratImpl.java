package ma.eai.boa.xbanking.service.signContrat;



import com.fasterxml.jackson.databind.ObjectMapper;
import ma.eai.boa.xbanking.dto.SignContrat.GetContartRequest;

import ma.eai.boa.xbanking.dto.SignContrat.SignContratResponse;
import ma.eai.boa.xbanking.dto.SignContrat.ValidateOtpSignContratRequest;
import ma.eai.boa.xbanking.dto.SignContrat.ValidateOtpSignContratResponse;
import ma.eai.boa.xbanking.util.Constants;

import ma.eai.boa.xbanking.vo.SignContrat.GetContratIn;
import ma.eai.boa.xbanking.vo.SignContrat.GetContratOut;
import ma.eai.boa.xbanking.vo.SignContrat.SignContratIn;
import ma.eai.boa.xbanking.vo.SignContrat.SignContratOut;
import ma.eai.boa.xbanking.vo.SignContrat.ValidateOtpSignContratOut;
import ma.eai.boa.xbanking.vo.SignContrat.ValidateOtpSigneContratIn;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;


import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;

@Service
public class SignContratImpl implements SignContrat{

    @Value("${api.url}")
    public String urlApi;
    @Autowired
    RestTemplate restTemplate;

    private static final String ACCEPT="Accept";
    private static final String ALL = "*/*";


    @Override
    public SignContratOut signContrat(SignContratIn signContratIn) {

	SignContratOut signContratOut=new SignContratOut();
	try{
	    String url = new StringBuilder(urlApi)
		    .append("prospect/signContrat")
		    .toString();
	    EaiLog.info("url appel prospect/signContrat: {}", url);

	    HttpHeaders headers = new HttpHeaders();
	    headers.set(ACCEPT, ALL);
	    headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
	    headers.set(HttpHeaders.AUTHORIZATION,signContratIn.getToken());
	    headers.set(Constants.CANAL_HEADER, Constants.CANAL);
	    EaiLog.info("headers==================>: {}",headers);
	    HttpEntity<String> requestEntity = new HttpEntity<>(headers);
	    ResponseEntity<SignContratResponse> response = restTemplate.
				exchange(url, HttpMethod.POST, requestEntity,
		    SignContratResponse.class);
	    EaiLog.info("---------------response: {} ",response);
	    SignContratResponse body=response.getBody();
	    EaiLog.info("---------------body: {}",body);
	    if(body != null && "SUCCESS_CODE".equals(body.getCode())) {
	    	EaiLog.info("-----------Calling BES OK-------------");
			signContratOut.setCode(Constants.CODE_SUCCESS);
			signContratOut.setMessage("OK");
			signContratOut.setStatus(body.getStatus());
			signContratOut.setTransactionId(body.getTransactionId());
	    }else {
			EaiLog.info("returned Code not OK");
			signContratOut.setCode(Constants.CODE_ERROR);
			signContratOut.setMessage((body != null ? body.getCode() : "RESPONSE_EMPTY"));
	    }
	    EaiLog.info("-----------Fin service signContrat------------");
	} catch (Exception e) {
	    EaiLog.info("----Error --- calling API ---- BES : {} " , e);
	    signContratOut.setCode(Constants.CODE_ERROR);
	    signContratOut.setMessage("ERR_TECHNICAL");
	}
	return signContratOut;
    }





    @Override
    public GetContratOut getContrat(GetContratIn getContratIn) {
	GetContratOut getContratOut = new GetContratOut();
	String responseBase64 = null;
	try {

	    String url = new StringBuilder(urlApi).append("prospect/contratToSign").toString();
	    EaiLog.info("url appel prospect/contratToSign: {} " , url);

	    HttpHeaders headers = new HttpHeaders();
	    headers.set(ACCEPT, ALL);
	    headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
	    headers.set("Authorization", getContratIn.getToken());
	    headers.set(Constants.CANAL_HEADER, Constants.CANAL);
	    EaiLog.info("--------**---Authorization__---**---------: {} " , getContratIn.getToken());
	    HttpEntity<GetContartRequest> requestEntity = new HttpEntity<>(headers);
	    EaiLog.info("---***--requestEntity__-----: {} " , requestEntity.getHeaders());

	    ResponseEntity<byte[]> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity, byte[].class);

	    if (response.getStatusCode().is2xxSuccessful()) {
		EaiLog.info("Response OK with status: {} " , response.getStatusCode());
			byte[] responseBytes = response.getBody();
			if (responseBytes != null) {
				responseBase64 = Base64.getEncoder().encodeToString(responseBytes);
				getContratOut.setBase64(responseBase64);
				getContratOut.setCode(Constants.CODE_SUCCESS);
				getContratOut.setMessage("OK");
				EaiLog.info("**********base64*********** : {} " , responseBase64);
			} else {
				getContratOut.setCode(Constants.CODE_ERROR);
				getContratOut.setMessage(Constants.TECHNICAL_ERROR);
				EaiLog.info("Empty response or damaged file");
			}
	    } else {
		getContratOut.setCode(Constants.CODE_ERROR);
		getContratOut.setMessage(Constants.TECHNICAL_ERROR);
		EaiLog.info("Error -- calling -- API BES : {}"  , response.getStatusCode());
	    }

	    EaiLog.info("-----------Fin service contratToSign------------");

	} catch (HttpClientErrorException | HttpServerErrorException e) {
	    getContratOut.setCode(Constants.CODE_ERROR);
	    getContratOut.setMessage("KO");
	    EaiLog.info("Erreur HTTP := {}====> : {}" , e.getStatusCode() + " -====> {} " , e.getMessage());
	} catch (Exception e) {
	    getContratOut.setCode(Constants.CODE_ERROR);
	    getContratOut.setMessage("KO");
	    EaiLog.info("Une erreur inconnue est survenue : {} " , e.getMessage(), e);
	}

	return getContratOut;
    }



    @Override
    public GetContratOut getContratGestion(GetContratIn getContratIn) {
	GetContratOut getContratOut = new GetContratOut();
	String responseBase64 = null;
	try {

	    String url = new StringBuilder(urlApi).append("gestion/contratToSign").toString();
	    EaiLog.info("url appel gestion/contratToSign: {} " , url);

	    HttpHeaders headers = new HttpHeaders();
	    headers.set(ACCEPT, ALL);
	    headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
	    headers.set("Authorization", getContratIn.getToken());
	    headers.set(Constants.CANAL_HEADER, Constants.CANAL);
	    EaiLog.info("--------**---Authorization_---*---------{} " , getContratIn.getToken());
	    HttpEntity<GetContartRequest> requestEntity = new HttpEntity<>(headers);
	    EaiLog.info("---**--request_Entity--**---{} " , requestEntity.getHeaders());

	    ResponseEntity<byte[]> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity, byte[].class);

	    if (response.getStatusCode().is2xxSuccessful()) {
		EaiLog.info("Response OK with status: {} " , response.getStatusCode());
		byte[] responseBytes = response.getBody();
		if (responseBytes != null) {
		    responseBase64 = Base64.getEncoder().encodeToString(responseBytes);
		    getContratOut.setBase64(responseBase64);
		    getContratOut.setCode(Constants.CODE_SUCCESS);
		    getContratOut.setMessage("OK");
		    EaiLog.info("**********base64*********** : {} " , responseBase64);
		} else {
		    getContratOut.setCode(Constants.CODE_ERROR);
		    getContratOut.setMessage(Constants.TECHNICAL_ERROR);
		    EaiLog.info("Empty response or damaged file");
		}
	    } else {
		getContratOut.setCode(Constants.CODE_ERROR);
		getContratOut.setMessage(Constants.TECHNICAL_ERROR);
		EaiLog.info("Error calling API - BES --{}"  , response.getStatusCode());
	    }

	    EaiLog.info("-----------Fin service contratToSign------------");

	} catch (HttpClientErrorException | HttpServerErrorException e) {
	    getContratOut.setCode(Constants.CODE_ERROR);
	    getContratOut.setMessage("KO");
	    EaiLog.info("Erreur ==== HTTP : {} " , e.getStatusCode() + " - {} " , e.getMessage());
	} catch (Exception e) {
	    getContratOut.setCode(Constants.CODE_ERROR);
	    getContratOut.setMessage("KO");
	    EaiLog.info("Une erreur inconnue _ est survenue : {} =====>" , e.getMessage(), e);
	}

	return getContratOut;
    }





    @Override
    public ValidateOtpSignContratOut validateOtpSigneContrat(ValidateOtpSigneContratIn validateOtpSigneContratIn) {
	ValidateOtpSignContratOut validateOtpSignContratOut = new ValidateOtpSignContratOut();

	try {
	    ValidateOtpSignContratRequest validateOtpSignContratRequest = new ValidateOtpSignContratRequest();
	    EaiLog.info("validateOtpSignContratRequest======>",validateOtpSignContratRequest);
	    validateOtpSignContratRequest.setOtp(validateOtpSigneContratIn.getOtp());
	    validateOtpSignContratRequest.setDeviceId(validateOtpSigneContratIn.getDeviceId());
	    validateOtpSignContratRequest.setOtpID(validateOtpSigneContratIn.getOtpID());
	    validateOtpSignContratRequest.setUuid(validateOtpSigneContratIn.getUuid());

	    String url = new StringBuilder(urlApi).append("prospect/validateOtpContrat").toString();
	    EaiLog.info("url appel prospect/validateOtpContrat: {} " , url);

	    HttpHeaders headers = new HttpHeaders();
	    headers.set(ACCEPT, ALL);
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.set(HttpHeaders.AUTHORIZATION, validateOtpSigneContratIn.getToken());
	    headers.set(Constants.CANAL_HEADER, Constants.CANAL);
	    ObjectMapper objectMapper = new ObjectMapper();

	    String jsonRequest = objectMapper.writeValueAsString(validateOtpSignContratRequest);

	    HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, headers);
	    EaiLog.info("-------*----_Authorization_----*--------{} " , validateOtpSigneContratIn.getToken());
	    EaiLog.info("-----request__Entity_*-----{} " , requestEntity.getHeaders());
	    ResponseEntity<ValidateOtpSignContratResponse> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
		    ValidateOtpSignContratResponse.class);
	    ValidateOtpSignContratResponse responseDTO=response.getBody();
	    EaiLog.info("returned response : {} ",response);
	    
	    if(responseDTO != null && "SUCCESS_CODE".equals(responseDTO.getCode())) {
		validateOtpSignContratOut.setCode(Constants.CODE_SUCCESS);
		validateOtpSignContratOut.setMessage("OK");
	    } else {
		validateOtpSignContratOut.setCode(Constants.CODE_ERROR);
		validateOtpSignContratOut.setMessage(responseDTO != null ? responseDTO.getCode(): Constants.RESPONSE_EMPTY);
		EaiLog.info("Error calling API BES ===>{}"  , response.getStatusCode());
	    }

	    EaiLog.info("-----------Fin service validateOtpContrat------------");

	} catch (HttpClientErrorException | HttpServerErrorException e) {
	    validateOtpSignContratOut.setCode(Constants.CODE_ERROR);
	    validateOtpSignContratOut.setMessage("KO");
	    EaiLog.info("Erreur HTTP :== {} " , e.getStatusCode() + " - ==>{} " , e.getMessage());
	} catch (Exception e) {
	    validateOtpSignContratOut.setCode(Constants.CODE_ERROR);
	    validateOtpSignContratOut.setMessage("KO");
	    EaiLog.info("Une erreur inconnue est survenue ==>: {} " , e.getMessage(), e);
	}

	return validateOtpSignContratOut;
    }

}
