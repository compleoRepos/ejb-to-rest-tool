package service;

import ma.eai.boa.xbanking.dto.ThirdStep.ThirdStepResponse;
import ma.eai.boa.xbanking.dto.createaccountphonenumber.PhoneNumberResponse;
import ma.eai.boa.xbanking.dto.firstStep.FistStepResponse;
import ma.eai.boa.xbanking.dto.steps.GetStepResponse;
import ma.eai.boa.xbanking.dto.tauxchange.TauxChangeResponse;
import ma.eai.boa.xbanking.entities.DataProspect;
import ma.eai.boa.xbanking.entities.User;
import ma.eai.boa.xbanking.repository.DataProspect.DataProspectRepository;
import ma.eai.boa.xbanking.repository.UserRepository;
import ma.eai.boa.xbanking.service.steper.SteperImpl;
import ma.eai.boa.xbanking.util.JwtUtil;
import ma.eai.boa.xbanking.vo.FirstStep.FirstStepIn;
import ma.eai.boa.xbanking.vo.FirstStep.FirstStepOut;
import ma.eai.boa.xbanking.vo.Retour;
import ma.eai.boa.xbanking.vo.Step.StepIn;
import ma.eai.boa.xbanking.vo.Step.StepOut;
import ma.eai.boa.xbanking.vo.TauxChange.TauxChangeIn;
import ma.eai.boa.xbanking.vo.TauxChange.TauxChangeOut;
import ma.eai.boa.xbanking.vo.ThirdStep.ThirdStepIn;
import ma.eai.boa.xbanking.vo.ThirdStep.ThirdStepOut;
import ma.eai.boa.xbanking.util.Constants;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.util.Date;
import java.util.Map;
import java.util.Optional;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class SteperServiceTest {

    @Mock
    private RestTemplate restTemplate;

	@Mock
	private UserRepository userRepository;

	@Mock
	private DataProspectRepository dataProspectRepository;

	@Mock
	private JwtUtil jwtUtil;

    @InjectMocks
    private SteperImpl steper;

    private FirstStepIn firstStepIn;
    private ThirdStepIn thirdStepIn;
    private StepIn stepIn;

    @Before
    public void setUp() {
	MockitoAnnotations.initMocks(this);
	steper.urlApi = "http://example.com/";
	firstStepIn = new FirstStepIn();
	firstStepIn.setToken("sample-token");
	firstStepIn.setBirthCity("Casablanca");
	firstStepIn.setNationality("Moroccan");
	firstStepIn.setAddress("123, rue de l'exemple");
	firstStepIn.setBirthCountry("Morocco");
	firstStepIn.setCivilite("Mr");
	firstStepIn.setClientBOA("clientBOA123");
	firstStepIn.setZipCode("20000");
	firstStepIn.setFirstname("John");
	firstStepIn.setLastname("Doe");
	firstStepIn.setCity("Casablanca");
	firstStepIn.setDatedenaissance(new Date());


	thirdStepIn = new ThirdStepIn();
	thirdStepIn.setToken("sample-token");
	thirdStepIn.setAmountofincome(5000.0);
	thirdStepIn.setSourceoffunds("Salary");
	thirdStepIn.setTransfertMotif("Payment for services");
	thirdStepIn.setPeriodicity("Monthly");
	thirdStepIn.setFrequency("Once");
	thirdStepIn.setIncomeBracket("Medium");
	thirdStepIn.setNationalIdentifier("123456789");
	thirdStepIn.setPoliticallyexposed(false);
	thirdStepIn.setProfession("Engineer");
	thirdStepIn.setActivityArea("Technology");
	thirdStepIn.setTransfervolume(1000.0);
	thirdStepIn.setLuiMemePPE(false);
	thirdStepIn.setFunctionPPE("None");
	thirdStepIn.setFullNamePPE("N/A");
	thirdStepIn.setRelationshipPPE("N/A");

	stepIn = new StepIn();
	stepIn.setToken("valide_token");
    }

    @Test
    public void testValideFirstStep_Success() throws Exception {
	FistStepResponse fistStepResponse = new FistStepResponse();
	fistStepResponse.setCode("SUCCESS_CODE");
	fistStepResponse.setMessage("");
	User user = new User();
	user.setUuid("123456");
	user.setEmail("test@test.com");
	ResponseEntity<FistStepResponse> mockResponseEntity =
		new ResponseEntity<>(fistStepResponse, HttpStatus.OK);

	when(jwtUtil.getUsernameFromToken(any())).thenReturn("test@test.com");
	when(userRepository.findByEmail(any())).thenReturn(user);

	when(restTemplate.exchange(
		eq("http://example.com/prospect/validatFirstForm"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(FistStepResponse.class)
	)).thenReturn(mockResponseEntity);
	FirstStepOut result = steper.valideFirstStep(firstStepIn);

	assertEquals(Constants.CODE_SUCCESS, result.getCode());
	assertEquals("OK", result.getMessage());
    }

    @Test
    public void validateFirstStepFailure() {

	FistStepResponse fistStepResponse = new FistStepResponse();
	fistStepResponse.setCode("ERROR_CODE");
	fistStepResponse.setMessage("Erreur API");
	User user = new User();
	user.setUuid("123456");
	user.setEmail("test@test.com");
	ResponseEntity<FistStepResponse> mockResponseEntity =
		new ResponseEntity<>(fistStepResponse, HttpStatus.OK);
	when(jwtUtil.getUsernameFromToken(any())).thenReturn("test@test.com");
	when(userRepository.findByEmail(any())).thenReturn(user);
	when(restTemplate.exchange(
		eq("http://example.com/prospect/validatFirstForm"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(FistStepResponse.class)
	)).thenReturn(mockResponseEntity);

	FirstStepOut result = steper.valideFirstStep(firstStepIn);


	Assert.assertEquals(Constants.CODE_ERROR, result.getCode());
	assertTrue(result.getMessage().contains("ERROR_CODE"));
    }

    @Test
    public void testValideFirstStep_Exception() throws Exception {

	when(restTemplate.exchange(
		eq("http://example.com/prospect/validatFirstForm"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(Retour.class)
	)).thenThrow(new RuntimeException("Service indisponible"));


	FirstStepOut result = steper.valideFirstStep(firstStepIn);


	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertTrue(result.getMessage().contains("TECHNICAL ERROR"));
    }

    @Test
    public void testGetStep_Success() throws Exception {
	GetStepResponse mockResponse = new GetStepResponse();
	mockResponse.setCode("SUCCESS_CODE");
	mockResponse.setMessage("");
	User user = new User();
	user.setUuid("123456");
	user.setEmail("test@test.com");
	ResponseEntity<GetStepResponse> responseEntity = ResponseEntity.ok(mockResponse);
	when(jwtUtil.getUsernameFromToken(any())).thenReturn("test@test.com");
	when(userRepository.findByEmail(any())).thenReturn(user);
	when(restTemplate.exchange(
		eq("http://example.com/prospect/getStep"),
		eq(HttpMethod.GET),
		any(HttpEntity.class),
		eq(GetStepResponse.class)
	)).thenReturn(responseEntity);

	StepOut result = steper.getStep(stepIn);

	assertEquals(Constants.CODE_SUCCESS, result.getCode());
	assertEquals("OK", result.getMessage());
    }

    @Test
    public void testGetStep_ApiError() throws Exception {

	GetStepResponse mockResponse = new GetStepResponse();
	mockResponse.setCode("ERROR_CODE");
	mockResponse.setMessage("Erreur lors de l'appel API");

	User user = new User();
	user.setUuid("123456");
	user.setEmail("test@test.com");
	ResponseEntity<GetStepResponse> responseEntity = new ResponseEntity<>(mockResponse, HttpStatus.BAD_REQUEST);

	when(jwtUtil.getUsernameFromToken(any())).thenReturn("test@test.com");
	when(userRepository.findByEmail(any())).thenReturn(user);
	when(restTemplate.exchange(
		eq("http://example.com/prospect/getStep"),
		eq(HttpMethod.GET),
		any(HttpEntity.class),
		eq(GetStepResponse.class)
	)).thenReturn(responseEntity);


	StepOut result = steper.getStep(stepIn);


	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertTrue(result.getMessage().contains("ERROR_CODE"));
    }

    @Test
    public void testGetStep_Exception() throws Exception {

	when(restTemplate.exchange(
		eq("http://example.com/prospect/getStep"),
		eq(HttpMethod.GET),
		any(HttpEntity.class),
		eq(GetStepResponse.class)
	)).thenThrow(new RuntimeException("Service indisponible"));



	StepOut result = steper.getStep(stepIn);



	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertTrue(result.getMessage().contains("ERR_TECHNICAL"));
    }

    @Test
    public void testValideThirdStep_Success() throws Exception {

	ThirdStepResponse mockResponse = new ThirdStepResponse();
	mockResponse.setCode("SUCCESS_CODE");
	mockResponse.setMessage("");
	Optional<DataProspect> dataProspect = Optional.of(new DataProspect());
	dataProspect.get().setUuid("th67h");
		User user = new User();
		user.setUuid("123456");
		user.setEmail("test@test.com");

	ResponseEntity<ThirdStepResponse> responseEntity = ResponseEntity.ok(mockResponse);

	when(jwtUtil.getUsernameFromToken(any())).thenReturn("test@test.com");
	when(userRepository.findByEmail(any())).thenReturn(user);
	when(dataProspectRepository.findById(any())).thenReturn(dataProspect);

	when(restTemplate.exchange(
		eq("http://example.com/prospect/validatThirdForm"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(ThirdStepResponse.class)
	)).thenReturn(responseEntity);


	ThirdStepOut result = steper.valideThirdStep(thirdStepIn);


	assertEquals(Constants.CODE_SUCCESS, result.getCode());
	assertEquals("OK", result.getMessage());
    }

    @Test
    public void testValideThirdStep_ApiError() throws Exception {
	ThirdStepResponse mockResponse = new ThirdStepResponse();
	mockResponse.setCode("ERROR_CODE");
	mockResponse.setMessage("Erreur lors de l'appel API");

	ResponseEntity<ThirdStepResponse> responseEntity = new ResponseEntity<>(mockResponse, HttpStatus.OK);

	when(jwtUtil.getUsernameFromToken(any())).thenReturn("test@test.com");

	when(restTemplate.exchange(
		eq("http://example.com/prospect/validatThirdForm"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(ThirdStepResponse.class)
	)).thenReturn(responseEntity);

	ThirdStepOut result = steper.valideThirdStep(thirdStepIn);

	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertTrue(result.getMessage().contains("ERROR_CODE"));
    }

    @Test
    public void testValideThirdStep_Exception() throws Exception {

	when(jwtUtil.getUsernameFromToken(any())).thenReturn("test@test.com");
	when(restTemplate.exchange(
		eq("http://example.com/prospect/validatThirdForm"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(Retour.class)
	)).thenThrow(new RuntimeException("Service indisponible"));

	ThirdStepOut result = steper.valideThirdStep(thirdStepIn);

	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertTrue(result.getMessage().contains("ERR_TECHNICAL"));
    }


}
