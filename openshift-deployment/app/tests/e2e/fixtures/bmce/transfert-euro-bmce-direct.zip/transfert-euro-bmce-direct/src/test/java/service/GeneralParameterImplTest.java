package service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import ma.eai.boa.xbanking.entities.ActivityArea;
import ma.eai.boa.xbanking.entities.Country;
import ma.eai.boa.xbanking.entities.GeneralParameters;
import ma.eai.boa.xbanking.entities.Parameters;
import ma.eai.boa.xbanking.repository.GeneralParametersRepository;
import ma.eai.boa.xbanking.service.parameters.GeneralParameterImpl;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.util.ParamType;
import ma.eai.boa.xbanking.vo.PersonalInformation.PersonalInfoIn;
import ma.eai.boa.xbanking.vo.PersonalInformation.PersonalInfoOut;
import org.jdom2.output.LineSeparator;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class GeneralParameterImplTest {
    @InjectMocks
    GeneralParameterImpl generalParameter;
    @Mock
    RestTemplate restTemplate;
    @Spy
    ObjectMapper objectMapper;

    @Mock
    GeneralParametersRepository generalParametersRepository;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        generalParameter.urlApi = "http://example.com/";
        objectMapper = new ObjectMapper();
    }

    @Test
    public void generalParamsSuccess() throws JsonProcessingException {
        PersonalInfoIn personalInfoIn = new PersonalInfoIn();
        personalInfoIn.setCtrBad("test");

        Parameters mockParameters = new Parameters();
        List<Country> listcountry=new ArrayList<>();
        Country country=new Country();
        country.setIndicatif("49");
        listcountry.add(country);
        mockParameters.setCountries(listcountry);
        String jsonResponse = "{\"activityAreas\":[{\"uuid\":\"ACT001\",\"label\":\"Finance\"}]}";
        Parameters parameters = new Parameters();
        ActivityArea activityArea = new ActivityArea();
        activityArea.setUuid("ACT001");
        activityArea.setLabel("Finance");
        parameters.setActivityAreas(Arrays.asList(activityArea));

        GeneralParameters generalParameters = new GeneralParameters();
        generalParameters.setLabelEn("Finance EN");

        String expectedUrl = "http://example.com/parameters/general";

        // Setup mocks -
        when(restTemplate.getForObject(anyString(), eq(String.class)))
                .thenReturn(jsonResponse);


        PersonalInfoOut personalInfoOut = generalParameter.fetchGeneralParameters(personalInfoIn);

        Assert.assertEquals(Constants.CODE_SUCCESS,personalInfoOut.getCode());

    }
}