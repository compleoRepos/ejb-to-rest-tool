package ma.eai.boa.xbanking.vo.transfert;

import ma.eai.boa.xbanking.vo.Retour;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "TransfertOut")
public class TransfertOut extends Retour {

    private String uuid;
    private String urlWebVue;

    private String bid;

    public String getUrlWebVue() {
	return urlWebVue;
    }

    public void setUrlWebVue(String urlWebVue) {
	this.urlWebVue = urlWebVue;
    }

    public String getUuid() {
	return uuid;
    }

    public void setUuid(String uuid) {
	this.uuid = uuid;
    }

    public String getBid() {
        return bid;
    }

    public void setBid(String bid) {
        this.bid = bid;
    }
}
