package ma.eai.boa.xbanking.dto.firstStep;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.Date;

public class FirstStepRequest implements Serializable {

    private static final long serialVersionUID = 2756652758050170162L;

    @JsonProperty("civilite")
    private String civilite;

    private String lastname;

    private String firstname;

    @JsonProperty("address")
    private String address;

    @JsonProperty("zipCode")
    private String zipCode;

    @JsonProperty("city")
    private String city;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date datedenaissance;

    @JsonProperty("nationality")
    private String nationality;

    @JsonProperty("birthCountry")
    private String birthCountry;

    private String clientBOA;

    private String birthCity;

    public String getCivilite() {
	return civilite;
    }

    public void setCivilite(String civilite) {
	this.civilite = civilite;
    }

    public String getLastname() {
	return lastname;
    }

    public void setLastname(String lastname) {
	this.lastname = lastname;
    }

    public String getFirstname() {
	return firstname;
    }

    public void setFirstname(String firstname) {
	this.firstname = firstname;
    }

    public String getAddress() {
	return address;
    }

    public void setAddress(String address) {
	this.address = address;
    }

    public String getZipCode() {
	return zipCode;
    }

    public void setZipCode(String zipCode) {
	this.zipCode = zipCode;
    }

    public String getCity() {
	return city;
    }

    public void setCity(String city) {
	this.city = city;
    }

    public Date getDatedenaissance() {
	return datedenaissance;
    }

    public void setDatedenaissance(Date datedenaissance) {
	this.datedenaissance = datedenaissance;
    }

    public String getNationality() {
	return nationality;
    }

    public void setNationality(String nationality) {
	this.nationality = nationality;
    }

    public String getBirthCountry() {
	return birthCountry;
    }

    public void setBirthCountry(String birthCountry) {
	this.birthCountry = birthCountry;
    }

    public String getClientBOA() {
	return clientBOA;
    }

    public void setClientBOA(String clientBOA) {
	this.clientBOA = clientBOA;
    }

    public String getBirthCity() {
	return birthCity;
    }

    public void setBirthCity(String birthCity) {
	this.birthCity = birthCity;
    }

    @Override
    public String toString() {
	return "FirstStepRequest{" + "civilite='" + civilite + '\'' + ", lastname='" + lastname + '\'' + ", firstname='"
		+ firstname + '\'' + ", address='" + address + '\'' + ", zipCode='" + zipCode + '\'' + ", city='" + city
		+ '\'' + ", datedenaissance=" + datedenaissance + ", nationality='" + nationality + '\''
		+ ", birthCountry='" + birthCountry + '\'' + ", clientBOA='" + clientBOA + '\'' + ", birthCity='"
		+ birthCity + '\'' + '}';
    }
}
