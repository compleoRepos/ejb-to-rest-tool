package ma.eai.boa.xbanking.vo.FirstStep;


import java.io.Serializable;

import java.util.Date;

public class FirstStepIn implements Serializable {

    private static final long serialVersionUID = 2756652758050170162L;

    private String civilite;

    private String lastname;

    private String firstname;

    private String address;

    private String zipCode;

    private String city;

    private Date datedenaissance;

    private String nationality;

    private String birthCountry;

    private String clientBOA;

    private String birthCity;


    private String token;

    public String getCivilite() {
        return civilite;
    }

    public void setCivilite(String civilite) {
        this.civilite = civilite;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Date getDatedenaissance() {
        return datedenaissance;
    }

    public void setDatedenaissance(Date datedenaissance) {
        this.datedenaissance = datedenaissance;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getBirthCountry() {
        return birthCountry;
    }

    public void setBirthCountry(String birthCountry) {
        this.birthCountry = birthCountry;
    }

    public String getClientBOA() {
        return clientBOA;
    }

    public void setClientBOA(String clientBOA) {
        this.clientBOA = clientBOA;
    }

    public String getBirthCity() {
        return birthCity;
    }

    public void setBirthCity(String birthCity) {
        this.birthCity = birthCity;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public String toString() {
        return "FirstStepIn{" + "civilite='" + civilite + '\'' + ", lastname='" + lastname + '\'' + ", firstname='"
                + firstname + '\'' + ", address='" + address + '\'' + ", zipCode='" + zipCode + '\'' + ", city='" + city
                + '\'' + ", datedenaissance=" + datedenaissance + ", nationality='" + nationality + '\''
                + ", birthCountry='" + birthCountry + '\'' + ", clientBOA='" + clientBOA + '\'' + ", birthCity='"
                + birthCity + '\'' + ", token='" + token + '\'' + '}';
    }
}
