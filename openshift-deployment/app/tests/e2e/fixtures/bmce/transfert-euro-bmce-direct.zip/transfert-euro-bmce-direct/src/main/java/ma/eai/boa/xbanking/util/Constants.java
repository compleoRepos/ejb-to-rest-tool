package ma.eai.boa.xbanking.util;


public class Constants {
    public static final String CODE_SUCCESS="000";
    public static final String CODE_ERROR="111";
    public static final String PASS_VALUE="Azerty@123";
    public static final String ERROR_API_BES = "ERROR API BES";
    public static final String RESPONSE_EMPTY = "RESPONSE_EMPTY";
    public static final String ERROR_CALL_BES = "Error calling BES API : {}";
    public static final String TECHNICAL_ERROR = "ERR_TECHNICAL";
    public static final Integer BLOCKED_TIME_MINUTES=60;
    public static final String CANAL = "BMCE_CLIENT";
    public static final String CANAL_HEADER="CANAL";

}
