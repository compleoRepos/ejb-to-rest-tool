package service;

import ma.eai.boa.xbanking.dto.validateOtp.ValidateOtpResponse;
import ma.eai.boa.xbanking.entities.User;
import ma.eai.boa.xbanking.repository.UserRepository;
import ma.eai.boa.xbanking.service.authentification.AuthentificationImpl;
import ma.eai.boa.xbanking.service.validationOtp.ValidationOtpImpl;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.vo.validationOtp.ValidationOtpIn;
import ma.eai.boa.xbanking.vo.validationOtp.ValidationOtpOut;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.Optional;

import static org.mockito.Mockito.*;


public class ValidationOtpTest {
    @InjectMocks
    ValidationOtpImpl validationOtpImpl;
    @Mock
    private RestTemplate restTemplate;

    @Mock
    private UserRepository userRepository;

    @Mock
    private AuthentificationImpl authenticationService;
    @Before
    public void setUp(){
	MockitoAnnotations.initMocks(this);
	validationOtpImpl.urlApi = "http://example.com/";
    }
    @Test
    public void validationOtpSuccess(){
        ValidationOtpIn validationOtpIn = new ValidationOtpIn();
        validationOtpIn.setOtpValue("123456");
        validationOtpIn.setDeviceId("device123");
        validationOtpIn.setOtpId("otp-uuid");
        validationOtpIn.setUuid("user-uuid");

        User user = new User();
        user.setEmail("email");
        user.setUuid("user-uuid");

        // Simulation de la réponse de l'API distante
        ValidateOtpResponse mockResponse = new ValidateOtpResponse();
        mockResponse.setCode("SUCCESS_CODE");

        ResponseEntity<ValidateOtpResponse> responseEntity = new ResponseEntity<>(mockResponse, HttpStatus.OK);

        // Mock de l'appel RestTemplate
        when(restTemplate.exchange(
                eq("http://example.com/prospect/validateOTP"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(ValidateOtpResponse.class)
        )).thenReturn(responseEntity);

        when(authenticationService.generateToken(any())).thenReturn("Ejqljhlskjglg");
        when(authenticationService.sendToken(any())).thenReturn(true);
        when(userRepository.findById(any())).thenReturn(Optional.of(user));

        // Exécution du service
        ValidationOtpOut result = validationOtpImpl.validateOtp(validationOtpIn);
        Assert.assertEquals(Constants.CODE_SUCCESS, result.getCode());
        Assert.assertEquals("OK", result.getMessage());
    }
    @Test
    public void validationOtpFailure() {
        // Préparation des données d'entrée
        ValidationOtpIn validationOtpIn = new ValidationOtpIn();
        validationOtpIn.setOtpValue("000000");
        validationOtpIn.setDeviceId("device123");
        validationOtpIn.setOtpId("otp-uuid");
        validationOtpIn.setUuid("user-uuid");

        // Simulation d'une réponse d'échec
        ValidateOtpResponse mockResponse = new ValidateOtpResponse();
        mockResponse.setCode("ERROR_CODE"); // Code différent de "SUCCESS_CODE"

        ResponseEntity<ValidateOtpResponse> responseEntity = new ResponseEntity<>(mockResponse, HttpStatus.OK);

        // Mock de l'appel RestTemplate
        when(restTemplate.exchange(
                eq("http://example.com/prospect/validateOTP"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(ValidateOtpResponse.class)
        )).thenReturn(responseEntity);

        // Exécution du service
        ValidationOtpOut result = validationOtpImpl.validateOtp(validationOtpIn);

        // Vérifications
        Assert.assertEquals(Constants.CODE_ERROR, result.getCode());
        Assert.assertTrue(result.getMessage().contains("ERROR_CODE"));
    }
    @Test
    public void validationOtpException() {
        // Préparation des données d'entrée
        ValidationOtpIn validationOtpIn = new ValidationOtpIn();
        validationOtpIn.setOtpValue("123456");
        validationOtpIn.setDeviceId("device123");
        validationOtpIn.setOtpId("otp-uuid");
        validationOtpIn.setUuid("user-uuid");

        // Simulation d'une exception lors de l'appel REST
        when(restTemplate.exchange(
                eq("http://example.com/prospect/validateOTP"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(ValidateOtpResponse.class)
        )).thenThrow(new RuntimeException("Service indisponible"));

        // Exécution du service
        ValidationOtpOut result = validationOtpImpl.validateOtp(validationOtpIn);

        // Vérifications
        Assert.assertEquals(Constants.CODE_ERROR, result.getCode());
        Assert.assertTrue(result.getMessage().contains("ERR_TECHNICAL"));
    }

}
