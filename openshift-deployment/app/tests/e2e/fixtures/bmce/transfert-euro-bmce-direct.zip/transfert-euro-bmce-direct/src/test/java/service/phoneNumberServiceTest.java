package service;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import ma.eai.boa.xbanking.dto.createaccountphonenumber.PhoneNumberResponse;
import ma.eai.boa.xbanking.repository.UserRepository;
import ma.eai.boa.xbanking.service.PhoneNumber.PhoneNumberImpl;
import ma.eai.boa.xbanking.service.authentification.AuthentificationImpl;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.vo.PhoneNumber.PhoneNumberIn;
import ma.eai.boa.xbanking.vo.PhoneNumber.PhoneNumberOut;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class phoneNumberServiceTest {

    @Mock
    private RestTemplate restTemplate;

	@Mock
	private UserRepository userRepository;

	@Mock
	private AuthentificationImpl authenticationService;

    @InjectMocks
    private PhoneNumberImpl phoneNumberService;

    private PhoneNumberIn phoneNumberIn;

    @Before
    public void setUp() {
	MockitoAnnotations.initMocks(this);
	phoneNumberService.urlApi = "http://example.com/";
    	phoneNumberIn = new PhoneNumberIn();
	phoneNumberIn.setPhoneNumber("609152686");
	phoneNumberIn.setEmail("testAddress@gmail.com");
	phoneNumberIn.setCallingCode("33");
	phoneNumberIn.setDeviceId("device123");
	phoneNumberIn.setPassword("Azert123");
	phoneNumberIn.setCountryCode("FR");
    }

    @Test
    public void testValidePhoneNumber_Success() {

	PhoneNumberResponse mockResponse = new PhoneNumberResponse();
	mockResponse.setCode("SUCCESS_CODE");
	mockResponse.setMessage("OK");
	mockResponse.setUuid("123L");
	mockResponse.setNexusUuid("456L");

	ResponseEntity<PhoneNumberResponse> responseEntity = ResponseEntity.ok(mockResponse);
	when(restTemplate.exchange(
		eq("http://example.com/prospect/validatPhone"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(PhoneNumberResponse.class)
	)).thenReturn(responseEntity);


	PhoneNumberOut result = phoneNumberService.validePhoneNumber(phoneNumberIn);

	assertEquals("000", result.getCode());
	assertEquals("OK", result.getMessage());
	assertEquals("123L", result.getUuid());
	assertEquals("456L", result.getNexusUuid());
    }

    @Test
    public void testValidePhoneNumber_ApiError() {

	PhoneNumberIn phoneNumberIn = new PhoneNumberIn();
	phoneNumberIn.setPhoneNumber("609152686");
	phoneNumberIn.setEmail("testAddress@gmail.com");
	phoneNumberIn.setCallingCode("33");
	phoneNumberIn.setDeviceId("device123");
	phoneNumberIn.setPassword("Azert123");
	phoneNumberIn.setCountryCode("FR");

	PhoneNumberResponse mockResponse = new PhoneNumberResponse();
	mockResponse.setCode("ERROR_CODE");
	mockResponse.setMessage("ERREUR API BES");

	ResponseEntity<PhoneNumberResponse> responseEntity = new ResponseEntity<>(mockResponse, HttpStatus.OK);

	when(restTemplate.exchange(
		eq("http://example.com/prospect/validatPhone"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(PhoneNumberResponse.class)
	)).thenReturn(responseEntity);
    when(authenticationService.generateToken(any())).thenReturn("Ejqljhlskjglg");
	when(authenticationService.sendToken(any())).thenReturn(true);

	PhoneNumberOut result = phoneNumberService.validePhoneNumber(phoneNumberIn);
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertTrue(result.getMessage().contains("ERROR_CODE"));  // Matches the updated mock response
    }

    @Test
    public void testValidePhoneNumber_Exception() {

	PhoneNumberIn phoneNumberIn = new PhoneNumberIn();
	phoneNumberIn.setPhoneNumber("609152686");
	phoneNumberIn.setEmail("testAddress@gmail.com");
	phoneNumberIn.setCallingCode("33");
	phoneNumberIn.setDeviceId("device123");
	phoneNumberIn.setPassword("Azert123");
	phoneNumberIn.setCountryCode("FR");


	when(restTemplate.exchange(
		eq("http://example.com/prospect/validatPhone"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(PhoneNumberResponse.class)
	)).thenThrow(new RuntimeException("Service indisponible"));

	PhoneNumberOut result = phoneNumberService.validePhoneNumber(phoneNumberIn);

	assertEquals(Constants.CODE_ERROR, result.getCode());
    }
}

