package ma.eai.boa.xbanking.dto.Beneficiaire;

import ma.eai.boa.xbanking.vo.Retour;

public class BeneficiaireResponse extends Retour {
}
