package ma.eai.boa.xbanking.entities;

import javax.persistence.Entity;

@Entity
public class RelationFamiliale extends NamedIdentified {

	private static final long serialVersionUID = 6207497689844269213L;
	

}
