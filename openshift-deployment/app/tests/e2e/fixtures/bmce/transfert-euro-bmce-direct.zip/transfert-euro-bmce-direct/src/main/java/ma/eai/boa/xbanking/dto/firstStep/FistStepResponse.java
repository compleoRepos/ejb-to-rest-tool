package ma.eai.boa.xbanking.dto.firstStep;

import ma.eai.boa.xbanking.vo.Retour;

public class FistStepResponse extends Retour {
}
