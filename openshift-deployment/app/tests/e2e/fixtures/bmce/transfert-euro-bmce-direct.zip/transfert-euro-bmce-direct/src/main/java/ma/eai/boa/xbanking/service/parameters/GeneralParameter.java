package ma.eai.boa.xbanking.service.parameters;

import ma.eai.boa.xbanking.vo.PersonalInformation.PersonalInfoIn;
import ma.eai.boa.xbanking.vo.PersonalInformation.PersonalInfoOut;

public interface GeneralParameter {
    PersonalInfoOut fetchGeneralParameters(PersonalInfoIn personalInfoIn);
}
