package ma.eai.boa.xbanking.dto.steps;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import ma.eai.boa.xbanking.entities.Frequency;
import ma.eai.boa.xbanking.entities.FundsSource;
import ma.eai.boa.xbanking.entities.Periodicity;
import ma.eai.boa.xbanking.entities.TransfertMotif;
import ma.eai.boa.xbanking.entities.RevenuTranche;
import ma.eai.boa.xbanking.entities.Utilisateur;
import ma.eai.boa.xbanking.entities.Profession;
import ma.eai.boa.xbanking.entities.ActivityArea;


import java.io.Serializable;

public class AdditionalDataProspectDTO implements Serializable {

    private static final long serialVersionUID = -6371886305772566433L;

    private String uuid;

    private double amountofincome;


    private FundsSource sourceoffunds;

    private double transfervolume;


    private TransfertMotif transfertMotif;


    private Periodicity periodicity;

    private Frequency frequency;

    private String nationalIdentifier;

    private RevenuTranche revenuTranche;

    @JsonIgnore
    private Utilisateur user;

    private Profession profession;

    private boolean politicallyexposed;

    @JsonProperty("luiMemePPE")
    private boolean luiMemePPE;

    @JsonProperty("functionPPE")
    private String fonctionPPE;

    @JsonProperty("fullNamePPE")
    private String fullNamePPE;

    @JsonProperty("relationshipPPE")
    private String lienPPE;

    @JsonProperty("activityArea")
    private ActivityArea activityArea;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public FundsSource getSourceoffunds() {
        return sourceoffunds;
    }

    public void setSourceoffunds(FundsSource sourceoffunds) {
        this.sourceoffunds = sourceoffunds;
    }

    public TransfertMotif getTransfertMotif() {
        return transfertMotif;
    }

    public void setTransfertMotif(TransfertMotif transfertMotif) {
        this.transfertMotif = transfertMotif;
    }

    public Periodicity getPeriodicity() {
        return periodicity;
    }

    public void setPeriodicity(Periodicity periodicity) {
        this.periodicity = periodicity;
    }


    public Utilisateur getUser() {
        return user;
    }

    public void setUser(Utilisateur user) {
        this.user = user;
    }

    public Frequency getFrequency() {
        return frequency;
    }

    public void setFrequency(Frequency frequency) {
        this.frequency = frequency;
    }

    public RevenuTranche getRevenuTranche() {
        return revenuTranche;
    }

    public void setRevenuTranche(RevenuTranche revenuTranche) {
        this.revenuTranche = revenuTranche;
    }

//	public String getIbanClient() {
//		return ibanClient;
//	}
//
//	public void setIbanClient(String ibanClient) {
//		this.ibanClient = ibanClient;
//	}

    public String getNationalIdentifier() {
        return nationalIdentifier;
    }

    public void setNationalIdentifier(String nationalIdentifier) {
        this.nationalIdentifier = nationalIdentifier;
    }

    public double getAmountofincome() {
        return amountofincome;
    }

    public void setAmountofincome(double amountofincome) {
        this.amountofincome = amountofincome;
    }

    public double getTransfervolume() {
        return transfervolume;
    }

    public void setTransfervolume(double transfervolume) {
        this.transfervolume = transfervolume;
    }

    public Profession getProfession() {
        return profession;
    }

    public void setProfession(Profession profession) {
        this.profession = profession;
    }

    public boolean isPoliticallyexposed() {
        return politicallyexposed;
    }

    public void setPoliticallyexposed(boolean politicallyexposed) {
        this.politicallyexposed = politicallyexposed;
    }

    public ActivityArea getActivityArea() {
        return activityArea;
    }

    public void setActivityArea(ActivityArea activityArea) {
        this.activityArea = activityArea;
    }

    public boolean isLuiMemePPE() {
        return luiMemePPE;
    }

    public void setLuiMemePPE(boolean luiMemePPE) {
        this.luiMemePPE = luiMemePPE;
    }

    public String getFonctionPPE() {
        return fonctionPPE;
    }

    public void setFonctionPPE(String fonctionPPE) {
        this.fonctionPPE = fonctionPPE;
    }

    public String getLienPPE() {
        return lienPPE;
    }

    public void setLienPPE(String lienPPE) {
        this.lienPPE = lienPPE;
    }

    public String getFullNamePPE() {
        return fullNamePPE;
    }

    public void setFullNamePPE(String fullNamePPE) {
        this.fullNamePPE = fullNamePPE;
    }

    @Override
    public String toString() {
        return "AdditionalDataProspect{" +
                "uuid='" + uuid + '\'' +
                ", amountofincome=" + amountofincome +
                ", sourceoffunds=" + sourceoffunds +
                ", transfervolume=" + transfervolume +
                ", transfertMotif=" + transfertMotif +
                ", periodicity=" + periodicity +
                ", frequency=" + frequency +
                ", nationalIdentifier='" + nationalIdentifier + '\'' +
                ", revenuTranche=" + revenuTranche +
                ", user=" + user +
                ", profession=" + profession +
                ", politicallyexposed=" + politicallyexposed +
                ", luiMemePPE=" + luiMemePPE +
                ", fonctionPPE='" + fonctionPPE + '\'' +
                ", fullNamePPE='" + fullNamePPE + '\'' +
                ", lienPPE='" + lienPPE + '\'' +
                ", activityArea=" + activityArea +
                '}';
    }
}
