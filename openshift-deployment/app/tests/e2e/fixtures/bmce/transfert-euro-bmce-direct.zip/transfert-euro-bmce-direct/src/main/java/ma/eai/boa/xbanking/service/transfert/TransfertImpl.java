package ma.eai.boa.xbanking.service.transfert;

import com.fasterxml.jackson.databind.ObjectMapper;
import ma.eai.boa.xbanking.dto.transfert.DetailTransfer;
import ma.eai.boa.xbanking.dto.transfert.HistoriqueResponse;
import ma.eai.boa.xbanking.dto.transfert.TransfertRequest;
import ma.eai.boa.xbanking.dto.transfert.TransfertResponse;
import ma.eai.boa.xbanking.entities.History;
import ma.eai.boa.xbanking.entities.TransfertBES;
import ma.eai.boa.xbanking.entities.User;
import ma.eai.boa.xbanking.repository.UserRepository;
import ma.eai.boa.xbanking.repository.transfert.TransfertRepository;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.util.Helpers;
import ma.eai.boa.xbanking.util.JwtUtil;
import ma.eai.boa.xbanking.vo.transfert.DetailTransferOut;
import ma.eai.boa.xbanking.vo.historiqueTransfert.HistoriqueOut;
import ma.eai.boa.xbanking.vo.historiqueTransfert.Transferts;
import ma.eai.boa.xbanking.vo.transfert.TransfertIn;
import ma.eai.boa.xbanking.vo.transfert.TransfertOut;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.security.SignatureException;
import java.util.List;
import java.util.Objects;
import java.util.ArrayList;


@Service
public class TransfertImpl implements Transfert {

    private static final String VALIDATE_ENDPOINT = "transfert/validat";
    private static final String RESPONSE_EMPTY = "RESPONSE_EMPTY";
    private static final String DETAIL_TRANSFER_ENDPOINT = "transfert/detail/";
    private static final String SUCCESS_CODE = "SUCCESS_CODE";
    private static final String ERR_TECHNICAL = "ERR_TECHNICAL";
    private final TransfertRepository transfertRepository;
    @Value("${api.url}")
    public String urlApi;

    @Value("${data.encrypt.mac.key}")
    public String keyData;

	@Value("${data.hash.key}")
	public String bidKey;

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;
    private final JwtUtil jwtTokenUtil;
    private final UserRepository userRepository;

	private final Helpers helpers;

    @Autowired
    public TransfertImpl(TransfertRepository transfertRepository, RestTemplate restTemplate, ObjectMapper objectMapper,
						 JwtUtil jwtTokenUtil, UserRepository userRepository, Helpers helpers) {
	this.transfertRepository = transfertRepository;
	this.restTemplate = restTemplate;
	this.objectMapper = objectMapper;
	this.jwtTokenUtil = jwtTokenUtil;
	this.userRepository = userRepository;
	this.helpers = helpers;
	}

    @Override
    public TransfertOut validatTransfert(TransfertIn transfertIn) {
	EaiLog.info("Starting transfer validation process for transfertIn: {}", transfertIn);
	validateInput(transfertIn);
	TransfertOut transfertOut = new TransfertOut();
	try {
	    EaiLog.info("Mapping TransfertIn to TransfertRequest");
	    TransfertRequest transfertRequest = mapToTransfertRequest(transfertIn);
	    EaiLog.info("Mapped TransfertRequest: {}", transfertRequest);

	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.set(HttpHeaders.AUTHORIZATION, transfertIn.getToken());
	    headers.set(Constants.CANAL_HEADER, Constants.CANAL);
	    EaiLog.info("Request headers prepared");

	    ObjectMapper objectMapper = new ObjectMapper();
	    String jsonRequest = objectMapper.writeValueAsString(transfertRequest);
	    EaiLog.info("JSON request payload: {}", jsonRequest);

	    EaiLog.info("Calculating MAC for request");
	    String mac = helpers.hashMac(jsonRequest, keyData);
	    headers.set("mac_data", mac);
	    EaiLog.info("MAC calculated and added to headers : {}",mac);

	    HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, headers);
	    String url = buildUrl(VALIDATE_ENDPOINT);
	    EaiLog.info("Prepared request entity for URL: {}", url);
	    EaiLog.info("Full request details - URL: {}, Headers: {}, Body: {}", url, headers, jsonRequest);

	    EaiLog.info("Initiating transfer validation request to: {}", url);
	    long startTime = System.currentTimeMillis();

	    ResponseEntity<TransfertResponse> response = restTemplate.exchange(
		    url,
		    HttpMethod.POST,
		    requestEntity,
		    TransfertResponse.class
	    );

	    long duration = System.currentTimeMillis() - startTime;
	    EaiLog.info("Received response from API in {} ms. Status code: {}", duration, response.getStatusCode());
	    EaiLog.info("API response body: {}", response.getBody());

	    processResponse(response, transfertOut,transfertIn);
	    EaiLog.info("Transfer validation processed successfully. TransfertOut: {}", transfertOut);

	} catch (RestClientException e) {
	    EaiLog.error("API communication error during transfer validation: {}", e);
	    handleApiError(transfertOut, "API communication error:" + e.getMessage());
	} catch (SignatureException e) {
	    EaiLog.error("MAC calculation error during transfer validation: {}", e);
	    handleApiError(transfertOut, "Error calculating MAC: " + e.getMessage());
	} catch (Exception e) {
	    EaiLog.error("Unexpected error during transfer validation : {}", e);
	    handleUnexpectedError(transfertOut, e);
	}

	EaiLog.info("Completed transfer validation process. Result: {}", transfertOut);
	return transfertOut;
    }

	@Override
	public DetailTransferOut getTransferDetail(String uuid, String token) {
		EaiLog.info("Start service get transfer detail by uuid : {}",uuid);

		DetailTransferOut detailTransferOut = new DetailTransferOut();
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(HttpHeaders.AUTHORIZATION,token);
		   	headers.set(Constants.CANAL_HEADER, Constants.CANAL);
			HttpEntity<String> requestEntity = new HttpEntity<>(headers);

			String url = buildUrl(DETAIL_TRANSFER_ENDPOINT) + uuid;
			EaiLog.info("Calling url to get transfer detail: {}", url);
			ResponseEntity<DetailTransfer> response = restTemplate.exchange(
					url,
					HttpMethod.GET,
					requestEntity,
					DetailTransfer.class
			);
			EaiLog.info("Detail transfer response : {}", response);
			if(response.getBody() != null && response.getStatusCode().is2xxSuccessful() &&
				SUCCESS_CODE.equals(response.getBody().getCode())) {
				EaiLog.info("detail transfer body : {}", response.getBody());
				detailTransferOut.setDetailTransfer(response.getBody());
				detailTransferOut.setCode(Constants.CODE_SUCCESS);
				detailTransferOut.setMessage("OK");
			} else {
				EaiLog.info("call detail transfer KO ");
				detailTransferOut.setCode(Constants.CODE_ERROR);
				detailTransferOut.setMessage(response.getBody() != null ? response.getBody().getCode() : RESPONSE_EMPTY);
			}
		} catch(Exception e) {
           EaiLog.info("Error in calling Detail transfer WS : {}",e);
		   detailTransferOut.setCode(Constants.CODE_ERROR);
		   detailTransferOut.setMessage(ERR_TECHNICAL);
		}
		return detailTransferOut;
	}

	private void validateInput(TransfertIn transfertIn) {
	Objects.requireNonNull(transfertIn, "TransfertIn cannot be null");
	if (!StringUtils.hasText(transfertIn.getToken())) {
	    throw new IllegalArgumentException("Token is required");
	}
	if (!StringUtils.hasText(transfertIn.getTransferMode())) {
	    throw new IllegalArgumentException("Transfer mode is required");
	}
	Double amountToSend = transfertIn.getAmountToSend();
	if (amountToSend == null || amountToSend <= 0) {
	    throw new IllegalArgumentException("Amount to send must be positive");
	}
    }

    private String buildUrl(String endpoint) {
	if (!StringUtils.hasText(urlApi)) {
	    throw new IllegalStateException("API URL is not configured");
	}
	return urlApi + endpoint;
    }

    private HttpEntity<String> buildRequestEntity(TransfertRequest request, TransfertIn transfertIn)
	    throws Exception {
	HttpHeaders headers = new HttpHeaders();
	headers.setContentType(MediaType.APPLICATION_JSON);
	headers.set(HttpHeaders.AUTHORIZATION, transfertIn.getToken());

	String jsonRequest = objectMapper.writeValueAsString(request);
	EaiLog.info("Request JSON: {}", jsonRequest);
	EaiLog.info("Request headers: {}", headers);

	return new HttpEntity<>(jsonRequest, headers);
    }

    private void processResponse(ResponseEntity<TransfertResponse> response, TransfertOut transfertOut,TransfertIn transfertIn) throws SignatureException {
	TransfertResponse responseDTO = response.getBody();
	if (responseDTO == null || responseDTO.getCode() == null) {
	    transfertOut.setCode(Constants.CODE_ERROR);
	    transfertOut.setMessage(ERR_TECHNICAL);
	    EaiLog.warn("Réponse API invalide ou manquante");
	    return;
	}
	EaiLog.info("Response received: {}", responseDTO);

	if (SUCCESS_CODE.equals(responseDTO.getCode())) {
	    //tracabilité
	    TransfertBES transfertBES = new TransfertBES();
	    String name= jwtTokenUtil.getUsernameFromToken(transfertIn.getToken());
	    EaiLog.info("name from token: {}",name);
	    User user = userRepository.findByEmail(name);
	    EaiLog.info("uuid user geted from database  : {}",user.getUuid());

	    if (user == null) {
		transfertOut.setCode(Constants.CODE_ERROR);
		transfertOut.setMessage("USER_NOT_FOUND");
		EaiLog.info("Utilisateur introuvable avec l'email : {}", name);
		return;
	    }

	    transfertBES.setUser(user);
	    transfertBES.setUrl(transfertBES.getUrl());
	    transfertBES.setCallbackUrl(transfertIn.getCallbackUrl());
	    transfertBES.setBankName(transfertIn.getBankName());
	    transfertBES.setNumCompteBes(transfertIn.getNumCompteBes());
	    transfertBES.setIban(transfertIn.getIban());
	    transfertBES.setCompteClient(transfertIn.getCompteClient());
	    transfertBES.setFirstName(transfertIn.getFirstName());
	    transfertBES.setLastName(transfertIn.getLastName());
	    transfertBES.setCommission(transfertIn.getCommission());
	    transfertBES.setAmountToReceive(transfertIn.getAmountToReceive());
	    transfertBES.setAmountToSend(transfertIn.getAmountToSend());
	    transfertBES.setAmountNetToSend(transfertIn.getAmountNetToSend());
	    transfertBES.setUuid(responseDTO.getUuid());
	    transfertBES.setRib(transfertIn.getCallbackUrl());
	    transfertBES.setTauxChange(transfertIn.getTauxChange());
	    transfertBES.setTransferMode(transfertIn.getTransferMode());
	    try {
		transfertRepository.save(transfertBES);
	    } catch (Exception e) {
		transfertOut.setCode(Constants.CODE_ERROR);
		transfertOut.setMessage(ERR_TECHNICAL);
		EaiLog.error("Erreur en sauvegardant TransfertBES : {}", e);
		return;
	    }
	    transfertOut.setCode(Constants.CODE_SUCCESS);
	    transfertOut.setMessage("OK");
	    transfertOut.setUuid(responseDTO.getUuid());
	    transfertOut.setUrlWebVue(buildUrl("paiement/nexiBoa"));
		transfertOut.setBid(helpers.hashMac(user.getUuid() + responseDTO.getUuid().substring(0,6),bidKey));
	    EaiLog.info("=================Transfer validation successful=======================");
	} else {
	    String errorMsg = responseDTO != null ? responseDTO.getMessage() + "code:" + responseDTO.getCode() : "Empty response";
	    transfertOut.setCode(Constants.CODE_ERROR);
	    transfertOut.setMessage(responseDTO != null ? responseDTO.getCode() : RESPONSE_EMPTY);
	    EaiLog.warn("Transfer validation failed: {}", errorMsg);
	}
    }

    private void handleApiError(TransfertOut transfertOut, String errorMessage) {
	EaiLog.error("API communication error: {}", errorMessage);
	transfertOut.setCode(Constants.CODE_ERROR);
	transfertOut.setMessage(ERR_TECHNICAL);
    }

    private void handleUnexpectedError(TransfertOut transfertOut, Exception e) {
	EaiLog.error("Unexpected error during transfer validation : {} ", e);
	transfertOut.setCode(Constants.CODE_ERROR);
	transfertOut.setMessage(ERR_TECHNICAL);
    }

    private TransfertRequest mapToTransfertRequest(TransfertIn transfertIn) {
	TransfertRequest request = new TransfertRequest();
	request.setModeTransfert(transfertIn.getTransferMode());
	request.setAmountNetToSend(transfertIn.getAmountNetToSend());
	request.setAmountToReceive(transfertIn.getAmountToReceive());
	request.setCommission(transfertIn.getCommission());
	request.setBankName(transfertIn.getBankName());
	request.setCompteClient(transfertIn.getCompteClient());
	request.setTauxChange(transfertIn.getTauxChange());
	request.setUuid(transfertIn.getUuid());
	request.setIbanBeneficiaire(transfertIn.getIban());
	request.setNomBeneficiaire(transfertIn.getFirstName());
	request.setPrenomBeneficiaire(transfertIn.getLastName());
	request.setUrlPaiement(transfertIn.getUrl());
	request.setUrlReturned(transfertIn.getCallbackUrl());
	request.setRibBenef(transfertIn.getRib());
	request.setNumCompteBes(transfertIn.getNumCompteBes());
	request.setAmountToSend(transfertIn.getAmountToSend());
	return request;
    }

    @Override
    public HistoriqueOut getHistoryTransfert(String token) {
	EaiLog.info("Start Service get history transfert");
	HistoriqueOut historiqueOut = new HistoriqueOut();
	try {
	    String url = urlApi.concat("transfert/history");
	    EaiLog.info("calling url : {}",url);
	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.set(HttpHeaders.AUTHORIZATION,token);
	    headers.set(Constants.CANAL_HEADER, Constants.CANAL);
	    HttpEntity<String> requestEntity = new HttpEntity<>(headers);
	    EaiLog.info("requestEntity : {}",requestEntity);
	    ResponseEntity<HistoriqueResponse> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
		    HistoriqueResponse.class);
	    HistoriqueResponse bodyResponse = response.getBody();
	    EaiLog.info("BES transfert history response : {}", bodyResponse);
	    if(bodyResponse != null && SUCCESS_CODE.equals(bodyResponse.getCode())) {
		Transferts transferts = new Transferts();
		List<History> histories = new ArrayList<>();
		if (bodyResponse.getListHistory() != null && !bodyResponse.getListHistory().isEmpty()) {
		    histories.addAll(bodyResponse.getListHistory());
		}
		transferts.setListHistory(histories);
		historiqueOut.setTransferts(transferts);
		historiqueOut.setCode(Constants.CODE_SUCCESS);
		historiqueOut.setMessage("OK");
	    } else {
		historiqueOut.setCode(Constants.CODE_ERROR);
		historiqueOut.setMessage(bodyResponse != null ? bodyResponse.getCode() : RESPONSE_EMPTY);
	    }
	} catch(Exception e) {
	    EaiLog.info("Technical Error : {}", e);
	    historiqueOut.setCode(Constants.CODE_ERROR);
	    historiqueOut.setMessage(ERR_TECHNICAL);
	}
	EaiLog.info("End Service transfert history");
	return historiqueOut;
    }


}