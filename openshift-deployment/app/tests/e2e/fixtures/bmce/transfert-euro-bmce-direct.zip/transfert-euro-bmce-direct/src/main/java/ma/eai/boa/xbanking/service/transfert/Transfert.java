package ma.eai.boa.xbanking.service.transfert;


import ma.eai.boa.xbanking.vo.transfert.DetailTransferOut;
import ma.eai.boa.xbanking.vo.historiqueTransfert.HistoriqueOut;
import ma.eai.boa.xbanking.vo.transfert.TransfertIn;
import ma.eai.boa.xbanking.vo.transfert.TransfertOut;

public interface Transfert {
    TransfertOut validatTransfert(TransfertIn transfertIn);


    DetailTransferOut getTransferDetail(String uuid, String token);

    HistoriqueOut getHistoryTransfert(String token);

}
