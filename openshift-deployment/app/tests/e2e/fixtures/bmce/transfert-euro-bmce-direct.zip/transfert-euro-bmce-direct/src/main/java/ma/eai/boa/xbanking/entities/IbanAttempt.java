package ma.eai.boa.xbanking.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "BES_IBAN_ATTEMPT")
public class IbanAttempt implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String attemptKey;
    private int ibanAttemptNumber;
    private Date lastIbanAttemptDate;

    public String getAttemptKey() {
        return attemptKey;
    }

    public void setAttemptKey(String attemptKey) {
        this.attemptKey = attemptKey;
    }

    public int getIbanAttemptNumber() {
        return ibanAttemptNumber;
    }

    public void setIbanAttemptNumber(int ibanAttemptNumber) {
        this.ibanAttemptNumber = ibanAttemptNumber;
    }

    public Date getLastIbanAttemptDate() {
        return lastIbanAttemptDate;
    }

    public void setLastIbanAttemptDate(Date lastIbanAttemptDate) {
        this.lastIbanAttemptDate = lastIbanAttemptDate;
    }
}
