package ma.eai.boa.xbanking.vo.enrollement;

import ma.eai.boa.xbanking.vo.Retour;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "EnrollementValidationOut")
public class EnrollementValidationOut extends Retour {

    private String uuid;

    private String otpID;

    private boolean completed;

    private boolean client;

    private String lang;

    private String phone;

    private long nombreNotifs;

    private String uuidKey;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getOtpID() {
        return otpID;
    }

    public void setOtpID(String otpID) {
        this.otpID = otpID;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public boolean isClient() {
        return client;
    }

    public void setClient(boolean client) {
        this.client = client;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public long getNombreNotifs() {
        return nombreNotifs;
    }

    public void setNombreNotifs(long nombreNotifs) {
        this.nombreNotifs = nombreNotifs;
    }

    public String getUuidKey() {
        return uuidKey;
    }

    public void setUuidKey(String uuidKey) {
        this.uuidKey = uuidKey;
    }
}
