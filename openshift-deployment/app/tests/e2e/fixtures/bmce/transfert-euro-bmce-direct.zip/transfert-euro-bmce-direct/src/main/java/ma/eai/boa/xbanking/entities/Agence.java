package ma.eai.boa.xbanking.entities;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;

@Entity
public class Agence extends NamedIdentified{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2282317895027112159L;

	private String codePostale;
	
	private String adresse;
	
	private String phone;
	
	private String email;
	
	@ManyToOne
	private Country country;
	
	public String getCodePostale() {
		return codePostale;
	}

	public void setCodePostale(String codePostale) {
		this.codePostale = codePostale;
	}


	public String getAdresse() {
		return adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	


}
