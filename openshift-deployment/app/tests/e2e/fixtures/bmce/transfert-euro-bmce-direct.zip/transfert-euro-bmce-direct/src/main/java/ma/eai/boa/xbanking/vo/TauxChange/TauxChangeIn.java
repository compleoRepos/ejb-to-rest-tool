package ma.eai.boa.xbanking.vo.TauxChange;


public class TauxChangeIn {
    private String langue;

    public String getLangue() {
	return langue;
    }

    public void setLangue(String langue) {
	this.langue = langue;
    }
}
