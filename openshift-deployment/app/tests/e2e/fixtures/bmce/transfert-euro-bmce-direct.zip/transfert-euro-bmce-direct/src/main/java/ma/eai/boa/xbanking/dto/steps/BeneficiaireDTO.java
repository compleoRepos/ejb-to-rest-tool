package ma.eai.boa.xbanking.dto.steps;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import ma.eai.boa.xbanking.entities.Bank;
import ma.eai.boa.xbanking.entities.RelationFamiliale;
import ma.eai.boa.xbanking.entities.Utilisateur;
import ma.eai.boa.xbanking.entities.Nationality;


import java.io.Serializable;


public class BeneficiaireDTO implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -4773915813784965261L;

    @JsonProperty("lastName")
    private String nom;

    @JsonProperty("firstName")
    private String prenom;

    private String iban;

    private String codeSwift;

    private Bank bank;

    @JsonIgnore
    private Utilisateur user;

    private RelationFamiliale relationFamiliale;

    private String rib;

    @JsonProperty("country")
    private Nationality pays;

    private boolean sendToAmplitude;

    private boolean client;

    @JsonIgnore
    private String attestationRib;


    private boolean beneficiareVerify;

    /**
     *
     */
    public BeneficiaireDTO() {
    }

    /**
     * @param nom
     * @param prenom
     * @param iban
     * @param user
     */
    public BeneficiaireDTO(String nom, String prenom, String iban, Utilisateur user) {
        super();
        this.nom = nom;
        this.prenom = prenom;
        this.iban = iban;
        this.user = user;
    }



    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getIban() {
        return iban;
    }

    public void setIban(String iban) {
        this.iban = iban;
    }

    public String getCodeSwift() {
        return codeSwift;
    }

    public void setCodeSwift(String codeSwift) {
        this.codeSwift = codeSwift;
    }

    public Utilisateur getUser() {
        return user;
    }

    public void setUser(Utilisateur user) {
        this.user = user;
    }

    public RelationFamiliale getRelationFamiliale() {
        return relationFamiliale;
    }

    public void setRelationFamiliale(RelationFamiliale relationFamiliale) {
        this.relationFamiliale = relationFamiliale;
    }

    public String getRib() {
        return rib;
    }

    public void setRib(String rib) {
        this.rib = rib;
    }

    public void setPays(Nationality pays) {
        this.pays = pays;
    }

    public boolean isSendToAmplitude() {
        return sendToAmplitude;
    }

    public void setSendToAmplitude(boolean sendToAmplitude) {
        this.sendToAmplitude = sendToAmplitude;
    }

    public Nationality getPays() {
        return pays;
    }

    public Bank getBank() {
        return bank;
    }

    public void setBank(Bank bank) {
        this.bank = bank;
    }

    public boolean isClient() {
        return client;
    }

    public void setClient(boolean client) {
        this.client = client;
    }

    public String getAttestationRib() {
        return attestationRib;
    }

    public void setAttestationRib(String attestationRib) {
        this.attestationRib = attestationRib;
    }

    public boolean isBeneficiareVerify() {
        return beneficiareVerify;
    }

    public void setBeneficiareVerify(boolean beneficiareVerify) {
        this.beneficiareVerify = beneficiareVerify;
    }

    @Override
    public String toString() {
        return "Beneficiaire{" +
                "nom='" + nom + '\'' +
                ", prenom='" + prenom + '\'' +
                ", iban='" + iban + '\'' +
                ", codeSwift='" + codeSwift + '\'' +
                ", bank=" + bank +
                ", user=" + user +
                ", relationFamiliale=" + relationFamiliale +
                ", rib='" + rib + '\'' +
                ", pays=" + pays +
                ", sendToAmplitude=" + sendToAmplitude +
                ", client=" + client +
                ", attestationRib='" + attestationRib + '\'' +
                ", beneficiareVerify=" + beneficiareVerify +
                '}';
    }
}
