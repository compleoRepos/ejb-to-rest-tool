package ma.eai.boa.xbanking.service.beneficiaire;

import ma.eai.boa.xbanking.vo.Beneficiaire.BeneficiaireIn;
import ma.eai.boa.xbanking.vo.Beneficiaire.BeneficiaireOut;
import ma.eai.boa.xbanking.vo.Beneficiaire.ListBeneficiaireOut;

public interface Beneficiaire {

    BeneficiaireOut addBeneficiaire(BeneficiaireIn beneficiaireIn);

    ListBeneficiaireOut getRecipients(String token);

    BeneficiaireOut addBeneficiareForClient(BeneficiaireIn beneficiaireIn);


}
