package ma.eai.boa.xbanking.vo.Beneficiaire;


public class BeneficiaireIn {

    private String firstName;

    private String lastName;

    private String country;

    private String rib;

    private String relationFamiliale;

    private String bank;

    private String attestationRib;  // Base64 format

    private String token;

    public String getFirstName() {
	return firstName;
    }

    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }

    public String getLastName() {
	return lastName;
    }

    public void setLastName(String lastName) {
	this.lastName = lastName;
    }

    public String getCountry() {
	return country;
    }

    public void setCountry(String country) {
	this.country = country;
    }

    public String getRib() {
	return rib;
    }

    public void setRib(String rib) {
	this.rib = rib;
    }

    public String getRelationFamiliale() {
	return relationFamiliale;
    }

    public void setRelationFamiliale(String relationFamiliale) {
	this.relationFamiliale = relationFamiliale;
    }

    public String getBank() {
	return bank;
    }

    public void setBank(String bank) {
	this.bank = bank;
    }

    public String getAttestationRib() {
	return attestationRib;
    }

    public void setAttestationRib(String attestationRib) {
	this.attestationRib = attestationRib;
    }

    public String getToken() {
	return token;
    }

    public void setToken(String token) {
	this.token = token;
    }
}
