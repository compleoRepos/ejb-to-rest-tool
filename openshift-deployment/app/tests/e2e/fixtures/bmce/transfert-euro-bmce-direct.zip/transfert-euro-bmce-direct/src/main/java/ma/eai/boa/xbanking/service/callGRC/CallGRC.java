package ma.eai.boa.xbanking.service.callGRC;

import ma.eai.boa.xbanking.vo.callGRC.CallGrcIn;
import ma.eai.boa.xbanking.vo.callGRC.CallGrcOut;

public interface CallGRC {

    CallGrcOut getInfosClient(CallGrcIn callGrcIn);
}
