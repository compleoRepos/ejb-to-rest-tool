package ma.eai.boa.xbanking.vo.TauxChange;

import ma.eai.boa.xbanking.dto.tauxchange.Commission;
import ma.eai.boa.xbanking.vo.Retour;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "TauxChangeOut")
public class TauxChangeOut extends Retour {
    private String fraisTransfertVirement;
    private String fraisTransfertCB;
    private String tauxChange;
    private String delaiToTransfert;

    private List<Commission> commissions;

    public String getFraisTransfertVirement() {
	return fraisTransfertVirement;
    }

    public void setFraisTransfertVirement(String fraisTransfertVirement) {
	this.fraisTransfertVirement = fraisTransfertVirement;
    }

    public String getFraisTransfertCB() {
	return fraisTransfertCB;
    }

    public void setFraisTransfertCB(String fraisTransfertCB) {
	this.fraisTransfertCB = fraisTransfertCB;
    }

    public String getTauxChange() {
	return tauxChange;
    }

    public void setTauxChange(String tauxChange) {
	this.tauxChange = tauxChange;
    }

    public String getDelaiToTransfert() {
	return delaiToTransfert;
    }

    public void setDelaiToTransfert(String delaiToTransfert) {
	this.delaiToTransfert = delaiToTransfert;
    }

    public List<Commission> getCommissions() {
        return commissions;
    }

    public void setCommissions(List<Commission> commissions) {
        this.commissions = commissions;
    }
}
