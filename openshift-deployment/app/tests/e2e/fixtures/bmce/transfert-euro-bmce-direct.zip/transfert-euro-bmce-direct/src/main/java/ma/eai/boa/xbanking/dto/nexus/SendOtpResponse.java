package ma.eai.boa.xbanking.dto.nexus;

import com.fasterxml.jackson.annotation.JsonProperty;
import ma.eai.boa.xbanking.entities.Retour;


import java.io.Serializable;

public class SendOtpResponse extends Retour implements Serializable {

	private static final long serialVersionUID = -1979649753611936791L;

	@JsonProperty("transactionId")
	private String transactionId;
	
	@JsonProperty("status")
	private String status;
	
	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}