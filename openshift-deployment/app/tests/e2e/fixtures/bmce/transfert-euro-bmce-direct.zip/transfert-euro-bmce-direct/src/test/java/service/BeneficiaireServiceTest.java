package service;


import ma.eai.boa.xbanking.dto.Beneficiaire.Beneficiaire;
import ma.eai.boa.xbanking.dto.Beneficiaire.BeneficiaireRequest;
import ma.eai.boa.xbanking.dto.Beneficiaire.BeneficiaireResponse;
import ma.eai.boa.xbanking.dto.Beneficiaire.ListBeneficiaire;
import ma.eai.boa.xbanking.dto.createaccountphonenumber.PhoneNumberResponse;
import ma.eai.boa.xbanking.service.beneficiaire.BeneficiaireImpl;
import ma.eai.boa.xbanking.util.Constants;
import ma.eai.boa.xbanking.vo.Beneficiaire.BeneficiaireIn;
import ma.eai.boa.xbanking.vo.Beneficiaire.BeneficiaireOut;
import ma.eai.boa.xbanking.vo.Beneficiaire.ListBeneficiaireOut;
import ma.eai.boa.xbanking.vo.Retour;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

public class BeneficiaireServiceTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private BeneficiaireImpl beneficiaireService;

    private BeneficiaireIn beneficiaireIn;

    @Before
    public void setUp() {
	MockitoAnnotations.initMocks(this);
	beneficiaireService.urlApi = "http://example.com/";
	beneficiaireIn = new BeneficiaireIn();
	beneficiaireIn.setBank("TestBank");
	beneficiaireIn.setFirstName("John");
	beneficiaireIn.setLastName("Doe");
	beneficiaireIn.setRib("123456789");
	beneficiaireIn.setCountry("FR");
	beneficiaireIn.setAttestationRib("attestation.pdf");
	beneficiaireIn.setRelationFamiliale("FRIEND");
	beneficiaireIn.setToken("Bearer test-token");
    }

    @Test
    public void testAddBeneficiaire_Success() {
	// Arrange
	BeneficiaireResponse mockResponse = new BeneficiaireResponse();
	mockResponse.setCode("SUCCESS_CODE");
	mockResponse.setMessage("Beneficiaire ajouté avec succès");

	ResponseEntity<BeneficiaireResponse> responseEntity =
		new ResponseEntity<>(mockResponse, HttpStatus.OK);

	when(restTemplate.exchange(
		eq("http://example.com/prospect/benef/add "),  // URL exacte de la méthode
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(BeneficiaireResponse.class)
	)).thenReturn(responseEntity);

	// Act
	BeneficiaireOut result = beneficiaireService.addBeneficiaire(beneficiaireIn);

	// Assert
	assertEquals(Constants.CODE_SUCCESS, result.getCode());
	assertEquals("OK", result.getMessage());  // Le message doit être vide en cas de succès selon le code
    }

    @Test
    public void testAddBeneficiaire_ApiError() {
	// Arrange
	BeneficiaireResponse mockResponse = new BeneficiaireResponse();
	mockResponse.setCode("111");
	mockResponse.setMessage("ERR_TECHNICAL");

	ResponseEntity<BeneficiaireResponse> responseEntity =
		new ResponseEntity<>(mockResponse, HttpStatus.OK);

	when(restTemplate.exchange(
		eq("http://example.com/prospect/benef/add "),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(BeneficiaireResponse.class)
	)).thenReturn(responseEntity);

	// Act
	BeneficiaireOut result = beneficiaireService.addBeneficiaire(beneficiaireIn);

	// Assert
	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertEquals("111", result.getMessage());
    }


    @Test
    public void testAddBeneficiare_Exception() {

	when(restTemplate.exchange(
		eq("http://example.com/gestion/addbenef"),
		eq(HttpMethod.POST),
		any(HttpEntity.class),
		eq(BeneficiaireResponse.class)
	)).thenThrow(new RuntimeException("Service indisponible"));

	BeneficiaireOut result = beneficiaireService.addBeneficiaire(beneficiaireIn);

	assertEquals(Constants.CODE_ERROR, result.getCode());
	assertTrue(result.getMessage().contains("ERR_TECHNICAL"));
    }

	@Test
	public void getRecipientTest_WithSuccess() {
		//Given
		String token = "ejkhljshgduqgdjh";

		Beneficiaire beneficiaire = new Beneficiaire();
		beneficiaire.setBankCode("211");
		beneficiaire.setFirstName("Test1");
		beneficiaire.setRib("Rib");
		beneficiaire.setId("1");

		Beneficiaire beneficiaire1 = new Beneficiaire();
		beneficiaire.setId("2");
		beneficiaire.setRib("Rib");
		beneficiaire.setFirstName("Test2");

		ListBeneficiaire listBeneficiaire = new ListBeneficiaire();

		listBeneficiaire.setListeBenef(Arrays.asList(beneficiaire, beneficiaire1));
		listBeneficiaire.setCommission(2.5f);
		listBeneficiaire.setCode("SUCCESS_CODE");

		ResponseEntity<ListBeneficiaire> responseEntity = ResponseEntity.ok(listBeneficiaire);
		when(restTemplate.exchange(
				eq("http://example.com/gestion/benificiaires"),
				eq(HttpMethod.GET),
				any(HttpEntity.class),
				eq(ListBeneficiaire.class)
		)).thenReturn(responseEntity);

		ListBeneficiaireOut listBeneficiaireOut = beneficiaireService.getRecipients(token);

		assertEquals(Constants.CODE_SUCCESS, listBeneficiaireOut.getCode());
		assertEquals(2, listBeneficiaireOut.getListeBenef().size());

	}

	@Test
	public void getRecipientTest_WithError() {
		//Given
		String token = "ejkhljshgduqgdjh";

		Beneficiaire beneficiaire = new Beneficiaire();
		beneficiaire.setBankCode("211");
		beneficiaire.setFirstName("Test1");
		beneficiaire.setRib("Rib");
		beneficiaire.setId("1");

		Beneficiaire beneficiaire1 = new Beneficiaire();
		beneficiaire.setId("2");
		beneficiaire.setRib("Rib");
		beneficiaire.setFirstName("Test2");

		ListBeneficiaire listBeneficiaire = new ListBeneficiaire();

		listBeneficiaire.setListeBenef(Arrays.asList(beneficiaire, beneficiaire1));
		listBeneficiaire.setCommission(2.5f);
		listBeneficiaire.setCode("111");

		ResponseEntity<ListBeneficiaire> responseEntity = ResponseEntity.ok(listBeneficiaire);
		when(restTemplate.exchange(
				eq("http://example.com/gestion/benificiaires"),
				eq(HttpMethod.GET),
				any(HttpEntity.class),
				eq(ListBeneficiaire.class)
		)).thenReturn(responseEntity);

		ListBeneficiaireOut listBeneficiaireOut = beneficiaireService.getRecipients(token);

		assertEquals(Constants.CODE_ERROR, listBeneficiaireOut.getCode());


	}

	@Test
	public void getRecipientTest_Exception() {
		//Given
		String token = "ejkhljshgduqgdjh";



		ResponseEntity<ListBeneficiaire> responseEntity = ResponseEntity.ok(null);
		when(restTemplate.exchange(
				eq("http://example.com/gestion/benificiaires"),
				eq(HttpMethod.GET),
				any(HttpEntity.class),
				eq(ListBeneficiaire.class)
		)).thenThrow(new RuntimeException());

		ListBeneficiaireOut listBeneficiaireOut = beneficiaireService.getRecipients(token);

		assertEquals(Constants.CODE_ERROR, listBeneficiaireOut.getCode());


	}

}
