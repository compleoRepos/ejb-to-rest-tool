package ma.eai.boa.xbanking.dto.steps;



import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import ma.eai.boa.xbanking.entities.Civilite;
import ma.eai.boa.xbanking.entities.Country;
import ma.eai.boa.xbanking.entities.Nationality;
import ma.eai.boa.xbanking.entities.Profession;
import ma.eai.boa.xbanking.entities.Agence;
import ma.eai.boa.xbanking.entities.Utilisateur;
import ma.eai.boa.xbanking.entities.ActivityArea;


import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;


public class DataProspectDTO implements Serializable{

    private static final long serialVersionUID = 5407805787971744757L;

    private String uuid;
    private Civilite civilite;

    private String lastname;

    private String firstname;

    private String address;

    private String codePostale;

    private String city;

    @JsonIgnore
    private boolean clientBOA;

    private Country country;

    @JsonFormat(pattern="yyyy-MM-dd")
    private Date datedenaissance;

    private Nationality nationality;


    private Profession profession;


    @JsonIgnore
    private ActivityArea activityArea;


    private boolean politicallyexposed;

    @JsonProperty("clientBOA")
    private String clientBOAStatus;


    @JsonIgnore

    private String politicallyexposedStr;

    @JsonIgnore
    private Agence agence;

    @JsonIgnore
    private Utilisateur user;

    private String birthCity;

    private Nationality birthCountry;

    @JsonIgnore
    private Timestamp ppeValidationDate;

    @JsonIgnore
    private String civiliteStr;

    @JsonIgnore
    private boolean luiMemePPE;

    @JsonIgnore
    private String fonctionPPE;

    @JsonIgnore
    private String fullNamePPE;

    @JsonIgnore
    private String lienPPE;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getClientBOAStatus() {
        return clientBOAStatus;
    }

    public void setClientBOAStatus(String clientBOAStatus) {
        this.clientBOAStatus = clientBOAStatus;
    }


    public Civilite getCivilite() {
        return civilite;
    }

    public void setCivilite(Civilite civilite) {
        this.civilite = civilite;
    }

    public boolean isClientBOA() {
        return clientBOA;
    }

    public void setClientBOA(boolean clientBOA) {
        this.clientBOA = clientBOA;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Nationality getNationality() {
        return nationality;
    }

    public void setNationality(Nationality nationality) {
        this.nationality = nationality;
    }

    public Profession getProfession() {
        return profession;
    }

    public void setProfession(Profession profession) {
        this.profession = profession;
    }

    public Utilisateur getUser() {
        return user;
    }

    public void setUser(Utilisateur user) {
        this.user = user;
    }

    public Date getDatedenaissance() {
        return datedenaissance;
    }

    public void setDatedenaissance(Date datedenaissance) {
        this.datedenaissance = datedenaissance;
    }

    public ActivityArea getActivityArea() {
        return activityArea;
    }

    public void setActivityArea(ActivityArea activityArea) {
        this.activityArea = activityArea;
    }

    public boolean isPoliticallyexposed() {
        return politicallyexposed;
    }

    public void setPoliticallyexposed(boolean politicallyexposed) {
        this.politicallyexposed = politicallyexposed;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }


    public String getCodePostale() {
        return codePostale;
    }

    public void setCodePostale(String codePostale) {
        this.codePostale = codePostale;
    }

    public String getPoliticallyexposedStr() {
        return politicallyexposedStr;
    }

    public void setPoliticallyexposedStr(String politicallyexposedStr) {
        this.politicallyexposedStr = politicallyexposedStr;
    }

    public String getBirthCity() {
        return birthCity;
    }

    public void setBirthCity(String birthCity) {
        this.birthCity = birthCity;
    }

    public Nationality getBirthCountry() {
        return birthCountry;
    }

    public void setBirthCountry(Nationality birthCountry) {
        this.birthCountry = birthCountry;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Agence getAgence() {
        return agence;
    }

    public void setAgence(Agence agence) {
        this.agence = agence;
    }

    public Timestamp getPpeValidationDate() {
        return ppeValidationDate;
    }

    public void setPpeValidationDate(Timestamp ppeValidationDate) {
        this.ppeValidationDate = ppeValidationDate;
    }

    public String getCiviliteStr() {
        return civiliteStr;
    }

    public void setCiviliteStr(String civiliteStr) {
        this.civiliteStr = civiliteStr;
    }

    public boolean isLuiMemePPE() {
        return luiMemePPE;
    }

    public void setLuiMemePPE(boolean luiMemePPE) {
        this.luiMemePPE = luiMemePPE;
    }

    public String getFonctionPPE() {
        return fonctionPPE;
    }

    public void setFonctionPPE(String fonctionPPE) {
        this.fonctionPPE = fonctionPPE;
    }

    public String getLienPPE() {
        return lienPPE;
    }

    public void setLienPPE(String lienPPE) {
        this.lienPPE = lienPPE;
    }

    public String getFullNamePPE() {
        return fullNamePPE;
    }

    public void setFullNamePPE(String fullNamePPE) {
        this.fullNamePPE = fullNamePPE;
    }

    @Override
    public String toString() {
        return "DataProspect{" +
                "uuid='" + uuid + '\'' +
                ", civilite=" + civilite +
                ", lastname='" + lastname + '\'' +
                ", firstname='" + firstname + '\'' +
                ", address='" + address + '\'' +
                ", codePostale='" + codePostale + '\'' +
                ", city='" + city + '\'' +
                ", clientBOA=" + clientBOA +
                ", country=" + country +
                ", datedenaissance=" + datedenaissance +
                ", nationality=" + nationality +
                ", profession=" + profession +
                ", activityArea=" + activityArea +
                ", politicallyexposed=" + politicallyexposed +
                ", clientBOAStatus='" + clientBOAStatus + '\'' +
                ", politicallyexposedStr='" + politicallyexposedStr + '\'' +
                ", agence=" + agence +
                ", user=" + user +
                ", birthCity='" + birthCity + '\'' +
                ", birthCountry=" + birthCountry +
                ", ppeValidationDate=" + ppeValidationDate +
                ", civiliteStr='" + civiliteStr + '\'' +
                ", luiMemePPE=" + luiMemePPE +
                ", fonctionPPE='" + fonctionPPE + '\'' +
                ", fullNamePPE='" + fullNamePPE + '\'' +
                ", lienPPE='" + lienPPE + '\'' +
                '}';
    }
}

