package ma.eai.boa.xbanking.entities;

import ma.eai.boa.xbanking.util.UserStep;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.Table;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Enumerated;
import javax.persistence.EnumType;
import java.io.Serializable;
import java.util.Date;


@Table(name = "BES_USER")
@Entity
public class User implements Serializable {

    private static final long serialVersionUID = -2282317895027112329L;


    @Id
    private String uuid;
    private String phone;
    private String countryCode;
    private String email;

    private String contratBad;
    @CreationTimestamp
    private Date createdAt;
    @UpdateTimestamp
    private Date updatedAt;

    @Enumerated(EnumType.STRING)
    private UserStep step;


    public UserStep getStep() {
	return step;
    }

    public void setStep(UserStep step) {
	this.step = step;
    }

    public String getPhone() {
	return phone;
    }

    public void setPhone(String phone) {
	this.phone = phone;
    }

    public String getCountryCode() {
        return countryCode;
    }
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getEmail() {
	return email;
    }

    public void setEmail(String email) {
	this.email = email;
    }

    public String getUuid() {
	return uuid;
    }

    public void setUuid(String uuid) {
	this.uuid = uuid;
    }

    public String getContratBad() {
        return contratBad;
    }
    public void setContratBad(String contratBad) {
        this.contratBad = contratBad;
    }
}
