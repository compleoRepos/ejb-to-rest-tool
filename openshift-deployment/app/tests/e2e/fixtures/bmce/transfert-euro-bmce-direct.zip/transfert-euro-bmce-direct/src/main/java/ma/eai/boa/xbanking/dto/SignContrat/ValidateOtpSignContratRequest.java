package ma.eai.boa.xbanking.dto.SignContrat;

public class ValidateOtpSignContratRequest {
    private String token;

    private String uuid;

    private String otpID;

    private String otp;

    private String deviceId;

    public String getUuid() {
	return uuid;
    }

    public void setUuid(String uuid) {
	this.uuid = uuid;
    }

    public String getOtpID() {
	return otpID;
    }

    public void setOtpID(String otpID) {
	this.otpID = otpID;
    }

    public String getOtp() {
	return otp;
    }

    public void setOtp(String otp) {
	this.otp = otp;
    }

    public String getDeviceId() {
	return deviceId;
    }

    public void setDeviceId(String deviceId) {
	this.deviceId = deviceId;
    }

    public String getToken() {
	return token;
    }

    public void setToken(String token) {
	this.token = token;
    }
}
