package ma.eai.boa.xbanking.vo.customer;

public class DetailsCustomerIn {
    private String token;

    public String getToken() {
	return token;
    }

    public void setToken(String token) {
	this.token = token;
    }
}
