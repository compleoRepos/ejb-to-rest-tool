package service.customer;

import ma.eai.boa.xbanking.dto.customer.DetailsCustomerResponse;
import ma.eai.boa.xbanking.service.customer.CustomerImpl;
import ma.eai.boa.xbanking.vo.customer.DetailsCustomerOut;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CustomerImplTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private CustomerImpl customerImpl;

    private static final String TOKEN = "Bearer test-token";
    private static final String API_URL = "http://api.example.com/";
    private static final String SUCCESS_CODE = "SUCCESS_CODE";
    private static final String CODE_SUCCESS = "000"; // Updated to match actual value
    private static final String CODE_ERROR = "500";
    private static final String TECHNICAL_ERROR = "TECHNICAL_ERROR";
    private static final String RESPONSE_EMPTY = "RESPONSE_EMPTY";
    private static final String CANAL = "WEB";

    @Before
    public void setUp() {
	ReflectionTestUtils.setField(customerImpl, "urlApi", API_URL);
    }

    @Test
    public void testGetDetailsCustomer_Success() {
	// Arrange
	DetailsCustomerResponse apiResponse = new DetailsCustomerResponse();
	apiResponse.setCode(SUCCESS_CODE);
	apiResponse.setDesignation("Mr");
	apiResponse.setFirstName("John");
	apiResponse.setLastName("Doe");
	apiResponse.setAdress("123 Main St");
	apiResponse.setEmail("john.doe@example.com");
	apiResponse.setPhone("1234567890");
	apiResponse.setProfile("VIP");
	apiResponse.setNationality("US");
	apiResponse.setCodePostal("12345");
	apiResponse.setVille("City");
	apiResponse.setDocType("Passport");
	apiResponse.setDocValue("123456789");
	apiResponse.setDocCountry("US");
	apiResponse.setCountry("USA");
	apiResponse.setPhoneContact("9876543210");

	ResponseEntity<DetailsCustomerResponse> responseEntity = new ResponseEntity<>(apiResponse, HttpStatus.OK);
	when(restTemplate.exchange(
		eq(API_URL + "customer/customerDetails"),
		eq(HttpMethod.GET),
		any(),
		eq(DetailsCustomerResponse.class)
	)).thenReturn(responseEntity);

	// Act
	DetailsCustomerOut result = customerImpl.getDetailsCustomer(TOKEN);

	// Assert
	assertEquals(CODE_SUCCESS, result.getCode()); // Expecting "000"
	assertEquals("OK", result.getMessage());
	assertEquals("Mr", result.getDesignation());
	assertEquals("John", result.getFirstName());
	assertEquals("Doe", result.getLastName());
	assertEquals("123 Main St", result.getAdress());
	assertEquals("john.doe@example.com", result.getEmail());
	assertEquals("1234567890", result.getPhone());
	assertEquals("VIP", result.getProfile());
	assertEquals("US", result.getNationality());
	assertEquals("12345", result.getCodePostal());
	assertEquals("City", result.getVille());
	assertEquals("Passport", result.getDocType());
	assertEquals("123456789", result.getDocValue());
	assertEquals("US", result.getDocCountry());
	assertEquals("USA", result.getCountry());
	assertEquals("9876543210", result.getPhoneContact());
    }


}