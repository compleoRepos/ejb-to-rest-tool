package ma.eai.boa.xbanking.vo.Authentication;

import ma.eai.boa.xbanking.vo.Retour;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "CheckUserOut")
public class CheckUserOut extends Retour {

    private boolean userFound;
    private String token;

    private String lang;

    private boolean client;

    public boolean isUserFound() {
        return userFound;
    }

    public String getToken() {
        return token;
    }

    public void setUserFound(boolean userFound) {
        this.userFound = userFound;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public boolean isClient() {
        return client;
    }

    public void setClient(boolean client) {
        this.client = client;
    }
}
