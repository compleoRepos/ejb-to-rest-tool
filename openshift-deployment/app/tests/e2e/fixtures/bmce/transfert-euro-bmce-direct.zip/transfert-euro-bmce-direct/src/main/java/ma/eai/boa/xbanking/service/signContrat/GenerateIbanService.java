package ma.eai.boa.xbanking.service.signContrat;

import ma.eai.boa.xbanking.vo.SignContrat.IbanResponseOut;

public interface GenerateIbanService {

    IbanResponseOut generateIban(String token);
}
