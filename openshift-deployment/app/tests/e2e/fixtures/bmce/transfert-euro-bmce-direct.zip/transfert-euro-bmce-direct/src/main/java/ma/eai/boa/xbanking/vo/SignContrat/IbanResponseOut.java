package ma.eai.boa.xbanking.vo.SignContrat;


import ma.eai.boa.xbanking.vo.Retour;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "IbanResponseOut")
public class IbanResponseOut extends Retour {

    private String iban;

    private String reference;

    private String bic;

    public String getIban() {
        return iban;
    }

    public String getReference() {
        return reference;
    }

    public String getBic() {
        return bic;
    }

    public void setIban(String iban) {
        this.iban = iban;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public void setBic(String bic) {
        this.bic = bic;
    }
}
