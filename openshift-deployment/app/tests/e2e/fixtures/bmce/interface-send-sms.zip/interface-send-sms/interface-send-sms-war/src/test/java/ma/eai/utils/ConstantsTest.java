package ma.eai.utils;

import ma.eai.models.Accounts;
import ma.eai.models.SmsWSRequest;
import ma.eai.properties.loader.PropConstantes;
import org.junit.Assert;
import org.junit.Test;
public class ConstantsTest {

    @Test
    public void testGetAccount(){
        PropConstantes.ENV_TYPE = "dy";
        // Test for ORANGE accounts
        SmsWSRequest request = new SmsWSRequest();
        request.setCanal("tos");
        Assert.assertNotNull(request.toString());
        Accounts orangeAccount = Constants.getAccount("tos");
        assert orangeAccount != null : "ORANGE account should not be null";
        assert "tosusername".equals(orangeAccount.getAccountName()) : "Incorrect ORANGE account name";
        assert "tosopassword".equals(orangeAccount.getAccountPassword()) : "Incorrect ORANGE account password";
        Assert.assertNotNull(orangeAccount);

        // Test for CASANET accounts
        Accounts casanetAccount = Constants.getAccount("boa");
        assert casanetAccount != null : "CASANET account should not be null";
        assert "boausername".equals(casanetAccount.getAccountName()) : "Incorrect CASANET account name";
        assert "boapassword".equals(casanetAccount.getAccountPassword()) : "Incorrect CASANET account password";
        Assert.assertNotNull(casanetAccount);
    }


}