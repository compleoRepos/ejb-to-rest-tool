package ma.eai.ws;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import ma.eai.models.SmsRequest;
import ma.eai.models.SmsResponse;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.Parser;
import ma.eai.midw.connectors.SynchroneService;
import ma.eai.midw.integration.Services;
import ma.eai.midw.log.Log;
import ma.eai.utils.Constants;

@WebService(serviceName = "SmsServiceService")
@SOAPBinding(style = SOAPBinding.Style.RPC)
public class SmsService {

    public static final String SEND_SMS_EI = "sendSmsEI";

    @WebMethod
	public SmsResponse sendSms(@WebParam(name = "smsRequest") SmsRequest smsRequest) {
	    Log.setNewThreadId();
	    Log.setServiceName(SEND_SMS_EI);
	    Log.info("sendSms start");

		SmsResponse response = new SmsResponse();

		try {

			Envelope envelopeIn = new Envelope();
			SynchroneService fatourati = Services.find(Constants.UDDI_OTP_GENERATOR, SynchroneService.class);
			envelopeIn.addNode("flux/action", SEND_SMS_EI);
			envelopeIn.addNode("flux/phone", smsRequest.getPhone());
			envelopeIn.addNode("flux/msg", smsRequest.getMessage());
			envelopeIn = Parser.update(envelopeIn);
			Log.info("Data sent to EJB send SMS : ");
			Log.info(Parser.marshall(envelopeIn));
			Envelope envelopeOut = fatourati.process(envelopeIn);
			Log.info("Call EJB success");
			if (envelopeOut != null) {
				Log.info("Data returned from EJB send sms : " + Parser.update(envelopeOut));
				envelopeOut = Parser.update(envelopeOut);

				response.setCode(envelopeOut.getNodeAsString("flux/code"));
				response.setMessage(envelopeOut.getNodeAsString("flux/message"));

			}

		} catch (Exception e) {
			Log.error(e.getMessage(), e);
			response.setCode("001");
			response.setMessage("Problème technique, veuillez réessayer plus tard");
		}
		return response;

	}

}
