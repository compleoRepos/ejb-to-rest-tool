package ma.eai.models;

public class Accounts {
    private String accountName;
    private String accountPassword;

    public Accounts() {
    }

    public Accounts(String accountName, String accountPassword) {
	this.accountName = accountName;
	this.accountPassword = accountPassword;
    }

    public String getAccountName() {
	return accountName;
    }

    public void setAccountName(String accountName) {
	this.accountName = accountName;
    }

    public String getAccountPassword() {
	return accountPassword;
    }

    public void setAccountPassword(String accountPassword) {
	this.accountPassword = accountPassword;
    }

    @Override
    public String toString() {
	return "Accounts{" + "accountName='" + accountName + '\'' + ", accountPassword='" + accountPassword + '\''
		+ '}';
    }
}
