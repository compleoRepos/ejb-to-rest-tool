package ma.eai.utils;

import ma.eai.midw.log.Log;
import ma.eai.models.Accounts;
import ma.eai.properties.loader.PropsLoader;

import java.util.Map;
import java.util.stream.Collectors;

public class Constants {

    public static final String UDDI_OTP_GENERATOR = "GenerateurOTP";
    //public static final String PROVIDER = Services.find("SMS_PROVIDER", String.class);
    public static final String PROVIDER = "ORANGE"; // Default provider, can be overridden by properties
    public static final Map<String, Accounts> ORANGE_ACCOUNTS = PropsLoader.getInstance().entrySet().stream()
                .filter(entry -> entry.getKey().toString().startsWith("orange."))
            .collect(Collectors.groupingBy(entry -> entry.getKey().toString().split("\\.")[1],
                        Collectors.collectingAndThen(
                                Collectors.toList(),
                                list -> {
                                    String username = null;
                                    String password = null;
                                    for (Map.Entry<Object, Object> entry : list) {
                                        String key = entry.getKey().toString();
                                        if (key.endsWith("username")) {
                                            username = entry.getValue().toString();
                                        } else if (key.endsWith("password")) {
                                            password = entry.getValue().toString();
                                        } else {
                                            Log.error("Unexpected key in properties: ",key);
                                        }
                                    }
                                    return new Accounts(username, password); // accountPassword
                                }
            )));
    public static final Map<String,Accounts> CASANET_ACCOUNTS =PropsLoader.getInstance().entrySet().stream()
                .filter(entry -> entry.getKey().toString().startsWith("casanet."))
            .collect(Collectors.groupingBy(entry -> entry.getKey().toString().split("\\.")[1],
                        Collectors.collectingAndThen(
                                Collectors.toList(),
                                list -> {
                                    String username = null;
                                    String password = null;
                                    for (Map.Entry<Object, Object> entry : list) {
                                        String key = entry.getKey().toString();
                                        if (key.endsWith("username")) {
                                            username = entry.getValue().toString();
                                        } else if (key.endsWith("password")) {
                                            password = entry.getValue().toString();
                                        } else {
                                            Log.error("Unexpected key in properties: ",key);
                                        }
                                    }
                                    return new Accounts(username, password); // accountPassword
                                }
            )));
    public static Accounts getAccount(String canal) {
        Map<String, Accounts> accounts = null;
        if (PROVIDER.isEmpty() || PROVIDER == null) {
            return null;
        }
        //accounts = "ORANGE".equalsIgnoreCase(PROVIDER) ? ORANGE_ACCOUNTS : CASANET_ACCOUNTS;
        accounts = CASANET_ACCOUNTS;
        Log.info("Accounts for provider " + PROVIDER + " : " + accounts);
        if (accounts == null || accounts.isEmpty()) {
	    return null;
        }
        Accounts account = accounts.get(canal);
        Log.info("Account for canal " + canal + " : " + account);
	return account;
    }

}
