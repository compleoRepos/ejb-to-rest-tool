package ma.eai;
import ma.eai.models.SmsRequest;
import ma.eai.models.SmsResponse;
import ma.eai.ws.SmsService;
import ma.eai.models.SmsWSRequest;
import ma.eai.ws.SmsEaiService;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.Parser;
import ma.eai.midw.connectors.SynchroneService;
import ma.eai.midw.integration.Services;
import org.junit.*;
import org.mockito.MockedStatic;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;


public class SmsServicesTest {
    private MockedStatic<Services> mockedServices;
    @Before
    public void setUp() throws Exception {
	mockedServices = mockStatic(Services.class);

	mockedServices.when(() -> Services.find("GenerateurOTP", SynchroneService.class))
		.thenReturn(new SynchroneService() {
		    @Override
		    public Envelope process(Envelope envelope) throws Exception {
			Envelope envelopeOut = Parser.unmarshall("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n"
				+ "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\">\n"
				+ "\t<soap:Header>\n" + "\t\t<x:MidwHeader xmlns:x=\"urn:midw\">\n"
				+ "\t\t\t<x:Crypt>false</x:Crypt>\n" + "\t\t</x:MidwHeader>\n" + "\t</soap:Header>\n"
				+ "\t<soap:Body>\n" + "\t\t<flux>\n" + "\t\t\t<code>1</code>\n" + "\t\t\t<message>1</message>\n"
				+ "\t\t</flux>\n" + "\t</soap:Body>\n" + "</soap:Envelope>");
			return envelopeOut;
		    }
		});

    }
    @After
    public void tearDown() {
	mockedServices.close();
    }
    @Test
    public void testSendSmsEai_Success() throws Exception {
	SmsWSRequest request = new SmsWSRequest();
	request.setPhone("1234567890");
	request.setMessage("Test message");
	request.setLabel("testlabel");

	SmsEaiService smsEaiService = new SmsEaiService();

	SmsResponse response = smsEaiService.sendSmsEai(request);

	assertNotNull(response);
	assertEquals("1", response.getCode());
	assertEquals("1", response.getMessage());

    }

    @Test
    public void testSendSmsEai_Failure() throws Exception {
	SmsWSRequest request = new SmsWSRequest();
	request.setPhone("1234567890");
	request.setMessage("Test message");
	request.setLabel("testlabel");

	SmsEaiService smsEaiService = new SmsEaiService();

	SmsResponse response = smsEaiService.sendSmsEai(request);

	assertNotNull(response);
	assertEquals("1", response.getCode());
	assertTrue(response.getMessage().startsWith("1"));

    }

    @Test
    public void testSendSms_Success() throws Exception {
	SmsRequest request = new SmsRequest();
	request.setPhone("1234567890");
	request.setMessage("Test message");

	SmsService smsService = new SmsService();

	SmsResponse response = smsService.sendSms(request);

	assertNotNull(response);
	assertEquals("1", response.getCode());
	assertEquals("1", response.getMessage());

    }

    @Test
    public void testSendSms_Failure() throws Exception {
	SmsRequest request = new SmsRequest();
	request.setPhone("1234567890");
	request.setMessage("Test message");

	SmsService smsService = new SmsService();
	SmsResponse response = smsService.sendSms(request);

	assertNotNull(response);
	assertEquals("1", response.getCode());
	assertTrue(response.getMessage().startsWith("1"));

    }

    @Test
    public void testSmsWSRequest() {
	SmsWSRequest request = new SmsWSRequest();
	request.setPhone("1234567890");
	request.setMessage("Test message");
	request.setLabel("testlabel");

	assertEquals("1234567890", request.getPhone());
	assertEquals("Test message", request.getMessage());
	assertEquals("testlabel", request.getLabel());
    }

    @Test
    public void testSmsRequest() {
	SmsRequest request = new SmsRequest();
	request.setPhone("1234567890");
	request.setMessage("Test message");

	assertEquals("1234567890", request.getPhone());
	assertEquals("Test message", request.getMessage());
    }

    @Test
    public void testSmsResponse() {
	SmsResponse response = new SmsResponse();
	response.setCode("000");
	response.setMessage("Success");

	assertEquals("000", response.getCode());
	assertEquals("Success", response.getMessage());
    }
}