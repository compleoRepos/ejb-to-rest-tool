package ma.eai.ws;

import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.Parser;
import ma.eai.midw.connectors.SynchroneService;
import ma.eai.midw.integration.Services;
import ma.eai.midw.log.Log;
import ma.eai.models.Accounts;
import ma.eai.models.SmsResponse;
import ma.eai.models.SmsWSRequest;
import ma.eai.utils.Constants;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

@WebService(serviceName = "SmsEaiServiceService")
@SOAPBinding(style = Style.RPC)
public class SmsEaiService {

    public static final String SMS_EAI = "sendSmsEAI";

    @WebMethod
    public SmsResponse sendSmsEai(@WebParam(name = "smsWSRequest") SmsWSRequest smsWSRequest) {
	Log.setNewThreadId();
	Log.setServiceName(SMS_EAI);
	Log.info("sendSmsEai start");
	Log.setUseCase("SMS EAI");
	SmsResponse response = new SmsResponse();

	try {
	    Log.info("Data received from client sendSmsEai : " + smsWSRequest.getPhone() + "  -- Canal: "
		    + smsWSRequest.getCanal() + " -- Label: " + smsWSRequest.getLabel());
	    Envelope envelopeIn = new Envelope();
	    SynchroneService service = Services.find(Constants.UDDI_OTP_GENERATOR, SynchroneService.class);
	    Accounts account = Constants.getAccount(smsWSRequest.getCanal());
	    Log.setUserSas(smsWSRequest.getCanal());
	    if (account == null) {
		Log.error("No account found for canal: " + smsWSRequest.getCanal());
		response.setCode("002");
		return response;
	    }
	    envelopeIn.addNode("flux/action", SMS_EAI);
	    envelopeIn.addNode("flux/phone", smsWSRequest.getPhone());
	    envelopeIn.addNode("flux/msg", smsWSRequest.getMessage());
	    envelopeIn.addNode("flux/usr", account.getAccountName());
	    envelopeIn.addNode("flux/pwd", account.getAccountPassword());
	    envelopeIn.addNode("flux/label", smsWSRequest.getLabel());
	    envelopeIn = Parser.update(envelopeIn);
	    Log.info("Data sent to EJB sendSmsEai SMS : " + smsWSRequest.getPhone() + "  -- User: "
		    + account.getAccountName() + " -- Label: " + smsWSRequest.getLabel());
	    Log.info("envelopeIn: {}", envelopeIn);
	    Envelope envelopeOut = service.process(envelopeIn);
	    Log.info("Call EJB success");
	    if (envelopeOut != null) {
		Log.info("Data returned from EJB sendSmsEai sms : " + Parser.update(envelopeOut));
		envelopeOut = Parser.update(envelopeOut);

		response.setCode(envelopeOut.getNodeAsString("flux/code"));
		response.setMessage(envelopeOut.getNodeAsString("flux/message"));

	    }

	} catch (Exception e) {
	    Log.error(e.getMessage(), e);
	    response.setCode("001");
	    response.setMessage("Problème technique, veuillez réessayer plus tard");
	}
	return response;

    }

}
