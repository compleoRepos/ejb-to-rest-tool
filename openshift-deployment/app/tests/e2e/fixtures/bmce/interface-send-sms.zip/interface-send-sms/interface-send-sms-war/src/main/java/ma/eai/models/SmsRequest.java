package ma.eai.models;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SmsRequest", namespace = "http://beans.eai.ma")
public class SmsRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private String phone;
    private String message;

    public SmsRequest() {
	super();
    }

    public SmsRequest(String phone, String message) {
	this.phone = phone;
	this.message = message;
    }

    public String getPhone() {
	return phone;
    }

    public void setPhone(String phone) {
	this.phone = phone;
    }

    public String getMessage() {
	return message;
    }

    public void setMessage(String message) {
	this.message = message;
    }

}
