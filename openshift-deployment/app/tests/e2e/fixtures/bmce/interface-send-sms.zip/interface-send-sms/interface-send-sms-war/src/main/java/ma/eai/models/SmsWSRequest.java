package ma.eai.models;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SmsWSRequest", namespace = "http://beans.eai.ma")
public class SmsWSRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private String phone;
	private String message;
	private String label;
	private String canal;


    public String getCanal() {
	return canal;
    }

    public void setCanal(String canal) {
	this.canal = canal;
    }
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

    @Override
    public String toString() {
	return "SmsWSRequest{" + "phone='" + phone + '\'' + ", message='" + message + '\'' + ", label='" + label + '\''
		+ ", canal='" + canal + '\'' + '}';
    }
}
