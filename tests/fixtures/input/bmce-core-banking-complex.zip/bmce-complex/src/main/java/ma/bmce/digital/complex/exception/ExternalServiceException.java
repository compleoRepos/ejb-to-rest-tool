package ma.bmce.digital.complex.exception;
public class ExternalServiceException extends Exception {
    public ExternalServiceException(String msg) { super(msg); }
}
