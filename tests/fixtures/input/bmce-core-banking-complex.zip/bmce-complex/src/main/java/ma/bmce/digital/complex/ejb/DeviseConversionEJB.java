package ma.bmce.digital.complex.ejb;

import ma.bmce.digital.complex.exception.TechnicalException;

import javax.ejb.*;
import javax.annotation.Resource;
import javax.sql.DataSource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import java.util.logging.Logger;

/**
 * DeviseConversionEJB — EJB 3.x Singleton.
 * Cache des taux de change BAM actualisés toutes les heures.
 * Source : https://api.bam.ma/market/rates
 * Fallback : Table T_TAUX_CHANGE_HISTORIQUE si API indisponible
 *
 * DataSource : jdbc/BMCE_MARKET_DATA_DS
 */
@Singleton
@Startup
@ConcurrencyManagement(ConcurrencyManagementType.CONTAINER)
@Local(DeviseConversionEJBLocal.class)
public class DeviseConversionEJB implements DeviseConversionEJBLocal {

    private static final Logger LOG =
        Logger.getLogger(DeviseConversionEJB.class.getName());

    private static final String MAD = "MAD";

    private static final String SQL_TAUX_HISTORIQUE =
        "SELECT t.DEVISE_SOURCE, t.DEVISE_CIBLE, t.TAUX_ACHAT, " +
        "  t.TAUX_VENTE, t.TAUX_MOYEN, t.DATE_COURS " +
        "FROM T_TAUX_CHANGE_HISTORIQUE t " +
        "WHERE t.DATE_COURS = (SELECT MAX(DATE_COURS) " +
        "  FROM T_TAUX_CHANGE_HISTORIQUE " +
        "  WHERE DEVISE_SOURCE = ? AND DEVISE_CIBLE = ?) " +
        "  AND t.DEVISE_SOURCE = ? AND t.DEVISE_CIBLE = ?";

    private static final String SQL_INSERT_COURS =
        "INSERT INTO T_TAUX_CHANGE_HISTORIQUE " +
        "  (ID_COURS, DEVISE_SOURCE, DEVISE_CIBLE, TAUX_ACHAT, " +
        "   TAUX_VENTE, TAUX_MOYEN, DATE_COURS, SOURCE) " +
        "VALUES (SEQ_COURS_CHANGE.NEXTVAL, ?, ?, ?, ?, ?, SYSDATE, 'BAM_API')";

    @Resource(name = "jdbc/BMCE_MARKET_DATA_DS")
    private DataSource marketDataDS;

    // Cache en mémoire : "EUR/MAD" → BigDecimal
    private final Map<String, BigDecimal> tauxCache = new HashMap<>();
    private LocalDate dateDernierRafraichissement;

    @javax.annotation.PostConstruct
    public void init() {
        chargerTauxDepuisDB();
    }

    @javax.ejb.Schedule(hour = "*", minute = "0", second = "0",
                        persistent = false)
    public void rafraichirTaux() {
        try {
            chargerTauxDepuisBAMApi();
        } catch (Exception e) {
            LOG.warning("Rafraîchissement taux BAM API échoué: " +
                e.getMessage() + " — conservation du cache");
        }
    }

    @Lock(LockType.READ)
    public BigDecimal getTauxChange(String deviseSource,
            String deviseCible) throws TechnicalException {

        if (deviseSource.equals(deviseCible)) return BigDecimal.ONE;

        String key = deviseSource + "/" + deviseCible;
        BigDecimal taux = tauxCache.get(key);

        if (taux == null) {
            // Recherche triangulaire via MAD
            BigDecimal sourceMAD = tauxCache.get(deviseSource + "/" + MAD);
            BigDecimal cibleMAD  = tauxCache.get(deviseCible + "/" + MAD);

            if (sourceMAD != null && cibleMAD != null &&
                cibleMAD.compareTo(BigDecimal.ZERO) != 0) {
                taux = sourceMAD.divide(cibleMAD, 6, RoundingMode.HALF_UP);
                tauxCache.put(key, taux);
            } else {
                // Fallback base de données
                taux = chargerTauxDepuisDB(deviseSource, deviseCible);
            }
        }

        if (taux == null) {
            throw new TechnicalException("ERR_CHANGE",
                "Taux non disponible: " + deviseSource + "/" + deviseCible);
        }
        return taux;
    }

    @Lock(LockType.READ)
    public BigDecimal convertir(BigDecimal montant, String deviseSource,
            String deviseCible) throws TechnicalException {
        BigDecimal taux = getTauxChange(deviseSource, deviseCible);
        return montant.multiply(taux).setScale(2, RoundingMode.HALF_UP);
    }

    @Lock(LockType.WRITE)
    private void chargerTauxDepuisBAMApi() {
        // GET https://api.bam.ma/market/rates
        // Simulé — en prod, appel REST réel
        Map<String, BigDecimal> newTaux = new HashMap<>();
        newTaux.put("EUR/" + MAD, new BigDecimal("10.8734"));
        newTaux.put("USD/" + MAD, new BigDecimal("9.9612"));
        newTaux.put("GBP/" + MAD, new BigDecimal("12.6891"));
        newTaux.put("CHF/" + MAD, new BigDecimal("11.1234"));
        newTaux.put("JPY/" + MAD, new BigDecimal("0.0671"));
        newTaux.put("SAR/" + MAD, new BigDecimal("2.6556"));
        newTaux.put("AED/" + MAD, new BigDecimal("2.7132"));
        tauxCache.putAll(newTaux);
        dateDernierRafraichissement = LocalDate.now();
        persistTaux(newTaux);
        LOG.info("Taux BAM rafraîchis: " + newTaux.size() + " devises");
    }

    private void chargerTauxDepuisDB() {
        chargerTauxDepuisBAMApi(); // init avec valeurs simulées
    }

    private BigDecimal chargerTauxDepuisDB(String source, String cible) {
        try (Connection conn = marketDataDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     SQL_TAUX_HISTORIQUE)) {
            ps.setString(1, source);
            ps.setString(2, cible);
            ps.setString(3, source);
            ps.setString(4, cible);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getBigDecimal("TAUX_MOYEN");
                }
            }
        } catch (SQLException e) {
            LOG.warning("Taux DB: " + e.getMessage());
        }
        return null;
    }

    private void persistTaux(Map<String, BigDecimal> taux) {
        try (Connection conn = marketDataDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_INSERT_COURS)) {
            for (Map.Entry<String, BigDecimal> e : taux.entrySet()) {
                String[] devises = e.getKey().split("/");
                BigDecimal spread = e.getValue()
                    .multiply(new BigDecimal("0.005"));
                ps.setString(1, devises[0]);
                ps.setString(2, devises[1]);
                ps.setBigDecimal(3, e.getValue().subtract(spread));
                ps.setBigDecimal(4, e.getValue().add(spread));
                ps.setBigDecimal(5, e.getValue());
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (SQLException ex) {
            LOG.warning("Persist taux: " + ex.getMessage());
        }
    }
}
