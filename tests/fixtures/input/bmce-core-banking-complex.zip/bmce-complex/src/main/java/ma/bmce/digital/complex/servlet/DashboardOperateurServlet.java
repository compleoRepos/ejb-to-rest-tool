package ma.bmce.digital.complex.servlet;

import ma.bmce.digital.complex.ejb.*;
import ma.bmce.digital.complex.exception.TechnicalException;

import javax.ejb.EJB;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.logging.Logger;

/**
 * DashboardOperateurServlet — Servlet Java EE.
 * Tableau de bord temps réel pour les opérateurs BMCE back-office.
 *
 * Routes :
 *   GET  /ops/dashboard          — état global du SI
 *   GET  /ops/transactions/live  — transactions en cours
 *   GET  /ops/compliance/alertes — alertes compliance ouvertes
 *   GET  /ops/risk/var           — VaR du jour
 *   POST /ops/transaction/annuler — annuler une transaction
 *   POST /ops/suspens/resoudre   — résoudre un suspens CLO
 */
@WebServlet(
    name = "DashboardOperateurServlet",
    urlPatterns = {
        "/ops/dashboard",
        "/ops/transactions/live",
        "/ops/compliance/alertes",
        "/ops/risk/var",
        "/ops/transaction/annuler",
        "/ops/suspens/resoudre"
    }
)
public class DashboardOperateurServlet extends HttpServlet {

    private static final Logger LOG =
        Logger.getLogger(DashboardOperateurServlet.class.getName());

    @EJB private ComplianceLBCFTEJBLocal complianceService;
    @EJB private RiskManagementEJBLocal  riskService;
    @EJB private VirementSEPAOrchestrateurEJBLocal virementService;
    @EJB private NotificationMulticanalEJBLocal notifService;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        resp.setContentType("application/json;charset=UTF-8");
        String path = req.getServletPath();

        try {
            switch (path) {
                case "/ops/dashboard":
                    handleDashboard(req, resp);
                    break;
                case "/ops/transactions/live":
                    handleTransactionsLive(req, resp);
                    break;
                case "/ops/compliance/alertes":
                    handleComplianceAlertes(req, resp);
                    break;
                case "/ops/risk/var":
                    handleVaR(req, resp);
                    break;
                default:
                    resp.setStatus(404);
                    resp.getWriter().write("{\"error\":\"Route inconnue\"}");
            }
        } catch (TechnicalException e) {
            LOG.severe("Dashboard error: " + e.getMessage());
            resp.setStatus(500);
            resp.getWriter().write(
                "{\"error\":\"" + e.getMessage() +
                "\",\"code\":\"" + e.getCode() + "\"}");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        resp.setContentType("application/json;charset=UTF-8");
        String path = req.getServletPath();

        try {
            switch (path) {
                case "/ops/transaction/annuler":
                    handleAnnulerTransaction(req, resp);
                    break;
                case "/ops/suspens/resoudre":
                    handleResoudreSuspens(req, resp);
                    break;
                default:
                    resp.setStatus(404);
            }
        } catch (Exception e) {
            resp.setStatus(500);
            resp.getWriter().write("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }

    private void handleDashboard(HttpServletRequest req,
            HttpServletResponse resp) throws IOException, TechnicalException {
        // Agréger les indicateurs clés
        resp.getWriter().write("{\"status\":\"OK\",\"nbTransactionsJour\":0," +
            "\"nbAlertesCompliance\":0,\"varJour\":0,\"systemeOperationnel\":true}");
    }

    private void handleTransactionsLive(HttpServletRequest req,
            HttpServletResponse resp) throws IOException, TechnicalException {
        String statut = req.getParameter("statut");
        String devise = req.getParameter("devise");
        LOG.info("Transactions live: statut=" + statut + " devise=" + devise);
        resp.getWriter().write("{\"transactions\":[],\"total\":0}");
    }

    private void handleComplianceAlertes(HttpServletRequest req,
            HttpServletResponse resp) throws IOException, TechnicalException {
        String niveau = req.getParameter("niveau");
        resp.getWriter().write("{\"alertes\":[],\"nbCritiques\":0}");
    }

    private void handleVaR(HttpServletRequest req,
            HttpServletResponse resp) throws IOException, TechnicalException {
        String portefeuille = req.getParameter("portefeuille");
        String methode = req.getParameter("methode") != null
            ? req.getParameter("methode") : "HISTORIQUE";
        if (portefeuille == null) {
            resp.setStatus(400);
            resp.getWriter().write("{\"error\":\"Paramètre portefeuille requis\"}");
            return;
        }
        var result = riskService.calculerVaR(portefeuille, methode);
        resp.getWriter().write(String.format(
            "{\"var99\":%s,\"var95\":%s,\"valeurPortefeuille\":%s}",
            result.getVar99Horizon1j(),
            result.getVar95Horizon1j(),
            result.getValeurPortefeuille()));
    }

    private void handleAnnulerTransaction(HttpServletRequest req,
            HttpServletResponse resp) throws IOException {
        String endToEndId = req.getParameter("endToEndId");
        String motif      = req.getParameter("motif");
        LOG.info("Annulation transaction: " + endToEndId + " motif=" + motif);
        resp.getWriter().write("{\"annule\":true,\"endToEndId\":\"" +
            endToEndId + "\"}");
    }

    private void handleResoudreSuspens(HttpServletRequest req,
            HttpServletResponse resp) throws IOException {
        String idSuspens = req.getParameter("idSuspens");
        String resolution = req.getParameter("resolution");
        LOG.info("Résolution suspens: " + idSuspens);
        resp.getWriter().write("{\"resolu\":true}");
    }
}
