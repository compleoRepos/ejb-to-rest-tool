package ma.bmce.digital.complex.exception;
public class LimiteDepasseeException extends Exception {
    public LimiteDepasseeException(String msg) { super(msg); }
}
