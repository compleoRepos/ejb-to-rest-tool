package ma.bmce.digital.complex.transformer;

import ma.bmce.digital.complex.dto.*;

import javax.enterprise.context.ApplicationScoped;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.logging.Logger;

/**
 * CreditDataTransformer — CDI Bean ApplicationScoped.
 * Transformations des données entre les formats legacy (VoIn/VoOut)
 * et les DTOs internes du moteur de scoring crédit.
 * Applique les normalisations BAM (revenus, garanties, ratios).
 */
@ApplicationScoped
public class CreditDataTransformer {

    private static final Logger LOG =
        Logger.getLogger(CreditDataTransformer.class.getName());

    /**
     * Normalise le revenu selon les règles BAM.
     * Revenu retenu = min(déclaré, CNSS, DGI) × facteur confiance source.
     */
    public BigDecimal normaliserRevenu(BigDecimal revenuDeclare,
            BigDecimal revenuCNSS, BigDecimal revenuDGI,
            String typeProfessionnel) {

        BigDecimal revenuBase = revenuDeclare;
        int nbSources = 1;

        if (revenuCNSS != null && revenuCNSS.compareTo(BigDecimal.ZERO) > 0) {
            revenuBase = revenuBase.min(revenuCNSS);
            nbSources++;
        }
        if (revenuDGI != null && revenuDGI.compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal revenuDGIMensuel = revenuDGI.divide(
                new BigDecimal("12"), 2, RoundingMode.HALF_UP);
            revenuBase = revenuBase.min(revenuDGIMensuel);
            nbSources++;
        }

        // Coefficient de confiance selon le nombre de sources croisées
        BigDecimal coeff = nbSources >= 3
            ? new BigDecimal("0.95")
            : nbSources == 2
                ? new BigDecimal("0.90")
                : new BigDecimal("0.80");

        // Majoration professions libérales (revenus irréguliers)
        if ("LIBERAL".equals(typeProfessionnel)) {
            coeff = coeff.subtract(new BigDecimal("0.10"));
        }
        if ("SALARIE_SECTEUR_PUBLIC".equals(typeProfessionnel)) {
            coeff = coeff.add(new BigDecimal("0.05"))
                .min(BigDecimal.ONE);
        }

        return revenuBase.multiply(coeff).setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * Transforme la note du bureau de crédit (0-1000) vers le
     * format normalisé BMCE (0-100).
     */
    public int normaliserScoreBureau(int scoreBrut, String sourceBureau) {
        switch (sourceBureau) {
            case "CREDIT_BUREAU_MA":
                // Score bureau MArocain : déjà sur 1000, normaliser /10
                return Math.min(100, scoreBrut / 10);
            case "EQUIFAX":
                // Equifax : 300-850, normaliser linéairement
                return (int)(((scoreBrut - 300.0) / (850 - 300)) * 100);
            case "EXPERIAN":
                // Experian : 0-999
                return scoreBrut / 10;
            default:
                return 50; // Neutre si source inconnue
        }
    }

    /**
     * Transforme la demande de crédit vers le format de scoring interne.
     */
    public ScoringRequestVoIn transformerDemande(
            DemandeCreditVoIn demande) {
        return ScoringRequestVoIn.builder()
            .codeClient(demande.getCodeClient())
            .cinClient(demande.getCinClient())
            .idDossier(demande.getIdDossier())
            .montantDemande(demande.getMontantDemande())
            .dureesMois(demande.getDureesMois())
            .typeCredit(demande.getTypeCredit())
            .tauxDemande(demande.getTauxPropose())
            .revenuNetMensuelDeclare(
                normaliserRevenu(
                    demande.getRevenuNetMensuelDeclare(), null, null,
                    demande.getTypeProfessionnel()))
            .build();
    }
}
