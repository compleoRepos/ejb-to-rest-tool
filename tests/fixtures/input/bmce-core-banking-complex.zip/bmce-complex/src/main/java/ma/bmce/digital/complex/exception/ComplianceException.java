package ma.bmce.digital.complex.exception;
public class ComplianceException extends Exception {
    public ComplianceException(String msg) { super(msg); }
}
