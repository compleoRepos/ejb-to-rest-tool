package ma.bmce.digital.complex.exception;

public class TechnicalException extends Exception {
    private final String code;
    public TechnicalException(String code, String message) { super(message); this.code = code; }
    public TechnicalException(String code, String message, Throwable cause) { super(message, cause); this.code = code; }
    public String getCode() { return code; }
}
