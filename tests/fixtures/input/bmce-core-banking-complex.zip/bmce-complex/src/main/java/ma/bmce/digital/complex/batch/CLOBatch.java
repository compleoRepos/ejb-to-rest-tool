package ma.bmce.digital.complex.batch;

import ma.bmce.digital.complex.exception.TechnicalException;

import javax.annotation.Resource;
import javax.batch.api.*;
import javax.batch.api.chunk.*;
import javax.batch.runtime.context.JobContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.jms.*;
import javax.sql.DataSource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * CLOBatch — JSR-352 Job de Clôture Journalière (CLO).
 * Exécuté chaque soir à 23h45 après la fermeture des marchés.
 *
 * Étapes du job :
 *   1. ReconciliationItemReader  — lire toutes les transactions du jour
 *   2. CLOItemProcessor          — calculer P&L, intérêts, commissions
 *   3. CLOItemWriter             — écrire écritures comptables + SWIFT
 *
 * Règles de réconciliation :
 *   - Chaque transaction doit avoir une contrepartie comptable
 *   - Suspens > 48h → alerter le back-office
 *   - Écart de réconciliation > 1 MAD → bloquer la clôture
 *   - Transactions SWIFT non confirmées → queue NOSTRO_SUSPENS
 *
 * DataSources : jdbc/BMCE_CORE_DS, jdbc/BMCE_SWIFT_DS, jdbc/BMCE_RISK_DS
 * JMS : jms/queue/SUSPENS_CLO, jms/topic/CLO_EVENTS
 */
public class CLOBatch {

    @Named("CLOItemReader")
    public static class CLOItemReader extends AbstractItemReader {

        private static final Logger LOG =
            Logger.getLogger(CLOItemReader.class.getName());

        private static final String SQL_TRANSACTIONS_JOUR =
            "SELECT t.ID_TRANS, t.END_TO_END_ID, t.TYPE_TRANSACTION, " +
            "  t.IBAN_DEBITEUR, t.IBAN_CREDITEUR, t.MONTANT, t.DEVISE, " +
            "  t.DATE_COMPTABLE, t.STATUT, t.CODE_RETOUR_SWIFT, " +
            "  t.CANAL_ROUTAGE, t.DATE_CREATION, " +
            "  NVL(e.NB_ECRITURES, 0) AS NB_ECRITURES_COMPTABLES " +
            "FROM T_TRANSACTIONS_SEPA t " +
            "LEFT JOIN (" +
            "  SELECT REFERENCE_EXTERNE, COUNT(*) AS NB_ECRITURES " +
            "  FROM T_ECRITURES_COMPTABLES " +
            "  WHERE TRUNC(DATE_COMPTABLE) = TRUNC(SYSDATE) " +
            "  GROUP BY REFERENCE_EXTERNE) e " +
            "    ON e.REFERENCE_EXTERNE = TO_CHAR(t.ID_TRANS) " +
            "WHERE TRUNC(t.DATE_CREATION) = TRUNC(SYSDATE) " +
            "  AND t.STATUT NOT IN ('ANNULE') " +
            "ORDER BY t.DATE_CREATION ASC";

        @Resource(name = "jdbc/BMCE_CORE_DS")
        private DataSource coreDS;

        @Inject
        private JobContext jobContext;

        private Connection   connection;
        private PreparedStatement ps;
        private ResultSet    cursor;
        private int          processed = 0;

        @Override
        public void open(java.io.Serializable checkpoint) throws Exception {
            connection = coreDS.getConnection();
            ps = connection.prepareStatement(SQL_TRANSACTIONS_JOUR,
                ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
            ps.setFetchSize(200);
            cursor = ps.executeQuery();

            if (checkpoint instanceof Integer) {
                processed = (Integer) checkpoint;
                for (int i = 0; i < processed && cursor.next(); i++) {}
                LOG.info("CLO reprise depuis position: " + processed);
            }
            LOG.info("CLOItemReader ouvert — traitement clôture " +
                LocalDate.now());
        }

        @Override
        public CLOTransactionItem readItem() throws Exception {
            if (!cursor.next()) return null;

            CLOTransactionItem item = new CLOTransactionItem();
            item.idTrans           = cursor.getLong("ID_TRANS");
            item.endToEndId        = cursor.getString("END_TO_END_ID");
            item.typeTransaction   = cursor.getString("TYPE_TRANSACTION");
            item.ibanDebiteur      = cursor.getString("IBAN_DEBITEUR");
            item.ibanCrediteur     = cursor.getString("IBAN_CREDITEUR");
            item.montant           = cursor.getBigDecimal("MONTANT");
            item.devise            = cursor.getString("DEVISE");
            item.dateComptable     = cursor.getDate("DATE_COMPTABLE") != null
                ? cursor.getDate("DATE_COMPTABLE").toLocalDate() : null;
            item.statut            = cursor.getString("STATUT");
            item.codeRetourSWIFT   = cursor.getString("CODE_RETOUR_SWIFT");
            item.canalRoutage      = cursor.getString("CANAL_ROUTAGE");
            item.nbEcrituresComptables = cursor.getInt("NB_ECRITURES_COMPTABLES");
            processed++;
            return item;
        }

        @Override
        public java.io.Serializable checkpointInfo() {
            return processed;
        }

        @Override
        public void close() throws Exception {
            if (cursor    != null) cursor.close();
            if (ps        != null) ps.close();
            if (connection != null) connection.close();
        }
    }

    // ────────────────────────────────────────────────────────────

    @Named("CLOItemProcessor")
    public static class CLOItemProcessor implements ItemProcessor {

        private static final Logger LOG =
            Logger.getLogger(CLOItemProcessor.class.getName());

        @Override
        public CLOTransactionItem processItem(Object obj) throws Exception {
            CLOTransactionItem item = (CLOTransactionItem) obj;

            // Règle 1 : Vérifier cohérence écritures comptables
            if (item.nbEcrituresComptables < 2) {
                item.ecartReconciliation  = true;
                item.motifEcart = "ECRITURES_COMPTABLES_MANQUANTES (" +
                    item.nbEcrituresComptables + "/2 attendues)";
                LOG.warning("Suspens CLO: " + item.endToEndId +
                    " — " + item.motifEcart);
            }

            // Règle 2 : Transaction SWIFT non confirmée
            if ("ENVOYE_TARGET2_STANDARD".equals(item.statut) ||
                "ENVOYE_SIMT".equals(item.statut)) {
                if (item.codeRetourSWIFT == null ||
                    !item.codeRetourSWIFT.contains("ACK")) {
                    item.swiftNonConfirme = true;
                    item.motifEcart = "SWIFT_ACK_MANQUANT statut=" + item.statut;
                }
            }

            // Règle 3 : Calcul commission sur transaction
            item.commissionCalculee = calculerCommission(item);

            // Règle 4 : Frais change si devise != MAD
            if (!"MAD".equals(item.devise)) {
                item.fraisChange = item.montant
                    .multiply(new BigDecimal("0.001"))
                    .setScale(2, RoundingMode.HALF_UP);
            }

            return item;
        }

        private BigDecimal calculerCommission(CLOTransactionItem item) {
            if (item.montant == null) return BigDecimal.ZERO;
            // Commission dégressive selon montant
            if (item.montant.compareTo(new BigDecimal("1000000")) > 0) {
                return item.montant.multiply(new BigDecimal("0.00010"));
            } else if (item.montant.compareTo(new BigDecimal("100000")) > 0) {
                return item.montant.multiply(new BigDecimal("0.00015"));
            } else {
                return item.montant.multiply(new BigDecimal("0.00020"))
                    .max(new BigDecimal("15.00"))
                    .min(new BigDecimal("500.00"));
            }
        }
    }

    // ────────────────────────────────────────────────────────────

    @Named("CLOItemWriter")
    public static class CLOItemWriter extends AbstractItemWriter {

        private static final Logger LOG =
            Logger.getLogger(CLOItemWriter.class.getName());

        private static final String SQL_INSERT_COMMISSION =
            "INSERT INTO T_COMMISSIONS_CLO " +
            "  (ID_COMM, ID_TRANS, DATE_CLO, MONTANT_COMMISSION, " +
            "   FRAIS_CHANGE, STATUT) " +
            "VALUES (SEQ_COMMISSIONS.NEXTVAL, ?, SYSDATE, ?, ?, 'CALCULE')";

        private static final String SQL_INSERT_SUSPENS =
            "INSERT INTO T_SUSPENS_CLO " +
            "  (ID_SUSPENS, END_TO_END_ID, MOTIF, DATE_DETECTION, " +
            "   STATUT, DATE_ECHEANCE) " +
            "VALUES (SEQ_SUSPENS.NEXTVAL, ?, ?, SYSDATE, 'OUVERT', SYSDATE + 2)";

        private static final String SQL_UPDATE_TRANS_CLO =
            "UPDATE T_TRANSACTIONS_SEPA SET " +
            "  STATUT_CLO = 'TRAITE', DATE_CLO = SYSDATE " +
            "WHERE ID_TRANS = ?";

        @Resource(name = "jdbc/BMCE_CORE_DS")
        private DataSource coreDS;

        @Resource(name = "jms/ConnectionFactory")
        private ConnectionFactory jmsFactory;

        @Resource(name = "jms/queue/SUSPENS_CLO")
        private Queue suspensQueue;

        @Resource(name = "jms/topic/CLO_EVENTS")
        private Topic cloEventsTopic;

        @Override
        public void writeItems(List<Object> items) throws Exception {
            LOG.info("CLOItemWriter — écriture de " + items.size() + " items");

            int nbSuspens  = 0;
            BigDecimal totalCommissions = BigDecimal.ZERO;

            try (Connection conn = coreDS.getConnection()) {
                conn.setAutoCommit(false);

                try (PreparedStatement psComm =
                        conn.prepareStatement(SQL_INSERT_COMMISSION);
                     PreparedStatement psSusp =
                        conn.prepareStatement(SQL_INSERT_SUSPENS);
                     PreparedStatement psUpdate =
                        conn.prepareStatement(SQL_UPDATE_TRANS_CLO)) {

                    for (Object obj : items) {
                        CLOTransactionItem item = (CLOTransactionItem) obj;

                        // Commissions
                        if (item.commissionCalculee != null &&
                            item.commissionCalculee.compareTo(BigDecimal.ZERO) > 0) {
                            psComm.setLong(1, item.idTrans);
                            psComm.setBigDecimal(2, item.commissionCalculee);
                            psComm.setBigDecimal(3,
                                item.fraisChange != null
                                    ? item.fraisChange : BigDecimal.ZERO);
                            psComm.addBatch();
                            totalCommissions = totalCommissions
                                .add(item.commissionCalculee);
                        }

                        // Suspens
                        if (item.ecartReconciliation || item.swiftNonConfirme) {
                            psSusp.setString(1, item.endToEndId);
                            psSusp.setString(2, item.motifEcart);
                            psSusp.addBatch();
                            nbSuspens++;
                            publierAlerteSuspens(item);
                        }

                        // Marquer transaction CLO
                        psUpdate.setLong(1, item.idTrans);
                        psUpdate.addBatch();
                    }

                    psComm.executeBatch();
                    psSusp.executeBatch();
                    psUpdate.executeBatch();
                    conn.commit();

                } catch (Exception e) {
                    conn.rollback();
                    throw e;
                }
            }

            // Broadcast fin CLO
            broadcastCloEvent(items.size(), nbSuspens, totalCommissions);

            LOG.info("CLO batch: " + items.size() + " transactions traitées, " +
                nbSuspens + " suspens, commissions=" + totalCommissions);
        }

        private void publierAlerteSuspens(CLOTransactionItem item) {
            try (JMSContext ctx = jmsFactory.createContext()) {
                String payload = String.format(
                    "{\"endToEndId\":\"%s\",\"motif\":\"%s\"," +
                    "\"montant\":%s,\"devise\":\"%s\"}",
                    item.endToEndId, item.motifEcart,
                    item.montant, item.devise);
                ctx.createProducer().send(suspensQueue, payload);
            } catch (Exception e) {
                LOG.warning("JMS suspens: " + e.getMessage());
            }
        }

        private void broadcastCloEvent(int nbTraites, int nbSuspens,
                BigDecimal totalCommissions) {
            try (JMSContext ctx = jmsFactory.createContext()) {
                String event = String.format(
                    "{\"event\":\"CLO_COMPLETE\",\"date\":\"%s\"," +
                    "\"nbTraites\":%d,\"nbSuspens\":%d," +
                    "\"totalCommissions\":%s}",
                    LocalDate.now(), nbTraites, nbSuspens, totalCommissions);
                ctx.createProducer().send(cloEventsTopic, event);
            } catch (Exception e) {
                LOG.warning("CLO broadcast: " + e.getMessage());
            }
        }
    }

    // ── Item de données ──────────────────────────────────────

    public static class CLOTransactionItem implements java.io.Serializable {
        public long         idTrans;
        public String       endToEndId;
        public String       typeTransaction;
        public String       ibanDebiteur;
        public String       ibanCrediteur;
        public BigDecimal   montant;
        public String       devise;
        public LocalDate    dateComptable;
        public String       statut;
        public String       codeRetourSWIFT;
        public String       canalRoutage;
        public int          nbEcrituresComptables;
        public boolean      ecartReconciliation;
        public boolean      swiftNonConfirme;
        public String       motifEcart;
        public BigDecimal   commissionCalculee;
        public BigDecimal   fraisChange;
    }

    // ── Job Listeners ──────────────────────────────────────

    @Named("CLOJobListener")
    public static class CLOJobListener extends AbstractJobListener {

        private static final Logger LOG =
            Logger.getLogger(CLOJobListener.class.getName());

        @Inject
        private JobContext jobContext;

        @Override
        public void beforeJob() {
            LOG.info("=== DEBUT CLO " + LocalDate.now() +
                " JobID=" + jobContext.getExecutionId() + " ===");
        }

        @Override
        public void afterJob() {
            LOG.info("=== FIN CLO " + LocalDate.now() +
                " JobID=" + jobContext.getExecutionId() +
                " Status=" + jobContext.getBatchStatus() + " ===");
        }
    }

    @Named("CLOStepListener")
    public static class CLOStepListener extends AbstractStepListener {

        @Inject
        private javax.batch.runtime.context.StepContext stepContext;

        @Override
        public void beforeStep() {
            Logger.getLogger(getClass().getName()).info(
                "CLO Step début: " + stepContext.getStepName());
        }

        @Override
        public void afterStep() {
            Logger.getLogger(getClass().getName()).info(
                "CLO Step fin: " + stepContext.getStepName() +
                " status=" + stepContext.getBatchStatus());
        }
    }
}
