package ma.bmce.digital.complex.ejb;

import ma.bmce.digital.complex.dto.*;
import ma.bmce.digital.complex.exception.*;
import ma.bmce.digital.complex.transformer.CreditDataTransformer;

import javax.ejb.*;
import javax.annotation.Resource;
import javax.inject.Inject;
import javax.sql.DataSource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.*;
import java.time.LocalDate;
import java.time.Period;
import java.util.*;
import java.util.logging.Logger;

/**
 * CreditScoringEJB — EJB 3.x Stateless.
 * Moteur de scoring crédit BMCE basé sur le modèle Basel III.
 * Calcule le score de risque crédit en croisant 7 sources de données :
 *   1. Historique interne BMCE (jdbc/BMCE_CORE_DS)
 *   2. Bureau de crédit (CREDIT_BUREAU_DS via IBM DB2)
 *   3. Données comportementales (jdbc/BMCE_ANALYTICS_DS)
 *   4. Score BAM (BAM REST API)
 *   5. Données CNSS (CNSS SOAP WebService)
 *   6. DGI revenus fiscaux (DGI SOAP WebService)
 *   7. Registre foncier (ANCFCC REST API)
 *
 * Règles métier :
 *   - Plafond endettement BAM : 45% du revenu net
 *   - Score minimum octroi : 620 / 1000
 *   - Décote immobilier : -15% sur valeur expertise si > 3 ans
 *   - Sur-pondération risque secteur : BTP +20%, Agriculture +15%
 *   - Règle jeune client (< 24 mois d'historique) : malus -50 pts
 *
 * DataSources : jdbc/BMCE_CORE_DS, jdbc/BMCE_ANALYTICS_DS, jdbc/CREDIT_BUREAU_DS
 * APIs : url/CNSS_WSDL, url/DGI_WSDL, https://api.ancfcc.ma/foncier
 * JMS : jms/queue/SCORING_REQUESTS, jms/topic/SCORING_RESULTS
 */
@Stateless
@Local(CreditScoringEJBLocal.class)
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class CreditScoringEJB implements CreditScoringEJBLocal {

    private static final Logger LOG =
        Logger.getLogger(CreditScoringEJB.class.getName());

    // ── Score thresholds ──────────────────────────────────────
    private static final int    SCORE_MIN_OCTROI       = 620;
    private static final int    SCORE_MAX              = 1000;
    private static final BigDecimal TAUX_ENDETTEMENT_BAM = new BigDecimal("0.45");
    private static final BigDecimal DECOTE_EXPERTISE_3ANS = new BigDecimal("0.15");
    private static final BigDecimal SURPONDERE_BTP        = new BigDecimal("0.20");
    private static final BigDecimal SURPONDERE_AGRI       = new BigDecimal("0.15");
    private static final int    MALUS_JEUNE_CLIENT     = 50;
    private static final int    MOIS_HISTORIQUE_MIN    = 24;

    // ── SQL Queries ───────────────────────────────────────────
    private static final String SQL_HISTORIQUE_CLIENT =
        "SELECT c.CODE_CLIENT, c.DATE_CREATION, " +
        "  COUNT(DISTINCT cr.ID_CREDIT) AS NB_CREDITS_ACTIFS, " +
        "  SUM(cr.MENSUALITE) AS TOTAL_MENSUALITES, " +
        "  SUM(cr.CAPITAL_RESTANT) AS TOTAL_ENCOURS, " +
        "  MAX(cr.NB_JOURS_RETARD) AS MAX_RETARD_JOURS, " +
        "  COUNT(CASE WHEN cr.NB_JOURS_RETARD > 90 THEN 1 END) AS NB_CREDITS_CONTENTIEUX, " +
        "  AVG(cr.TAUX_INTERET) AS TAUX_MOYEN " +
        "FROM T_CLIENTS c " +
        "LEFT JOIN T_CREDITS cr ON cr.CODE_CLIENT = c.CODE_CLIENT " +
        "  AND cr.STATUT NOT IN ('SOLDE', 'ANNULE') " +
        "WHERE c.CODE_CLIENT = ? " +
        "GROUP BY c.CODE_CLIENT, c.DATE_CREATION";

    private static final String SQL_MOUVEMENTS_12M =
        "SELECT " +
        "  COUNT(*) AS NB_MOUVEMENTS, " +
        "  AVG(CASE WHEN m.TYPE_MVT = 'CREDIT' THEN m.MONTANT END) AS CREDIT_MOYEN, " +
        "  SUM(CASE WHEN m.TYPE_MVT = 'CREDIT' THEN m.MONTANT ELSE 0 END) AS TOTAL_CREDITS_12M, " +
        "  MIN(s.SOLDE_MINIMUM_MOIS) AS SOLDE_MIN_12M, " +
        "  COUNT(CASE WHEN m.CODE_MOTIF = 'IMPAYE' THEN 1 END) AS NB_IMPAYES, " +
        "  COUNT(CASE WHEN m.CODE_MOTIF = 'REJET_CHEQUE' THEN 1 END) AS NB_REJETS " +
        "FROM T_MOUVEMENTS m " +
        "JOIN T_SOLDES_MENSUELS s ON s.NUM_COMPTE = m.NUM_COMPTE " +
        "  AND TRUNC(s.DATE_SOLDE, 'MM') = TRUNC(m.DATE_OPERATION, 'MM') " +
        "WHERE m.NUM_COMPTE IN (" +
        "  SELECT NUM_COMPTE FROM T_COMPTES WHERE CODE_CLIENT = ?) " +
        "  AND m.DATE_OPERATION >= ADD_MONTHS(SYSDATE, -12)";

    private static final String SQL_GARANTIES =
        "SELECT g.TYPE_GARANTIE, g.VALEUR_EXPERTISE, " +
        "  g.DATE_EXPERTISE, g.VALEUR_RETENUE, " +
        "  NVL(h.TAUX_DEPRECIATION, 0) AS TAUX_DEPRECIATION " +
        "FROM T_GARANTIES g " +
        "LEFT JOIN T_HISTORIQUE_GARANTIES h ON h.ID_GARANTIE = g.ID_GARANTIE " +
        "  AND h.DATE_VALUATION = (SELECT MAX(DATE_VALUATION) " +
        "    FROM T_HISTORIQUE_GARANTIES WHERE ID_GARANTIE = g.ID_GARANTIE) " +
        "WHERE g.CODE_CLIENT = ? AND g.STATUT = 'ACTIVE'";

    private static final String SQL_INSERT_SCORE =
        "INSERT INTO T_SCORES_CREDIT " +
        "  (ID_SCORE, CODE_CLIENT, ID_DOSSIER, DATE_SCORE, " +
        "   SCORE_GLOBAL, SCORE_COMPORTEMENTAL, SCORE_FINANCIER, " +
        "   SCORE_GARANTIES, SCORE_BUREAU, DECISION, " +
        "   TAUX_ENDETTEMENT, CAPACITE_REMBOURSEMENT, " +
        "   MOTIFS_REFUS, VALIDITE_JOURS, STATUT) " +
        "VALUES (SEQ_SCORES.NEXTVAL, ?, ?, SYSDATE, " +
        "        ?, ?, ?, ?, ?, ?, ?, ?, ?, 90, 'VALIDE')";

    private static final String SQL_SECTEUR_ACTIVITE =
        "SELECT e.CODE_SECTEUR, e.CHIFFRE_AFFAIRES_ANNUEL, " +
        "  e.DATE_CREATION_ENTREPRISE, e.NB_EMPLOYES " +
        "FROM T_ENTREPRISES e " +
        "WHERE e.CODE_CLIENT = ? AND e.STATUT = 'ACTIF'";

    // ── DataSources ───────────────────────────────────────────
    @Resource(name = "jdbc/BMCE_CORE_DS")
    private DataSource coreDS;

    @Resource(name = "jdbc/BMCE_ANALYTICS_DS")
    private DataSource analyticsDS;

    @Resource(name = "jdbc/CREDIT_BUREAU_DS")
    private DataSource bureauDS;

    // ── Dépendances EJB ───────────────────────────────────────
    @EJB
    private RiskManagementEJBLocal riskManager;

    @EJB
    private ClientProfilingEJBLocal clientProfiler;

    @EJB
    private DocumentValidationEJBLocal docValidator;

    @Inject
    private CreditDataTransformer transformer;

    // ── Méthodes métier ───────────────────────────────────────

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public ScoringResultVoOut calculerScoreCredit(ScoringRequestVoIn voIn)
            throws ClientNotFoundException, DossierInvalidException,
                   ExternalServiceException, TechnicalException {

        LOG.info("calculerScoreCredit: client=" + voIn.getCodeClient() +
                 " montant=" + voIn.getMontantDemande() +
                 " duree=" + voIn.getDureesMois() + " mois");

        validateDossier(voIn);

        ScoringContext ctx = new ScoringContext();
        ctx.voIn = voIn;

        try {
            // Phase 1 — Collecte données internes (parallèle logique)
            collecterHistoriqueClient(ctx);
            collecterDonneesComportementales(ctx);
            collecterGaranties(ctx);
            collecterSecteurActivite(ctx);

            // Phase 2 — Collecte données externes
            collecterDonneesBureau(ctx);
            collecterRevenusExternesAsync(ctx);  // CNSS + DGI

            // Phase 3 — Calcul des sous-scores
            ctx.scoreComportemental  = calculerScoreComportemental(ctx);
            ctx.scoreFinancier       = calculerScoreFinancier(ctx);
            ctx.scoreGaranties       = calculerScoreGaranties(ctx);
            ctx.scoreBureau          = calculerScoreBureau(ctx);

            // Phase 4 — Score global pondéré (Basel III weights)
            ctx.scoreGlobal = calculerScoreGlobalPondere(ctx);

            // Phase 5 — Application règles métier BAM/BMCE
            appliquerReglesMetier(ctx);

            // Phase 6 — Décision finale
            ScoringResultVoOut result = construireResultat(ctx);

            // Phase 7 — Persistance
            persisterScore(ctx, result);

            // Phase 8 — Notification asynchrone
            notifierResultatAsync(ctx, result);

            LOG.info("Score calculé: " + ctx.scoreGlobal +
                     " Décision: " + result.getDecision());
            return result;

        } catch (ExternalServiceException e) {
            // Scoring dégradé si services externes indisponibles
            LOG.warning("Service externe indisponible: " + e.getMessage() +
                        " — Score dégradé appliqué");
            return calculerScoreDegradeSansExterne(ctx);
        }
    }

    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<ScoringHistoriqueVoOut> getHistoriqueScores(
            String codeClient, int nombreScores)
            throws TechnicalException {

        List<ScoringHistoriqueVoOut> historique = new ArrayList<>();

        String sql = "SELECT s.ID_SCORE, s.DATE_SCORE, s.SCORE_GLOBAL, " +
            "  s.DECISION, s.TAUX_ENDETTEMENT, s.STATUT " +
            "FROM T_SCORES_CREDIT s " +
            "WHERE s.CODE_CLIENT = ? " +
            "ORDER BY s.DATE_SCORE DESC " +
            "FETCH FIRST ? ROWS ONLY";

        try (Connection conn = coreDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, codeClient);
            ps.setInt(2, nombreScores);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ScoringHistoriqueVoOut item =
                        ScoringHistoriqueVoOut.builder()
                        .idScore(rs.getLong("ID_SCORE"))
                        .dateScore(rs.getDate("DATE_SCORE").toLocalDate())
                        .scoreGlobal(rs.getInt("SCORE_GLOBAL"))
                        .decision(rs.getString("DECISION"))
                        .tauxEndettement(rs.getBigDecimal("TAUX_ENDETTEMENT"))
                        .statut(rs.getString("STATUT"))
                        .build();
                    historique.add(item);
                }
            }
        } catch (SQLException e) {
            throw new TechnicalException("ERR_SCR_001", e.getMessage(), e);
        }
        return historique;
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public SimulationCreditVoOut simulerCredit(SimulationCreditVoIn voIn)
            throws TechnicalException {

        LOG.info("simulerCredit: montant=" + voIn.getMontant() +
                 " duree=" + voIn.getDureesMois() +
                 " type=" + voIn.getTypeCredit());

        // Calcul mensualité selon type de crédit
        BigDecimal mensualite = calculerMensualite(
            voIn.getMontant(), voIn.getTauxAnnuel(), voIn.getDureesMois(),
            voIn.getTypeCredit()
        );

        // Coût total du crédit
        BigDecimal coutTotal = mensualite.multiply(
            new BigDecimal(voIn.getDureesMois())).subtract(voIn.getMontant());

        // Tableau d'amortissement simplifié (premiers et derniers mois)
        List<LigneAmortissementDTO> tableau =
            genererTableauAmortissement(voIn, mensualite);

        // Assurances obligatoires
        BigDecimal primeAssuranceVie  = calculerAssuranceVie(voIn);
        BigDecimal primeAssuranceIncap = calculerAssuranceIncapacite(voIn);

        // Frais de dossier et inscription hypothécaire
        BigDecimal fraisDossier      = calculerFraisDossier(voIn);
        BigDecimal fraisInscription  = calculerFraisInscriptionHypotheque(voIn);

        // TEG (Taux Effectif Global) conforme BAM
        BigDecimal teg = calculerTEG(voIn.getMontant(), mensualite,
            voIn.getDureesMois(), primeAssuranceVie, primeAssuranceIncap,
            fraisDossier);

        return SimulationCreditVoOut.builder()
            .montant(voIn.getMontant())
            .dureesMois(voIn.getDureesMois())
            .tauxNominal(voIn.getTauxAnnuel())
            .teg(teg)
            .mensualiteHorsAssurance(mensualite)
            .mensualiteAssuranceVie(primeAssuranceVie)
            .mensualiteAssuranceIncap(primeAssuranceIncap)
            .mensualiteTotale(mensualite.add(primeAssuranceVie)
                .add(primeAssuranceIncap))
            .coutTotalCredit(coutTotal)
            .fraisDossier(fraisDossier)
            .fraisInscriptionHypotheque(fraisInscription)
            .tableauAmortissement(tableau)
            .dateSimulation(LocalDate.now())
            .build();
    }

    // ── Implémentations privées ────────────────────────────────

    private void collecterHistoriqueClient(ScoringContext ctx)
            throws TechnicalException {
        try (Connection conn = coreDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_HISTORIQUE_CLIENT)) {
            ps.setString(1, ctx.voIn.getCodeClient());
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new TechnicalException("ERR_CLIENT_NF",
                        "Client non trouvé: " + ctx.voIn.getCodeClient());
                }
                ctx.dateCreationClient = rs.getDate("DATE_CREATION").toLocalDate();
                ctx.nbCreditsActifs    = rs.getInt("NB_CREDITS_ACTIFS");
                ctx.totalMensualites   = rs.getBigDecimal("TOTAL_MENSUALITES");
                ctx.totalEncours       = rs.getBigDecimal("TOTAL_ENCOURS");
                ctx.maxRetardJours     = rs.getInt("MAX_RETARD_JOURS");
                ctx.nbCreditsContentieux = rs.getInt("NB_CREDITS_CONTENTIEUX");
                ctx.tauxMoyenCredits   = rs.getBigDecimal("TAUX_MOYEN");
            }
        } catch (SQLException e) {
            throw new TechnicalException("ERR_SCR_002", e.getMessage(), e);
        }
    }

    private void collecterDonneesComportementales(ScoringContext ctx)
            throws TechnicalException {
        try (Connection conn = analyticsDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_MOUVEMENTS_12M)) {
            ps.setString(1, ctx.voIn.getCodeClient());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ctx.nbMouvements12m   = rs.getInt("NB_MOUVEMENTS");
                    ctx.creditMoyen12m    = rs.getBigDecimal("CREDIT_MOYEN");
                    ctx.totalCredits12m   = rs.getBigDecimal("TOTAL_CREDITS_12M");
                    ctx.soldeMin12m       = rs.getBigDecimal("SOLDE_MIN_12M");
                    ctx.nbImpayes12m      = rs.getInt("NB_IMPAYES");
                    ctx.nbRejets12m       = rs.getInt("NB_REJETS");
                }
            }
        } catch (SQLException e) {
            throw new TechnicalException("ERR_SCR_003", e.getMessage(), e);
        }
    }

    private void collecterGaranties(ScoringContext ctx)
            throws TechnicalException {
        ctx.garanties = new ArrayList<>();
        try (Connection conn = coreDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_GARANTIES)) {
            ps.setString(1, ctx.voIn.getCodeClient());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    GarantieDTO g = GarantieDTO.builder()
                        .typeGarantie(rs.getString("TYPE_GARANTIE"))
                        .valeurExpertise(rs.getBigDecimal("VALEUR_EXPERTISE"))
                        .dateExpertise(rs.getDate("DATE_EXPERTISE").toLocalDate())
                        .valeurRetenue(rs.getBigDecimal("VALEUR_RETENUE"))
                        .tauxDepreciation(rs.getBigDecimal("TAUX_DEPRECIATION"))
                        .build();
                    ctx.garanties.add(g);
                }
            }
        } catch (SQLException e) {
            throw new TechnicalException("ERR_SCR_004", e.getMessage(), e);
        }
    }

    private void collecterSecteurActivite(ScoringContext ctx)
            throws TechnicalException {
        try (Connection conn = coreDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_SECTEUR_ACTIVITE)) {
            ps.setString(1, ctx.voIn.getCodeClient());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ctx.codeSecteur    = rs.getString("CODE_SECTEUR");
                    ctx.chiffreAffaires = rs.getBigDecimal("CHIFFRE_AFFAIRES_ANNUEL");
                    ctx.dateCreationEntreprise =
                        rs.getDate("DATE_CREATION_ENTREPRISE").toLocalDate();
                    ctx.nbEmployes     = rs.getInt("NB_EMPLOYES");
                }
            }
        } catch (SQLException e) {
            throw new TechnicalException("ERR_SCR_005", e.getMessage(), e);
        }
    }

    private void collecterDonneesBureau(ScoringContext ctx) {
        // IBM DB2 LUW — Credit Bureau SCORES
        String sqlBureau =
            "SELECT b.SCORE_BUREAU, b.NB_INCIDENTS, " +
            "  b.DATE_DERNIER_INCIDENT, b.MONTANT_INCIDENTS, " +
            "  b.NB_DEMANDES_CREDIT_6M, b.CLASSE_RISQUE " +
            "FROM BUREAU_DB2.T_SCORES_BUREAU b " +
            "WHERE b.CIN_CLIENT = ? " +
            "  AND b.DATE_SCORE >= ADD_MONTHS(CURRENT_DATE, -6) " +
            "ORDER BY b.DATE_SCORE DESC " +
            "FETCH FIRST 1 ROWS ONLY";

        try (Connection conn = bureauDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(sqlBureau)) {
            ps.setString(1, ctx.voIn.getCinClient());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ctx.scoreBureauExterne  = rs.getInt("SCORE_BUREAU");
                    ctx.nbIncidentsBureau   = rs.getInt("NB_INCIDENTS");
                    ctx.montantIncidents    = rs.getBigDecimal("MONTANT_INCIDENTS");
                    ctx.nbDemandesCredit6m  = rs.getInt("NB_DEMANDES_CREDIT_6M");
                    ctx.classeRisqueBureau  = rs.getString("CLASSE_RISQUE");
                }
            }
        } catch (Exception e) {
            LOG.warning("Bureau indisponible: " + e.getMessage() +
                        " — score bureau ignoré");
            ctx.bureauIndisponible = true;
        }
    }

    private void collecterRevenusExternesAsync(ScoringContext ctx) {
        // Appel CNSS SOAP — Revenus déclarés
        // URL : url/CNSS_WSDL
        try {
            ctx.revenuNetCNSS = appellerCNSSSoap(ctx.voIn.getCinClient());
        } catch (Exception e) {
            LOG.warning("CNSS indisponible: " + e.getMessage());
            ctx.cnssIndisponible = true;
        }

        // Appel DGI SOAP — Revenus fiscaux
        // URL : url/DGI_WSDL
        try {
            ctx.revenuFiscalDGI = appellerDGISoap(ctx.voIn.getCinClient());
        } catch (Exception e) {
            LOG.warning("DGI indisponible: " + e.getMessage());
            ctx.dgiIndisponible = true;
        }

        // Revenu retenu = min(CNSS, DGI, Déclaré) * facteur de confiance
        ctx.revenuRetenu = calculerRevenuRetenu(ctx);
    }

    private int calculerScoreComportemental(ScoringContext ctx) {
        int score = 500; // Base

        // Ancienneté client (max +100 pts)
        int moisAnciennete = Period.between(ctx.dateCreationClient,
            LocalDate.now()).getYears() * 12 +
            Period.between(ctx.dateCreationClient, LocalDate.now()).getMonths();

        if (moisAnciennete < MOIS_HISTORIQUE_MIN) {
            score -= MALUS_JEUNE_CLIENT;
        } else if (moisAnciennete >= 120) {
            score += 100;
        } else if (moisAnciennete >= 60) {
            score += 60;
        } else if (moisAnciennete >= 24) {
            score += 30;
        }

        // Incidents de paiement (max -300 pts)
        if (ctx.maxRetardJours > 90) {
            score -= 300;
        } else if (ctx.maxRetardJours > 30) {
            score -= 150;
        } else if (ctx.maxRetardJours > 0) {
            score -= 50;
        }

        // Rejets chèques et impayés
        score -= ctx.nbRejets12m * 30;
        score -= ctx.nbImpayes12m * 20;

        // Crédits contentieux
        if (ctx.nbCreditsContentieux > 0) {
            score -= 200;
        }

        // Activité compte (flux réguliers positifs)
        if (ctx.nbMouvements12m > 60) score += 50;
        if (ctx.totalCredits12m != null &&
            ctx.totalCredits12m.compareTo(new BigDecimal("100000")) > 0) {
            score += 30;
        }

        return Math.max(0, Math.min(1000, score));
    }

    private int calculerScoreFinancier(ScoringContext ctx) {
        int score = 500;

        // Taux d'endettement actuel
        BigDecimal tauxActuel = ctx.totalMensualites != null &&
            ctx.revenuRetenu != null &&
            ctx.revenuRetenu.compareTo(BigDecimal.ZERO) > 0
            ? ctx.totalMensualites.divide(ctx.revenuRetenu, 4, RoundingMode.HALF_UP)
            : BigDecimal.ONE;

        if (tauxActuel.compareTo(new BigDecimal("0.30")) < 0) {
            score += 100; // Faiblement endetté
        } else if (tauxActuel.compareTo(new BigDecimal("0.40")) < 0) {
            score += 50;
        } else if (tauxActuel.compareTo(TAUX_ENDETTEMENT_BAM) > 0) {
            score -= 200; // Dépasse le plafond BAM
        }

        // Capacité de remboursement mensuelle
        ctx.capaciteRemboursement = ctx.revenuRetenu != null
            ? ctx.revenuRetenu.multiply(TAUX_ENDETTEMENT_BAM)
                .subtract(ctx.totalMensualites != null
                    ? ctx.totalMensualites : BigDecimal.ZERO)
            : BigDecimal.ZERO;

        BigDecimal mensualiteNouvelleSimulee = calculerMensualiteSimple(
            ctx.voIn.getMontantDemande(),
            ctx.voIn.getTauxDemande(),
            ctx.voIn.getDureesMois()
        );

        if (ctx.capaciteRemboursement.compareTo(mensualiteNouvelleSimulee) < 0) {
            score -= 300; // Incapacité de remboursement
        } else {
            BigDecimal ratio = ctx.capaciteRemboursement.divide(
                mensualiteNouvelleSimulee, 2, RoundingMode.HALF_UP);
            if (ratio.compareTo(new BigDecimal("2.0")) > 0) score += 80;
            else if (ratio.compareTo(new BigDecimal("1.5")) > 0) score += 40;
        }

        // Sur-pondération sectorielle
        if ("BTP".equals(ctx.codeSecteur)) {
            score = (int)(score * (1 - SURPONDERE_BTP.doubleValue()));
        } else if ("AGR".equals(ctx.codeSecteur)) {
            score = (int)(score * (1 - SURPONDERE_AGRI.doubleValue()));
        }

        return Math.max(0, Math.min(1000, score));
    }

    private int calculerScoreGaranties(ScoringContext ctx) {
        if (ctx.garanties == null || ctx.garanties.isEmpty()) {
            return 300; // Score minimal sans garantie
        }

        BigDecimal valeurTotaleGaranties = BigDecimal.ZERO;
        for (GarantieDTO g : ctx.garanties) {
            BigDecimal valeur = g.getValeurExpertise();

            // Décote si expertise > 3 ans
            if (g.getDateExpertise() != null) {
                int ansDernierExpertise = Period.between(
                    g.getDateExpertise(), LocalDate.now()).getYears();
                if (ansDernierExpertise >= 3) {
                    valeur = valeur.multiply(
                        BigDecimal.ONE.subtract(DECOTE_EXPERTISE_3ANS));
                }
            }

            // Pondération par type de garantie (Basel III LGD)
            BigDecimal coeff;
            switch (g.getTypeGarantie()) {
                case "HYPOTHEQUE_1ER_RANG": coeff = new BigDecimal("0.80"); break;
                case "HYPOTHEQUE_2EME_RANG": coeff = new BigDecimal("0.60"); break;
                case "NANTISSEMENT_FONDS":   coeff = new BigDecimal("0.50"); break;
                case "CAUTION_PERSONNELLE":  coeff = new BigDecimal("0.30"); break;
                case "CAUTION_BANCAIRE":     coeff = new BigDecimal("0.90"); break;
                default:                     coeff = new BigDecimal("0.20"); break;
            }
            valeurTotaleGaranties = valeurTotaleGaranties.add(
                valeur.multiply(coeff));
        }

        // Ratio couverture : valeur garanties / montant demandé
        BigDecimal ratioCouverture = valeurTotaleGaranties.divide(
            ctx.voIn.getMontantDemande(), 4, RoundingMode.HALF_UP);

        if (ratioCouverture.compareTo(new BigDecimal("1.5")) >= 0) return 900;
        if (ratioCouverture.compareTo(new BigDecimal("1.2")) >= 0) return 750;
        if (ratioCouverture.compareTo(new BigDecimal("1.0")) >= 0) return 600;
        if (ratioCouverture.compareTo(new BigDecimal("0.8")) >= 0) return 450;
        return 300;
    }

    private int calculerScoreBureau(ScoringContext ctx) {
        if (ctx.bureauIndisponible) {
            return 500; // Score neutre si bureau indisponible
        }
        int score = ctx.scoreBureauExterne;

        // Ajustements
        if (ctx.nbDemandesCredit6m > 5) score -= 50; // Hard inquiries
        if ("C".equals(ctx.classeRisqueBureau)) score -= 200;
        if ("D".equals(ctx.classeRisqueBureau)) score -= 400;
        if (ctx.montantIncidents != null &&
            ctx.montantIncidents.compareTo(new BigDecimal("10000")) > 0) {
            score -= 100;
        }
        return Math.max(0, Math.min(1000, score));
    }

    private int calculerScoreGlobalPondere(ScoringContext ctx) {
        // Poids Basel III adaptés BMCE
        double w1 = 0.35; // Comportemental
        double w2 = 0.30; // Financier
        double w3 = 0.20; // Garanties
        double w4 = 0.15; // Bureau

        return (int)(
            ctx.scoreComportemental  * w1 +
            ctx.scoreFinancier       * w2 +
            ctx.scoreGaranties       * w3 +
            ctx.scoreBureau          * w4
        );
    }

    private void appliquerReglesMetier(ScoringContext ctx) {
        // Règles d'exclusion automatique (score → 0)
        if (ctx.nbCreditsContentieux > 0) {
            ctx.scoreGlobal   = 0;
            ctx.motifRefus    = "CONTENTIEUX_ACTIF";
        }
        if (ctx.maxRetardJours > 180) {
            ctx.scoreGlobal   = 0;
            ctx.motifRefus    = "RETARD_EXCESSIF_180J";
        }

        // Taux endettement BAM — règle absolue
        if (ctx.capaciteRemboursement.compareTo(BigDecimal.ZERO) <= 0) {
            ctx.scoreGlobal   = 0;
            ctx.motifRefus    = "TAUX_ENDETTEMENT_DEPASSE_BAM_45PCT";
        }
    }

    private ScoringResultVoOut construireResultat(ScoringContext ctx) {
        String decision;
        String motif;

        if (ctx.scoreGlobal == 0) {
            decision = "REFUSE";
            motif    = ctx.motifRefus;
        } else if (ctx.scoreGlobal >= SCORE_MIN_OCTROI) {
            decision = "ACCORDE";
            motif    = "SCORE_SUFFISANT";
        } else if (ctx.scoreGlobal >= 550) {
            decision = "COMITE_CREDIT";  // Passage en comité
            motif    = "SCORE_LIMITE_COMITE";
        } else {
            decision = "REFUSE";
            motif    = "SCORE_INSUFFISANT";
        }

        // Taux proposé selon score (grille BMCE)
        BigDecimal tauxPropose = calculerTauxSelon(ctx.scoreGlobal,
            ctx.voIn.getTypeCredit());

        BigDecimal tauxEndettementFinal = ctx.revenuRetenu != null &&
            ctx.revenuRetenu.compareTo(BigDecimal.ZERO) > 0
            ? (ctx.totalMensualites != null ? ctx.totalMensualites : BigDecimal.ZERO)
                .divide(ctx.revenuRetenu, 4, RoundingMode.HALF_UP)
            : BigDecimal.ZERO;

        return ScoringResultVoOut.builder()
            .codeClient(ctx.voIn.getCodeClient())
            .montantDemande(ctx.voIn.getMontantDemande())
            .scoreGlobal(ctx.scoreGlobal)
            .scoreComportemental(ctx.scoreComportemental)
            .scoreFinancier(ctx.scoreFinancier)
            .scoreGaranties(ctx.scoreGaranties)
            .scoreBureau(ctx.scoreBureau)
            .decision(decision)
            .motifDecision(motif)
            .tauxPropose(tauxPropose)
            .tauxEndettement(tauxEndettementFinal)
            .capaciteRemboursementMensuelle(ctx.capaciteRemboursement)
            .bureauDisponible(!ctx.bureauIndisponible)
            .cnssDisponible(!ctx.cnssIndisponible)
            .dgiDisponible(!ctx.dgiIndisponible)
            .validiteJours(90)
            .dateScore(LocalDate.now())
            .build();
    }

    private void persisterScore(ScoringContext ctx, ScoringResultVoOut result)
            throws TechnicalException {
        try (Connection conn = coreDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_INSERT_SCORE)) {
            ps.setString(1, ctx.voIn.getCodeClient());
            ps.setString(2, ctx.voIn.getIdDossier());
            ps.setInt(3, result.getScoreGlobal());
            ps.setInt(4, result.getScoreComportemental());
            ps.setInt(5, result.getScoreFinancier());
            ps.setInt(6, result.getScoreGaranties());
            ps.setInt(7, result.getScoreBureau());
            ps.setString(8, result.getDecision());
            ps.setBigDecimal(9, result.getTauxEndettement());
            ps.setBigDecimal(10, result.getCapaciteRemboursementMensuelle());
            ps.setString(11, result.getMotifDecision());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new TechnicalException("ERR_SCR_010", e.getMessage(), e);
        }
    }

    // Stubs pour appels externes
    private BigDecimal appellerCNSSSoap(String cin) throws Exception {
        LOG.info("Appel CNSS SOAP pour CIN: " + cin);
        // JAX-WS call vers url/CNSS_WSDL
        return new BigDecimal("15000.00");
    }

    private BigDecimal appellerDGISoap(String cin) throws Exception {
        LOG.info("Appel DGI SOAP pour CIN: " + cin);
        // JAX-WS call vers url/DGI_WSDL
        return new BigDecimal("14500.00");
    }

    private BigDecimal calculerRevenuRetenu(ScoringContext ctx) {
        BigDecimal revenuDeclare = ctx.voIn.getRevenuNetMensuelDeclare();
        BigDecimal revenuCNSS    = ctx.revenuNetCNSS;
        BigDecimal revenuDGI     = ctx.revenuFiscalDGI != null
            ? ctx.revenuFiscalDGI.divide(new BigDecimal("12"), 2, RoundingMode.HALF_UP)
            : null;

        // Retenir le minimum des sources disponibles × facteur confiance
        BigDecimal min = revenuDeclare;
        if (revenuCNSS  != null) min = min.min(revenuCNSS);
        if (revenuDGI   != null) min = min.min(revenuDGI);

        // Facteur de confiance selon sources disponibles
        BigDecimal facteurConfiance = new BigDecimal("0.85");
        if (!ctx.cnssIndisponible && !ctx.dgiIndisponible) {
            facteurConfiance = new BigDecimal("0.95");
        }

        return min.multiply(facteurConfiance).setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal calculerMensualiteSimple(BigDecimal capital,
            BigDecimal tauxAnnuel, int dureesMois) {
        if (tauxAnnuel == null || tauxAnnuel.compareTo(BigDecimal.ZERO) == 0) {
            return capital.divide(new BigDecimal(dureesMois), 2, RoundingMode.HALF_UP);
        }
        BigDecimal tauxMensuel = tauxAnnuel.divide(
            new BigDecimal("1200"), 10, RoundingMode.HALF_UP);
        BigDecimal puissance = BigDecimal.ONE.add(tauxMensuel)
            .pow(dureesMois);
        return capital.multiply(tauxMensuel).multiply(puissance)
            .divide(puissance.subtract(BigDecimal.ONE), 2, RoundingMode.HALF_UP);
    }

    private BigDecimal calculerMensualite(BigDecimal capital,
            BigDecimal tauxAnnuel, int dureesMois, String typeCredit) {
        BigDecimal mensualiteBase = calculerMensualiteSimple(
            capital, tauxAnnuel, dureesMois);

        // Ajustements par type de crédit
        switch (typeCredit) {
            case "IMMOBILIER":
                // In fine sur les 2 premières années
                return mensualiteBase;
            case "AUTO":
                return mensualiteBase.multiply(new BigDecimal("1.02"));
            case "CONSOMMATION":
                return mensualiteBase.multiply(new BigDecimal("1.05"));
            default:
                return mensualiteBase;
        }
    }

    private BigDecimal calculerTauxSelon(int score, String typeCredit) {
        // Grille de taux BMCE selon score
        BigDecimal tauxBase;
        if (score >= 800)      tauxBase = new BigDecimal("4.50");
        else if (score >= 700) tauxBase = new BigDecimal("5.20");
        else if (score >= 620) tauxBase = new BigDecimal("6.10");
        else                   tauxBase = new BigDecimal("7.50");

        BigDecimal majorationTypeCredit;
        switch (typeCredit) {
            case "IMMOBILIER":   majorationTypeCredit = new BigDecimal("0.00"); break;
            case "AUTO":         majorationTypeCredit = new BigDecimal("0.50"); break;
            case "CONSOMMATION": majorationTypeCredit = new BigDecimal("1.50"); break;
            default:             majorationTypeCredit = new BigDecimal("1.00"); break;
        }
        return tauxBase.add(majorationTypeCredit);
    }

    private BigDecimal calculerTEG(BigDecimal capital, BigDecimal mensualite,
            int duree, BigDecimal assuranceVie, BigDecimal assuranceIncap,
            BigDecimal fraisDossier) {
        // TEG simplifié (Newton-Raphson complet serait plus précis)
        BigDecimal totalMensualites = mensualite.add(assuranceVie)
            .add(assuranceIncap).multiply(new BigDecimal(duree));
        BigDecimal coutTotal = totalMensualites.add(fraisDossier)
            .subtract(capital);
        return coutTotal.divide(capital, 4, RoundingMode.HALF_UP)
            .divide(new BigDecimal(duree).divide(
                new BigDecimal("12"), 4, RoundingMode.HALF_UP),
                4, RoundingMode.HALF_UP)
            .multiply(new BigDecimal("100"))
            .setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal calculerAssuranceVie(SimulationCreditVoIn voIn) {
        // 0.03% du capital par mois standard BMCE
        return voIn.getMontant().multiply(new BigDecimal("0.0003"))
            .setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal calculerAssuranceIncapacite(SimulationCreditVoIn voIn) {
        return voIn.getMontant().multiply(new BigDecimal("0.0001"))
            .setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal calculerFraisDossier(SimulationCreditVoIn voIn) {
        // 1% du montant, min 500 MAD, max 5000 MAD
        BigDecimal frais = voIn.getMontant().multiply(new BigDecimal("0.01"));
        return frais.max(new BigDecimal("500"))
            .min(new BigDecimal("5000"))
            .setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal calculerFraisInscriptionHypotheque(
            SimulationCreditVoIn voIn) {
        if (!"IMMOBILIER".equals(voIn.getTypeCredit())) return BigDecimal.ZERO;
        // 1.5% du montant pour inscription hypothécaire ANCFCC
        return voIn.getMontant().multiply(new BigDecimal("0.015"))
            .setScale(2, RoundingMode.HALF_UP);
    }

    private List<LigneAmortissementDTO> genererTableauAmortissement(
            SimulationCreditVoIn voIn, BigDecimal mensualite) {
        List<LigneAmortissementDTO> tableau = new ArrayList<>();
        BigDecimal capitalRestant = voIn.getMontant();
        BigDecimal tauxMensuel = voIn.getTauxAnnuel().divide(
            new BigDecimal("1200"), 10, RoundingMode.HALF_UP);

        for (int i = 1; i <= voIn.getDureesMois(); i++) {
            if (i > 3 && i < voIn.getDureesMois() - 2) {
                if (i == 4) {
                    tableau.add(LigneAmortissementDTO.builder()
                        .numeroEcheance(i).isEllipsis(true).build());
                }
                BigDecimal interet = capitalRestant.multiply(tauxMensuel)
                    .setScale(2, RoundingMode.HALF_UP);
                capitalRestant = capitalRestant.subtract(
                    mensualite.subtract(interet));
                continue;
            }
            BigDecimal interet = capitalRestant.multiply(tauxMensuel)
                .setScale(2, RoundingMode.HALF_UP);
            BigDecimal principal = mensualite.subtract(interet);
            capitalRestant = capitalRestant.subtract(principal)
                .max(BigDecimal.ZERO);
            tableau.add(LigneAmortissementDTO.builder()
                .numeroEcheance(i)
                .mensualite(mensualite)
                .principal(principal)
                .interet(interet)
                .capitalRestant(capitalRestant)
                .build());
        }
        return tableau;
    }

    private void notifierResultatAsync(ScoringContext ctx,
                                        ScoringResultVoOut result) {
        // Publication JMS async — jms/topic/SCORING_RESULTS
        LOG.info("Notification JMS scoring: " + result.getDecision() +
                 " client=" + ctx.voIn.getCodeClient());
    }

    private ScoringResultVoOut calculerScoreDegradeSansExterne(
            ScoringContext ctx) {
        return ScoringResultVoOut.builder()
            .decision("SCORE_DEGRADE")
            .motifDecision("SERVICES_EXTERNES_INDISPONIBLES")
            .scoreGlobal(-1)
            .build();
    }

    private void validateDossier(ScoringRequestVoIn voIn)
            throws DossierInvalidException {
        if (voIn.getMontantDemande() == null ||
            voIn.getMontantDemande().compareTo(BigDecimal.ZERO) <= 0) {
            throw new DossierInvalidException("Montant demandé invalide");
        }
        if (voIn.getDureesMois() <= 0 || voIn.getDureesMois() > 360) {
            throw new DossierInvalidException("Durée invalide (1-360 mois)");
        }
    }

    // ── Contexte interne de scoring ───────────────────────────
    private static class ScoringContext {
        ScoringRequestVoIn voIn;
        LocalDate dateCreationClient;
        int nbCreditsActifs;
        BigDecimal totalMensualites;
        BigDecimal totalEncours;
        int maxRetardJours;
        int nbCreditsContentieux;
        BigDecimal tauxMoyenCredits;
        int nbMouvements12m;
        BigDecimal creditMoyen12m;
        BigDecimal totalCredits12m;
        BigDecimal soldeMin12m;
        int nbImpayes12m;
        int nbRejets12m;
        List<GarantieDTO> garanties;
        String codeSecteur;
        BigDecimal chiffreAffaires;
        LocalDate dateCreationEntreprise;
        int nbEmployes;
        int scoreBureauExterne;
        int nbIncidentsBureau;
        BigDecimal montantIncidents;
        int nbDemandesCredit6m;
        String classeRisqueBureau;
        BigDecimal revenuNetCNSS;
        BigDecimal revenuFiscalDGI;
        BigDecimal revenuRetenu;
        BigDecimal capaciteRemboursement;
        boolean bureauIndisponible;
        boolean cnssIndisponible;
        boolean dgiIndisponible;
        int scoreComportemental;
        int scoreFinancier;
        int scoreGaranties;
        int scoreBureau;
        int scoreGlobal;
        String motifRefus;
    }
}
