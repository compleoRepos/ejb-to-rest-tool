package ma.bmce.digital.complex.exception;
public class IBANInvalidException extends Exception {
    public IBANInvalidException(String msg) { super(msg); }
}
