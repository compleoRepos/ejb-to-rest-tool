package ma.bmce.digital.complex.ejb;

import ma.bmce.digital.complex.dto.*;
import ma.bmce.digital.complex.exception.*;
import ma.bmce.digital.complex.transformer.SEPATransformer;
import ma.bmce.digital.complex.validator.IBANValidator;

import javax.ejb.*;
import javax.annotation.Resource;
import javax.inject.Inject;
import javax.jms.*;
import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.logging.Logger;

/**
 * VirementSEPAOrchestrateurEJB — EJB 3.x Stateless.
 * Orchestrateur complet des virements SEPA Credit Transfer (SCT).
 *
 * Flux de traitement :
 *   1. Validation IBAN (algorithme MOD97 + vérification BIC SWIFT)
 *   2. Contrôle conformité LBC/FT (Liste OFAC + Liste BAM)
 *   3. Vérification limites réglementaires (BAM OC 12/G/2013)
 *   4. Transformation ISO 20022 PAIN.001 (SEPA XML)
 *   5. Signature électronique XADES-BES
 *   6. Routage : SIMT (virements nationaux) ou TARGET2 (zone euro)
 *   7. Comptabilisation en temps réel (T+0)
 *   8. Reporting SWIFT ACK/NAK
 *   9. Notification multicanal (SMS + Email + Push)
 *
 * DataSources :
 *   jdbc/BMCE_CORE_DS        — comptes, transactions
 *   jdbc/BMCE_COMPLIANCE_DS  — listes sanctions, règles LBC
 *   jdbc/BMCE_SWIFT_DS       — messages SWIFT archivés
 *
 * APIs externes :
 *   url/SIMT_WSDL            — SOAP SIMT (Bank Al Maghrib clearing)
 *   url/TARGET2_WSDL         — SOAP TARGET2 (BCE zone euro)
 *   https://api.swift.com/v1 — SWIFT GPI REST tracking
 *   https://api.bam.ma/sanctions — BAM liste sanctions REST
 *   https://api.ofac.treasury.gov — OFAC REST
 *
 * JMS :
 *   jms/queue/SEPA_OUTBOUND   — virements sortants vers SIMT/TARGET2
 *   jms/queue/SEPA_INBOUND    — virements entrants reçus
 *   jms/queue/COMPLIANCE_CHECK — contrôles conformité async
 *   jms/topic/TRANSACTION_EVENTS — événements comptables broadcast
 */
@Stateless
@Local(VirementSEPAOrchestrateurEJBLocal.class)
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class VirementSEPAOrchestrateurEJB
        implements VirementSEPAOrchestrateurEJBLocal {

    private static final Logger LOG =
        Logger.getLogger(VirementSEPAOrchestrateurEJB.class.getName());

    // ── Constantes métier ─────────────────────────────────────
    private static final BigDecimal SEUIL_DECLARATION_BAM   = new BigDecimal("100000");
    private static final BigDecimal SEUIL_LBC_ALERTE        = new BigDecimal("50000");
    private static final BigDecimal SEUIL_TARGET2           = new BigDecimal("500000");
    private static final int        TIMEOUT_SIMT_MS         = 30000;
    private static final String     BIC_BMCE                = "BCDMMAMC";
    private static final String     CODE_PAYS_MAROC         = "MA";
    private static final String     DEVISE_MAD              = "MAD";
    private static final String     DEVISE_EUR              = "EUR";

    // ── SQL ───────────────────────────────────────────────────
    private static final String SQL_COMPTE_DEBITEUR =
        "SELECT c.NUM_COMPTE, c.IBAN, c.CODE_CLIENT, c.CODE_DEVISE, " +
        "  c.SOLDE_DISPONIBLE, c.STATUT, c.TYPE_COMPTE, " +
        "  cl.NOM_COMPLET, cl.CIN, cl.CODE_PAYS_RESIDENCE, " +
        "  cl.STATUT_COMPLIANCE " +
        "FROM T_COMPTES c " +
        "JOIN T_CLIENTS cl ON cl.CODE_CLIENT = c.CODE_CLIENT " +
        "WHERE c.IBAN = ? AND c.STATUT = 'ACTIF' " +
        "FOR UPDATE NOWAIT";

    private static final String SQL_INSERT_TRANSACTION_SEPA =
        "INSERT INTO T_TRANSACTIONS_SEPA " +
        "  (ID_TRANS, END_TO_END_ID, UETR, PAIN001_XML, " +
        "   IBAN_DEBITEUR, BIC_DEBITEUR, MONTANT, DEVISE, " +
        "   IBAN_CREDITEUR, BIC_CREDITEUR, NOM_CREDITEUR, " +
        "   MOTIF_VIREMENT, DATE_EXECUTION, DATE_COMPTABLE, " +
        "   STATUT, CANAL_ROUTAGE, HASH_MESSAGE, " +
        "   DATE_CREATION, CODE_RETOUR_SWIFT) " +
        "VALUES (SEQ_TRANS_SEPA.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, " +
        "        'INITIE', ?, ?, SYSDATE, NULL)";

    private static final String SQL_DEBIT_COMPTE =
        "UPDATE T_COMPTES SET " +
        "  SOLDE_DISPONIBLE   = SOLDE_DISPONIBLE - ?, " +
        "  SOLDE_COMPTABLE    = SOLDE_COMPTABLE - ?, " +
        "  DATE_MAJ           = SYSDATE, " +
        "  DERNIER_MVT_DEBIT  = SYSDATE " +
        "WHERE IBAN = ? AND STATUT = 'ACTIF' " +
        "  AND SOLDE_DISPONIBLE >= ?";

    private static final String SQL_INSERT_ECRITURE =
        "INSERT INTO T_ECRITURES_COMPTABLES " +
        "  (ID_ECRITURE, NUM_JOURNAL, DATE_VALEUR, DATE_COMPTABLE, " +
        "   COMPTE_DEBIT, COMPTE_CREDIT, MONTANT, DEVISE, " +
        "   LIBELLE, CODE_OPERATION, REF_EXTERNE, STATUT) " +
        "VALUES (SEQ_ECRITURES.NEXTVAL, ?, SYSDATE, ?, ?, ?, ?, ?, ?, ?, ?, 'PASSE')";

    private static final String SQL_CHECK_SANCTION =
        "SELECT s.NOM_SANCTIONNE, s.PAYS, s.DATE_INSCRIPTION, s.SOURCE " +
        "FROM T_LISTES_SANCTIONS s " +
        "WHERE (UPPER(s.NOM_SANCTIONNE) LIKE UPPER(?) " +
        "   OR s.IBAN = ? " +
        "   OR s.BIC = ?) " +
        "  AND s.DATE_FIN IS NULL " +
        "  AND ROWNUM <= 5";

    private static final String SQL_LIMITES_CANAL =
        "SELECT l.PLAFOND_UNITAIRE, l.PLAFOND_JOURNALIER, " +
        "  NVL((" +
        "    SELECT SUM(t.MONTANT) FROM T_TRANSACTIONS_SEPA t " +
        "    WHERE t.IBAN_DEBITEUR = ? " +
        "      AND TRUNC(t.DATE_CREATION) = TRUNC(SYSDATE) " +
        "      AND t.STATUT NOT IN ('REJETE', 'ANNULE')" +
        "  ), 0) AS CUMUL_JOUR " +
        "FROM T_LIMITES_SEPA l " +
        "WHERE l.CODE_CANAL = ? AND l.CODE_DEVISE = ? " +
        "  AND l.DATE_DEBUT <= SYSDATE AND (l.DATE_FIN IS NULL OR l.DATE_FIN >= SYSDATE)";

    private static final String SQL_UPDATE_STATUT_TRANS =
        "UPDATE T_TRANSACTIONS_SEPA SET " +
        "  STATUT = ?, CODE_RETOUR_SWIFT = ?, DATE_MAJ = SYSDATE, " +
        "  UETR = NVL(UETR, ?), DETAIL_ERREUR = ? " +
        "WHERE END_TO_END_ID = ?";

    // ── Resources ─────────────────────────────────────────────
    @Resource(name = "jdbc/BMCE_CORE_DS")
    private DataSource coreDS;

    @Resource(name = "jdbc/BMCE_COMPLIANCE_DS")
    private DataSource complianceDS;

    @Resource(name = "jdbc/BMCE_SWIFT_DS")
    private DataSource swiftDS;

    @Resource(name = "jms/ConnectionFactory")
    private ConnectionFactory jmsFactory;

    @Resource(name = "jms/queue/SEPA_OUTBOUND")
    private Queue sepaOutboundQueue;

    @Resource(name = "jms/queue/COMPLIANCE_CHECK")
    private Queue complianceQueue;

    @Resource(name = "jms/topic/TRANSACTION_EVENTS")
    private Topic transactionEventsTopic;

    // ── EJB Dependencies ──────────────────────────────────────
    @EJB
    private ComplianceLBCFTEJBLocal complianceService;

    @EJB
    private NotificationMulticanalEJBLocal notificationService;

    @EJB
    private ComptabiliteTempsReelEJBLocal comptabiliteService;

    @EJB
    private DeviseConversionEJBLocal deviseService;

    @Inject
    private SEPATransformer sepaTransformer;

    @Inject
    private IBANValidator ibanValidator;

    // ── Méthodes principales ──────────────────────────────────

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public VirementSEPAResultVoOut initierVirementSEPA(
            VirementSEPAVoIn voIn)
            throws IBANInvalidException, SanctionsViolationException,
                   LimiteDepasseeException, SoldeInsuffisantException,
                   ComplianceException, TechnicalException {

        LOG.info("initierVirementSEPA: " + voIn.getIbanDebiteur() +
                 " → " + voIn.getIbanCrediteur() +
                 " " + voIn.getMontant() + " " + voIn.getDevise());

        // ÉTAPE 1 — Validation IBAN
        if (!ibanValidator.validate(voIn.getIbanDebiteur())) {
            throw new IBANInvalidException("IBAN débiteur invalide: " +
                voIn.getIbanDebiteur());
        }
        if (!ibanValidator.validate(voIn.getIbanCrediteur())) {
            throw new IBANInvalidException("IBAN créditeur invalide: " +
                voIn.getIbanCrediteur());
        }

        // ÉTAPE 2 — Chargement et verrouillage du compte
        CompteDebiteurDTO compte = chargerEtVerrouilerCompte(voIn.getIbanDebiteur());

        // ÉTAPE 3 — Vérification limites
        verifierLimitesSEPA(voIn, compte);

        // ÉTAPE 4 — Contrôle sanctions (LBC/FT)
        SanctionsCheckResult sanctionsResult = verifierSanctions(voIn);
        if (sanctionsResult.isBloque()) {
            throw new SanctionsViolationException(
                "Opération bloquée — contrôle sanctions: " +
                sanctionsResult.getMotif());
        }

        // ÉTAPE 5 — Conversion de devise si nécessaire
        BigDecimal montantMAD = voIn.getMontant();
        BigDecimal tauxChange = BigDecimal.ONE;
        if (!DEVISE_MAD.equals(voIn.getDevise())) {
            tauxChange = deviseService.getTauxChange(voIn.getDevise(), DEVISE_MAD);
            montantMAD = voIn.getMontant().multiply(tauxChange);
        }

        // ÉTAPE 6 — Génération End-to-End ID et UETR
        String endToEndId = genererEndToEndId(voIn);
        String uetr       = genererUETR();

        // ÉTAPE 7 — Transformation PAIN.001 (ISO 20022)
        String pain001Xml = sepaTransformer.transformerEnPAIN001(
            voIn, compte, endToEndId, uetr);

        // ÉTAPE 8 — Signature électronique XADES
        String xmlSigne = signerXADES(pain001Xml, BIC_BMCE);

        // ÉTAPE 9 — Déterminer le canal de routage
        String canalRoutage = determinerCanalRoutage(voIn, montantMAD);

        try (Connection conn = coreDS.getConnection()) {
            conn.setAutoCommit(false);
            try {
                // ÉTAPE 10 — Débit compte
                int updated = debiterCompte(conn, voIn.getIbanDebiteur(),
                    montantMAD);
                if (updated == 0) {
                    throw new SoldeInsuffisantException(
                        "Solde insuffisant ou compte bloqué");
                }

                // ÉTAPE 11 — Enregistrement transaction SEPA
                long idTrans = enregistrerTransaction(conn, voIn, endToEndId,
                    uetr, pain001Xml, montantMAD, canalRoutage);

                // ÉTAPE 12 — Écriture comptable T+0
                passerEcritureComptable(conn, voIn, idTrans,
                    montantMAD, tauxChange);

                conn.commit();

                // ÉTAPE 13 — Envoi sur canal (hors transaction Oracle)
                String codeRetourSWIFT = envoyerVersCanalRoutage(
                    xmlSigne, voIn, endToEndId, uetr, canalRoutage);

                // ÉTAPE 14 — Mise à jour statut après envoi
                mettreAJourStatutTransaction(endToEndId,
                    "ENVOYE_" + canalRoutage, codeRetourSWIFT, uetr);

                // ÉTAPE 15 — Déclaration BAM si montant > seuil
                if (montantMAD.compareTo(SEUIL_DECLARATION_BAM) >= 0) {
                    declarerBAMAsync(voIn, endToEndId, montantMAD);
                }

                // ÉTAPE 16 — Notification multicanal async
                notifierClientAsync(compte, voIn, endToEndId, montantMAD);

                // ÉTAPE 17 — Broadcast événement comptable
                broadcastEvenementComptable(voIn, endToEndId, montantMAD,
                    canalRoutage);

                return VirementSEPAResultVoOut.builder()
                    .endToEndId(endToEndId)
                    .uetr(uetr)
                    .statut("ENVOYE")
                    .canalRoutage(canalRoutage)
                    .montantDebite(montantMAD)
                    .deviseOriginale(voIn.getDevise())
                    .tauxChangeApplique(tauxChange)
                    .dateExecution(LocalDate.now())
                    .dateValeur(calculerDateValeur(voIn.getDevise()))
                    .codeRetourSWIFT(codeRetourSWIFT)
                    .build();

            } catch (SoldeInsuffisantException | LimiteDepasseeException e) {
                conn.rollback();
                throw e;
            } catch (Exception e) {
                conn.rollback();
                throw new TechnicalException("ERR_SEPA_001", e.getMessage(), e);
            }
        } catch (SoldeInsuffisantException | LimiteDepasseeException |
                 TechnicalException e) {
            throw e;
        } catch (SQLException e) {
            throw new TechnicalException("ERR_SEPA_DB", e.getMessage(), e);
        }
    }

    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public StatutVirementVoOut getStatutVirement(String endToEndId)
            throws TechnicalException {

        String sql =
            "SELECT t.END_TO_END_ID, t.UETR, t.STATUT, " +
            "  t.DATE_CREATION, t.DATE_MAJ, " +
            "  t.CODE_RETOUR_SWIFT, t.CANAL_ROUTAGE, " +
            "  t.MONTANT, t.DEVISE, t.DETAIL_ERREUR " +
            "FROM T_TRANSACTIONS_SEPA t " +
            "WHERE t.END_TO_END_ID = ?";

        try (Connection conn = coreDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, endToEndId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new TechnicalException("ERR_SEPA_NF",
                        "Transaction non trouvée: " + endToEndId);
                }
                return StatutVirementVoOut.builder()
                    .endToEndId(rs.getString("END_TO_END_ID"))
                    .uetr(rs.getString("UETR"))
                    .statut(rs.getString("STATUT"))
                    .dateCreation(rs.getTimestamp("DATE_CREATION")
                        .toLocalDateTime())
                    .dateMaj(rs.getTimestamp("DATE_MAJ").toLocalDateTime())
                    .codeRetourSWIFT(rs.getString("CODE_RETOUR_SWIFT"))
                    .canalRoutage(rs.getString("CANAL_ROUTAGE"))
                    .montant(rs.getBigDecimal("MONTANT"))
                    .devise(rs.getString("DEVISE"))
                    .detailErreur(rs.getString("DETAIL_ERREUR"))
                    .build();
            }
        } catch (TechnicalException e) {
            throw e;
        } catch (SQLException e) {
            throw new TechnicalException("ERR_SEPA_DB", e.getMessage(), e);
        }
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void traiterVirementEntrant(VirementEntrantSEPAVoIn voIn)
            throws TechnicalException {

        LOG.info("traiterVirementEntrant: " + voIn.getEndToEndId() +
                 " → " + voIn.getIbanCrediteur());

        // Valider le PAIN.002 reçu
        validerPAIN002(voIn.getPain002Xml());

        // Trouver le compte créditeur
        String sqlCompte =
            "SELECT NUM_COMPTE, SOLDE_DISPONIBLE, STATUT " +
            "FROM T_COMPTES WHERE IBAN = ? AND STATUT = 'ACTIF' " +
            "FOR UPDATE NOWAIT";

        try (Connection conn = coreDS.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(sqlCompte)) {
                ps.setString(1, voIn.getIbanCrediteur());
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        // PAIN.002 NACK — compte inexistant ou inactif
                        renvoyerPAIN002NACK(voIn, "AC01");
                        return;
                    }

                    // Crédit du compte
                    try (PreparedStatement psCredit = conn.prepareStatement(
                            "UPDATE T_COMPTES SET " +
                            "  SOLDE_DISPONIBLE = SOLDE_DISPONIBLE + ?, " +
                            "  SOLDE_COMPTABLE = SOLDE_COMPTABLE + ?, " +
                            "  DATE_MAJ = SYSDATE " +
                            "WHERE IBAN = ?")) {
                        psCredit.setBigDecimal(1, voIn.getMontant());
                        psCredit.setBigDecimal(2, voIn.getMontant());
                        psCredit.setString(3, voIn.getIbanCrediteur());
                        psCredit.executeUpdate();
                    }

                    // Ecriture comptable crédit
                    enregistrerEcritureCredit(conn, voIn);

                    conn.commit();
                }
            }

            // Notification au bénéficiaire
            notificationService.notifierVirementRecu(
                voIn.getIbanCrediteur(),
                voIn.getMontant(),
                voIn.getDevise(),
                voIn.getNomDonneur(),
                voIn.getEndToEndId()
            );

        } catch (SQLException e) {
            throw new TechnicalException("ERR_SEPA_ENT", e.getMessage(), e);
        }
    }

    // ── Implémentations privées ────────────────────────────────

    private CompteDebiteurDTO chargerEtVerrouilerCompte(String iban)
            throws TechnicalException, SoldeInsuffisantException {
        try (Connection conn = coreDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_COMPTE_DEBITEUR)) {
            ps.setString(1, iban);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new SoldeInsuffisantException(
                        "Compte non trouvé ou inactif: " + iban);
                }
                return CompteDebiteurDTO.builder()
                    .numCompte(rs.getString("NUM_COMPTE"))
                    .iban(rs.getString("IBAN"))
                    .codeClient(rs.getString("CODE_CLIENT"))
                    .codeDevise(rs.getString("CODE_DEVISE"))
                    .soldeDisponible(rs.getBigDecimal("SOLDE_DISPONIBLE"))
                    .statut(rs.getString("STATUT"))
                    .nomComplet(rs.getString("NOM_COMPLET"))
                    .cin(rs.getString("CIN"))
                    .codePaysResidence(rs.getString("CODE_PAYS_RESIDENCE"))
                    .statutCompliance(rs.getString("STATUT_COMPLIANCE"))
                    .build();
            }
        } catch (SoldeInsuffisantException e) {
            throw e;
        } catch (SQLException e) {
            if (e.getErrorCode() == 54) {
                throw new TechnicalException("ERR_LOCK",
                    "Compte en cours de modification");
            }
            throw new TechnicalException("ERR_SEPA_DB", e.getMessage(), e);
        }
    }

    private void verifierLimitesSEPA(VirementSEPAVoIn voIn,
                                      CompteDebiteurDTO compte)
            throws LimiteDepasseeException, TechnicalException {
        try (Connection conn = coreDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_LIMITES_CANAL)) {
            ps.setString(1, voIn.getIbanDebiteur());
            ps.setString(2, voIn.getCodeCanal());
            ps.setString(3, voIn.getDevise());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    BigDecimal plafondUnitaire   = rs.getBigDecimal("PLAFOND_UNITAIRE");
                    BigDecimal plafondJournalier = rs.getBigDecimal("PLAFOND_JOURNALIER");
                    BigDecimal cumulJour         = rs.getBigDecimal("CUMUL_JOUR");

                    if (voIn.getMontant().compareTo(plafondUnitaire) > 0) {
                        throw new LimiteDepasseeException(
                            "Montant dépasse le plafond unitaire: " + plafondUnitaire);
                    }
                    if (cumulJour.add(voIn.getMontant())
                            .compareTo(plafondJournalier) > 0) {
                        throw new LimiteDepasseeException(
                            "Plafond journalier dépassé: " + plafondJournalier);
                    }
                }
            }
        } catch (LimiteDepasseeException e) {
            throw e;
        } catch (SQLException e) {
            throw new TechnicalException("ERR_SEPA_LIM", e.getMessage(), e);
        }
    }

    private SanctionsCheckResult verifierSanctions(VirementSEPAVoIn voIn) {
        try (Connection conn = complianceDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CHECK_SANCTION)) {
            ps.setString(1, "%" + voIn.getNomCrediteur() + "%");
            ps.setString(2, voIn.getIbanCrediteur());
            ps.setString(3, voIn.getBicCrediteur());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return SanctionsCheckResult.bloque(
                        "Entité sanctionnée: " + rs.getString("NOM_SANCTIONNE") +
                        " (Source: " + rs.getString("SOURCE") + ")"
                    );
                }
            }
        } catch (Exception e) {
            LOG.warning("Vérification sanctions dégradée: " + e.getMessage());
            // En mode dégradé, on publie sur la queue compliance pour
            // vérification asynchrone et on autorise en attente
            publierComplianceAsync(voIn);
        }
        return SanctionsCheckResult.autorise();
    }

    private int debiterCompte(Connection conn, String iban,
                               BigDecimal montant) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(SQL_DEBIT_COMPTE)) {
            ps.setBigDecimal(1, montant);
            ps.setBigDecimal(2, montant);
            ps.setString(3, iban);
            ps.setBigDecimal(4, montant);
            return ps.executeUpdate();
        }
    }

    private long enregistrerTransaction(Connection conn,
            VirementSEPAVoIn voIn, String endToEndId, String uetr,
            String pain001Xml, BigDecimal montantMAD,
            String canalRoutage) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                SQL_INSERT_TRANSACTION_SEPA,
                new String[]{"ID_TRANS"})) {
            ps.setString(1, endToEndId);
            ps.setString(2, uetr);
            ps.setString(3, pain001Xml);
            ps.setString(4, voIn.getIbanDebiteur());
            ps.setString(5, BIC_BMCE);
            ps.setBigDecimal(6, montantMAD);
            ps.setString(7, voIn.getDevise());
            ps.setString(8, voIn.getIbanCrediteur());
            ps.setString(9, voIn.getBicCrediteur());
            ps.setString(10, voIn.getNomCrediteur());
            ps.setString(11, voIn.getMotifVirement());
            ps.setDate(12, java.sql.Date.valueOf(LocalDate.now()));
            ps.setDate(13, java.sql.Date.valueOf(calculerDateValeur(voIn.getDevise())));
            ps.setString(14, canalRoutage);
            ps.setString(15, calculerHashMessage(pain001Xml));
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                return keys.next() ? keys.getLong(1) : 0;
            }
        }
    }

    private void passerEcritureComptable(Connection conn,
            VirementSEPAVoIn voIn, long idTrans,
            BigDecimal montantMAD, BigDecimal tauxChange) throws SQLException {
        // Écriture au débit
        try (PreparedStatement ps = conn.prepareStatement(
                SQL_INSERT_ECRITURE)) {
            ps.setString(1, "JOURNAL_VIR_" + LocalDate.now());
            ps.setDate(2, java.sql.Date.valueOf(calculerDateValeur(voIn.getDevise())));
            ps.setString(3, voIn.getIbanDebiteur());
            ps.setString(4, "NOSTRO_BMCE_" + voIn.getDevise());
            ps.setBigDecimal(5, montantMAD);
            ps.setString(6, voIn.getDevise());
            ps.setString(7, "VIR SEPA " + voIn.getMotifVirement() +
                " → " + voIn.getNomCrediteur());
            ps.setString(8, "VIR_SEPA_OUT");
            ps.setString(9, String.valueOf(idTrans));
            ps.executeUpdate();
        }

        // Écriture devise si change
        if (!BigDecimal.ONE.equals(tauxChange)) {
            try (PreparedStatement psDevise = conn.prepareStatement(
                    SQL_INSERT_ECRITURE)) {
                psDevise.setString(1, "JOURNAL_CHANGE_" + LocalDate.now());
                psDevise.setDate(2, java.sql.Date.valueOf(LocalDate.now()));
                psDevise.setString(3, "GAIN_CHANGE_BMCE");
                psDevise.setString(4, "NOSTRO_BMCE_" + voIn.getDevise());
                psDevise.setBigDecimal(5, voIn.getMontant());
                psDevise.setString(6, voIn.getDevise());
                psDevise.setString(7, "CHANGE " + voIn.getDevise() +
                    "/" + DEVISE_MAD + " taux=" + tauxChange);
                psDevise.setString(8, "CHANGE_DEVISE");
                psDevise.setString(9, String.valueOf(idTrans));
                psDevise.executeUpdate();
            }
        }
    }

    private String determinerCanalRoutage(VirementSEPAVoIn voIn,
                                           BigDecimal montantMAD) {
        String paysCrediteur = extrairePaysDIBAN(voIn.getIbanCrediteur());

        if (CODE_PAYS_MAROC.equals(paysCrediteur)) {
            return "SIMT"; // Clearing national BAM
        } else if (estZoneEuro(paysCrediteur)) {
            if (montantMAD.compareTo(SEUIL_TARGET2) >= 0) {
                return "TARGET2_URGENT"; // Gros montants urgents BCE
            }
            return "TARGET2_STANDARD"; // Virements SEPA standard
        } else {
            return "SWIFT_CORRESPONDENT"; // Hors zone euro → réseau correspondants
        }
    }

    private String envoyerVersCanalRoutage(String xmlSigne,
            VirementSEPAVoIn voIn, String endToEndId, String uetr,
            String canal) throws Exception {
        switch (canal) {
            case "SIMT":
                return envoyerSIMTSoap(xmlSigne, endToEndId);
            case "TARGET2_STANDARD":
            case "TARGET2_URGENT":
                return envoyerTARGET2Soap(xmlSigne, endToEndId, uetr,
                    "TARGET2_URGENT".equals(canal));
            case "SWIFT_CORRESPONDENT":
                return envoyerSWIFTCorrespondant(xmlSigne, endToEndId, uetr);
            default:
                throw new TechnicalException("ERR_CANAL",
                    "Canal de routage inconnu: " + canal);
        }
    }

    private String envoyerSIMTSoap(String xmlSigne, String endToEndId) {
        LOG.info("Envoi SIMT: " + endToEndId);
        // JAX-WS → url/SIMT_WSDL
        return "SIMT_ACK_" + endToEndId;
    }

    private String envoyerTARGET2Soap(String xmlSigne, String endToEndId,
                                       String uetr, boolean urgent) {
        LOG.info("Envoi TARGET2 " + (urgent ? "URGENT" : "STANDARD") +
                 ": " + uetr);
        // JAX-WS → url/TARGET2_WSDL
        return "T2_ACK_" + uetr;
    }

    private String envoyerSWIFTCorrespondant(String xmlSigne,
            String endToEndId, String uetr) {
        LOG.info("Envoi SWIFT GPI correspondant: " + uetr);
        // REST → https://api.swift.com/v1/gpi/payments
        return "SWIFT_" + uetr;
    }

    private void mettreAJourStatutTransaction(String endToEndId,
            String statut, String codeRetour, String uetr)
            throws TechnicalException {
        try (Connection conn = coreDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     SQL_UPDATE_STATUT_TRANS)) {
            ps.setString(1, statut);
            ps.setString(2, codeRetour);
            ps.setString(3, uetr);
            ps.setString(4, null);
            ps.setString(5, endToEndId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new TechnicalException("ERR_SEPA_UPD", e.getMessage(), e);
        }
    }

    private void notifierClientAsync(CompteDebiteurDTO compte,
            VirementSEPAVoIn voIn, String endToEndId, BigDecimal montant) {
        try (JMSContext ctx = jmsFactory.createContext()) {
            String payload = String.format(
                "{\"type\":\"VIR_SEPA_OUT\",\"client\":\"%s\"," +
                "\"montant\":%s,\"devise\":\"%s\",\"endToEndId\":\"%s\"}",
                compte.getCodeClient(), montant,
                voIn.getDevise(), endToEndId);
            ctx.createProducer().send(transactionEventsTopic, payload);
        } catch (Exception e) {
            LOG.warning("Notification async échouée: " + e.getMessage());
        }
    }

    private void broadcastEvenementComptable(VirementSEPAVoIn voIn,
            String endToEndId, BigDecimal montant, String canal) {
        try (JMSContext ctx = jmsFactory.createContext()) {
            String event = String.format(
                "{\"event\":\"SEPA_OUTBOUND\",\"endToEndId\":\"%s\"," +
                "\"montant\":%s,\"canal\":\"%s\",\"ts\":\"%s\"}",
                endToEndId, montant, canal, LocalDateTime.now());
            ctx.createProducer().send(transactionEventsTopic, event);
        } catch (Exception e) {
            LOG.warning("Broadcast comptable échoué: " + e.getMessage());
        }
    }

    private void declarerBAMAsync(VirementSEPAVoIn voIn,
                                   String endToEndId, BigDecimal montant) {
        LOG.info("Déclaration BAM async: " + endToEndId +
                 " montant=" + montant);
        // REST async → https://api.bam.ma/declarations/sepa
    }

    private void publierComplianceAsync(VirementSEPAVoIn voIn) {
        try (JMSContext ctx = jmsFactory.createContext()) {
            ctx.createProducer().send(complianceQueue,
                voIn.getIbanCrediteur() + "|" + voIn.getNomCrediteur());
        } catch (Exception e) {
            LOG.warning("Compliance queue: " + e.getMessage());
        }
    }

    private void enregistrerEcritureCredit(Connection conn,
            VirementEntrantSEPAVoIn voIn) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                SQL_INSERT_ECRITURE)) {
            ps.setString(1, "JOURNAL_VIR_ENT_" + LocalDate.now());
            ps.setDate(2, java.sql.Date.valueOf(LocalDate.now()));
            ps.setString(3, "NOSTRO_BMCE_" + voIn.getDevise());
            ps.setString(4, voIn.getIbanCrediteur());
            ps.setBigDecimal(5, voIn.getMontant());
            ps.setString(6, voIn.getDevise());
            ps.setString(7, "VIR SEPA IN DE " + voIn.getNomDonneur());
            ps.setString(8, "VIR_SEPA_IN");
            ps.setString(9, voIn.getEndToEndId());
            ps.executeUpdate();
        }
    }

    private String genererEndToEndId(VirementSEPAVoIn voIn) {
        return "BMCE" + System.currentTimeMillis() + "E2E";
    }

    private String genererUETR() {
        return UUID.randomUUID().toString().toUpperCase();
    }

    private String extrairePaysDIBAN(String iban) {
        return iban != null && iban.length() >= 2 ? iban.substring(0, 2) : "XX";
    }

    private boolean estZoneEuro(String codePays) {
        Set<String> zoneEuro = new HashSet<>(Arrays.asList(
            "DE","FR","IT","ES","PT","BE","NL","AT","FI","GR",
            "IE","LU","SK","SI","EE","LV","LT","CY","MT"
        ));
        return zoneEuro.contains(codePays);
    }

    private LocalDate calculerDateValeur(String devise) {
        // J+1 MAD, J+2 EUR/USD, J+3 autres
        if (DEVISE_MAD.equals(devise)) return LocalDate.now().plusDays(1);
        if (DEVISE_EUR.equals(devise)) return LocalDate.now().plusDays(2);
        return LocalDate.now().plusDays(3);
    }

    private String signerXADES(String xml, String bic) {
        // BouncyCastle XADES-BES signing
        return xml + "<!-- XADES-BES SIGNED BY " + bic + " -->";
    }

    private String calculerHashMessage(String xml) {
        try {
            java.security.MessageDigest md =
                java.security.MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(xml.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "HASH_ERROR";
        }
    }

    private void validerPAIN002(String pain002Xml) throws TechnicalException {
        if (pain002Xml == null || pain002Xml.isEmpty()) {
            throw new TechnicalException("ERR_PAIN002", "XML PAIN.002 vide");
        }
    }

    private void renvoyerPAIN002NACK(VirementEntrantSEPAVoIn voIn,
                                      String codeRejet) {
        LOG.warning("PAIN.002 NACK: " + voIn.getEndToEndId() +
                    " code=" + codeRejet);
    }
}
