package ma.bmce.digital.complex.ejb;
public interface DocumentValidationEJBLocal {}
