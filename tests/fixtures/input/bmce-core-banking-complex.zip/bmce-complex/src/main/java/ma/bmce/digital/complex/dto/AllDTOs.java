package ma.bmce.digital.complex.dto;

import lombok.Builder;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

// ── Scoring Crédit ────────────────────────────────────────────

@Data @Builder class ScoringRequestVoIn {
    String codeClient, cinClient, idDossier, typeCredit, codeCanal;
    BigDecimal montantDemande, tauxDemande, revenuNetMensuelDeclare;
    int dureesMois;
}

@Data @Builder class ScoringResultVoOut {
    String codeClient, decision, motifDecision;
    BigDecimal montantDemande, tauxPropose, tauxEndettement;
    BigDecimal capaciteRemboursementMensuelle;
    int scoreGlobal, scoreComportemental, scoreFinancier;
    int scoreGaranties, scoreBureau;
    boolean bureauDisponible, cnssDisponible, dgiDisponible;
    int validiteJours;
    LocalDate dateScore;
}

@Data @Builder class ScoringHistoriqueVoOut {
    long idScore;
    LocalDate dateScore;
    int scoreGlobal;
    String decision, statut;
    BigDecimal tauxEndettement;
}

@Data @Builder class SimulationCreditVoIn {
    BigDecimal montant, tauxAnnuel;
    int dureesMois;
    String typeCredit;
}

@Data @Builder class SimulationCreditVoOut {
    BigDecimal montant, tauxNominal, teg;
    BigDecimal mensualiteHorsAssurance, mensualiteAssuranceVie;
    BigDecimal mensualiteAssuranceIncap, mensualiteTotale;
    BigDecimal coutTotalCredit, fraisDossier, fraisInscriptionHypotheque;
    int dureesMois;
    LocalDate dateSimulation;
    List<LigneAmortissementDTO> tableauAmortissement;
}

@Data @Builder class LigneAmortissementDTO {
    int numeroEcheance;
    BigDecimal mensualite, principal, interet, capitalRestant;
    boolean isEllipsis;
}

@Data @Builder class GarantieDTO {
    String typeGarantie;
    BigDecimal valeurExpertise, valeurRetenue, tauxDepreciation;
    LocalDate dateExpertise;
}

@Data @Builder class DemandeCreditVoIn {
    String codeClient, cinClient, idDossier, typeCredit, typeProfessionnel;
    BigDecimal montantDemande, tauxPropose, revenuNetMensuelDeclare;
    int dureesMois;
}

// ── SEPA Virements ────────────────────────────────────────────

@Data @Builder class VirementSEPAVoIn {
    String ibanDebiteur, ibanCrediteur, bicCrediteur, nomCrediteur;
    String motifVirement, devise, codeCanal, paysDestination;
    BigDecimal montant;
    Boolean instantPayment;
    LocalDate dateExecution;
}

@Data @Builder class VirementSEPAResultVoOut {
    String endToEndId, uetr, statut, canalRoutage, codeRetourSWIFT;
    String deviseOriginale;
    BigDecimal montantDebite, tauxChangeApplique;
    LocalDate dateExecution, dateValeur;
}

@Data @Builder class StatutVirementVoOut {
    String endToEndId, uetr, statut, codeRetourSWIFT, canalRoutage, detailErreur, devise;
    BigDecimal montant;
    LocalDateTime dateCreation, dateMaj;
}

@Data @Builder class VirementEntrantSEPAVoIn {
    String endToEndId, ibanCrediteur, nomDonneur, bicDonneur, devise, pain002Xml;
    BigDecimal montant;
}

@Data @Builder class CompteDebiteurDTO {
    String numCompte, iban, codeClient, codeDevise, statut, nomComplet;
    String cin, codePaysResidence, statutCompliance;
    BigDecimal soldeDisponible;
}

@Data @Builder class SanctionsCheckResult {
    boolean bloque;
    String motif;
    static SanctionsCheckResult bloque(String m) {
        SanctionsCheckResult r = new SanctionsCheckResult(); r.bloque=true; r.motif=m; return r;
    }
    static SanctionsCheckResult autorise() {
        SanctionsCheckResult r = new SanctionsCheckResult(); r.bloque=false; return r;
    }
}

@Data @Builder class PAINNackDTO {
    String endToEndId, codeRejet, raison;
}

// ── Compliance LBC/FT ─────────────────────────────────────────

@Data @Builder class ComplianceCheckVoIn {
    String codeClient, typeTransaction, devise, referenceTransaction;
    String nomContrepartie, numeroIdentiteContrepartie, ibanContrepartie;
    String paysDestination;
    BigDecimal montant;
    Boolean justificatifPresent;
}

@Data @Builder class ComplianceCheckResultVoOut {
    String codeClient, decision, referenceControle;
    boolean bloque, declarationRequise;
    int scoreRisque;
    List<ComplianceAlerteDTO> alertes;
    LocalDateTime dateVerification;
}

@Data @Builder class ComplianceAlerteDTO {
    long idAlerte;
    String typeAlerte, niveauRisque, description, statut;
    BigDecimal montant;
    LocalDateTime dateCreation;
}

@Data @Builder class SanctionMatchDTO {
    String nomEntite, sourceListe;
    double scoreSimilarite;
}

@Data @Builder class ProfilRisqueDTO {
    BigDecimal moyenneMensuelle, ecartType, maxTransactionHistorique;
}

@Data @Builder class PaysRisqueDTO {
    String codePays, niveauRisque, listeGafi;
}

// ── Risk Management ───────────────────────────────────────────

@Data @Builder class VaRResultVoOut {
    String codePortefeuille, methode;
    BigDecimal var99Horizon1j, var95Horizon1j, var99Horizon10j, cvar99;
    BigDecimal valeurPortefeuille;
    int nbSimulations;
    LocalDate dateCalcul;
    List<LimiteAlertDTO> alertesLimites;
}

@Data @Builder class StressTestResultVoOut {
    String codePortefeuille, scenarioBAM;
    BigDecimal pnlStressTotal;
    boolean conforme;
    LocalDate dateExecution;
    List<ContributionStressDTO> contributions;
}

@Data @Builder class ContributionStressDTO {
    String codeInstrument;
    BigDecimal pnlContribution, pctContribution;
}

@Data @Builder class LimiteAlertDTO {
    String typeLimite;
    BigDecimal valeurActuelle, valeurLimite, tauxUtilisation;
    boolean depassement;
}

@Data @Builder class PositionDTO {
    String codeInstrument;
    BigDecimal quantite, prixRevient, valeurMarche;
    BigDecimal delta, gamma, vega, theta;
}

// ── Notifications ─────────────────────────────────────────────

@Data @Builder class PreferencesNotifDTO {
    Boolean canalSmsActif, canalEmailActif, canalPushActif;
    String telephoneMobile, emailPrincipal, deviceTokenPush, languePreference;
}
