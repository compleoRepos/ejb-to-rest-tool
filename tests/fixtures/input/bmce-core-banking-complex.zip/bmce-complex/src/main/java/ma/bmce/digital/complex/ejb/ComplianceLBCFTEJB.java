package ma.bmce.digital.complex.ejb;

import ma.bmce.digital.complex.dto.*;
import ma.bmce.digital.complex.exception.*;

import javax.ejb.*;
import javax.annotation.Resource;
import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.logging.Logger;

/**
 * ComplianceLBCFTEJB — EJB 3.x Stateless.
 * Moteur de conformité LBC/FT (Lutte contre le Blanchiment de Capitaux
 * et le Financement du Terrorisme) conforme à la loi 12-18 BAM.
 *
 * Règles de filtrage :
 *   - Listes OFAC (Office of Foreign Assets Control)
 *   - Liste BAM consolidée (500+ entités)
 *   - Règle des 10 000 MAD (seuil déclaration espèces)
 *   - Smurfing detection (fractionnement de transactions)
 *   - Structuring detection (montants juste en dessous du seuil)
 *   - Profil comportemental clients (écarts > 3 sigma)
 *   - Transactions pays à risque élevé (GAFI liste noire/grise)
 *
 * DataSources :
 *   jdbc/BMCE_COMPLIANCE_DS  — listes sanctions + règles
 *   jdbc/BMCE_ANALYTICS_DS   — historique comportemental
 *   jdbc/BMCE_CORE_DS        — données clients et transactions
 *
 * JMS :
 *   jms/queue/ALERTS_COMPLIANCE  — alertes à traiter par l'équipe compliance
 *   jms/queue/DECLARATIONS_TRAPROC — déclarations TRAPROC (BAM)
 */
@Stateless
@Local(ComplianceLBCFTEJBLocal.class)
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class ComplianceLBCFTEJB implements ComplianceLBCFTEJBLocal {

    private static final Logger LOG =
        Logger.getLogger(ComplianceLBCFTEJB.class.getName());

    private static final BigDecimal SEUIL_ESPECES_DECLARATION  = new BigDecimal("10000");
    private static final BigDecimal SEUIL_STRUCTURING_DETECTION = new BigDecimal("9000");
    private static final int        FENETRE_SMURFING_HEURES     = 24;
    private static final int        NB_TX_SMURFING_SEUIL        = 5;
    private static final double     SIGMA_ECART_ALERTE          = 3.0;

    private static final String SQL_FILTRAGE_SANCTIONS =
        "SELECT s.ID_ENTITE, s.NOM_ENTITE, s.TYPE_ENTITE, " +
        "  s.PAYS_NATIONALITE, s.DATE_INSCRIPTION, s.SOURCE_LISTE, " +
        "  s.SCORE_SIMILARITE " +
        "FROM T_ENTITES_SANCTIONNEES s " +
        "WHERE s.STATUT_SANCTION = 'ACTIVE' " +
        "  AND (UPPER(TRANSLATE(s.NOM_ENTITE, 'àâäéèêëîïôùûü', 'aaaeeeeiioouuu')) " +
        "    LIKE UPPER(TRANSLATE(?, 'àâäéèêëîïôùûü', 'aaaeeeeiioouuu')) " +
        "  OR s.NUMERO_IDENTITE = ? " +
        "  OR s.IBAN_REFERENCE = ?) " +
        "ORDER BY s.SCORE_SIMILARITE DESC";

    private static final String SQL_DETECTION_SMURFING =
        "SELECT COUNT(*) AS NB_TX, SUM(t.MONTANT) AS TOTAL_MONTANT " +
        "FROM T_TRANSACTIONS t " +
        "WHERE t.CODE_CLIENT = ? " +
        "  AND t.DATE_TRANSACTION >= ? " +
        "  AND t.TYPE_TRANSACTION IN ('ESPECES_DEPOT', 'VIREMENT_SORTANT') " +
        "  AND t.MONTANT BETWEEN ? AND ? " +
        "  AND t.STATUT != 'ANNULE'";

    private static final String SQL_PROFIL_COMPORTEMENTAL =
        "SELECT p.MOYENNE_MENSUELLE, p.ECART_TYPE, " +
        "  p.MAX_TRANSACTION_HISTORIQUE, p.PAYS_HABITUELS, " +
        "  p.SECTEURS_HABITUELS, p.DATE_MAJ_PROFIL " +
        "FROM T_PROFILS_RISQUE_CLIENT p " +
        "WHERE p.CODE_CLIENT = ? " +
        "  AND p.STATUT_PROFIL = 'ACTIF'";

    private static final String SQL_INSERT_ALERTE =
        "INSERT INTO T_ALERTES_COMPLIANCE " +
        "  (ID_ALERTE, CODE_CLIENT, TYPE_ALERTE, NIVEAU_RISQUE, " +
        "   DESCRIPTION, MONTANT, DEVISE, REFERENCE_TRANSACTION, " +
        "   STATUT, DATE_CREATION, DATE_ECHEANCE_TRAITEMENT) " +
        "VALUES (SEQ_ALERTES_COMPL.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, " +
        "        'OUVERTE', SYSDATE, SYSDATE + 3)";

    private static final String SQL_PAYS_RISQUE =
        "SELECT pr.CODE_PAYS, pr.NIVEAU_RISQUE, pr.LISTE_GAFI " +
        "FROM T_PAYS_RISQUE pr " +
        "WHERE pr.CODE_PAYS = ? AND pr.DATE_FIN IS NULL";

    private static final String SQL_UPDATE_SCORE_CLIENT =
        "MERGE INTO T_SCORES_RISQUE_CLIENT sc " +
        "USING DUAL ON (sc.CODE_CLIENT = ?) " +
        "WHEN MATCHED THEN UPDATE SET " +
        "  sc.SCORE_RISQUE = ?, sc.NIVEAU_RISQUE = ?, " +
        "  sc.DATE_MAJ = SYSDATE, sc.NB_ALERTES_OUVERTES = sc.NB_ALERTES_OUVERTES + ? " +
        "WHEN NOT MATCHED THEN INSERT " +
        "  (CODE_CLIENT, SCORE_RISQUE, NIVEAU_RISQUE, DATE_CREATION, NB_ALERTES_OUVERTES) " +
        "VALUES (?, ?, ?, SYSDATE, ?)";

    @Resource(name = "jdbc/BMCE_COMPLIANCE_DS")
    private DataSource complianceDS;

    @Resource(name = "jdbc/BMCE_ANALYTICS_DS")
    private DataSource analyticsDS;

    @Resource(name = "jdbc/BMCE_CORE_DS")
    private DataSource coreDS;

    @EJB
    private NotificationMulticanalEJBLocal notificationService;

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public ComplianceCheckResultVoOut verifierTransaction(
            ComplianceCheckVoIn voIn)
            throws TechnicalException {

        LOG.info("verifierTransaction: client=" + voIn.getCodeClient() +
                 " montant=" + voIn.getMontant() +
                 " type=" + voIn.getTypeTransaction());

        List<ComplianceAlerteDTO> alertes = new ArrayList<>();
        int scoreRisque = 0;

        // Règle 1 — Filtrage listes sanctions
        List<SanctionMatchDTO> matches = filtrerSanctions(
            voIn.getNomContrepartie(),
            voIn.getNumeroIdentiteContrepartie(),
            voIn.getIbanContrepartie()
        );
        if (!matches.isEmpty()) {
            alertes.add(ComplianceAlerteDTO.builder()
                .typeAlerte("SANCTIONS_HIT")
                .niveauRisque("CRITIQUE")
                .description("Correspondance liste sanctions: " +
                    matches.get(0).getNomEntite() +
                    " (source: " + matches.get(0).getSourceListe() + ")")
                .build());
            scoreRisque += 100;
        }

        // Règle 2 — Détection structuring (montants juste sous seuil)
        if (detecterStructuring(voIn)) {
            alertes.add(ComplianceAlerteDTO.builder()
                .typeAlerte("STRUCTURING_SUSPICION")
                .niveauRisque("ELEVE")
                .description("Montant de " + voIn.getMontant() +
                    " MAD proche du seuil de déclaration (" +
                    SEUIL_ESPECES_DECLARATION + " MAD)")
                .build());
            scoreRisque += 50;
        }

        // Règle 3 — Détection smurfing (fractionnement)
        if (detecterSmurfing(voIn)) {
            alertes.add(ComplianceAlerteDTO.builder()
                .typeAlerte("SMURFING_SUSPICION")
                .niveauRisque("ELEVE")
                .description("Fractionnement détecté: " +
                    NB_TX_SMURFING_SEUIL + "+ transactions similaires " +
                    "dans les " + FENETRE_SMURFING_HEURES + " dernières heures")
                .build());
            scoreRisque += 60;
        }

        // Règle 4 — Profil comportemental
        ProfilRisqueDTO profil = getProfilComportemental(voIn.getCodeClient());
        if (profil != null) {
            double ecart = calculerEcartSigma(voIn.getMontant(),
                profil.getMoyenneMensuelle(), profil.getEcartType());
            if (ecart > SIGMA_ECART_ALERTE) {
                alertes.add(ComplianceAlerteDTO.builder()
                    .typeAlerte("ECART_COMPORTEMENTAL")
                    .niveauRisque("MOYEN")
                    .description(String.format(
                        "Transaction %.0f fois supérieure à la moyenne " +
                        "historique du client (%.2f sigma)", ecart, ecart))
                    .build());
                scoreRisque += 30;
            }
        }

        // Règle 5 — Pays à risque élevé
        if (voIn.getPaysDestination() != null) {
            PaysRisqueDTO paysRisque = getPaysRisque(voIn.getPaysDestination());
            if (paysRisque != null && "LISTE_NOIRE".equals(paysRisque.getListeGafi())) {
                alertes.add(ComplianceAlerteDTO.builder()
                    .typeAlerte("PAYS_RISQUE_GAFI")
                    .niveauRisque("CRITIQUE")
                    .description("Destination vers pays liste noire GAFI: " +
                        voIn.getPaysDestination())
                    .build());
                scoreRisque += 80;
            } else if (paysRisque != null &&
                       "LISTE_GRISE".equals(paysRisque.getListeGafi())) {
                alertes.add(ComplianceAlerteDTO.builder()
                    .typeAlerte("PAYS_SURVEILLANCE_GAFI")
                    .niveauRisque("MOYEN")
                    .description("Destination vers pays sous surveillance GAFI: " +
                        voIn.getPaysDestination())
                    .build());
                scoreRisque += 30;
            }
        }

        // Règle 6 — Seuil déclaration espèces
        boolean declarationRequired = false;
        if ("ESPECES_DEPOT".equals(voIn.getTypeTransaction()) &&
            voIn.getMontant().compareTo(SEUIL_ESPECES_DECLARATION) >= 0) {
            declarationRequired = true;
            if (voIn.getJustificatifPresent() == null ||
                !voIn.getJustificatifPresent()) {
                alertes.add(ComplianceAlerteDTO.builder()
                    .typeAlerte("DECLARATION_ESPECES_MANQUANTE")
                    .niveauRisque("ELEVE")
                    .description("Dépôt espèces > 10 000 MAD sans justificatif")
                    .build());
                scoreRisque += 40;
            }
        }

        // Persistance des alertes
        if (!alertes.isEmpty()) {
            persisterAlertes(voIn, alertes);
            mettreAJourScoreRisqueClient(voIn.getCodeClient(),
                scoreRisque, alertes.size());
        }

        // Décision finale
        String decision = determinerDecision(scoreRisque, alertes);
        boolean bloque  = "BLOQUE".equals(decision);

        // Notification compliance si alerte critique
        boolean hasCritique = alertes.stream()
            .anyMatch(a -> "CRITIQUE".equals(a.getNiveauRisque()));
        if (hasCritique) {
            notifierEquipeComplianceAsync(voIn, alertes);
        }

        return ComplianceCheckResultVoOut.builder()
            .codeClient(voIn.getCodeClient())
            .decision(decision)
            .bloque(bloque)
            .scoreRisque(scoreRisque)
            .alertes(alertes)
            .declarationRequise(declarationRequired)
            .dateVerification(LocalDateTime.now())
            .referenceControle("CTRL_" + System.currentTimeMillis())
            .build();
    }

    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<ComplianceAlerteDTO> getAlertesOuvertes(String codeClient)
            throws TechnicalException {

        List<ComplianceAlerteDTO> alertes = new ArrayList<>();
        String sql =
            "SELECT a.ID_ALERTE, a.TYPE_ALERTE, a.NIVEAU_RISQUE, " +
            "  a.DESCRIPTION, a.MONTANT, a.DATE_CREATION, a.STATUT " +
            "FROM T_ALERTES_COMPLIANCE a " +
            "WHERE a.CODE_CLIENT = ? AND a.STATUT = 'OUVERTE' " +
            "ORDER BY a.NIVEAU_RISQUE DESC, a.DATE_CREATION DESC";

        try (Connection conn = complianceDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, codeClient);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    alertes.add(ComplianceAlerteDTO.builder()
                        .idAlerte(rs.getLong("ID_ALERTE"))
                        .typeAlerte(rs.getString("TYPE_ALERTE"))
                        .niveauRisque(rs.getString("NIVEAU_RISQUE"))
                        .description(rs.getString("DESCRIPTION"))
                        .montant(rs.getBigDecimal("MONTANT"))
                        .dateCreation(rs.getTimestamp("DATE_CREATION")
                            .toLocalDateTime())
                        .statut(rs.getString("STATUT"))
                        .build());
                }
            }
        } catch (SQLException e) {
            throw new TechnicalException("ERR_COMPL_001", e.getMessage(), e);
        }
        return alertes;
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void genererDeclarationTRAPROC(String codeClient,
            String referenceTransaction, BigDecimal montant,
            String typeDeclaration) throws TechnicalException {

        LOG.info("genererDeclarationTRAPROC: client=" + codeClient +
                 " ref=" + referenceTransaction);

        String sql =
            "INSERT INTO T_DECLARATIONS_TRAPROC " +
            "  (ID_DECL, CODE_CLIENT, REFERENCE_TRANSACTION, " +
            "   MONTANT, TYPE_DECLARATION, DATE_DECLARATION, " +
            "   STATUT, CANAL_ENVOI) " +
            "VALUES (SEQ_DECLARATIONS.NEXTVAL, ?, ?, ?, ?, SYSDATE, " +
            "        'EN_ATTENTE', 'TRAPROC_API')";

        try (Connection conn = complianceDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, codeClient);
            ps.setString(2, referenceTransaction);
            ps.setBigDecimal(3, montant);
            ps.setString(4, typeDeclaration);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new TechnicalException("ERR_TRAPROC", e.getMessage(), e);
        }
    }

    // ── Privés ────────────────────────────────────────────────

    private List<SanctionMatchDTO> filtrerSanctions(String nom,
            String numIdentite, String iban) {
        List<SanctionMatchDTO> matches = new ArrayList<>();
        try (Connection conn = complianceDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     SQL_FILTRAGE_SANCTIONS)) {
            ps.setString(1, "%" + (nom != null ? nom : "") + "%");
            ps.setString(2, numIdentite != null ? numIdentite : "");
            ps.setString(3, iban != null ? iban : "");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    matches.add(SanctionMatchDTO.builder()
                        .nomEntite(rs.getString("NOM_ENTITE"))
                        .sourceListe(rs.getString("SOURCE_LISTE"))
                        .scoreSimilarite(rs.getDouble("SCORE_SIMILARITE"))
                        .build());
                }
            }
        } catch (SQLException e) {
            LOG.warning("Erreur filtrage sanctions: " + e.getMessage());
        }
        return matches;
    }

    private boolean detecterStructuring(ComplianceCheckVoIn voIn) {
        if (!"ESPECES_DEPOT".equals(voIn.getTypeTransaction())) return false;
        return voIn.getMontant()
            .compareTo(SEUIL_STRUCTURING_DETECTION) >= 0 &&
            voIn.getMontant()
            .compareTo(SEUIL_ESPECES_DECLARATION) < 0;
    }

    private boolean detecterSmurfing(ComplianceCheckVoIn voIn) {
        LocalDateTime depuis = LocalDateTime.now()
            .minusHours(FENETRE_SMURFING_HEURES);
        try (Connection conn = analyticsDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     SQL_DETECTION_SMURFING)) {
            ps.setString(1, voIn.getCodeClient());
            ps.setTimestamp(2, java.sql.Timestamp.valueOf(depuis));
            ps.setBigDecimal(3, SEUIL_STRUCTURING_DETECTION);
            ps.setBigDecimal(4, SEUIL_ESPECES_DECLARATION);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("NB_TX") >= NB_TX_SMURFING_SEUIL;
                }
            }
        } catch (SQLException e) {
            LOG.warning("Smurfing detection error: " + e.getMessage());
        }
        return false;
    }

    private ProfilRisqueDTO getProfilComportemental(String codeClient) {
        try (Connection conn = analyticsDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     SQL_PROFIL_COMPORTEMENTAL)) {
            ps.setString(1, codeClient);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return ProfilRisqueDTO.builder()
                        .moyenneMensuelle(rs.getBigDecimal("MOYENNE_MENSUELLE"))
                        .ecartType(rs.getBigDecimal("ECART_TYPE"))
                        .maxTransactionHistorique(
                            rs.getBigDecimal("MAX_TRANSACTION_HISTORIQUE"))
                        .build();
                }
            }
        } catch (SQLException e) {
            LOG.warning("Profil comportemental error: " + e.getMessage());
        }
        return null;
    }

    private PaysRisqueDTO getPaysRisque(String codePays) {
        try (Connection conn = complianceDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_PAYS_RISQUE)) {
            ps.setString(1, codePays);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return PaysRisqueDTO.builder()
                        .codePays(rs.getString("CODE_PAYS"))
                        .niveauRisque(rs.getString("NIVEAU_RISQUE"))
                        .listeGafi(rs.getString("LISTE_GAFI"))
                        .build();
                }
            }
        } catch (SQLException e) {
            LOG.warning("Pays risque error: " + e.getMessage());
        }
        return null;
    }

    private double calculerEcartSigma(BigDecimal montant,
            java.math.BigDecimal moyenne, java.math.BigDecimal ecartType) {
        if (ecartType == null ||
            ecartType.compareTo(java.math.BigDecimal.ZERO) == 0) return 0;
        return montant.subtract(moyenne).abs()
            .divide(ecartType, 4, java.math.RoundingMode.HALF_UP)
            .doubleValue();
    }

    private void persisterAlertes(ComplianceCheckVoIn voIn,
            List<ComplianceAlerteDTO> alertes) {
        try (Connection conn = complianceDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_INSERT_ALERTE)) {
            for (ComplianceAlerteDTO alerte : alertes) {
                ps.setString(1, voIn.getCodeClient());
                ps.setString(2, alerte.getTypeAlerte());
                ps.setString(3, alerte.getNiveauRisque());
                ps.setString(4, alerte.getDescription());
                ps.setBigDecimal(5, voIn.getMontant());
                ps.setString(6, voIn.getDevise());
                ps.setString(7, voIn.getReferenceTransaction());
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (SQLException e) {
            LOG.severe("Erreur persistance alertes: " + e.getMessage());
        }
    }

    private void mettreAJourScoreRisqueClient(String codeClient,
            int scoreRisque, int nbAlertes) {
        String niveau = scoreRisque >= 80 ? "CRITIQUE"
            : scoreRisque >= 50 ? "ELEVE"
            : scoreRisque >= 20 ? "MOYEN" : "FAIBLE";
        try (Connection conn = coreDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     SQL_UPDATE_SCORE_CLIENT)) {
            ps.setString(1, codeClient);
            ps.setInt(2, scoreRisque);
            ps.setString(3, niveau);
            ps.setInt(4, nbAlertes);
            ps.setString(5, codeClient);
            ps.setInt(6, scoreRisque);
            ps.setString(7, niveau);
            ps.setInt(8, nbAlertes);
            ps.executeUpdate();
        } catch (SQLException e) {
            LOG.warning("Update score risque: " + e.getMessage());
        }
    }

    private String determinerDecision(int score,
            List<ComplianceAlerteDTO> alertes) {
        boolean hasSanctions = alertes.stream()
            .anyMatch(a -> "SANCTIONS_HIT".equals(a.getTypeAlerte()));
        boolean hasPaysNoir  = alertes.stream()
            .anyMatch(a -> "PAYS_RISQUE_GAFI".equals(a.getTypeAlerte()));
        if (hasSanctions || hasPaysNoir) return "BLOQUE";
        if (score >= 80) return "REVUE_COMPLIANCE_REQUISE";
        if (score >= 40) return "ALERTE_GENEREE";
        return "AUTORISE";
    }

    private void notifierEquipeComplianceAsync(ComplianceCheckVoIn voIn,
            List<ComplianceAlerteDTO> alertes) {
        LOG.info("Notification compliance critique: client=" +
            voIn.getCodeClient() + " alertes=" + alertes.size());
        // Email + SMS équipe compliance
    }
}
