package ma.bmce.digital.complex.exception;
public class ClientNotFoundException extends Exception {
    public ClientNotFoundException(String msg) { super(msg); }
}
