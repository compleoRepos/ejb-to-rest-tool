package ma.bmce.digital.complex.exception;
public class SanctionsViolationException extends Exception {
    public SanctionsViolationException(String msg) { super(msg); }
}
