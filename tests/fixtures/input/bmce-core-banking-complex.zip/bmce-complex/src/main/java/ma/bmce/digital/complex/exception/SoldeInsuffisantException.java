package ma.bmce.digital.complex.exception;
public class SoldeInsuffisantException extends Exception {
    public SoldeInsuffisantException(String msg) { super(msg); }
}
