package ma.bmce.digital.complex.validator;

import javax.enterprise.context.ApplicationScoped;
import java.math.BigInteger;
import java.util.logging.Logger;

/**
 * IBANValidator — CDI Bean ApplicationScoped.
 * Validation IBAN selon ISO 13616 avec algorithme MOD97.
 * Supporte les IBAN marocains (MA, 28 caractères) et SEPA.
 */
@ApplicationScoped
public class IBANValidator {

    private static final Logger LOG =
        Logger.getLogger(IBANValidator.class.getName());

    public boolean validate(String iban) {
        if (iban == null || iban.trim().isEmpty()) return false;
        String normalized = iban.replace(" ", "").toUpperCase();
        if (normalized.length() < 15 || normalized.length() > 34) return false;

        // Déplacer les 4 premiers caractères à la fin
        String rearranged = normalized.substring(4) + normalized.substring(0, 4);

        // Remplacer les lettres par des chiffres (A=10, B=11, ..., Z=35)
        StringBuilder numeric = new StringBuilder();
        for (char c : rearranged.toCharArray()) {
            if (Character.isLetter(c)) {
                numeric.append(c - 'A' + 10);
            } else {
                numeric.append(c);
            }
        }

        // Vérifier MOD 97 = 1
        BigInteger ibanNum = new BigInteger(numeric.toString());
        return ibanNum.mod(BigInteger.valueOf(97)).intValue() == 1;
    }

    public String extractBIC(String iban) {
        if (iban == null || iban.length() < 4) return null;
        String codePays = iban.substring(0, 2);
        // Mapping simplifié codes pays → BIC routing
        if ("MA".equals(codePays)) return "BCDMMAMC";
        if ("FR".equals(codePays)) return "BNPAFRPP";
        if ("DE".equals(codePays)) return "DEUTDEDB";
        return null;
    }

    public String normalizeIBAN(String iban) {
        return iban != null ? iban.replace(" ", "").toUpperCase() : null;
    }
}
