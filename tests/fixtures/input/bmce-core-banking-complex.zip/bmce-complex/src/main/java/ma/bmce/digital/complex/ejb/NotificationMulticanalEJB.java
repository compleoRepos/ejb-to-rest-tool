package ma.bmce.digital.complex.ejb;

import ma.bmce.digital.complex.exception.TechnicalException;

import javax.ejb.*;
import javax.annotation.Resource;
import javax.jms.*;
import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.logging.Logger;

/**
 * NotificationMulticanalEJB — EJB 3.x Stateless.
 * Envoi de notifications sur tous les canaux : SMS (Infobip), Email (SMTP),
 * Push mobile (Firebase FCM), WebSocket (JMS topic), In-App BMCE Direct.
 *
 * Règles de routage canal :
 *   - Alertes sécurité → SMS + Push (immédiat)
 *   - Virements > 5000 MAD → SMS + Email
 *   - Virements <= 5000 MAD → Push uniquement
 *   - Marketing → Email batch uniquement (jamais SMS)
 *   - Compliance → Email chiffré interne uniquement
 *
 * DataSources : jdbc/BMCE_NOTIF_DS
 * APIs : https://api.infobip.com/sms/2/text/single
 *        url/SMTP_BMCE
 *        https://fcm.googleapis.com/v1/projects/bmce-digital/messages:send
 */
@Stateless
@Local(NotificationMulticanalEJBLocal.class)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class NotificationMulticanalEJB implements NotificationMulticanalEJBLocal {

    private static final Logger LOG =
        Logger.getLogger(NotificationMulticanalEJB.class.getName());

    private static final BigDecimal SEUIL_SMS_VIREMENT = new BigDecimal("5000");

    private static final String SQL_PREFERENCES_NOTIF =
        "SELECT n.CANAL_SMS_ACTIF, n.CANAL_EMAIL_ACTIF, n.CANAL_PUSH_ACTIF, " +
        "  n.TELEPHONE_MOBILE, n.EMAIL_PRINCIPAL, n.DEVICE_TOKEN_PUSH, " +
        "  n.LANGUE_PREFERENCE, n.HEURE_DEBUT_NOTIF, n.HEURE_FIN_NOTIF " +
        "FROM T_PREFERENCES_NOTIF n " +
        "WHERE n.CODE_CLIENT = ? AND n.STATUT_PREFS = 'ACTIF'";

    private static final String SQL_INSERT_LOG_NOTIF =
        "INSERT INTO T_LOGS_NOTIFICATIONS " +
        "  (ID_LOG, CODE_CLIENT, TYPE_NOTIF, CANAL_UTILISE, " +
        "   CONTENU_MESSAGE, STATUT_ENVOI, DATE_ENVOI, CODE_ERREUR) " +
        "VALUES (SEQ_NOTIF_LOGS.NEXTVAL, ?, ?, ?, ?, ?, SYSDATE, ?)";

    @Resource(name = "jdbc/BMCE_NOTIF_DS")
    private DataSource notifDS;

    @Resource(name = "jms/ConnectionFactory")
    private ConnectionFactory jmsFactory;

    @Resource(name = "jms/topic/BMCE_NOTIFS")
    private Topic notifTopic;

    public void notifierVirementEmis(String codeClient, BigDecimal montant,
            String devise, String nomBenef, String reference) {
        try {
            PreferencesNotifDTO prefs = chargerPreferences(codeClient);
            if (prefs == null) return;

            String msg = String.format(
                "BMCE: Virement de %s %s vers %s effectué. Réf: %s",
                montant, devise, nomBenef, reference);

            if (montant.compareTo(SEUIL_SMS_VIREMENT) >= 0) {
                if (Boolean.TRUE.equals(prefs.getCanalSmsActif())) {
                    envoyerSMS(prefs.getTelephoneMobile(), msg);
                    loggerNotification(codeClient, "VIREMENT_EMIS",
                        "SMS", msg, "ENVOYE", null);
                }
                if (Boolean.TRUE.equals(prefs.getCanalEmailActif())) {
                    envoyerEmail(prefs.getEmailPrincipal(),
                        "Virement effectué — " + reference, msg);
                    loggerNotification(codeClient, "VIREMENT_EMIS",
                        "EMAIL", msg, "ENVOYE", null);
                }
            }
            if (Boolean.TRUE.equals(prefs.getCanalPushActif()) &&
                prefs.getDeviceTokenPush() != null) {
                envoyerPushFCM(prefs.getDeviceTokenPush(),
                    "Virement effectué", msg);
                loggerNotification(codeClient, "VIREMENT_EMIS",
                    "PUSH", msg, "ENVOYE", null);
            }

            // Broadcast WebSocket via JMS
            broadcastWebSocket(codeClient, "VIREMENT_EMIS",
                montant, devise, reference);

        } catch (Exception e) {
            LOG.warning("Notification virement échouée: " + e.getMessage());
        }
    }

    public void notifierVirementRecu(String ibanCrediteur, BigDecimal montant,
            String devise, String nomDonneur, String endToEndId) {
        LOG.info("Notification virement reçu: " + ibanCrediteur +
                 " " + montant + " " + devise);
        // Récupérer code client depuis IBAN puis notifier
    }

    public void notifierAlerteSecurite(String codeClient,
            String typeAlerte, String details) {
        try {
            PreferencesNotifDTO prefs = chargerPreferences(codeClient);
            if (prefs == null) return;

            String msg = "⚠️ BMCE SECURITE: " + typeAlerte + " — " + details;

            // Sécurité : toujours SMS + Push, même la nuit
            if (prefs.getTelephoneMobile() != null) {
                envoyerSMS(prefs.getTelephoneMobile(), msg);
            }
            if (prefs.getDeviceTokenPush() != null) {
                envoyerPushFCM(prefs.getDeviceTokenPush(),
                    "⚠️ Alerte sécurité", msg);
            }
        } catch (Exception e) {
            LOG.severe("Notification sécurité échouée: " + e.getMessage());
        }
    }

    private PreferencesNotifDTO chargerPreferences(String codeClient) {
        try (Connection conn = notifDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     SQL_PREFERENCES_NOTIF)) {
            ps.setString(1, codeClient);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return PreferencesNotifDTO.builder()
                        .canalSmsActif(rs.getBoolean("CANAL_SMS_ACTIF"))
                        .canalEmailActif(rs.getBoolean("CANAL_EMAIL_ACTIF"))
                        .canalPushActif(rs.getBoolean("CANAL_PUSH_ACTIF"))
                        .telephoneMobile(rs.getString("TELEPHONE_MOBILE"))
                        .emailPrincipal(rs.getString("EMAIL_PRINCIPAL"))
                        .deviceTokenPush(rs.getString("DEVICE_TOKEN_PUSH"))
                        .languePreference(rs.getString("LANGUE_PREFERENCE"))
                        .build();
                }
            }
        } catch (SQLException e) {
            LOG.warning("Préférences notif: " + e.getMessage());
        }
        return null;
    }

    private void envoyerSMS(String telephone, String message) {
        LOG.info("SMS → " + telephone + ": " + message.substring(0, Math.min(50, message.length())));
        // POST https://api.infobip.com/sms/2/text/single
    }

    private void envoyerEmail(String email, String sujet, String corps) {
        LOG.info("Email → " + email + " sujet: " + sujet);
        // JavaMail via url/SMTP_BMCE
    }

    private void envoyerPushFCM(String deviceToken, String titre, String corps) {
        LOG.info("Push FCM → " + deviceToken.substring(0, 10) + "...");
        // POST https://fcm.googleapis.com/v1/projects/bmce-digital/messages:send
    }

    private void broadcastWebSocket(String codeClient, String type,
            BigDecimal montant, String devise, String reference) {
        try (JMSContext ctx = jmsFactory.createContext()) {
            String payload = String.format(
                "{\"client\":\"%s\",\"type\":\"%s\"," +
                "\"montant\":%s,\"devise\":\"%s\",\"ref\":\"%s\",\"ts\":\"%s\"}",
                codeClient, type, montant, devise, reference,
                LocalDateTime.now());
            ctx.createProducer().send(notifTopic, payload);
        } catch (Exception e) {
            LOG.warning("WebSocket broadcast: " + e.getMessage());
        }
    }

    private void loggerNotification(String codeClient, String type,
            String canal, String contenu, String statut, String erreur) {
        try (Connection conn = notifDS.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_INSERT_LOG_NOTIF)) {
            ps.setString(1, codeClient);
            ps.setString(2, type);
            ps.setString(3, canal);
            ps.setString(4, contenu.length() > 500
                ? contenu.substring(0, 500) : contenu);
            ps.setString(5, statut);
            ps.setString(6, erreur);
            ps.executeUpdate();
        } catch (SQLException e) {
            LOG.warning("Log notif: " + e.getMessage());
        }
    }
}
