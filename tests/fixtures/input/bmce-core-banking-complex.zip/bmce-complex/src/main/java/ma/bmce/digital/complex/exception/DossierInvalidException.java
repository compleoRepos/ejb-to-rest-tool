package ma.bmce.digital.complex.exception;
public class DossierInvalidException extends Exception {
    public DossierInvalidException(String msg) { super(msg); }
}
