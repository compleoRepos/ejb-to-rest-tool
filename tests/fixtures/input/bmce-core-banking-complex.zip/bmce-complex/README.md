# BMCE Core Banking Complex — Projet de stress-test Compleo

## Complexité du projet

| Composant | Type | Complexité |
|-----------|------|-----------|
| CreditScoringEJB | @Stateless EJB 3.x | 7 sources de données, VaR Basel III, tableau amortissement, CNSS+DGI SOAP |
| VirementSEPAOrchestrateurEJB | @Stateless EJB 3.x | 17 étapes, ISO 20022 PAIN.001, XADES-BES, SIMT+TARGET2+SWIFT, sanctions |
| ComplianceLBCFTEJB | @Stateless EJB 3.x | Drools, OFAC+BAM, smurfing detection, structuring, sigma comportemental |
| RiskManagementEJB | @Stateless EJB 3.x | VaR historique + Monte Carlo, CVaR, stress tests BAM, Greek letters |
| NotificationMulticanalEJB | @Stateless EJB 3.x | SMS+Email+Push FCM+WebSocket, règles routage canal |
| DeviseConversionEJB | @Singleton EJB 3.x | Cache taux BAM, @Schedule horaire, calcul triangulaire |
| CLOBatch | JSR-352 3 composants | Réconciliation, commissions dégressive, suspens, checkpoint |
| DashboardOperateurServlet | HttpServlet 6 routes | VaR live, alertes, annulation transactions |
| SEPATransformer | CDI @ApplicationScoped | ISO 20022 PAIN.001/002, XSLT Saxon, MT103→ISO20022 |
| IBANValidator | CDI @ApplicationScoped | MOD97, extraction BIC, normalisation |
| CreditDataTransformer | CDI @ApplicationScoped | Normalisation revenus BAM, scoring bureau cross-source |

## DataSources (7 au total)

| JNDI | Vendor | Usage |
|------|--------|-------|
| jdbc/BMCE_CORE_DS | Oracle 19c RAC | Comptes, transactions, clients, écritures |
| jdbc/BMCE_ANALYTICS_DS | Oracle 19c | Données comportementales, profils risque |
| jdbc/BMCE_COMPLIANCE_DS | Oracle 19c | Listes sanctions, alertes LBC/FT |
| jdbc/BMCE_SWIFT_DS | Oracle 19c | Messages SWIFT archivés |
| jdbc/BMCE_RISK_DS | Oracle 19c | Positions, VaR, limites marché |
| jdbc/BMCE_MARKET_DATA_DS | Oracle 19c | Taux de change, données marché |
| jdbc/CREDIT_BUREAU_DS | IBM DB2 LUW | Bureau crédit externe, scores historiques |

## Tables Oracle (35+)

T_CLIENTS, T_COMPTES, T_CREDITS, T_MOUVEMENTS, T_SOLDES_MENSUELS,
T_GARANTIES, T_HISTORIQUE_GARANTIES, T_SCORES_CREDIT, T_ENTREPRISES,
T_TRANSACTIONS_SEPA, T_ECRITURES_COMPTABLES, T_LIMITES_SEPA,
T_POSITIONS, T_VAR_CALCULS, T_LIMITES_MARCHE, T_HISTORIQUE_PRIX,
T_ENTITES_SANCTIONNEES, T_ALERTES_COMPLIANCE, T_SCORES_RISQUE_CLIENT,
T_PROFILS_RISQUE_CLIENT, T_PAYS_RISQUE, T_DECLARATIONS_TRAPROC,
T_TAUX_CHANGE_HISTORIQUE, T_PREFERENCES_NOTIF, T_LOGS_NOTIFICATIONS,
T_COMMISSIONS_CLO, T_SUSPENS_CLO, T_HABILITATIONS_OPS,
BUREAU_DB2.T_SCORES_BUREAU (IBM DB2)

## APIs Externes (9)

- CNSS SOAP : url/CNSS_WSDL (revenus déclarés)
- DGI SOAP  : url/DGI_WSDL (revenus fiscaux)
- SIMT SOAP : url/SIMT_WSDL (clearing national BAM)
- TARGET2 SOAP : url/TARGET2_WSDL (zone euro BCE)
- SWIFT GPI REST : https://api.swift.com/v1/gpi
- BAM Sanctions REST : https://api.bam.ma/sanctions
- BAM Rates REST : https://api.bam.ma/market/rates
- Infobip SMS : https://api.infobip.com/sms/2/text/single
- FCM Push : https://fcm.googleapis.com/v1/projects/bmce-digital

## JMS (6 queues/topics)

- jms/queue/SEPA_OUTBOUND       — virements sortants
- jms/queue/SEPA_INBOUND        — virements entrants
- jms/queue/COMPLIANCE_CHECK    — contrôles async
- jms/queue/SUSPENS_CLO         — suspens réconciliation
- jms/topic/TRANSACTION_EVENTS  — événements temps réel
- jms/topic/CLO_EVENTS          — événements clôture

## Découpage microservices attendu par Compleo

```
credit-service      ← CreditScoringEJB (scoring + simulation)
sepa-service        ← VirementSEPAOrchestrateurEJB (17 étapes)
compliance-service  ← ComplianceLBCFTEJB (LBC/FT + TRAPROC)
risk-service        ← RiskManagementEJB (VaR + stress tests)
notification-service ← NotificationMulticanalEJB
devise-service      ← DeviseConversionEJB (@Singleton cache)
clo-service         ← CLOBatch (réconciliation nocturne)
ops-service         ← DashboardOperateurServlet
```
