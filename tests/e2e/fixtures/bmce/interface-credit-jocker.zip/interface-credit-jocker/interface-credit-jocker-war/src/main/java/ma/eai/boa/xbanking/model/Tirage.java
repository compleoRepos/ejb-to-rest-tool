package ma.eai.boa.xbanking.model;

import ma.eai.boa.xbanking.utils.Constants;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import java.io.Serializable;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Tirage", namespace = Constants.NAME_SPACE_CREDIT)
public class Tirage implements Serializable {
    private static final long serialVersionUID = 1L;
    private String noDoss;

    private String libelle;

    private String mntTirage;

    private String durTirage;

    private String dt1Echeance;

    private String resteTirage;

    private String montant1Echeance;

    private String centreFrais;

    private String categorie;

    private String noTiers;

    private String mntDispo;

    private String nomClient;

    private String dtDebTirage;

    private String compte;

    private String nbrEchEchu;

    private String nbrEchRest;

    private String msgRefus;

    private String sourceOperation;

    private String dateJour;

    private String codeRetourGab;

    private String idTirage;

    private String etatTirage;

    private String numTirage;

    public String getCodeRetourGab() {
	return this.codeRetourGab;
    }

    public void setCodeRetourGab(String codeRetourGab) {
	this.codeRetourGab = codeRetourGab;
    }

    public String getNumTirage() {
	return this.numTirage;
    }

    public void setNumTirage(String numTirage) {
	this.numTirage = numTirage;
    }

    public String getDateJour() {
	return this.dateJour;
    }

    public void setDateJour(String dateJour) {
	this.dateJour = dateJour;
    }

    public String getNoDoss() {
	return this.noDoss;
    }

    public void setNoDoss(String noDoss) {
	this.noDoss = noDoss;
    }

    public String getLibelle() {
	return this.libelle;
    }

    public void setLibelle(String libelle) {
	this.libelle = libelle;
    }

    public String getMntTirage() {
	return this.mntTirage;
    }

    public void setMntTirage(String mntTirage) {
	this.mntTirage = mntTirage;
    }

    public String getDurTirage() {
	return this.durTirage;
    }

    public void setDurTirage(String durTirage) {
	this.durTirage = durTirage;
    }

    public String getDt1Echeance() {
	return this.dt1Echeance;
    }

    public void setDt1Echeance(String dt1Echeance) {
	this.dt1Echeance = dt1Echeance;
    }

    public String getResteTirage() {
	return this.resteTirage;
    }

    public void setResteTirage(String resteTirage) {
	this.resteTirage = resteTirage;
    }

    public String getMontant1Echeance() {
	return this.montant1Echeance;
    }

    public void setMontant1Echeance(String montant1Echeance) {
	this.montant1Echeance = montant1Echeance;
    }

    public String getCentreFrais() {
	return this.centreFrais;
    }

    public void setCentreFrais(String centreFrais) {
	this.centreFrais = centreFrais;
    }

    public String getCategorie() {
	return this.categorie;
    }

    public void setCategorie(String categorie) {
	this.categorie = categorie;
    }

    public String getNoTiers() {
	return this.noTiers;
    }

    public void setNoTiers(String noTiers) {
	this.noTiers = noTiers;
    }

    public String getNomClient() {
	return this.nomClient;
    }

    public void setNomClient(String nomClient) {
	this.nomClient = nomClient;
    }

    public String getDtDebTirage() {
	return this.dtDebTirage;
    }

    public void setDtDebTirage(String dtDebTirage) {
	this.dtDebTirage = dtDebTirage;
    }

    public String getCompte() {
	return this.compte;
    }

    public void setCompte(String compte) {
	this.compte = compte;
    }

    public String getNbrEchRest() {
	return this.nbrEchRest;
    }

    public void setNbrEchRest(String nbrEchRest) {
	this.nbrEchRest = nbrEchRest;
    }

    public String getNbrEchEchu() {
	return this.nbrEchEchu;
    }

    public void setNbrEchEchu(String nbrEchEchu) {
	this.nbrEchEchu = nbrEchEchu;
    }

    public String getMntDispo() {
	return this.mntDispo;
    }

    public void setMntDispo(String mntDispo) {
	this.mntDispo = mntDispo;
    }

    public String getMsgRefus() {
	return this.msgRefus;
    }

    public void setMsgRefus(String msgRefus) {
	this.msgRefus = msgRefus;
    }

    public String getSourceOperation() {
	return this.sourceOperation;
    }

    public void setSourceOperation(String sourceOperation) {
	this.sourceOperation = sourceOperation;
    }

    public String getIdTirage() {
	return this.idTirage;
    }

    public void setIdTirage(String idTirage) {
	this.idTirage = idTirage;
    }

    public String getEtatTirage() {
	return this.etatTirage;
    }

    public void setEtatTirage(String etatTirage) {
	this.etatTirage = etatTirage;
    }

}
