package ma.eai.boa.xbanking.monetique.models;

import ma.eai.boa.xbanking.utils.Constants;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FluxReleveResponse", namespace = Constants.NAME_SPACE_CREDIT_MONETIQUE)
public class FluxReleveResponse {
    @XmlElement(name = "CodeReponse")
    private String code;
    @XmlElement(name = "MessageReponse")
    private String message;

    @XmlElement(name = "MntDisponible")
    private String mntDisponible;

    @XmlElement(name = "Ligne")
    private List<Ligne> ligne;

    public List<Ligne> getLigne() {
	if (ligne == null) {
	    ligne = new ArrayList<>();
	}
	return ligne;
    }

    public void setLigne(List<Ligne> ligne) {
	this.ligne = ligne;
    }

    public String getCode() {
	return code;
    }

    public void setCode(String code) {
	this.code = code;
    }

    public String getMessage() {
	return message;
    }

    public void setMessage(String message) {
	this.message = message;
    }

    public String getMntDisponible() {
	return mntDisponible;
    }

    public void setMntDisponible(String mntDisponible) {
	this.mntDisponible = mntDisponible;
    }

    @Override
    public String toString() {
	return "FluxReleveResponse{" + "code='" + code + '\'' + ", message='" + message + '\'' + ", mntDisponible='"
		+ mntDisponible + '\'' + ", ligne=" + ligne + '}';
    }
}
