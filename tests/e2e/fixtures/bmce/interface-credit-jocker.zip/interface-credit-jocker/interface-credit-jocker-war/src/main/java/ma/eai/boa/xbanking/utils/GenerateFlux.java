package ma.eai.boa.xbanking.utils;

import ma.eai.midw.log.Log;

public class GenerateFlux {
    private static final String XML_HEADER = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n\r\n";
    private static final String SOAP_ENVELOPE_START =
	    "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\">\r\n" + "  <soap:Header/>\r\n"
		    + "  <soap:Body>\r\n" + "    <Flux>\r\n";
    private static final String SOAP_ENVELOPE_END = "    </Flux>\r\n" + "  </soap:Body>\r\n" + "</soap:Envelope>\r\n";

    // Constants for parameter names
    private static final String PARAM_LISTE_COMPTE = "listecompte";
    private static final String PARAM_COMPTE = "compte";
    private static final String PARAM_MNT_TIRAGE = "mntTirage";
    private static final String PARAM_NOM_CLIENT = "nomClient";
    private static final String PARAM_DUR_TIRAGE = "durTirage";
    private static final String PARAM_SOURCE_OPERATION = "sourceOperation";
    private static final String PARAM_NO_DOSS = "NoDoss";
    private static final String PARAM_DT_SAISI = "dtSaisi";
    private static final String PARAM_NO_SLIGN_IN = "noSlignIn";
    private static final String PARAM_NO_UTIL_IN = "noUtilIn";
    private static final String PARAM_LIBELLE = "libelle";
    private static final String PARAM_CENTRE_FRAIS = "centreFrais";
    private static final String PARAM_CATEGORIE = "categorie";
    private static final String PARAM_DT_DEB_TIRAGE = "dtDebTirage";
    private static final String PARAM_DT_1_ECHEANCE = "dt1Echeance";
    private static final String PARAM_NO_TIERS = "noTiers";
    private static final String PARAM_TYP_BLOCAGE = "TYPBLOCAGE";
    private static final String PARAM_ETAT = "ETAT";
    private static final String PARAM_NO_COMPTE = "NOCOMPTE";
    private static final String PARAM_DATE_BLOCAGE = "DATEBLOCAGE";
    private static final String PARAM_MOTIF = "MOTIF";

    private static String createFlux(String action, String... params) {
	StringBuilder flux = new StringBuilder(XML_HEADER).append(SOAP_ENVELOPE_START).append("<action>").append(action)
		.append("</action>\r\n");

	for (int i = 0; i < params.length; i += 2) {
	    flux.append("<").append(params[i]).append(">").append(params[i + 1]).append("</").append(params[i])
		    .append(">\r\n");
	}

	flux.append(SOAP_ENVELOPE_END);

	String result = flux.toString();
	Log.info("flux in : " + action + " " + result);
	return result;
    }

    public static String getFluxLigneDeclic(String listCompte) {
	return createFlux("selectLigneDECLIC", PARAM_LISTE_COMPTE, listCompte);
    }

    public static String getFluxDeclicTPE(String compte, String mntTirage, String nomClient, String durTirage,
	    String sourceOperation) {
	return createFlux("traitementTPE", PARAM_COMPTE, compte, PARAM_MNT_TIRAGE, mntTirage, PARAM_NOM_CLIENT,
		nomClient, PARAM_DUR_TIRAGE, durTirage, PARAM_SOURCE_OPERATION, sourceOperation);
    }

    public static String getFluxLigneDeclicGAB(String listCompte) {
	return createFlux("selectLigneDECLICGAB", PARAM_LISTE_COMPTE, listCompte);
    }

    public static String selectTirageDECLIC(String noDoss) {
	return createFlux("selectTirageDECLIC", PARAM_NO_DOSS, noDoss);
    }

    public static String selectTirageDECLICModif(String noDoss) {
	return createFlux("selectTirageDECLICModif", PARAM_NO_DOSS, noDoss);
    }

    public static String updateTirage(String noDoss, String dtSaisi, String durTirage, String sourceOperation,
	    String noSlignIn, String noUtilIn) {
	return createFlux("updateTirage", PARAM_NO_DOSS, noDoss, PARAM_DT_SAISI, dtSaisi, PARAM_DUR_TIRAGE, durTirage,
		PARAM_SOURCE_OPERATION, sourceOperation, PARAM_NO_SLIGN_IN, noSlignIn, PARAM_NO_UTIL_IN, noUtilIn);
    }

    public static String updateTirageDerogation(String noDoss, String dtSaisi, String durTirage, String sourceOperation,
	    String noSlignIn, String noUtilIn) {
	return createFlux("updateTirageDerogation", PARAM_NO_DOSS, noDoss, PARAM_DT_SAISI, dtSaisi, PARAM_DUR_TIRAGE,
		durTirage, PARAM_SOURCE_OPERATION, sourceOperation, PARAM_NO_SLIGN_IN, noSlignIn, PARAM_NO_UTIL_IN,
		noUtilIn);
    }

    public static String selectTirageDECLICGAB(String noDoss) {
	return createFlux("selectTirageDECLICGAB", PARAM_NO_DOSS, noDoss);
    }

    public static String traitementDECLIC(String compte, String montantEVOLAN, String libelle, String centreFrais,
	    String categorie, String dtDebTirage, String dt1Echeance, String noDoss, String noTiers, String nomClient,
	    String nbrEcheance, String sourceOperation) {
	return createFlux("traitementDECLIC", PARAM_COMPTE, compte, PARAM_MNT_TIRAGE, montantEVOLAN, PARAM_LIBELLE,
		libelle, PARAM_CENTRE_FRAIS, centreFrais, PARAM_CATEGORIE, categorie, PARAM_DT_DEB_TIRAGE, dtDebTirage,
		PARAM_DT_1_ECHEANCE, dt1Echeance, PARAM_NO_DOSS, noDoss, PARAM_NO_TIERS, noTiers, PARAM_NOM_CLIENT,
		nomClient, PARAM_DUR_TIRAGE, nbrEcheance, PARAM_SOURCE_OPERATION, sourceOperation);
    }

    public static String traitementGAB(String compte, String montantEVOLAN, String libelle, String centreFrais,
	    String categorie, String dtDebTirage, String dt1Echeance, String noDoss, String noTiers, String nomClient,
	    String nbrEcheance, String sourceOperation) {
	return createFlux("traitementGAB", PARAM_COMPTE, compte, PARAM_MNT_TIRAGE, montantEVOLAN, PARAM_LIBELLE,
		libelle, PARAM_CENTRE_FRAIS, centreFrais, PARAM_CATEGORIE, categorie, PARAM_DT_DEB_TIRAGE, dtDebTirage,
		PARAM_DT_1_ECHEANCE, dt1Echeance, PARAM_NO_DOSS, noDoss, PARAM_NO_TIERS, noTiers, PARAM_NOM_CLIENT,
		nomClient, PARAM_DUR_TIRAGE, nbrEcheance, PARAM_SOURCE_OPERATION, sourceOperation);
    }

    public static String simulationTirageGAB(String mntTirage, String durTirage, String compte) {
	return createFlux("SimulationTirageGAB", PARAM_MNT_TIRAGE, mntTirage, PARAM_DUR_TIRAGE, durTirage, PARAM_COMPTE,
		compte);
    }

    public static String blocageJOKER(String typBlocage, String etat, String noCompte, String dateBlocage,
	    String motif) {
	return createFlux("BlocageEvolan", PARAM_TYP_BLOCAGE, typBlocage, PARAM_ETAT, etat, PARAM_NO_COMPTE, noCompte,
		PARAM_DATE_BLOCAGE, dateBlocage, PARAM_MOTIF, motif);
    }
}
