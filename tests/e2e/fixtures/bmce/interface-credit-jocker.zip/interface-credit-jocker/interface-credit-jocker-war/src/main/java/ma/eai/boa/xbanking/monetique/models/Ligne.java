package ma.eai.boa.xbanking.monetique.models;

import ma.eai.boa.xbanking.utils.Constants;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Ligne", namespace = Constants.NAME_SPACE_CREDIT_MONETIQUE)
public class Ligne {

    @XmlElement(name = "DateTransaction")
    private String dateTransaction;
    @XmlElement(name = "NumTransaction")
    private String numTransaction;
    @XmlElement(name = "MntTransaction")
    private String mntTransaction;
    @XmlElement(name = "LibelleTransaction")
    private String libelleTransaction;

    public String getDateTransaction() {
	return dateTransaction;
    }

    public void setDateTransaction(String dateTransaction) {
	this.dateTransaction = dateTransaction;
    }

    public String getNumTransaction() {
	return numTransaction;
    }

    public void setNumTransaction(String numTransaction) {
	this.numTransaction = numTransaction;
    }

    public String getMntTransaction() {
	return mntTransaction;
    }

    public void setMntTransaction(String mntTransaction) {
	this.mntTransaction = mntTransaction;
    }

    public String getLibelleTransaction() {
	return libelleTransaction;
    }

    public void setLibelleTransaction(String libelleTransaction) {
	this.libelleTransaction = libelleTransaction;
    }

    @Override
    public String toString() {
	return "Ligne{" + "dateTransaction='" + dateTransaction + '\'' + ", numTransaction='" + numTransaction + '\''
		+ ", mntTransaction='" + mntTransaction + '\'' + ", libelleTransaction='" + libelleTransaction + '\''
		+ '}';
    }
}
