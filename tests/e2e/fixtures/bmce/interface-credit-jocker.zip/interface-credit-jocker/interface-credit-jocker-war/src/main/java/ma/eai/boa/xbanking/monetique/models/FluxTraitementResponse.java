package ma.eai.boa.xbanking.monetique.models;

import ma.eai.boa.xbanking.utils.Constants;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FluxTraitementResponse", namespace = Constants.NAME_SPACE_CREDIT_MONETIQUE)
public class FluxTraitementResponse {
    @XmlElement(name = "CodeReponse")
    private String code;
    @XmlElement(name = "MessageReponse")
    private String message;

    public String getCode() {
	return code;
    }

    public void setCode(String code) {
	this.code = code;
    }

    public String getMessage() {
	return message;
    }

    public void setMessage(String message) {
	this.message = message;
    }

    @Override
    public String toString() {
	return "FluxTraitementResponse{" + "code='" + code + '\'' + ", message='" + message + '\'' + '}';
    }
}
