/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ma.eai.boa.xbanking.ws.monetique;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import ma.eai.boa.xbanking.monetique.models.FluxReleveResponse;
import ma.eai.boa.xbanking.monetique.models.Ligne;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.Parser;
import ma.eai.midw.connectors.SynchroneService;
import ma.eai.midw.integration.Services;
import ma.eai.midw.log.Log;
import ma.eai.boa.xbanking.utils.Constants;
import ma.eai.boa.xbanking.utils.GenerateFlux;
import ma.eai.boa.xbanking.monetique.models.FluxSimulationResponse;
import ma.eai.boa.xbanking.monetique.models.FluxSoldeResponse;
import ma.eai.boa.xbanking.monetique.models.FluxTraitementResponse;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * @author Administrateur
 */
@WebService(serviceName = "WsMonetiqueCreditJocker", targetNamespace = Constants.NAME_SPACE_CREDIT_MONETIQUE)
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT, use = SOAPBinding.Use.LITERAL, parameterStyle = SOAPBinding.ParameterStyle.WRAPPED)
public class MonetiqueCreditJockerWS {
    public static final DateTimeFormatter DT_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");
    public static final String COMPTE_LOGS = "compte : %s";
    public static final String CANAL_LOGS = "canal : %s";
    public static final String REFERENCE_LOGS = "reference : %s";
    public static final String MNT_TIRAGE_LOGS = "mntTirage: %s";
    public static final String DUREE_TIRAGE_LOGS = "DureeTirage: %s ";
    public static final String FLUX_OUT_LOGS = " flux out : %s";
    public static final String FLUX_CODE = "flux/code";
    public static final String RETURNED_SOLDE_DATA_LOGS = "returned solde data : %s";
    public static final String FLUX_TIRAGES_TIRAGE = "flux/tirages/tirage,";

    @WebMethod(operationName = "Solde")
    public FluxSoldeResponse getLigneDeclicGAB(@WebParam(name = "Compte") String compte,
            @WebParam(name = "Canal") String canal, @WebParam(name = "Reference") String reference) {
        Log.setNewThreadId();
        Log.setServiceName("getLigneDeclicGAB  [ ' Solde ' ] ");
        Log.info("start : getLigneDeclicGAB");

        return getSolde(compte, canal, reference);
    }

    private FluxSoldeResponse getSolde(String compte, String canal, String reference) {
        Log.info(String.format(COMPTE_LOGS, compte));
        Log.info(String.format(CANAL_LOGS, canal));
        Log.info(String.format(REFERENCE_LOGS, reference));
        String fluxLigneDeclic = GenerateFlux.getFluxLigneDeclicGAB(compte);
        SynchroneService declicEjbService = null;
        FluxSoldeResponse fluxRetour = new FluxSoldeResponse();

        try {
            Log.info("num compte = " + compte);
            declicEjbService = Services.find(Constants.UDDI_DECLIC_SERVICES, SynchroneService.class);

            Envelope reponseEJB = declicEjbService.process(Parser.unmarshall(fluxLigneDeclic));
            Log.info(String.format(FLUX_OUT_LOGS, reponseEJB));
            reponseEJB = Parser.update(reponseEJB);
            String code = reponseEJB.getNodeAsString(FLUX_CODE);
            Log.info("code = " + code);
            if (code != null) {
                fluxRetour.setCode("222");
                fluxRetour.setMessage("Cursor vide pas de ligne de crédit.");
            } else {

                String blocageBase = reponseEJB.getNodeAsString("flux/ligne/blocageBase");
                String blocageDoss = reponseEJB.getNodeAsString("flux/ligne/blocageDoss");
                if ("1".equalsIgnoreCase(blocageBase)) {
                    fluxRetour.setCode("900");
                    fluxRetour.setMessage("Base bloquée.");
                } else if ("1".equalsIgnoreCase(blocageDoss)) {
                    fluxRetour.setCode("901");
                    fluxRetour.setMessage("Dossier bloqué.");
                } else {
                    fluxRetour.setCode("000");
                    fluxRetour.setMessage("OK. Cursor plein.");
                }

                fluxRetour.setDateDoctroi(reponseEJB.getNodeAsString("flux/ligne/dateDoctroi"));
                fluxRetour.setEncours(reponseEJB.getNodeAsString("flux/ligne/encours"));
                fluxRetour.setImpayes(reponseEJB.getNodeAsString("flux/ligne/impayes"));
                fluxRetour.setMntDisponible(reponseEJB.getNodeAsString("flux/ligne/mntDisponible"));
                fluxRetour.setNoDoss(reponseEJB.getNodeAsString("flux/ligne/noDoss"));
            }
        } catch (Throwable e) {
            fluxRetour.setCode("111");
            fluxRetour.setMessage(Constants.PROBLEM_TECHNIQUE);
            Log.error("Solde error ", e);

        }
        Log.info(String.format(RETURNED_SOLDE_DATA_LOGS, fluxRetour));
        Log.info("End");
        return fluxRetour;
    }

    @WebMethod(operationName = "Simulation")
    public FluxSimulationResponse simulationTirageGAB(@WebParam(name = "MntTirage") String mntTirage,
            @WebParam(name = "DureeTirage") String DureeTirage, @WebParam(name = "Compte") String compte,
            @WebParam(name = "Canal") String canal, @WebParam(name = "Reference") String reference) {
        String fluxTirageDeclic = GenerateFlux.simulationTirageGAB(mntTirage, DureeTirage, compte);
        SynchroneService declickServices = null;
        Log.setNewThreadId();
        Log.setServiceName("simulationTirageGAB  [ ' Solde ' ] ");
        Log.info("start : simulationTirageGAB");
        Log.info(String.format(COMPTE_LOGS, compte));
        Log.info(String.format(CANAL_LOGS, canal));
        Log.info(String.format(REFERENCE_LOGS, reference));
        Log.info(String.format(MNT_TIRAGE_LOGS, mntTirage));
        Log.info(String.format(DUREE_TIRAGE_LOGS, DureeTirage));
        FluxSimulationResponse fluxSimulationResponse = new FluxSimulationResponse();
        try {

            declickServices = Services.find(Constants.UDDI_DECLIC_SERVICES, SynchroneService.class);
            Log.info(String.format(FLUX_OUT_LOGS, declickServices));

            Envelope reponseEJB = declickServices.process(Parser.unmarshall(fluxTirageDeclic));
            reponseEJB = Parser.update(reponseEJB);

            String codeGab = reponseEJB.getNodeAsString("flux/tirage/codeRetourGab");
            Log.info("codeGab: " + codeGab);
            if (codeGab.equals("000")) {
                Log.info("entre if case :000 ");
                fluxSimulationResponse.setCode("000");
                fluxSimulationResponse.setMessage("Traitement terminé avec succès");
                fluxSimulationResponse.setMntEcheance(reponseEJB.getNodeAsString("flux/tirage/montant1Echeance"));
                Log.info("sortie if case :000 ");
            } else if ("444".equals(codeGab)) {
                Log.info("entre if case :444 ");
                fluxSimulationResponse.setCode("444");
                fluxSimulationResponse.setMessage("Montant choisi est supéreur au Disponible");
                Log.info("sortie if case :444 ");
            } else if ("333".equals(codeGab)) {
                Log.info("entre if case :333 ");
                fluxSimulationResponse.setCode("333");
                fluxSimulationResponse.setMessage("Montant choisi est inférieur à 500 DH");
                Log.info("sortie if case :333 ");
            } else {
                Log.info("entre if case :else ");
                fluxSimulationResponse.setCode("009");
                fluxSimulationResponse.setMessage("Problème technique");
                Log.info("sortie if case :else ");
            }

        } catch (Exception e) {
            fluxSimulationResponse.setCode("009");
            fluxSimulationResponse.setMessage("Problème technique");
            Log.error("simulation error ", e);

        }
        Log.info("Fin simulation web service joker: ");
        Log.info(String.format(RETURNED_SOLDE_DATA_LOGS, fluxSimulationResponse));
        Log.info("End");

        return fluxSimulationResponse;
    }

    @WebMethod(operationName = "Releve")
    public FluxReleveResponse selectTirageDECLICGAB(@WebParam(name = "Compte") String compte,
            @WebParam(name = "Canal") String canal, @WebParam(name = "Reference") String reference) {
        Log.setNewThreadId();
        Log.setServiceName("selectTirageDECLICGAB  [ ' Releve ' ] ");
        Log.info("start : selectTirageDECLICGAB");
        Log.info(String.format(COMPTE_LOGS, compte));
        Log.info(String.format(CANAL_LOGS, canal));
        Log.info(String.format(REFERENCE_LOGS, reference));
        FluxSoldeResponse fluxSoldeResponse = this.getSolde(compte, canal, reference);
        FluxReleveResponse fluxReleveResponse = new FluxReleveResponse();
        try {
            if (!"000".equals(fluxSoldeResponse.getCode())) {
                fluxReleveResponse.setCode(fluxSoldeResponse.getCode());
                fluxReleveResponse.setMessage(fluxSoldeResponse.getMessage());
                return fluxReleveResponse;
            }
            String noDoss = fluxSoldeResponse.getNoDoss();
            String fluxTirageDeclic = GenerateFlux.selectTirageDECLICGAB(noDoss);
            SynchroneService declickServices = null;

            Log.info("num dossier" + noDoss);
            declickServices = Services.find(Constants.UDDI_DECLIC_SERVICES, SynchroneService.class);
            Log.info(String.format(FLUX_OUT_LOGS, declickServices));
            Envelope reponseEJB = declickServices.process(Parser.unmarshall(fluxTirageDeclic));
            reponseEJB = Parser.update(reponseEJB);
            List<String> listTirages = reponseEJB.getNodeAsList("flux/Tirages");
            if (listTirages == null) {
                fluxReleveResponse.setCode("000");
                fluxReleveResponse.setMessage("OK");
                return fluxReleveResponse;
            }
            int nbTirages = listTirages.size();
            Log.info("nbre de tirages " + nbTirages);
            fluxReleveResponse.setMntDisponible(fluxSoldeResponse.getMntDisponible());
            for (int tirageIndex = 1; tirageIndex <= nbTirages; tirageIndex++) {

                Ligne ligne = new Ligne();
                ligne.setNumTransaction(reponseEJB.getNodeAsString(FLUX_TIRAGES_TIRAGE + tirageIndex + "/idTirage"));
                ligne.setMntTransaction(reponseEJB.getNodeAsString(FLUX_TIRAGES_TIRAGE + tirageIndex + "/nmtTirage"));
                ligne.setLibelleTransaction(reponseEJB.getNodeAsString(FLUX_TIRAGES_TIRAGE + tirageIndex + "/libelle"));
                ligne.setDateTransaction(
                        reponseEJB.getNodeAsString(FLUX_TIRAGES_TIRAGE + tirageIndex + "/dtDebTirage"));
                Log.info(String.format("add ligne tirage %s", ligne));
                fluxReleveResponse.getLigne().add(ligne);
            }

            fluxReleveResponse.setCode("000");
            fluxReleveResponse.setMessage("OK");
        } catch (Exception e) {
            fluxReleveResponse.setCode("009");
            fluxReleveResponse.setMessage(Constants.PROBLEM_TECHNIQUE);
            Log.error("releve error ", e);
        }
        Log.info("Etape 2 : fin fonction select tirage declic GAB" + fluxReleveResponse);
        Log.info(String.format(RETURNED_SOLDE_DATA_LOGS, fluxReleveResponse));
        Log.info("End");

        return fluxReleveResponse;
    }

    @WebMethod(operationName = "Traitement")
    public FluxTraitementResponse Traitement(@WebParam(name = "Compte") String compte,
            @WebParam(name = "Canal") String canal, @WebParam(name = "MntTirage") String mntTirage,
            @WebParam(name = "DureeTirage") String dureeTirage, @WebParam(name = "LibelleTirage") String libelleTirage,
            @WebParam(name = "Reference") String reference) {
        Log.setNewThreadId();
        Log.setServiceName(String.format("[ ' Traitement ' : '%s'] ", canal));
        Log.info("start : Traitement");
        Log.info(String.format(COMPTE_LOGS, compte));
        Log.info(String.format(CANAL_LOGS, canal));
        Log.info(String.format("mntTirage : %s", mntTirage));
        Log.info(String.format("dureeTirage : %s", dureeTirage));
        Log.info(String.format("libelleTirage : %s", libelleTirage));
        Log.info(String.format(REFERENCE_LOGS, reference));
        FluxTraitementResponse fluxTraitementResponse = new FluxTraitementResponse();
        try {
            String categorie = compte.substring(12, 15);
            String centredefrais = compte.substring(3, 6) + compte.substring(10, 12);
            LocalDate currentDate = LocalDate.now();
            Long dureeTirageToAdd = Long.parseLong(dureeTirage);
            LocalDate dateEcheance = currentDate.plusMonths(dureeTirageToAdd);
            String dtDebTirage = DT_FORMATTER.format(currentDate); // current  date
            String dt1Echeance = DT_FORMATTER.format(dateEcheance);
            String noTiers = "0000000";
            String nomClient = " ";

            FluxSoldeResponse fluxSoldeResponse = this.getSolde(compte, canal, reference);
            if (!"000".equals(fluxSoldeResponse.getCode())) {
                fluxTraitementResponse.setCode(fluxSoldeResponse.getCode());
                fluxTraitementResponse.setMessage(fluxSoldeResponse.getMessage());
                return fluxTraitementResponse;
            }
            String noDoss = fluxSoldeResponse.getNoDoss();
            String fluxTirageDeclic;
            if ("GAB".equalsIgnoreCase(canal.toLowerCase())) {
                String sourceOperation = "GAB";
                fluxTirageDeclic = GenerateFlux.traitementGAB(compte, mntTirage, libelleTirage, centredefrais,
                        categorie, dtDebTirage, dt1Echeance, noDoss, noTiers, nomClient, dureeTirage, sourceOperation);
            } else if ("TPE".equalsIgnoreCase(canal.toLowerCase())) {
                Float montantDouble = Float.parseFloat(mntTirage.trim());
                Log.info("montantDouble en MAD et ,,,,,  " + montantDouble);

                double montantMinAutorise = 500.00;
                Log.info("montantMinAutorise en MAD et ,,,,,  " + montantMinAutorise);
                Float montantMaxAutorise = Float.parseFloat(fluxSoldeResponse.getMntDisponible().trim());
                Log.info("montantMaxAutorise en MAD et ,,,,,  " + montantMaxAutorise);
                Log.info("ici ");

                if (montantDouble > montantMaxAutorise) {

                    Log.info("montant superieur au montant disponible ");
                    fluxTraitementResponse.setCode("444");
                    fluxTraitementResponse.setMessage("Montant choisi est supéreur au Disponible");
                    return fluxTraitementResponse;

                }

                if (montantDouble < montantMinAutorise) {

                    Log.info("montant inferieur au montant autorise ");
                    fluxTraitementResponse.setCode("333");
                    fluxTraitementResponse.setMessage("Montant choisi est inférieur à 500 DH");
                    return fluxTraitementResponse;

                }
                fluxTirageDeclic = GenerateFlux.getFluxDeclicTPE(compte, mntTirage, nomClient, dureeTirage, canal);
            } else {
                String sourceOperation = "Immediat";
                fluxTirageDeclic = GenerateFlux.traitementDECLIC(compte, mntTirage, libelleTirage, centredefrais,
                        categorie, dtDebTirage, dt1Echeance, noDoss, noTiers, nomClient, dureeTirage, sourceOperation);

            }
            fluxTraitementResponse = traitementDeclic(fluxTirageDeclic);
        } catch (Exception exception) {
            fluxTraitementResponse.setCode("009");
            fluxTraitementResponse.setMessage(Constants.PROBLEM_TECHNIQUE);
            Log.error("Traitement error ", exception);

        }

        Log.info(String.format(RETURNED_SOLDE_DATA_LOGS, fluxTraitementResponse));
        Log.info("End");

        return fluxTraitementResponse;
    }

    private FluxTraitementResponse traitementDeclic(String fluxIn) throws Exception {
        FluxTraitementResponse fluxTraitementResponse = new FluxTraitementResponse();
        try {
            SynchroneService posteAgenceSolde = null;

            posteAgenceSolde = Services.find(Constants.UDDI_DECLIC_SERVICES, SynchroneService.class);

            Envelope reponseEJB = posteAgenceSolde.process(Parser.unmarshall(fluxIn));
            reponseEJB = Parser.update(reponseEJB);
            Log.info(String.format(FLUX_OUT_LOGS, reponseEJB));

            String code = reponseEJB.getNodeAsString(FLUX_CODE);
            Log.info("code retour" + code);
            if (code == null) {
                fluxTraitementResponse.setCode("009");
                fluxTraitementResponse.setMessage(Constants.PROBLEM_TECHNIQUE);

            } else {
                fluxTraitementResponse.setCode(reponseEJB.getNodeAsString(FLUX_CODE).substring(0, 3));
                fluxTraitementResponse.setMessage(reponseEJB.getNodeAsString("flux/message"));
            }
        } catch (Exception e) {
            fluxTraitementResponse.setCode("009");
            fluxTraitementResponse.setMessage(Constants.PROBLEM_TECHNIQUE);
            Log.error("traitementDeclic error ", e);
        }
        return fluxTraitementResponse;
    }
}
