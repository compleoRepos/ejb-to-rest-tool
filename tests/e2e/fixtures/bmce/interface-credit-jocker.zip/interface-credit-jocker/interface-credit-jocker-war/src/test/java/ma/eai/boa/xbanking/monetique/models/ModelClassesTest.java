package ma.eai.boa.xbanking.monetique.models;

import org.junit.Test;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;

public class ModelClassesTest {

    @Test
    public void testFluxReleveResponse() {
	FluxReleveResponse response = new FluxReleveResponse();
	response.setCode("200");
	response.setMessage("Success");
	response.setMntDisponible("1000");

	Ligne ligne1 = new Ligne();
	ligne1.setDateTransaction("2023-08-07");
	ligne1.setNumTransaction("123");
	ligne1.setMntTransaction("500");
	ligne1.setLibelleTransaction("Purchase");

	response.setLigne(Arrays.asList(ligne1));

	assertEquals("200", response.getCode());
	assertEquals("Success", response.getMessage());
	assertEquals("1000", response.getMntDisponible());
	assertEquals(1, response.getLigne().size());
	assertEquals(ligne1, response.getLigne().get(0));

	String expectedToString = "FluxReleveResponse{code='200', message='Success', mntDisponible='1000', ligne=[" + ligne1.toString() + "]}";
	assertEquals(expectedToString, response.toString());
    }

    @Test
    public void testFluxSimulationResponse() {
	FluxSimulationResponse response = new FluxSimulationResponse();
	response.setCode("200");
	response.setMessage("Success");
	response.setMntEcheance("100");

	assertEquals("200", response.getCode());
	assertEquals("Success", response.getMessage());
	assertEquals("100", response.getMntEcheance());

	String expectedToString = "FluxSimulationResponse{code='200', message='Success', mntEcheance='100'}";
	assertEquals(expectedToString, response.toString());
    }

    @Test
    public void testFluxSoldeResponse() {
	FluxSoldeResponse response = new FluxSoldeResponse();
	response.setCode("200");
	response.setMessage("Success");
	response.setNoDoss("D001");
	response.setDateDoctroi("2023-08-07");
	response.setMntDisponible("1000");
	response.setImpayes("0");
	response.setEncours("500");

	assertEquals("200", response.getCode());
	assertEquals("Success", response.getMessage());
	assertEquals("D001", response.getNoDoss());
	assertEquals("2023-08-07", response.getDateDoctroi());
	assertEquals("1000", response.getMntDisponible());
	assertEquals("0", response.getImpayes());
	assertEquals("500", response.getEncours());

	String expectedToString = "FluxSoldeResponse{code='200', message='Success', noDoss='D001', dateDoctroi='2023-08-07', mntDisponible='1000', impayes='0', encours='500'}";
	assertEquals(expectedToString, response.toString());
    }

    @Test
    public void testFluxTraitementResponse() {
	FluxTraitementResponse response = new FluxTraitementResponse();
	response.setCode("200");
	response.setMessage("Success");

	assertEquals("200", response.getCode());
	assertEquals("Success", response.getMessage());

	String expectedToString = "FluxTraitementResponse{code='200', message='Success'}";
	assertEquals(expectedToString, response.toString());
    }

    @Test
    public void testLigne() {
	Ligne ligne = new Ligne();
	ligne.setDateTransaction("2023-08-07");
	ligne.setNumTransaction("123");
	ligne.setMntTransaction("500");
	ligne.setLibelleTransaction("Purchase");

	assertEquals("2023-08-07", ligne.getDateTransaction());
	assertEquals("123", ligne.getNumTransaction());
	assertEquals("500", ligne.getMntTransaction());
	assertEquals("Purchase", ligne.getLibelleTransaction());

	String expectedToString = "Ligne{dateTransaction='2023-08-07', numTransaction='123', mntTransaction='500', libelleTransaction='Purchase'}";
	assertEquals(expectedToString, ligne.toString());
    }
}
