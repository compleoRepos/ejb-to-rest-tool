package ma.eai.boa.xbanking.monetique.models;

import ma.eai.boa.xbanking.utils.Constants;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FluxSoldeResponse", namespace = Constants.NAME_SPACE_CREDIT_MONETIQUE)
public class FluxSoldeResponse {
    @XmlElement(name = "CodeReponse")
    private String code;
    @XmlElement(name = "MessageReponse")
    private String message;
    @XmlElement(name = "NoDoss")
    private String noDoss;
    @XmlElement(name = "DateDossier")
    private String dateDoctroi;
    @XmlElement(name = "MntDisponible")
    private String mntDisponible;
    @XmlElement(name = "MntImpayes")
    private String impayes;
    @XmlElement(name = "MntEncours")
    private String encours;

    public String getNoDoss() {
	return noDoss;
    }

    public void setNoDoss(String noDoss) {
	this.noDoss = noDoss;
    }

    public String getDateDoctroi() {
	return dateDoctroi;
    }

    public void setDateDoctroi(String dateDoctroi) {
	this.dateDoctroi = dateDoctroi;
    }

    public String getMntDisponible() {
	return mntDisponible;
    }

    public void setMntDisponible(String mntDisponible) {
	this.mntDisponible = mntDisponible;
    }

    public String getImpayes() {
	return impayes;
    }

    public void setImpayes(String impayes) {
	this.impayes = impayes;
    }

    public String getEncours() {
	return encours;
    }

    public void setEncours(String encours) {
	this.encours = encours;
    }

    public String getCode() {
	return code;
    }

    public void setCode(String code) {
	this.code = code;
    }

    public String getMessage() {
	return message;
    }

    public void setMessage(String message) {
	this.message = message;
    }

    @Override
    public String toString() {
	return "FluxSoldeResponse{" + "code='" + code + '\'' + ", message='" + message + '\'' + ", noDoss='" + noDoss
		+ '\'' + ", dateDoctroi='" + dateDoctroi + '\'' + ", mntDisponible='" + mntDisponible + '\''
		+ ", impayes='" + impayes + '\'' + ", encours='" + encours + '\'' + '}';
    }
}
