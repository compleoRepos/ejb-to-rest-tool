package ma.eai.boa.xbanking.utils;

public class Constants {

    public static final String PROBLEM_TECHNIQUE = "Problème technique.";
    public static final String NAME_SPACE_CREDIT = "http://model.xbanking.boa.eai.ma";
    public static final String NAME_SPACE_CREDIT_MONETIQUE = "http://monetique.model.xbanking.boa.eai.ma";

    public static final String UDDI_DECLIC_SERVICES = "DeclicServices";
}
