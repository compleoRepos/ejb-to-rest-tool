package ma.eai.boa.xbanking.ws;

import ma.eai.boa.xbanking.model.ModelFlux;
import ma.eai.boa.xbanking.monetique.models.*;
import ma.eai.boa.xbanking.ws.monetique.MonetiqueCreditJockerWS;
import ma.eai.boa.xbanking.ws.salafin.CreditJockerWebService;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.Parser;
import ma.eai.midw.connectors.SynchroneService;
import ma.eai.midw.integration.Services;
import ma.eai.boa.xbanking.utils.Constants;
import ma.eai.boa.xbanking.utils.GenerateFlux;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class WebServicesTest {

    @Mock
    private SynchroneService mockSynchroneService;

    @Mock
    private Envelope mockEnvelope;

    private MockedStatic<Services> mockedServices;
    private MockedStatic<Parser> mockedParser;
    private MockedStatic<GenerateFlux> mockedGenerateFlux;

    @Before
    public void setUp() throws Exception {
	MockitoAnnotations.openMocks(this);
	mockedServices = mockStatic(Services.class);
	mockedParser = mockStatic(Parser.class);
	mockedGenerateFlux = mockStatic(GenerateFlux.class);

	mockedServices.when(() -> Services.find(eq(Constants.UDDI_DECLIC_SERVICES), eq(SynchroneService.class)))
		.thenReturn(mockSynchroneService);
	mockedParser.when(() -> Parser.unmarshall(anyString())).thenReturn(mockEnvelope);
	mockedParser.when(() -> Parser.update(any(Envelope.class))).thenReturn(mockEnvelope);
	mockedGenerateFlux.when(() -> GenerateFlux.getFluxLigneDeclicGAB(anyString())).thenReturn("mock flux");
	mockedGenerateFlux.when(() -> GenerateFlux.simulationTirageGAB(anyString(), anyString(), anyString())).thenReturn("mock flux");
	mockedGenerateFlux.when(() -> GenerateFlux.selectTirageDECLICGAB(anyString())).thenReturn("mock flux");
	mockedGenerateFlux.when(() -> GenerateFlux.traitementGAB(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn("mock flux");

	mockedServices.when(() -> Services.find(Constants.UDDI_DECLIC_SERVICES, SynchroneService.class)).thenReturn(new SynchroneService() {
	    @Override
	    public Envelope process(Envelope envelope) throws Exception {
		Envelope envelopeOut = Parser.unmarshall("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n" +
			"<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\">\n" +
			"\t<soap:Header>\n" +
			"\t\t<x:MidwHeader xmlns:x=\"urn:midw\">\n" +
			"\t\t\t<x:Crypt>false</x:Crypt>\n" +
			"\t\t</x:MidwHeader>\n" +
			"\t</soap:Header>\n" +
			"\t<soap:Body>\n" +
			"\t\t<flux>\n" +
			"\t\t\t<code>111</code>\n" +
			"\t\t\t<msg>pas de tirage à modifier</msg>\n" +
			"\t\t</flux>\n" +
			"\t</soap:Body>\n" +
			"</soap:Envelope>");
		envelopeOut = Parser.update(envelopeOut);
		return envelopeOut;
	    }
	});
    }

    @After
    public void tearDown() {
	mockedServices.close();
	mockedParser.close();
	mockedGenerateFlux.close();
    }

    @Test
    public void testConstantsValues() {
	assertEquals("Problème technique.", Constants.PROBLEM_TECHNIQUE);
	assertEquals("DeclicServices", Constants.UDDI_DECLIC_SERVICES);
    }

    @Test
    public void testCreditJockerWebServiceGetLigneDeclicGAB() throws Exception {
	CreditJockerWebService service = new CreditJockerWebService();
	when(mockEnvelope.getNodeAsString("flux/code")).thenReturn(null);
	when(mockEnvelope.getNodeAsString("flux/ligne/mntTotal")).thenReturn("1000");

	ModelFlux result = service.getLigneDeclicGAB("123456");

	assertNotNull(result);
	assertNotNull(result.getFlux());
	assertNotNull(result.getFlux().getLigne());
	assertEquals("1000", result.getFlux().getLigne().getMntTotal());
    }

    @Test
    public void testMonetiqueCreditJockerWSGetLigneDeclicGAB() throws Exception {
	MonetiqueCreditJockerWS service = new MonetiqueCreditJockerWS();
	when(mockEnvelope.getNodeAsString("flux/code")).thenReturn(null);
	when(mockEnvelope.getNodeAsString("flux/ligne/mntDisponible")).thenReturn("5000");

	FluxSoldeResponse result = service.getLigneDeclicGAB("123456", "WEB", "REF001");

	assertNotNull(result);
	assertEquals("000", result.getCode());
	assertEquals("5000", result.getMntDisponible());
    }

    @Test
    public void testMonetiqueCreditJockerWSSimulationTirageGAB() throws Exception {
	MonetiqueCreditJockerWS service = new MonetiqueCreditJockerWS();
	when(mockEnvelope.getNodeAsString("flux/tirage/codeRetourGab")).thenReturn("000");
	when(mockEnvelope.getNodeAsString("flux/tirage/montant1Echeance")).thenReturn("100");

	FluxSimulationResponse result = service.simulationTirageGAB("1000", "12", "123456", "WEB", "REF001");

	assertNotNull(result);
	assertEquals("000", result.getCode());
	assertEquals("100", result.getMntEcheance());
    }

    @Test
    public void testMonetiqueCreditJockerWSSelectTirageDECLICGAB() throws Exception {
	MonetiqueCreditJockerWS service = new MonetiqueCreditJockerWS();
	when(mockEnvelope.getNodeAsString("flux/code")).thenReturn(null);
	when(mockEnvelope.getNodeAsString("flux/ligne/mntDisponible")).thenReturn("5000");
	when(mockEnvelope.getNodeAsString("flux/ligne/noDoss")).thenReturn("D001");
	when(mockEnvelope.getNodeAsList("flux/Tirages")).thenReturn(java.util.Collections.singletonList("dummy"));

	FluxReleveResponse result = service.selectTirageDECLICGAB("123456", "WEB", "REF001");

	assertNotNull(result);
	assertEquals("000", result.getCode());
	assertEquals("5000", result.getMntDisponible());
	assertEquals(1, result.getLigne().size());
    }

    @Test
    public void testMonetiqueCreditJockerWSTraitement() throws Exception {
	MonetiqueCreditJockerWS service = new MonetiqueCreditJockerWS();
	when(mockEnvelope.getNodeAsString("flux/code")).thenReturn("000");
	when(mockEnvelope.getNodeAsString("flux/message")).thenReturn("Success");

	FluxTraitementResponse result = service.Traitement("123456789012345", "WEB", "1000", "12", "Test", "REF001");

	assertNotNull(result);
	assertEquals("222", result.getCode());
	assertEquals("Cursor vide pas de ligne de crédit.", result.getMessage());
    }
}