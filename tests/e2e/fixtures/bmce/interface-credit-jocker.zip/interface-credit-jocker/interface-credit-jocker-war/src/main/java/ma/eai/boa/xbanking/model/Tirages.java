package ma.eai.boa.xbanking.model;

import ma.eai.boa.xbanking.utils.Constants;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Tirages", namespace = Constants.NAME_SPACE_CREDIT)
public class Tirages {
	
	
	
	private Tirage tirage ;

	public Tirage getTirage() {
		return tirage;
	}

	public void setTirage(Tirage tirage) {
		this.tirage = tirage;
	}
	
	
	private List<Tirage> ListeTirage;

	public List<Tirage> getListeTirage() {
		return ListeTirage;
	}

	public void setListeTirage(List<Tirage> listeTirage) {
		ListeTirage = listeTirage;
	}
	
	
	
	

}
