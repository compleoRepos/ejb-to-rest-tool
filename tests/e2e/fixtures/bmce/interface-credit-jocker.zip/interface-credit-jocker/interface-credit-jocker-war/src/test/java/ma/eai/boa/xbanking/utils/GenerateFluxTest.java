package ma.eai.boa.xbanking.utils;

import org.junit.Test;
import org.junit.Before;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;

import static org.junit.Assert.assertEquals;

public class GenerateFluxTest {

    private DocumentBuilder builder;

    @Before
    public void setUp() throws Exception {
	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	builder = factory.newDocumentBuilder();
    }

    private Document parseXml(String xml) throws Exception {
	return builder.parse(new InputSource(new StringReader(xml)));
    }

    private void assertXmlContains(Document doc, String tagName, String expectedValue) {
	String actualValue = doc.getElementsByTagName(tagName).item(0).getTextContent();
	assertEquals("Unexpected value for " + tagName, expectedValue, actualValue);
    }

    @Test
    public void testGetFluxLigneDeclic() throws Exception {
	String result = GenerateFlux.getFluxLigneDeclic("123456");
	Document doc = parseXml(result);
	assertXmlContains(doc, "action", "selectLigneDECLIC");
	assertXmlContains(doc, "listecompte", "123456");
    }

    @Test
    public void testGetFluxDeclicTPE() throws Exception {
	String result = GenerateFlux.getFluxDeclicTPE("123", "1000", "John Doe", "30", "TPE");
	Document doc = parseXml(result);
	assertXmlContains(doc, "action", "traitementTPE");
	assertXmlContains(doc, "compte", "123");
	assertXmlContains(doc, "mntTirage", "1000");
	assertXmlContains(doc, "nomClient", "John Doe");
	assertXmlContains(doc, "durTirage", "30");
	assertXmlContains(doc, "sourceOperation", "TPE");
    }

    @Test
    public void testGetFluxLigneDeclicGAB() throws Exception {
	String result = GenerateFlux.getFluxLigneDeclicGAB("789012");
	Document doc = parseXml(result);
	assertXmlContains(doc, "action", "selectLigneDECLICGAB");
	assertXmlContains(doc, "listecompte", "789012");
    }

    @Test
    public void testSelectTirageDECLIC() throws Exception {
	String result = GenerateFlux.selectTirageDECLIC("D001");
	Document doc = parseXml(result);
	assertXmlContains(doc, "action", "selectTirageDECLIC");
	assertXmlContains(doc, "NoDoss", "D001");
    }

    @Test
    public void testUpdateTirage() throws Exception {
	String result = GenerateFlux.updateTirage("D002", "2023-08-07", "60", "WEB", "S001", "U001");
	Document doc = parseXml(result);
	assertXmlContains(doc, "action", "updateTirage");
	assertXmlContains(doc, "NoDoss", "D002");
	assertXmlContains(doc, "dtSaisi", "2023-08-07");
	assertXmlContains(doc, "durTirage", "60");
	assertXmlContains(doc, "sourceOperation", "WEB");
	assertXmlContains(doc, "noSlignIn", "S001");
	assertXmlContains(doc, "noUtilIn", "U001");
    }

    @Test
    public void testTraitementDECLIC() throws Exception {
	String result = GenerateFlux.traitementDECLIC("456", "2000", "Payment", "CF001", "CAT1",
		"2023-08-07", "2023-09-07", "D003", "T001",
		"Jane Doe", "30", "DECLIC");
	Document doc = parseXml(result);
	assertXmlContains(doc, "action", "traitementDECLIC");
	assertXmlContains(doc, "compte", "456");
	assertXmlContains(doc, "mntTirage", "2000");
	assertXmlContains(doc, "libelle", "Payment");
	assertXmlContains(doc, "centreFrais", "CF001");
	assertXmlContains(doc, "categorie", "CAT1");
	assertXmlContains(doc, "dtDebTirage", "2023-08-07");
	assertXmlContains(doc, "dt1Echeance", "2023-09-07");
	assertXmlContains(doc, "NoDoss", "D003");
	assertXmlContains(doc, "noTiers", "T001");
	assertXmlContains(doc, "nomClient", "Jane Doe");
	assertXmlContains(doc, "durTirage", "30");
	assertXmlContains(doc, "sourceOperation", "DECLIC");
    }

    @Test
    public void testSimulationTirageGAB() throws Exception {
	String result = GenerateFlux.simulationTirageGAB("500", "15", "789");
	Document doc = parseXml(result);
	assertXmlContains(doc, "action", "SimulationTirageGAB");
	assertXmlContains(doc, "mntTirage", "500");
	assertXmlContains(doc, "durTirage", "15");
	assertXmlContains(doc, "compte", "789");
    }

    @Test
    public void testBlocageJOKER() throws Exception {
	String result = GenerateFlux.blocageJOKER("TYPE1", "ACTIVE", "ACC001", "2023-08-07", "TEST");
	Document doc = parseXml(result);
	assertXmlContains(doc, "action", "BlocageEvolan");
	assertXmlContains(doc, "TYPBLOCAGE", "TYPE1");
	assertXmlContains(doc, "ETAT", "ACTIVE");
	assertXmlContains(doc, "NOCOMPTE", "ACC001");
	assertXmlContains(doc, "DATEBLOCAGE", "2023-08-07");
	assertXmlContains(doc, "MOTIF", "TEST");
    }
}
