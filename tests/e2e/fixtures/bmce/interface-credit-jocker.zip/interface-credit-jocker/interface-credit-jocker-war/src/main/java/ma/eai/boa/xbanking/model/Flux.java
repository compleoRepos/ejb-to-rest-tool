package ma.eai.boa.xbanking.model;

import ma.eai.boa.xbanking.utils.Constants;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Flux", namespace = Constants.NAME_SPACE_CREDIT)
public class Flux {

    private Ligne ligne;

    private Tirages tirages;

    private Tirage tirage;

    private String code;
    private String message;

    private String codeRefusTirageGAB;

    private String messagedeRefus;

    public Tirage getTirage() {
	return tirage;
    }

    public void setTirage(Tirage tirage) {
	this.tirage = tirage;
    }

    public Tirages getTirages() {
	return tirages;
    }

    public void setTirages(Tirages tirages) {
	this.tirages = tirages;
    }

    public Ligne getLigne() {
	return ligne;
    }

    public void setLigne(Ligne ligne) {
	this.ligne = ligne;
    }

    public String getCodeRefusTirageGAB() {
	return codeRefusTirageGAB;
    }

    public void setCodeRefusTirageGAB(String codeRefusTirageGAB) {
	this.codeRefusTirageGAB = codeRefusTirageGAB;
    }

    public String getMessagedeRefus() {
	return messagedeRefus;
    }

    public void setMessagedeRefus(String messagedeRefus) {
	this.messagedeRefus = messagedeRefus;
    }

    public String getCode() {
	return code;
    }

    public void setCode(String code) {
	this.code = code;
    }

    public String getMessage() {
	return message;
    }

    public void setMessage(String message) {
	this.message = message;
    }

}
