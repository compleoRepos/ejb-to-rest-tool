package ma.eai.boa.xbanking.model;

import ma.eai.boa.xbanking.utils.Constants;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ModelFlux", namespace = Constants.NAME_SPACE_CREDIT)
public class ModelFlux {

    private Flux flux;

    public Flux getFlux() {
	return flux;
    }

    public void setFlux(Flux flux) {
	this.flux = flux;
    }

}
