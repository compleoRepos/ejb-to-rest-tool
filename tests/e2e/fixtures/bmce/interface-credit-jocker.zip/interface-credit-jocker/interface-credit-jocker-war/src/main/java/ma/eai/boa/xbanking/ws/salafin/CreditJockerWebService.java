/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ma.eai.boa.xbanking.ws.salafin;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import ma.eai.boa.xbanking.model.Flux;
import ma.eai.boa.xbanking.model.Ligne;
import ma.eai.boa.xbanking.model.ModelFlux;
import ma.eai.boa.xbanking.model.Tirage;
import ma.eai.boa.xbanking.model.Tirages;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.Parser;
import ma.eai.midw.connectors.SynchroneService;
import ma.eai.midw.integration.Services;
import ma.eai.midw.log.Log;
import ma.eai.boa.xbanking.utils.Constants;
import ma.eai.boa.xbanking.utils.GenerateFlux;

/**
 * @author Administrateur
 */
@WebService(serviceName = "WsCreditJocker", targetNamespace = Constants.NAME_SPACE_CREDIT)
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT, use = SOAPBinding.Use.LITERAL, parameterStyle = SOAPBinding.ParameterStyle.WRAPPED)
public class CreditJockerWebService {

    public static final String FLUX_CODE = "flux/code";
    public static final String DUR_TIRAGE_LOGS = "durTirage: ";
    public static final String NUM_DOSSIER_LOGS = "num dossier";
    public static final String FLUX_TIRAGE_CODE_RETOUR_GAB = "flux/tirage/codeRetourGab";
    public static final String EXCEPTION_ERROR_LOGS = "exception error :";

    @WebMethod(operationName = "getLigneDeclicGAB")
    public ModelFlux getLigneDeclicGAB(@WebParam(name = "compte") String compte) throws Exception {
	Log.setNewThreadId();
	Log.setServiceName("getLigneDeclicGAB");
	Log.info("Etape 1 : Debut fonction get ligne declic GAB");
	String fluxLigneDeclic = GenerateFlux.getFluxLigneDeclicGAB(compte);
	SynchroneService posteAgenceSolde = null;
	try {
	    Log.info("num compte = " + compte);
	    posteAgenceSolde = Services.find(Constants.UDDI_DECLIC_SERVICES, SynchroneService.class);
	} catch (Exception e) {
	    Log.error(EXCEPTION_ERROR_LOGS, e);
	}
	ModelFlux fluxRetour = new ModelFlux();
	Flux flux = new Flux();

	if (posteAgenceSolde == null) {
	    flux.setCode("222");
	    fluxRetour.setFlux(flux);
	    return fluxRetour;
	}
	Envelope reponseEJB = posteAgenceSolde.process(Parser.unmarshall(fluxLigneDeclic));
	reponseEJB = Parser.update(reponseEJB);
	Ligne ligne = new Ligne();
	String code = reponseEJB.getNodeAsString(FLUX_CODE);
	Log.info("code = " + code);
	if (code != null) {
	    flux.setCode("222");
	} else {
	    ligne.setMntTotal(reponseEJB.getNodeAsString("flux/ligne/mntTotal"));
	    ligne.setBlocageBase(reponseEJB.getNodeAsString("flux/ligne/blocageBase"));
	    ligne.setBlocageDoss(reponseEJB.getNodeAsString("flux/ligne/blocageDoss"));
	    ligne.setCode(reponseEJB.getNodeAsString("flux/ligne/code"));
	    ligne.setCompte(reponseEJB.getNodeAsString("flux/ligne/compte"));
	    ligne.setDateDoctroi(reponseEJB.getNodeAsString("flux/ligne/dateDoctroi"));
	    ligne.setEncours(reponseEJB.getNodeAsString("flux/ligne/encours"));
	    ligne.setImpayes(reponseEJB.getNodeAsString("flux/ligne/impayes"));
	    ligne.setMntDisponible(reponseEJB.getNodeAsString("flux/ligne/mntDisponible"));
	    ligne.setNbrImpaye(reponseEJB.getNodeAsString("flux/ligne/nbrImpaye"));
	    ligne.setNoDoss(reponseEJB.getNodeAsString("flux/ligne/noDoss"));
	    flux.setLigne(ligne);
	}
	fluxRetour.setFlux(flux);
	Log.info("Etape fin : Fin fonction get ligne declic");
	return fluxRetour;
    }

    @WebMethod(operationName = "selectTirageDECLICGAB")
    public ModelFlux selectTirageDECLICGAB(@WebParam(name = "noDoss") String noDoss) throws Exception {
	Log.setNewThreadId();
	Log.setServiceName("selectTirageDECLICGAB");
	Log.info("Etape 1 : Debut fonction select tirage declic GAB");
	String fluxTirageDeclic = GenerateFlux.selectTirageDECLICGAB(noDoss);
	SynchroneService posteAgenceSolde = null;
	try {
	    Log.info(NUM_DOSSIER_LOGS + noDoss);
	    posteAgenceSolde = Services.find(Constants.UDDI_DECLIC_SERVICES, SynchroneService.class);
	} catch (Exception e) {
	    Log.error(EXCEPTION_ERROR_LOGS, e);
	}
	ModelFlux fluxRetour = new ModelFlux();
	Flux flux = new Flux();

	if (posteAgenceSolde == null) {
	    flux.setCode("222");
	    fluxRetour.setFlux(flux);
	    return fluxRetour;
	}
	Envelope reponseEJB = posteAgenceSolde.process(Parser.unmarshall(fluxTirageDeclic));
	reponseEJB = Parser.update(reponseEJB);
	List<Tirage> liste = new ArrayList<Tirage>();
	Tirages tirages = new Tirages();
	Tirage tirage = new Tirage();
	int nbTirages = reponseEJB.getNodeAsList("flux/Tirages").size();
	Log.info("nbre de tirages " + nbTirages);
	for (int j = 0; j < nbTirages; j++) {
	    j++;
	    tirage.setMntTirage(reponseEJB.getNodeAsString("flux/tirages/tirage," + (j + 1) + "/mntTirage"));
	    tirage.setMntDispo(reponseEJB.getNodeAsString("flux/tirages/tirage/mntDispo"));
	    tirage.setIdTirage(reponseEJB.getNodeAsString("flux/tirages/tirage/idTirage"));
	    tirage.setNomClient(reponseEJB.getNodeAsString("flux/tirages/tirage/nomClient"));
	    tirage.setDt1Echeance(reponseEJB.getNodeAsString("flux/tirages/tirage/dt1Echeance"));
	    tirage.setDtDebTirage(reponseEJB.getNodeAsString("flux/tirages/tirage/dtDebTirage"));
	    tirage.setMontant1Echeance(reponseEJB.getNodeAsString("flux/tirages/tirage/montant1Echeance"));
	    tirage.setNoDoss(reponseEJB.getNodeAsString("flux/tirages/tirage/noDoss"));
	    Log.info("nbrEchEchu " + reponseEJB.getNodeAsString("flux/tirages/tirage/nbrEcheEchu"));
	    tirage.setNbrEchEchu(reponseEJB.getNodeAsString("flux/tirages/tirage/nbrEcheEchu"));
	    Log.info("nbrEchRest " + reponseEJB.getNodeAsString("flux/tirages/tirage/nbrEcheRestant"));
	    tirage.setNbrEchRest(reponseEJB.getNodeAsString("flux/tirages/tirage/nbrEcheRestant"));
	    String libelle = reponseEJB.getNodeAsString("flux/tirages/tirage/libelle");
	    Log.info("Libelle tirage " + libelle);
	    if (libelle.isEmpty()) {
		tirage.setLibelle("LibelleTirage");
	    } else if (libelle.length() > 40) {
		libelle = libelle.substring(0, 20);
		Log.info("Libelle tirage " + libelle);
		tirage.setLibelle(libelle);
	    } else {
		tirage.setLibelle(libelle);
	    }
	    tirage.setDurTirage(reponseEJB.getNodeAsString("flux/tirages/tirage/durTirage"));
	    tirage.setResteTirage(reponseEJB.getNodeAsString("flux/tirages/tirage/resteTirage"));
	    liste.add(tirage);
	}
	tirages.setListeTirage(liste);
	flux.setTirages(tirages);
	fluxRetour.setFlux(flux);
	Log.info("Etape 2 : fin fonction select tirage declic GAB" + fluxRetour);
	return fluxRetour;
    }

    @WebMethod(operationName = "traitementDECLICGAB")
    public ModelFlux traitementDECLICGAB(@WebParam(name = "compte") String compte,
	    @WebParam(name = "mntTirage") String mntTirage, @WebParam(name = "libelle") String libelle,
	    @WebParam(name = "centreFrais") String centreFrais, @WebParam(name = "categorie") String categorie,
	    @WebParam(name = "dtDebTirage") String dtDebTirage, @WebParam(name = "dt1Echeance") String dt1Echeance,
	    @WebParam(name = "noDoss") String noDoss, @WebParam(name = "noTiers") String noTiers,
	    @WebParam(name = "nomClient") String nomClient, @WebParam(name = "durTirage") String durTirage,
	    @WebParam(name = "sourceOperation") String sourceOperation) throws Exception {
	Log.setNewThreadId();
	Log.setServiceName("traitementDECLICGAB");
	Log.info("Debut Traitement DECLIC GAB");
	String fluxTirageDeclic = GenerateFlux.traitementGAB(compte, mntTirage, libelle, centreFrais, categorie,
		dtDebTirage, dt1Echeance, noDoss, noTiers, nomClient, durTirage, "GAB");
	SynchroneService posteAgenceSolde = null;
	try {
	    posteAgenceSolde = Services.find(Constants.UDDI_DECLIC_SERVICES, SynchroneService.class);
	} catch (Exception e) {
	    Log.error(EXCEPTION_ERROR_LOGS, e);
	}
	ModelFlux fluxRetour = new ModelFlux();
	Flux flux = new Flux();

	if (posteAgenceSolde == null) {
	    flux.setCode("009");
	    fluxRetour.setFlux(flux);
	    return fluxRetour;
	}
	Envelope reponseEJB = posteAgenceSolde.process(Parser.unmarshall(fluxTirageDeclic));
	reponseEJB = Parser.update(reponseEJB);
	String code = reponseEJB.getNodeAsString(FLUX_CODE);
	Log.info("code retour" + code);
	if (code == null) {
	    flux.setCode("009");
	} else {
	    flux.setCode(reponseEJB.getNodeAsString(FLUX_CODE));
	    flux.setMessage(reponseEJB.getNodeAsString("flux/message"));
	}
	fluxRetour.setFlux(flux);
	Log.info("fin Traitement DECLIC GAB" + fluxRetour);
	return fluxRetour;
    }

    @WebMethod(operationName = "traitementTPE")
    public ModelFlux traitementTPE(@WebParam(name = "compte") String compte,
	    @WebParam(name = "mntTirage") String mntTirage, @WebParam(name = "nomClient") String nomClient,
	    @WebParam(name = "durTirage") String durTirage, @WebParam(name = "sourceOperation") String sourceOperation)
	    throws Exception {
	Log.setNewThreadId();
	Log.setServiceName("traitementTPE");
	Log.info("Debut traitement TPE ");
	String fluxTirageDeclic = GenerateFlux.getFluxDeclicTPE(compte, mntTirage, nomClient, durTirage,
		sourceOperation);
	SynchroneService posteAgenceSolde = null;
	try {
	    posteAgenceSolde = Services.find(Constants.UDDI_DECLIC_SERVICES, SynchroneService.class);
	} catch (Exception e) {
	    Log.error(EXCEPTION_ERROR_LOGS, e);
	}
	ModelFlux fluxRetour = new ModelFlux();
	Flux flux = new Flux();

	if (posteAgenceSolde == null) {
	    flux.setCode("009");
	    fluxRetour.setFlux(flux);
	    return fluxRetour;
	}
	Envelope reponseEJB = posteAgenceSolde.process(Parser.unmarshall(fluxTirageDeclic));
	reponseEJB = Parser.update(reponseEJB);

	String code = reponseEJB.getNodeAsString(FLUX_CODE);
	Log.info("code retour" + code);
	if (code == null) {
	    flux.setCode("009");
	} else {
	    flux.setCode(reponseEJB.getNodeAsString(FLUX_CODE));
	    flux.setMessage(reponseEJB.getNodeAsString("flux/message"));
	}
	fluxRetour.setFlux(flux);
	Log.info("fin traitement TPE " + fluxRetour);
	return fluxRetour;
    }

    @WebMethod(operationName = "simulationTirageGAB")
    public ModelFlux simulationTirageGAB(@WebParam(name = "mntTirage") String mntTirage,
	    @WebParam(name = "durTirage") String durTirage, @WebParam(name = "compte") String compte)
	    throws Exception {
	String fluxTirageDeclic = GenerateFlux.simulationTirageGAB(mntTirage, durTirage, compte);
	SynchroneService posteAgenceSolde = null;
	Log.setNewThreadId();
	Log.setServiceName("simulationTirageGAB");
	Log.info("Debut simulation web service joker: ");
	try {
	    Log.info("mntTirage: " + mntTirage);
	    Log.info(DUR_TIRAGE_LOGS + durTirage);
	    Log.info("compte: " + compte);
	    posteAgenceSolde = Services.find(Constants.UDDI_DECLIC_SERVICES, SynchroneService.class);
	} catch (Exception e) {
	    Log.error(EXCEPTION_ERROR_LOGS, e);
	}
	ModelFlux fluxRetour = new ModelFlux();
	Flux flux = new Flux();

	if (posteAgenceSolde == null) {
	    flux.setCodeRefusTirageGAB("009");
	    flux.setMessagedeRefus("Probleme technique");
	    fluxRetour.setFlux(flux);
	    return fluxRetour;
	}
	Envelope reponseEJB = posteAgenceSolde.process(Parser.unmarshall(fluxTirageDeclic));
	reponseEJB = Parser.update(reponseEJB);

	Tirage tirage = new Tirage();
	String codeGab = reponseEJB.getNodeAsString(FLUX_TIRAGE_CODE_RETOUR_GAB);
	Log.info("codeGab: " + codeGab);
	if (codeGab.equals("000")) {
	    Log.info("entre if case :000 ");
	    tirage.setMntTirage(reponseEJB.getNodeAsString("flux/tirage/mntTirage"));
	    tirage.setMontant1Echeance(reponseEJB.getNodeAsString("flux/tirage/montant1Echeance"));
	    tirage.setDurTirage(reponseEJB.getNodeAsString("flux/tirage/durTirage"));
	    tirage.setDtDebTirage(reponseEJB.getNodeAsString("flux/tirage/dtDebTirage"));
	    tirage.setDt1Echeance(reponseEJB.getNodeAsString("flux/tirage/dt1Echeance"));
	    tirage.setCodeRetourGab(reponseEJB.getNodeAsString(FLUX_TIRAGE_CODE_RETOUR_GAB));
	    Log.info("sortie if case :000 ");
	} else if (codeGab.equals("444")) {
	    Log.info("entre if case :444 ");
	    tirage.setCodeRetourGab(reponseEJB.getNodeAsString(FLUX_TIRAGE_CODE_RETOUR_GAB));
	    Log.info("sortie if case :444 ");
	} else if (codeGab.equals("333")) {
	    Log.info("entre if case :333 ");
	    tirage.setCodeRetourGab(reponseEJB.getNodeAsString(FLUX_TIRAGE_CODE_RETOUR_GAB));
	    Log.info("sortie if case :333 ");
	} else {
	    Log.info("entre if case :else ");
	    flux.setCodeRefusTirageGAB("009");
	    flux.setMessagedeRefus("Probleme technique");
	    Log.info("sortie if case :else ");
	}
	flux.setTirage(tirage);
	fluxRetour.setFlux(flux);
	Log.info("Fin simulation web service joker: ");
	return fluxRetour;
    }

    @WebMethod(operationName = "BlocageJoker")
    public String BlocageJoker(@WebParam(name = "TYPBLOCAGE") String TYPBLOCAGE, @WebParam(name = "ETAT") String ETAT,
	    @WebParam(name = "NOCOMPTE") String NOCOMPTE, @WebParam(name = "DATEBLOCAGE") String DATEBLOCAGE,
	    @WebParam(name = "MOTIF") String MOTIF) throws Exception {
	String fluxBlocageJoker = GenerateFlux.blocageJOKER(TYPBLOCAGE, ETAT, NOCOMPTE, DATEBLOCAGE, MOTIF);
	SynchroneService posteAgenceSolde = null;
	Log.setNewThreadId();
	Log.setServiceName("BlocageJoker");
	Log.info("Debut blocage joker: ");
	try {
	    Log.info("TYPBLOCAGE: " + TYPBLOCAGE);
	    Log.info("ETAT: " + ETAT);
	    Log.info("NOCOMPTE: " + NOCOMPTE);
	    Log.info("DATEBLOCAGE: " + DATEBLOCAGE);
	    Log.info("MOTIF: " + MOTIF);
	    posteAgenceSolde = Services.find(Constants.UDDI_DECLIC_SERVICES, SynchroneService.class);
	} catch (Exception e) {
	    Log.error(EXCEPTION_ERROR_LOGS, e);
	    Log.info("erreur : " + e);
	}

	if (posteAgenceSolde == null) {
	    return "";
	}
	Envelope reponseEJB = posteAgenceSolde.process(Parser.unmarshall(fluxBlocageJoker));
	String reponseXml = Parser.marshall(reponseEJB);
	Log.info("fin blocage joker  " + reponseXml);
	return reponseXml;
    }

    @WebMethod(operationName = "getLigneDeclic")
    public String getLigneDeclic(@WebParam(name = "compte") String compte) throws Exception {
	Log.setNewThreadId();
	Log.setServiceName("getLigneDeclic");
	Log.info("Debut web service get ligne  ");
	String fluxLigneDeclic = GenerateFlux.getFluxLigneDeclic(compte);
	SynchroneService posteAgenceSolde = null;
	try {
	    Log.info("num compte = " + compte);
	    posteAgenceSolde = Services.find(Constants.UDDI_DECLIC_SERVICES, SynchroneService.class);
	} catch (Exception e) {
	    Log.error(EXCEPTION_ERROR_LOGS, e);
	}
	if (posteAgenceSolde == null) {
	    return "";
	}
	Envelope reponseEJB = posteAgenceSolde.process(Parser.unmarshall(fluxLigneDeclic));
	String reponseXml = Parser.marshall(reponseEJB);
	Log.info("fin web service get ligne  " + reponseXml);
	return reponseXml;
    }

    @WebMethod(operationName = "selectTirageDECLIC")
    public String selectTirageDECLIC(@WebParam(name = "noDoss") String noDoss) throws Exception {
	Log.setNewThreadId();
	Log.setServiceName("selectTirageDECLIC");
	Log.info("Debut web service tirage ligne  ");
	String fluxTirageDeclic = GenerateFlux.selectTirageDECLIC(noDoss);
	SynchroneService posteAgenceSolde = null;
	try {
	    Log.info(NUM_DOSSIER_LOGS + noDoss);
	    posteAgenceSolde = Services.find(Constants.UDDI_DECLIC_SERVICES, SynchroneService.class);
	} catch (Exception e) {
	    Log.error(EXCEPTION_ERROR_LOGS, e);
	}
	if (posteAgenceSolde == null) {
	    return "";
	}
	Envelope reponseEJB = posteAgenceSolde.process(Parser.unmarshall(fluxTirageDeclic));
	String reponseXml = Parser.marshall(reponseEJB);
	Log.info("Debut web service select tirage  " + reponseXml);
	return reponseXml;
    }

    @WebMethod(operationName = "traitementDECLIC")
    public String traitementDECLIC(@WebParam(name = "compte") String compte,
	    @WebParam(name = "mntTirage") String mntTirage, @WebParam(name = "libelle") String libelle,
	    @WebParam(name = "centreFrais") String centreFrais, @WebParam(name = "categorie") String categorie,
	    @WebParam(name = "dtDebTirage") String dtDebTirage, @WebParam(name = "dt1Echeance") String dt1Echeance,
	    @WebParam(name = "noDoss") String noDoss, @WebParam(name = "noTiers") String noTiers,
	    @WebParam(name = "nomClient") String nomClient, @WebParam(name = "durTirage") String durTirage,
	    @WebParam(name = "sourceOperation") String sourceOperation) throws Exception {
	String fluxTirageDeclic = GenerateFlux.traitementDECLIC(compte, mntTirage, libelle, centreFrais, categorie,
		dtDebTirage, dt1Echeance, noDoss, noTiers, nomClient, durTirage, "Immediat");
	Log.setNewThreadId();
	Log.setServiceName("traitementDECLIC");
	Log.info("Debut web service traitement declic  ");
	SynchroneService posteAgenceSolde = null;
	try {
	    posteAgenceSolde = Services.find(Constants.UDDI_DECLIC_SERVICES, SynchroneService.class);
	} catch (Exception e) {
	    Log.error(EXCEPTION_ERROR_LOGS, e);
	}
	if (posteAgenceSolde == null) {
	    return "";
	}
	Envelope reponseEJB = posteAgenceSolde.process(Parser.unmarshall(fluxTirageDeclic));
	String reponseXml = Parser.marshall(reponseEJB);
	Log.info("fin web service traitement declic  " + reponseXml);
	return reponseXml;
    }

    @WebMethod(operationName = "selectTirageModifDECLIC")
    public String selectTirageModifDECLIC(@WebParam(name = "noDoss") String noDoss) throws Exception {
	Log.setNewThreadId();
	Log.setServiceName("selectTirageModifDECLIC");
	Log.info("Debut web service tirage avec eligibilite de modification   ");
	String fluxTirageDeclic = GenerateFlux.selectTirageDECLICModif(noDoss);
	SynchroneService posteAgenceSolde = null;
	try {
	    Log.info(NUM_DOSSIER_LOGS + noDoss);
	    posteAgenceSolde = Services.find(Constants.UDDI_DECLIC_SERVICES, SynchroneService.class);
	} catch (Exception e) {
	    Log.error(EXCEPTION_ERROR_LOGS, e);
	}
	if (posteAgenceSolde == null) {
	    return "";
	}
	Envelope reponseEJB = posteAgenceSolde.process(Parser.unmarshall(fluxTirageDeclic));
	String reponseXml = Parser.marshall(reponseEJB);
	Log.info("retour web service select tirage avec eligibilite de modification  " + reponseXml);
	return reponseXml;
    }

    @WebMethod(operationName = "updateTirage")
    public String updateTirage(@WebParam(name = "noDoss") String noDoss, @WebParam(name = "dtSaisi") String dtSaisi,
	    @WebParam(name = "durTirage") String durTirage, @WebParam(name = "sourceOperation") String sourceOperation,
	    @WebParam(name = "noSlignIn") String noSlignIn, @WebParam(name = "noUtilIn") String noUtilIn)
	    throws Exception {
	String fluxUpdateTirage = GenerateFlux.updateTirage(noDoss, dtSaisi, durTirage, sourceOperation, noSlignIn,
		noUtilIn);
	SynchroneService posteAgenceSolde = null;
	Log.setNewThreadId();
	Log.setServiceName("updateTirage");
	Log.info("Debut updateTirager: ");
	try {
	    Log.info("noDoss: " + noDoss);
	    Log.info("dtSaisi: " + dtSaisi);
	    Log.info(DUR_TIRAGE_LOGS + durTirage);
	    Log.info("sourceOperation: " + sourceOperation);
	    Log.info("noSlignIn: " + noSlignIn);
	    Log.info("noUtilIn: " + noUtilIn);
	    posteAgenceSolde = Services.find(Constants.UDDI_DECLIC_SERVICES, SynchroneService.class);
	} catch (Exception e) {
	    Log.error(EXCEPTION_ERROR_LOGS, e);
	    Log.info("erreur : " + e);
	}
	if (posteAgenceSolde == null) {
	    return "";
	}
	Envelope reponseEJB = posteAgenceSolde.process(Parser.unmarshall(fluxUpdateTirage));
	String reponseXml = Parser.marshall(reponseEJB);
	Log.info("updateTirage  " + reponseXml);
	return reponseXml;
    }

    @WebMethod(operationName = "updateTirageDerogation")
    public String updateTirageDerogation(@WebParam(name = "noDoss") String noDoss,
	    @WebParam(name = "dtSaisi") String dtSaisi, @WebParam(name = "durTirage") String durTirage,
	    @WebParam(name = "sourceOperation") String sourceOperation, @WebParam(name = "noSlignIn") String noSlignIn,
	    @WebParam(name = "noUtilIn") String noUtilIn) throws Exception {
	String fluxUpdateTirage = GenerateFlux.updateTirageDerogation(noDoss, dtSaisi, durTirage, sourceOperation,
		noSlignIn, noUtilIn);
	SynchroneService posteAgenceSolde = null;
	Log.setNewThreadId();
	Log.setServiceName("updateTirageDerogation");
	Log.info("Debut updateTirage derogation: ");
	try {
	    Log.info("noDoss: " + noDoss);
	    Log.info("dtSaisi: " + dtSaisi);
	    Log.info(DUR_TIRAGE_LOGS + durTirage);
	    Log.info("sourceOperation: " + sourceOperation);
	    Log.info("noSlignIn: " + noSlignIn);
	    Log.info("noUtilIn: " + noUtilIn);
	    posteAgenceSolde = Services.find(Constants.UDDI_DECLIC_SERVICES, SynchroneService.class);
	} catch (Exception e) {
	    Log.error(EXCEPTION_ERROR_LOGS, e);
	    Log.info("erreur derogation : " + e);
	}
	if (posteAgenceSolde == null) {
	    return "";
	}
	Envelope reponseEJB = posteAgenceSolde.process(Parser.unmarshall(fluxUpdateTirage));
	String reponseXml = Parser.marshall(reponseEJB);
	Log.info("updateTirage derogation  " + reponseXml);
	return reponseXml;
    }
}
