package ma.eai.boa.xbanking.model;

import ma.eai.boa.xbanking.utils.Constants;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Ligne", namespace = Constants.NAME_SPACE_CREDIT)
public class Ligne {

    private String mntTotal;
    private String compte;
    private String mntDisponible;
    private String dateDoctroi;
    private String noDoss;
    private String code;
    private String encours;
    private String impayes;
    private String nbrImpaye;
    private String blocageBase;
    private String blocageDoss;

    public String getCompte() {
	return compte;
    }

    public void setCompte(String compte) {
	this.compte = compte;
    }

    public String getMntDisponible() {
	return mntDisponible;
    }

    public void setMntDisponible(String mntDisponible) {
	this.mntDisponible = mntDisponible;
    }

    public String getDateDoctroi() {
	return dateDoctroi;
    }

    public void setDateDoctroi(String dateDoctroi) {
	this.dateDoctroi = dateDoctroi;
    }

    public String getNoDoss() {
	return noDoss;
    }

    public void setNoDoss(String noDoss) {
	this.noDoss = noDoss;
    }

    public String getCode() {
	return code;
    }

    public void setCode(String code) {
	this.code = code;
    }

    public String getEncours() {
	return encours;
    }

    public void setEncours(String encours) {
	this.encours = encours;
    }

    public String getImpayes() {
	return impayes;
    }

    public void setImpayes(String impayes) {
	this.impayes = impayes;
    }

    public String getNbrImpaye() {
	return nbrImpaye;
    }

    public void setNbrImpaye(String nbrImpaye) {
	this.nbrImpaye = nbrImpaye;
    }

    public String getBlocageBase() {
	return blocageBase;
    }

    public void setBlocageBase(String blocageBase) {
	this.blocageBase = blocageBase;
    }

    public String getBlocageDoss() {
	return blocageDoss;
    }

    public void setBlocageDoss(String blocageDoss) {
	this.blocageDoss = blocageDoss;
    }

    public String getMntTotal() {
	return mntTotal;
    }

    public void setMntTotal(String mntTotal) {
	this.mntTotal = mntTotal;
    }

}
