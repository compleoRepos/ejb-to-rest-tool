package ma.eai.boa.xbanking.dto;

import java.io.Serializable;

public class Doc implements Serializable {
    private static final long serialVersionUID = 1L;
    private String dateClassement;
    private String datefichier;
    private Types typeao;
    private String folio;
    private Double montant;
    private String numcompte;

    private String baseName;
    private long baseId;
    private long guid;

    public Types getTypeao() {
	return typeao;
    }

    public void setTypeao(Types typeao) {
	this.typeao = typeao;
    }

    public String getDateClassement() {
	return dateClassement;
    }

    public void setDateClassement(String dateClassement) {
	this.dateClassement = dateClassement;
    }

    public String getDatefichier() {
	return datefichier;
    }

    public void setDatefichier(String datefichier) {
	this.datefichier = datefichier;
    }

    public String getFolio() {
	return folio;
    }

    public void setFolio(String folio) {
	this.folio = folio;
    }

    public Double getMontant() {
	return montant;
    }

    public void setMontant(Double montant) {
	this.montant = montant;
    }

    public String getNumcompte() {
	return numcompte;
    }

    public void setNumcompte(String numcompte) {
	this.numcompte = numcompte;
    }

    public String getBaseName() {
	return baseName;
    }

    public void setBaseName(String baseName) {
	this.baseName = baseName;
    }

    public long getBaseId() {
	return baseId;
    }

    public void setBaseId(long baseId) {
	this.baseId = baseId;
    }

    public long getGuid() {
	return guid;
    }

    public void setGuid(long guid) {
	this.guid = guid;
    }
}
