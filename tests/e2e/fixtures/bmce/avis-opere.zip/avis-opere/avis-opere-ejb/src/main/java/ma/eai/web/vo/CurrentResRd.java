package ma.eai.web.vo;

import ma.eai.boa.xbanking.entities.TypeAoRd;
import ma.eai.ingdev.fwk.uc.ValueObject;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
@XmlRootElement(name = "currentRes")
public class CurrentResRd implements ValueObject {
    private static final long serialVersionUID = 1L;
    private List<TypeAoRd> row;

    public List<TypeAoRd> getRow() {
	return row;
    }

    public void setRow(List<TypeAoRd> row) {
	this.row = row;
    }
}
