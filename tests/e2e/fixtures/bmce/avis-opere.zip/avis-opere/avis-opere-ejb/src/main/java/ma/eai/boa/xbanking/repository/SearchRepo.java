package ma.eai.boa.xbanking.repository;

import ma.eai.boa.xbanking.entities.TypeAO;
import ma.eai.ingdev.fwk.annotation.tx.ContinueOrStartTransaction;
import ma.eai.ingdev.fwk.annotations.Manager;
import ma.eai.ingdev.fwk.dao.GeneriqueDAO;
import ma.eai.ingdev.fwk.logging.EaiLog;

import org.hibernate.Query;

import java.util.List;

@Manager
@ContinueOrStartTransaction
public class SearchRepo extends GeneriqueDAO<TypeAO, String> {
    public List<TypeAO> SearchTypes() {
	long start = System.currentTimeMillis();
	List<TypeAO> list = null;
	try {
	    Query query = this.createQuery("From TypeAO");
	    list = query.list();
	    EaiLog.info("============> SearchRepository listtype  size...." + list.size());
	} catch (Exception e) {
	    EaiLog.error(e);
	}
	long end = System.currentTimeMillis();
	EaiLog.info("temps Total d'execution requette BDD:  " + (end - start) + " ms");
	return list != null && !list.isEmpty() ? list : null;
    }

}
