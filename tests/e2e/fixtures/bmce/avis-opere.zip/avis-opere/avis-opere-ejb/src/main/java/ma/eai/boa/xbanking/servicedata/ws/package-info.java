@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.bmce.org")
package ma.eai.boa.xbanking.servicedata.ws;
