package ma.eai.boa.xbanking.dto;

import java.io.Serializable;
import java.util.List;

public class RepdematDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private List<RepdematDoc> row;

    public List<RepdematDoc> getRow() {
	return row;
    }

    public void setRow(List<RepdematDoc> row) {
	this.row = row;
    }
}
