package ma.eai.boa.xbanking.usecases;

import ma.eai.boa.xbanking.dto.AvisOpereDTO;
import ma.eai.boa.xbanking.dto.Doc;
import ma.eai.boa.xbanking.service.CallDocubase;
import ma.eai.boa.xbanking.service.avisopere.ISearchService;
import ma.eai.boa.xbanking.servicedata.ws.Document;
import ma.eai.boa.xbanking.servicedata.ws.Pager;
import ma.eai.boa.xbanking.utils.CommonFunction;
import ma.eai.ingdev.fwk.annotations.UseCase;
import ma.eai.ingdev.fwk.exceptions.FwkRollbackException;
import ma.eai.ingdev.fwk.logging.EaiLog;
import ma.eai.ingdev.fwk.uc.BaseUseCase;
import ma.eai.ingdev.fwk.uc.ValueObject;

import ma.eai.boa.xbanking.dto.Types;

import ma.eai.web.vo.AvisOpereGetListVO;
import ma.eai.web.vo.AvisOpereGetListVoOut;
import net.java.dev.jaxb.array.StringArray;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

@UseCase
@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = FwkRollbackException.class)
public class AvisOpereGetListIndexUC implements BaseUseCase {
    @Autowired
    ISearchService searchService;
    @Autowired
    private CallDocubase callDocubase;
    @Override
    public ValueObject execute(ValueObject in) throws FwkRollbackException {
	EaiLog.info("==== BEGIN : RECUPERER DOCS_SERVICEDATA AVISOPERE AvisOpereGetListIndexUC ");
	AvisOpereGetListVoOut out=new AvisOpereGetListVoOut();
	try {
	    AvisOpereGetListVO criteriaVo = (AvisOpereGetListVO) in;
	    // Diviser la chaîne de critères 'Ntiere' en utilisant le delimiteur "|"
	    // Initialiser les listes pour les comptes et les types
	    StringArray compteList = buildCompteList(criteriaVo);
	    StringArray typeList = buildTypeList(criteriaVo);

	    String DateDebutFormatted = CommonFunction.convertDateFormat(criteriaVo.getDatedebut());
	    String DateFinFormatted = CommonFunction.convertDateFormat(criteriaVo.getDatefin());
	    double min = (criteriaVo.getMontantmin() != null) ? criteriaVo.getMontantmin() : 0.0;
	    double max = (criteriaVo.getMontantmax() != null) ? criteriaVo.getMontantmax() : Double.MAX_VALUE;
	    Pager pager = callDocubase.appelDocubase(compteList, typeList, DateDebutFormatted, DateFinFormatted,
		    criteriaVo.getNumPage(), criteriaVo.getPageSize(),
		    min, max);

	    out = buildOutputFromPager(pager);

	    EaiLog.info("nombre total des document depuis la sortie out..." + out.getNbResultats());
	    EaiLog.info("==============Fiiiiiiiin AvisOpereGetListUC==========");
	}catch (Exception e){
	    EaiLog.error("Erreur lors de l'exécution de AvisOpereGetListIndexUC : " + e.getMessage(), e);
	    throw new FwkRollbackException("Erreur lors de l'exécution de AvisOpereGetListIndexUC");
	}
	return out;
    }

    private AvisOpereGetListVoOut buildOutputFromPager(Pager pager) {
	AvisOpereGetListVoOut out = new AvisOpereGetListVoOut();
	AvisOpereDTO avisDto = new AvisOpereDTO();

	List<Doc> listDoc = new ArrayList<Doc>();
	Doc docu;
	Types type;
	for (Document doc : pager.getDocuments()) {
	    docu = new Doc();
	    type = new Types();
	    docu.setBaseName(doc.getBase());
	    docu.setBaseId(doc.getBaseId());
	    try {
		docu.setDatefichier(CommonFunction.formattedDate(doc.getDateOperation()));
	    } catch (Exception e) {
		EaiLog.error(e.getMessage());
	    }
	    try {
		docu.setDateClassement(CommonFunction.formattedDate(doc.getDateClassement()));
	    } catch (Exception e) {
		EaiLog.error(e.getMessage());
	    }
	    docu.setFolio(doc.getFolio());
	    docu.setGuid(doc.getDocId());
	    type.setLibelle(doc.getTitre());
	    type.setCode(doc.getTypeDocument());
	    docu.setTypeao(type);
	    docu.setNumcompte(doc.getNumeroCompte());
	    docu.setMontant(doc.getMontant() != null
		    ? Double.valueOf(doc.getMontant().replace(",", "."))
		    : null);
	   // docu.setMontant(doc.getMontant() != null ? Double.valueOf(doc.getMontant()) : null);
	   // docu.setMontant(Double.valueOf(doc.getMontant()));
	    listDoc.add(docu);
	}
	avisDto.setAvisopere(listDoc);
	out.setNbResultats(pager.getNombreTotalDeDocument());
	out.setCurrentRes(avisDto);
	return out;
    }

    private StringArray buildTypeList(AvisOpereGetListVO criteriaVo) {
	StringArray typeList = new StringArray();
	// Vérifier si le type est spécifié
	if (criteriaVo.getType() != null && !criteriaVo.getType().equals("") && !criteriaVo.getType().equals("*")) {
	    EaiLog.info("################## type spécifié ###################" + criteriaVo.getType());
	    typeList.getItem().add(criteriaVo.getType());
	} else {
	    EaiLog.info("################## Tous les types ###################");
	    String types = searchService.getReqTypeAvis();
	    for (String element : types.split(",")) {
		typeList.getItem().add(element);
	    }
	}
	return typeList;
    }

    private StringArray buildCompteList(AvisOpereGetListVO criteriaVo) {
	StringTokenizer st = new StringTokenizer(criteriaVo.getNtiere(), "|");
	StringArray compteList = new StringArray();
	// Verifier si le numero de compte est specifie ou non
	if (criteriaVo.getNumcompte() == null || criteriaVo.getNumcompte().equals("*") || criteriaVo.getNumcompte()
		.equals("")) {
	    EaiLog.info("################## Tous les comptes ###################");
	    while (st.hasMoreTokens()) {
		compteList.getItem().add(CommonFunction.getCompte19(st.nextToken()));
	    }
	} else {
	    EaiLog.info("################## compte spécifié ###################" + criteriaVo.getNumcompte());
	    // Si un numero de compte est specifie, l'ajouter à la liste des comptes
	    compteList.getItem().add(criteriaVo.getNumcompte());
	}
	return compteList;
    }
}
