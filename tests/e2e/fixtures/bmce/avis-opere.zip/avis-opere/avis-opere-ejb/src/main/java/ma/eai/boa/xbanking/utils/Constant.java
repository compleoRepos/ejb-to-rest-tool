package ma.eai.boa.xbanking.utils;

public class Constant {
    public  static final String DOCUBASE_ADRIA_URL = "interface-docubase-adriaws";
    public  static final String DOCUBASE_EDOCS_URL = "interface-docubase-edoc";
    public  static final String DOCUBASE_SERVICEDATA_URL = "interface-docubase-dataservice";
    public static final String BMCE = "http://ws.bmce.org/";
}

