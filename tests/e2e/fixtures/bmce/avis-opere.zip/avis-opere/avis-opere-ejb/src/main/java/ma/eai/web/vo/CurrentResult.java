package ma.eai.web.vo;

import ma.eai.ingdev.fwk.uc.ValueObject;

public class CurrentResult implements ValueObject {
    private static final long serialVersionUID = 1L;
    private AvisOpere row;

    public AvisOpere getRow() {
	return row;
    }

    public void setRow(AvisOpere row) {
	this.row = row;
    }
}
