package ma.eai.boa.xbanking.models;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.io.Serializable;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GedOutPutDocument", namespace = "http://beans.eai.ma")
public class GedOutPutDocument implements Serializable {

    private static final long serialVersionUID = 1L;

    @XmlElement(name = "ListDocuments", required = true)
    private List<DocumentGed> listDocuments;

    public GedOutPutDocument() {
	super();
    }

    public List<DocumentGed> getListDocuments() {
	return listDocuments;
    }

    public void setListDocuments(List<DocumentGed> listDocuments) {
	this.listDocuments = listDocuments;
    }

}