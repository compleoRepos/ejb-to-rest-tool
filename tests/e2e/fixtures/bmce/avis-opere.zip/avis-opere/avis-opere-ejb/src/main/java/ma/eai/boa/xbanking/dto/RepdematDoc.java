package ma.eai.boa.xbanking.dto;

import java.io.Serializable;

public class RepdematDoc implements Serializable {
    private static final long serialVersionUID = 1L;
    private String dateTraitement;
    private String typeDoc;

    private Double montant;
    private String numCompte;

    private String baseName;
    private long base;
    private long guid;

    public long getGuid() {
	return guid;
    }

    public void setGuid(long guid) {
	this.guid = guid;
    }

    public long getBase() {
	return base;
    }

    public void setBase(long base) {
	this.base = base;
    }

    public String getBaseName() {
	return baseName;
    }

    public void setBaseName(String baseName) {
	this.baseName = baseName;
    }

    public String getNumCompte() {
	return numCompte;
    }

    public void setNumCompte(String numCompte) {
	this.numCompte = numCompte;
    }

    public Double getMontant() {
	return montant;
    }

    public void setMontant(Double montant) {
	this.montant = montant;
    }

    public String getTypeDoc() {
	return typeDoc;
    }

    public void setTypeDoc(String typeDoc) {
	this.typeDoc = typeDoc;
    }

    public String getDateTraitement() {
	return dateTraitement;
    }

    public void setDateTraitement(String dateTraitement) {
	this.dateTraitement = dateTraitement;
    }
}
