package ma.eai.boa.xbanking.models;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.io.Serializable;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FichierGed", namespace = "http://beans.eai.ma")
public class FichierGed implements Serializable {

    private static final long serialVersionUID = 1L;

    @XmlElement(name = "FICHIER_CLIENT", required = true)
    private String fichier;

    public FichierGed(String fichier) {
	this.fichier = fichier;
    }

    public FichierGed() {
    }

    public String getFichier() {
	return fichier;
    }

    public void setFichier(String fichier) {
	this.fichier = fichier;
    }

}
