package ma.eai.boa.xbanking.usecases;

import ma.eai.boa.xbanking.entities.TypeAoRd;
import ma.eai.boa.xbanking.service.repdemat.IServiceRepDemat;
import ma.eai.ingdev.fwk.annotations.UseCase;
import ma.eai.ingdev.fwk.exceptions.FwkRollbackException;
import ma.eai.ingdev.fwk.logging.EaiLog;
import ma.eai.ingdev.fwk.uc.BaseUseCase;
import ma.eai.ingdev.fwk.uc.ValueObject;
import ma.eai.web.vo.CurrentResRd;
import ma.eai.web.vo.GetTypeDocumentVO;
import ma.eai.web.vo.SearchVoRdOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

//UC DEDIE  AU PROJET REPDEMAT
@UseCase
@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = FwkRollbackException.class)
public class GetTypeDocument implements BaseUseCase {
    @Autowired
    IServiceRepDemat searchService ;
    @Override
    public ValueObject execute(ValueObject in) throws FwkRollbackException {

	EaiLog.info("GET TYPESUC REPDEMAT: GetTypeDocument");
	SearchVoRdOut out = new SearchVoRdOut();
	try {
	    GetTypeDocumentVO typevo = (GetTypeDocumentVO) in;
	    List<TypeAoRd> listeType = new ArrayList();
	    long start = System.currentTimeMillis();
	    if (typevo.getCategorie() != null) {
		listeType = searchService.getListTypes(typevo.getCategorie());
	    } else {
		listeType = searchService.getListTypes(null);
	    }
	    long end = System.currentTimeMillis();
	    EaiLog.info("TEMPS DE REPONSE RECUPERATION DES TYPES : " + (end - start) + " ms");
	    EaiLog.info("Size liste des types recuperés => " + listeType.size());
	    /*TypeAoRd type = new TypeAoRd();
	    type.setCode("*");
	    type.setLibelle("Choisissez un type d'avis...");
	    type.setCategorie(typevo.getCategorie());
	    listeType.add(0, type);*/

	    CurrentResRd res = new CurrentResRd();
	    res.setRow(listeType);
	    out.setCurrentRes(res);
	    EaiLog.info("End GetTypeDocument liste des types returné out .:" + out.getCurrentRes().getRow().size());
	}catch (Exception e){
	    EaiLog.error("Erreur lors de l'exécution de GetTypeDocumentUC : " + e.getMessage(), e);
	    throw new FwkRollbackException("Erreur lors de l'exécution de GetTypeDocumentUC");
	}
	return out;
    }

}
