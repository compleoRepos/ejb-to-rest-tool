package ma.eai.boa.xbanking.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "AO_TYPE")
public class TypeAO implements Serializable {
    private static final long serialVersionUID = -1474799622712735125L;
    @Id
    private String code;
    @Column(name = "LIBELLE")
    private String libelle;
    @Column(name = "NATURE")
    private String nature;

    public String getCode() {
	return code;
    }

    public void setCode(String code) {
	this.code = code;
    }

    public String getLibelle() {
	return libelle;
    }

    public void setLibelle(String libelle) {
	this.libelle = libelle;
    }

    public String getNature() {
	return nature;
    }

    public void setNature(String nature) {
	this.nature = nature;
    }
}
