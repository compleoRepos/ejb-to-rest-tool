package ma.eai.boa.xbanking.service.avisopere;

import ma.eai.boa.xbanking.models.DocumentGed;
import ma.eai.boa.xbanking.models.FichierGed;
import ma.eai.boa.xbanking.models.GedOutPutDocument;

import ma.eai.boa.xbanking.utils.Constant;
import ma.eai.boa.xbanking.utils.SoapUiLikeLoggingHandler;
import ma.eai.ingdev.fwk.logging.EaiLog;
import ma.eai.midw.integration.Services;
import net.java.dev.jaxb.array.StringArrayArray;
import ws.bmce.WebServicesAdriaService;
import ws.bmce.WsAdria;

import javax.jws.WebParam;
import javax.xml.ws.handler.Handler;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
public class GedServiceBackup {
    private static void processDocuments(Calendar beginCalendar, Calendar finishCalendar, List<String> listDates) {
	while (beginCalendar.before(finishCalendar) || (
		beginCalendar.get(Calendar.MONTH) == finishCalendar.get(Calendar.MONTH)
			&& beginCalendar.get(Calendar.YEAR) == finishCalendar.get(Calendar.YEAR))) {
	    String date = new SimpleDateFormat("dd-MM-yyyy").format(beginCalendar.getTime());
	    listDates.add(date);
	    beginCalendar.add(Calendar.MONTH, 1);
	}
    }

    private static void processDocument(String[] docTab, int i, DocumentGed documentGed) {
	try {
	    FichierGed fichierGed = null;
	    List<FichierGed> lstFileTmp = new ArrayList<FichierGed>();
	    fichierGed = new FichierGed(docTab[0]);
	    lstFileTmp.add(fichierGed);
	    documentGed.setListFichiers(lstFileTmp);
	} catch (ArrayIndexOutOfBoundsException e) {
	    EaiLog.error("Catch processDocument:" + e);
	}
    }

    public static void processListDocuments(StringArrayArray listDocument, List<String> listDates,
	    List<DocumentGed> lstDocTmp) {
	for (int i = 0; i < listDocument.getItem().size(); i++) {
	    DocumentGed documentGed = new DocumentGed();
	    if (i < listDates.size()) {
		documentGed.setMoisDocument(listDates.get(i));
	    }
	    String[] docTab = listDocument.getItem().get(i).getItem().toArray(new String[0]);
	    processDocument(docTab, i, documentGed);
	    lstDocTmp.add(documentGed);
	}
    }

    public static GedOutPutDocument getdocumentRelve(@WebParam(name = "numCpt") String numCpt,
	    @WebParam(name = "dateDebut") String dateDebut, @WebParam(name = "dateFin") String dateFin) {
	long startGlobalExecutionTime = System.currentTimeMillis();

	GedOutPutDocument out = new GedOutPutDocument();
	StringArrayArray listDocument = null;
	try {
	    DateFormat formater = new SimpleDateFormat("dd/MM/yyyy");

	    Calendar beginCalendar = Calendar.getInstance();
	    Calendar finishCalendar = Calendar.getInstance();

	    beginCalendar.setTime(formater.parse(dateDebut));
	    finishCalendar.setTime(formater.parse(dateFin));
	    List<String> listDates = new ArrayList<String>();
	    processDocuments(beginCalendar, finishCalendar, listDates);

	    long start = System.currentTimeMillis();
	    String docubaseAdriaWsdlUrl = Services.find(Constant.DOCUBASE_ADRIA_URL, String.class);
	    EaiLog.info("URL DOCUBASE ADRIA ======> " + docubaseAdriaWsdlUrl);
	    URL wsdlAdriaFromUDDI= null;
	    try {
		wsdlAdriaFromUDDI = new URL(docubaseAdriaWsdlUrl);
	    } catch (MalformedURLException e) {
		throw new RuntimeException(e);
	    }
	    WebServicesAdriaService locator = new WebServicesAdriaService(wsdlAdriaFromUDDI);
	    locator.setHandlerResolver(portInfo -> {
		List<Handler> handlers = new ArrayList<Handler>();
		handlers.add(new SoapUiLikeLoggingHandler());
		return handlers;
	    });
	    WsAdria wsAdria = locator.getWsAdriaPort();
	    listDocument = wsAdria.getdocumenRelve(numCpt, dateDebut, dateFin);
	    long end = System.currentTimeMillis();
	    EaiLog.info("TEMPS REPONSE WEB SERVCICE  interface-docubase-adriaws SEULPAGE(UC):" + (end - start) + " ms");

	    EaiLog.info("Nombre des Docs:" + listDocument.getItem().size());
	    if (listDocument != null) {
		List<DocumentGed> lstDocTmp = new ArrayList<DocumentGed>();
		processListDocuments(listDocument, listDates, lstDocTmp);
		out.setListDocuments(lstDocTmp);
	    }
	} catch (Exception e) {
	    EaiLog.error(e);
	}
	long endGlobalExecutionTime = System.currentTimeMillis();
	long timeingGlobalExecutionTime = (endGlobalExecutionTime - startGlobalExecutionTime);
	EaiLog.info("=================ViewReleveSeulePageUC ===============\n temps d'execution : "
		+ timeingGlobalExecutionTime + "\n================================\n ");
	return out;
    }

}

