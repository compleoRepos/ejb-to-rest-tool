package ma.eai.web.vo;

import ma.eai.ingdev.fwk.uc.ValueObject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "object")
public class SearchAvisOpereVO implements ValueObject {
    private static final long serialVersionUID = 1L;
    private String numcompte;
    private String comptes;
    private String typeavis;
    private String dated;
    private String datef;
    private String categorie;
    private int numPage;
    private int pageSize;
    private Double montantmin;
    private Double montantmax;

    public String getNumcompte() {
	return numcompte;
    }

    public void setNumcompte(String numcompte) {
	this.numcompte = numcompte;
    }

    public String getComptes() {
	return comptes;
    }

    public void setComptes(String comptes) {
	this.comptes = comptes;
    }

    public String getTypeavis() {
	return typeavis;
    }

    public void setTypeavis(String typeavis) {
	this.typeavis = typeavis;
    }

    public String getDated() {
	return dated;
    }

    public void setDated(String dated) {
	this.dated = dated;
    }

    public String getDatef() {
	return datef;
    }

    public void setDatef(String datef) {
	this.datef = datef;
    }

    public String getCategorie() {
	return categorie;
    }

    public void setCategorie(String categorie) {
	this.categorie = categorie;
    }

    public int getNumPage() {
	return numPage;
    }

    public void setNumPage(int numPage) {
	this.numPage = numPage;
    }

    public int getPageSize() {
	return pageSize;
    }

    public void setPageSize(int pageSize) {
	this.pageSize = pageSize;
    }

    public Double getMontantmax() {
	return montantmax;
    }

    public void setMontantmax(Double montantmax) {
	this.montantmax = montantmax;
    }

    public Double getMontantmin() {
	return montantmin;
    }

    public void setMontantmin(Double montantmin) {
	this.montantmin = montantmin;
    }
}
