package ma.eai.web.tests.models;

import ma.eai.boa.xbanking.dto.RepdematDTO;
import ma.eai.boa.xbanking.dto.RepdematDoc;
import ma.eai.boa.xbanking.entities.TypeAO;
import ma.eai.boa.xbanking.entities.TypeAoRd;
import ma.eai.boa.xbanking.models.FichierGed;
import ma.eai.web.vo.*;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class EntitiesTest {
    @Test
    public void testSetAndGetAvisopere() {
	// Arrange
	CurrentRes currentRes = new CurrentRes();
	TypeAO typeAO1 = new TypeAO(); // si TypeAO a un constructeur par défaut
	TypeAO typeAO2 = new TypeAO();
	List<TypeAO> typeAOList = Arrays.asList(typeAO1, typeAO2);

	// Act
	currentRes.setAvisopere(typeAOList);
	List<TypeAO> result = currentRes.getAvisopere();

	// Assert
	assertNotNull(result);
	assertEquals(2, result.size());
	assertEquals(typeAO1, result.get(0));
	assertEquals(typeAO2, result.get(1));
    }
    @Test
    public void testSetAndGetFichier() {
	FichierGed fichierGed = new FichierGed();

	String testFichier = "mon_fichier.pdf";
	fichierGed.setFichier(testFichier);

	assertEquals(testFichier, fichierGed.getFichier());
    }
    @Test
    public void testGettersAndSetter() {
	TypeAoRd typeAoRd = new TypeAoRd();

	typeAoRd.setCode("T123");
	typeAoRd.setLibelle("Libellé exemple");
	typeAoRd.setCategorie("Catégorie exemple");
	typeAoRd.setDATE_CREATION("2025-07-01");

	assertEquals("T123", typeAoRd.getCode());
	assertEquals("Libellé exemple", typeAoRd.getLibelle());
	assertEquals("Catégorie exemple", typeAoRd.getCategorie());
	assertEquals("2025-07-01", typeAoRd.getDATE_CREATION());
    }
    @Test
    public void testSetAndGetRow() {
	CurrentResRd currentResRd = new CurrentResRd();
	TypeAoRd typeAoRd1 = new TypeAoRd(); // si TypeAoRd a un constructeur par défaut
	TypeAoRd typeAoRd2 = new TypeAoRd();

	List<TypeAoRd> rowList = Arrays.asList(typeAoRd1, typeAoRd2);

	// Act
	currentResRd.setRow(rowList);
	List<TypeAoRd> result = currentResRd.getRow();

	// Assert
	assertNotNull(result);
	assertEquals(2, result.size());
	assertEquals(typeAoRd1, result.get(0));
	assertEquals(typeAoRd2, result.get(1));
    }
    @Test
    public void testSetAndGtRow() {
	RepdematDTO dto = new RepdematDTO();
	RepdematDoc doc1 = new RepdematDoc();
	RepdematDoc doc2 = new RepdematDoc();
	List<RepdematDoc> list = Arrays.asList(doc1, doc2);

	dto.setRow(list);
	List<RepdematDoc> result = dto.getRow();

	assertNotNull(result);
	assertEquals(2, result.size());
	assertEquals(doc1, result.get(0));
	assertEquals(doc2, result.get(1));
    }
    @Test
    public void testGettersAndSetters() {
	RepdematDoc doc = new RepdematDoc();

	doc.setDateTraitement("2025-07-01");
	doc.setTypeDoc("Facture");
	doc.setMontant(1234.56);
	doc.setNumCompte("1234567890");
	doc.setBaseName("Base1");
	doc.setBase(100L);
	doc.setGuid(9999L);

	assertEquals("2025-07-01", doc.getDateTraitement());
	assertEquals("Facture", doc.getTypeDoc());
	assertEquals(Double.valueOf(1234.56), doc.getMontant());
	assertEquals("1234567890", doc.getNumCompte());
	assertEquals("Base1", doc.getBaseName());
	assertEquals(100L, doc.getBase());
	assertEquals(9999L, doc.getGuid());
    }
    @Test
    public void testSetAndGetCategorie() {
	GetTypeDocumentVO vo = new GetTypeDocumentVO();

	vo.setCategorie("Facture");
	String result = vo.getCategorie();

	assertEquals("Facture", result);
    }
    @Test
    public void testGettersAndSet() {
	SearchAvisOpereVO vo = new SearchAvisOpereVO();

	vo.setNumcompte("12345");
	vo.setComptes("compte1,compte2");
	vo.setTypeavis("Avis1");
	vo.setDated("2025-01-01");
	vo.setDatef("2025-12-31");
	vo.setCategorie("Facture");
	vo.setNumPage(2);
	vo.setPageSize(50);

	assertEquals("12345", vo.getNumcompte());
	assertEquals("compte1,compte2", vo.getComptes());
	assertEquals("Avis1", vo.getTypeavis());
	assertEquals("2025-01-01", vo.getDated());
	assertEquals("2025-12-31", vo.getDatef());
	assertEquals("Facture", vo.getCategorie());
	assertEquals(2, vo.getNumPage());
	assertEquals(50, vo.getPageSize());
    }
    @Test
    public void testSetAndGetCurrentRes() {
	// Arrange
	SearchVoRdOut searchVoRdOut = new SearchVoRdOut();
	CurrentResRd currentResRd = new CurrentResRd();

	TypeAoRd typeAoRd1 = new TypeAoRd();
	TypeAoRd typeAoRd2 = new TypeAoRd();
	List<TypeAoRd> rowList = Arrays.asList(typeAoRd1, typeAoRd2);

	currentResRd.setRow(rowList);

	// Act
	searchVoRdOut.setCurrentRes(currentResRd);
	CurrentResRd result = searchVoRdOut.getCurrentRes();

	// Assert
	assertNotNull(result);
	assertNotNull(result.getRow());
	assertEquals(2, result.getRow().size());
	assertEquals(typeAoRd1, result.getRow().get(0));
	assertEquals(typeAoRd2, result.getRow().get(1));
    }
    @Test
    public void testGetrsAndSetters() {
	TypeAO typeAO = new TypeAO();

	typeAO.setCode("A001");
	typeAO.setLibelle("Libellé test");
	typeAO.setNature("Nature test");

	assertEquals("A001", typeAO.getCode());
	assertEquals("Libellé test", typeAO.getLibelle());
	assertEquals("Nature test", typeAO.getNature());
    }
    @Test
    public void testGettrsAndSetters() {
	RepdematGetListVoOut voOut = new RepdematGetListVoOut();
	RepdematDTO dto = new RepdematDTO();

	RepdematDoc doc1 = new RepdematDoc();
	RepdematDoc doc2 = new RepdematDoc();
	List<RepdematDoc> docs = Arrays.asList(doc1, doc2);

	dto.setRow(docs);

	voOut.setNumPage(1);
	voOut.setPageSize(20);
	voOut.setNbResultats(100L);
	voOut.setCurrentRes(dto);

	assertEquals(1, voOut.getNumPage());
	assertEquals(20, voOut.getPageSize());
	assertEquals(100L, voOut.getNbResultats());
	assertNotNull(voOut.getCurrentRes());
	assertEquals(2, voOut.getCurrentRes().getRow().size());
	assertEquals(doc1, voOut.getCurrentRes().getRow().get(0));
	assertEquals(doc2, voOut.getCurrentRes().getRow().get(1));
    }
}
