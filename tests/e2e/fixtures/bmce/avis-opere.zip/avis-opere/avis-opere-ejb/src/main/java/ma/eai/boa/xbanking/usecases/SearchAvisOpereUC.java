package ma.eai.boa.xbanking.usecases;
import ma.eai.boa.xbanking.dto.RepdematDTO;
import ma.eai.boa.xbanking.dto.RepdematDoc;
import ma.eai.boa.xbanking.service.CallDocubase;
import ma.eai.boa.xbanking.service.repdemat.RepdematService;
import ma.eai.boa.xbanking.servicedata.ws.Document;
import ma.eai.boa.xbanking.servicedata.ws.Pager;
import ma.eai.ingdev.fwk.annotations.UseCase;
import ma.eai.ingdev.fwk.exceptions.FwkRollbackException;
import ma.eai.ingdev.fwk.uc.BaseUseCase;
import ma.eai.ingdev.fwk.uc.ValueObject;
import ma.eai.ingdev.fwk.logging.EaiLog;

import ma.eai.boa.xbanking.utils.CommonFunction;
import ma.eai.web.vo.RepdematGetListVoOut;
import ma.eai.web.vo.SearchAvisOpereVO;
import net.java.dev.jaxb.array.StringArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import javax.xml.datatype.DatatypeConfigurationException;
import java.util.ArrayList;
import java.util.List;

//CLASSE DEDIE AU PROJET REPDEMAT
@UseCase
@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = FwkRollbackException.class)
public class SearchAvisOpereUC implements BaseUseCase {

    @Autowired
    private RepdematService repdematService;

    @Autowired
    private CallDocubase callDocubase;
    @Override
    public ValueObject execute(ValueObject in) throws FwkRollbackException {
	EaiLog.info("==== BEGIN : RECUPERER DOCS_SERVICEDATA REPDEMAT SearchAvisOpereUC ");
	Pager resultat;
	try {
	    SearchAvisOpereVO avisVO = (SearchAvisOpereVO) in;
	    long start = System.currentTimeMillis();
	    String types = repdematService.getReqTypeAvis(avisVO.getCategorie());
	    long end = System.currentTimeMillis();
	    EaiLog.info("TEMPS REPONSE TYPES FROM BDD :" + (end - start) + " ms");
	    EaiLog.info("Types Apres traitement getReqTypeAvis..." + types);

	    String numAccount = avisVO.getNumcompte();

	    StringArray arrCompte = checkCompteLength(numAccount, avisVO.getComptes());
	    StringArray arrType = typesCheck(avisVO.getCategorie(), avisVO.getTypeavis(), types);

	    for (int i = 0; i < arrCompte.getItem().size(); i++) {
		EaiLog.info("Compte " + i + "num:" + arrCompte.getItem().get(i));
	    }
	    for (int i = 0; i < arrType.getItem().size(); i++) {
		EaiLog.info("arrType " + i + "num:" + arrType.getItem().get(i));
	    }

	    String DateDebutFormatted = CommonFunction.convertDateFormat(avisVO.getDated());
	    String DateFinFormatted = CommonFunction.convertDateFormat(avisVO.getDatef());

	    double min = (avisVO.getMontantmin() != null) ? avisVO.getMontantmin() : 0.0;
	    double max = (avisVO.getMontantmax() != null) ? avisVO.getMontantmax() : Double.MAX_VALUE;

	    resultat = callDocubase.appelDocubase(arrCompte, arrType, DateDebutFormatted, DateFinFormatted,
		    avisVO.getNumPage(), avisVO.getPageSize(),
		    min,max);
	}catch (Exception e){
	    EaiLog.error("Erreur lors de l'exécution de SearchAvisOpereUC : " + e.getMessage()+ e);
	    throw new FwkRollbackException("Erreur lors de l'exécution de SearchAvisOpereUC");
	}
	RepdematGetListVoOut out = getRepdematGetListVoOut(resultat);
	EaiLog.info("nombre total des document depuis la sortie out.:" + out.getNbResultats());
	EaiLog.info("End AvisOpereGetList_UC");
	return out;
    }

    private RepdematGetListVoOut getRepdematGetListVoOut(Pager resultat) {
	RepdematGetListVoOut out = new RepdematGetListVoOut();
	RepdematDTO repDto = new RepdematDTO();
	repDto.setRow(getListDoc(resultat));
	out.setNbResultats(resultat.getNombreTotalDeDocument());
	out.setCurrentRes(repDto);
	return out;
    }

    public List<RepdematDoc> getListDoc(Pager resultat){
	List<RepdematDoc> listDoc = new ArrayList<RepdematDoc>();
	RepdematDoc docu;
	if (resultat != null){
	    for (Document doc : resultat.getDocuments()) {
		docu = new RepdematDoc();
		docu.setBaseName(doc.getBase());
		docu.setBase(doc.getBaseId());

		try {
		    docu.setDateTraitement(CommonFunction.formattedDate(doc.getDateClassement()));
		} catch (DatatypeConfigurationException e) {
		    throw new RuntimeException(e);
		}
		docu.setGuid(doc.getDocId());
		docu.setTypeDoc(doc.getTypeDocument());
		docu.setNumCompte(doc.getNumeroCompte());
		docu.setMontant(doc.getMontant() != null
			? Double.valueOf(doc.getMontant().replace(",", "."))
			: null);
		//docu.setMontant(doc.getMontant() != null ? Double.valueOf(doc.getMontant()) : null);
		//docu.setMontant(Double.valueOf(doc.getMontant()));
		listDoc.add(docu);
	    }
	    return listDoc;
	}
	else {
	    EaiLog.info("Result of Pager is null :");
	    return null;
	}
    }

    public StringArray checkCompteLength(String numAccount,String comptes ){
	StringArray arrCompte = new StringArray();
	if (numAccount != null && !numAccount.isEmpty() && !numAccount.equals("*")) {
	    String compte19 = numAccount;
	    String compte24 = numAccount.length() == 24 ? numAccount : "011" + numAccount.substring(0, 2) + "00" + numAccount.substring(3, 19);
	    compte19 = compte24.length() == 24 ? compte24.substring(3, 8) + compte24.substring(10, 24) : compte19;
	    arrCompte.getItem().add(compte19);
	} else {
	    List<String> res = CommonFunction.extractAccounts(comptes);
	    EaiLog.info("size extractAccount.." + res.size());
	    for (int i = 0; i < res.size(); i++) {
		arrCompte.getItem().add(res.get(i));
	    }
	}
	return arrCompte;
    }
    public StringArray typesCheck(String category,String typeavis, String types){
	StringArray arrType = new StringArray();
	if (typeavis != null && !typeavis.isEmpty() && !typeavis.equals("*")) {
	    arrType.getItem().add(typeavis);
	}
	if (category != null) {
	    if (typeavis == null || typeavis.equals("*")) {
		EaiLog.info("################## Tous les types ###################",types);
		//trait tous types
		EaiLog.info("Trait tous les types...");
		for (String element : types.split(",")) {
		    EaiLog.info("################## type ###################"+element);
		    arrType.getItem().add(element);
		}
	    }
	}
	if (category == null || category.equals("")) {
	    //report du jour
	    //String type = repdematService.getReqCat();
	    arrType.getItem().add("EXTRAIT");
	    EaiLog.info("Trait Report du jour getReqCat..." + arrType.getItem());
	    /*arrType.getItem().add("EXTRAIT");
	    for (String element : type.split(",")) {
		arrType.getItem().add(element);
	    }*/
	}
	return arrType;
    }
}
