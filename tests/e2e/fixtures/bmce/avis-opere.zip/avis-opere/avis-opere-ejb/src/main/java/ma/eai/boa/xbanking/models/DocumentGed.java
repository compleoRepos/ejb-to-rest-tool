package ma.eai.boa.xbanking.models;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.io.Serializable;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DocumentGed", namespace = "http://beans.eai.ma")
public class DocumentGed implements Serializable {

    private static final long serialVersionUID = 1L;

    @XmlElement(name = "ListFichiers", required = true)
    private List<FichierGed> listFichiers;

    @XmlElement(name = "MONTH", required = true)
    private String moisDocument;

    public DocumentGed(List<FichierGed> listFichiers) {
	this.listFichiers = listFichiers;
    }

    public DocumentGed() {
	super();
    }

    public List<FichierGed> getListFichiers() {
	return listFichiers;
    }

    public void setListFichiers(List<FichierGed> listFichiers) {
	this.listFichiers = listFichiers;
    }

    public String getMoisDocument() {
	return moisDocument;
    }

    public void setMoisDocument(String moisDocument) {
	this.moisDocument = moisDocument;
    }

}