package ma.eai.web.tests;

import junit.framework.TestCase;
import ma.eai.boa.xbanking.avisopereBean;
import ma.eai.boa.xbanking.utils.Constant;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.Parser;
import ma.eai.commons.utilities.UtilFile;
import ma.eai.commons.utilities.UtilString;
import ma.eai.ingdev.fwk.logging.EaiLog;
import ma.eai.midw.integration.Services;
import org.mockito.MockedStatic;

import static org.mockito.Mockito.mockStatic;

public class ViewAvisOpereUCTest extends TestCase {
    public void testCase() throws Exception {

        try (MockedStatic<Services> mockedServices = mockStatic(Services.class)){
            mockedServices.when(() -> Services.find(Constant.DOCUBASE_EDOCS_URL, String.class)).thenReturn("https://docubase-ws-dy.bankofafrica.ma:8443/WsReportDirect/WsEdoc?wsdl");
            System.setProperty("execution.env", "dev");
            avisopereBean reventBean = new avisopereBean();
            Envelope env = Parser.unmarshall(UtilString.toString(UtilFile.searchResource("ViewAvisOpereUC.xml")));
            Envelope envRetour = reventBean.process(env);
            String envString = Parser.marshall(envRetour);

            assertNotNull(envString);

            EaiLog.info("Resultat :" + envString);

        } catch (Exception e) {
            EaiLog.error(e);
        }
    }
}
