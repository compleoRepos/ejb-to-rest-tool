package ma.eai.boa.xbanking.utils;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.ingdev.fwk.logging.EaiLog;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CommonFunction {

    private CommonFunction() {

    }
    public static String bodyError = "<object>\r\n" +
	    "<codeRetour>0001</codeRetour>\r\n" +
	    "<messageRetour>Retour KO</messageRetour>\r\n" +
	    "</object>\r\n";
    public static Envelope constructEnvWhenGlobalError(Envelope envIn) {
	envIn.setBody(bodyError);
	return envIn;
    }
    public static List<String> extractAccounts(String input) {
	List<String> accountsList = new ArrayList<String>();
	// Supprimer les parenthses et diviser la chane en fonction des virgules
	String[] accountsArray = input.substring(1, input.length() - 1).split(",");
	for (String account : accountsArray) {
	    // Supprimer les guillemets simples et les espaces vides
	    String cleanAccount = account.trim().replace("'", "");
	    accountsList.add(cleanAccount);
	}
	return accountsList;
    }
    public static String getCompte19(String num_compte) {

	if(num_compte !=null && num_compte.length()==28){
	    String compte19;
	    //num_compte=num_compte.substring(4);
	    compte19 = num_compte.substring(7, 12) + num_compte.substring(14, 28);
	    EaiLog.info("num compte 28 ==> 19::"+compte19);
	    return compte19;
	}else{
	    EaiLog.info("num compte 19:"+num_compte);
	    return num_compte;
	}

    }
    public static String convertDateFormat(String dateString) {
	SimpleDateFormat inputFormat = new SimpleDateFormat("yyyyMMdd");
	SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy");

	try {
	    // Parse the date string
	    Date date = inputFormat.parse(dateString);
	    return outputFormat.format(date);
	} catch (Exception e) {
	    EaiLog.info("Invalid date format or date string");
	    return null;
	}
    }
    public static String formattedDate(XMLGregorianCalendar dateClassement) throws DatatypeConfigurationException {
	String dateString =String.valueOf(dateClassement);
	DateTimeFormatter formatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
	OffsetDateTime dateTime = OffsetDateTime.parse(dateString, formatter);
	String formattedDate = dateTime.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
	XMLGregorianCalendar formattedXmlDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(formattedDate);
	return formattedDate;
    }
}
