package ma.eai.boa.xbanking.dto;

import java.io.Serializable;
import java.util.List;

public class AvisOpereDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private List<Doc> avisopere;

    public List<Doc> getAvisopere() {
	return avisopere;
    }

    public void setAvisopere(List<Doc> avisopere) {
	this.avisopere = avisopere;
    }
}
