package ma.eai.boa.xbanking;

import javax.ejb.Remote;
import javax.ejb.Stateless;

import ma.eai.boa.xbanking.utils.CommonFunction;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.ingdev.fwk.logging.EaiLog;
import ma.eai.ingdev.fwk.strategie.impl.UCStrategie;
import ma.eai.midw.connectors.SynchroneService;


@Stateless(name = "avisopereBean")
@Remote(SynchroneService.class)
public class avisopereBean extends UCStrategie {

    @Override
    public Envelope process(Envelope envelopeIn) throws Exception {
	Envelope envOut = null;
	try {
	    EaiLog.initLogTraceInfos(envelopeIn);
	    EaiLog.info("======>FLUX ENTRE EN XML: " + envelopeIn);
	    envOut = super.process(envelopeIn);
	} catch (Exception e) {
	    EaiLog.error("Erreur Service : ", e);
	    return CommonFunction.constructEnvWhenGlobalError(envelopeIn);
	}
	EaiLog.info("=========>FLUX SORTIE EN XML:  " + envOut);
	return envOut;
    }

}
