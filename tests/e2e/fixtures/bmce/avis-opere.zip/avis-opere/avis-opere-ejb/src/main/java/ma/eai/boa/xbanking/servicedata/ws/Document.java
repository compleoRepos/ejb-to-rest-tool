
package ma.eai.boa.xbanking.servicedata.ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour document complex type.
 * 
 * <p>Le fragment de schema suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="document">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dateClassement" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="dateOperation" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="titre" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TypeDocument" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="folio" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="montant" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="numeroCompte" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="base" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="baseId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="docId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "document", propOrder = {
    "dateClassement",
    "dateOperation",
    "titre",
    "typeDocument",
    "folio",
    "montant",
    "numeroCompte",
    "base",
    "baseId",
    "docId"
})
public class Document {

    @XmlElement(required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dateClassement;
    @XmlElement(required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dateOperation;
    @XmlElement(required = true)
    protected String titre;
    @XmlElement(name = "TypeDocument", required = true)
    protected String typeDocument;
    protected String folio;
    protected String montant;
    @XmlElement(required = true)
    protected String numeroCompte;
    @XmlElement(required = true)
    protected String base;
    protected long baseId;
    protected long docId;

    /**
     * Obtient la valeur de la propriete dateClassement.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateClassement() {
        return dateClassement;
    }

    /**
     * Definit la valeur de la propriete dateClassement.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateClassement(XMLGregorianCalendar value) {
        this.dateClassement = value;
    }

    /**
     * Obtient la valeur de la propriete dateOperation.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateOperation() {
        return dateOperation;
    }

    /**
     * Definit la valeur de la propriete dateOperation.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateOperation(XMLGregorianCalendar value) {
        this.dateOperation = value;
    }

    /**
     * Obtient la valeur de la propriete titre.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitre() {
        return titre;
    }

    /**
     * Definit la valeur de la propriete titre.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitre(String value) {
        this.titre = value;
    }

    /**
     * Obtient la valeur de la propriete typeDocument.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeDocument() {
        return typeDocument;
    }

    /**
     * Definit la valeur de la propriete typeDocument.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeDocument(String value) {
        this.typeDocument = value;
    }

    /**
     * Obtient la valeur de la propriete folio.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFolio() {
        return folio;
    }

    /**
     * Definit la valeur de la propriete folio.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFolio(String value) {
        this.folio = value;
    }

    /**
     * Obtient la valeur de la propriete montant.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMontant() {
        return montant;
    }

    /**
     * Definit la valeur de la propriete montant.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMontant(String value) {
        this.montant = value;
    }

    /**
     * Obtient la valeur de la propriete numeroCompte.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroCompte() {
        return numeroCompte;
    }

    /**
     * Definit la valeur de la propriete numeroCompte.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroCompte(String value) {
        this.numeroCompte = value;
    }

    /**
     * Obtient la valeur de la propriete base.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBase() {
        return base;
    }

    /**
     * Definit la valeur de la propriete base.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBase(String value) {
        this.base = value;
    }

    /**
     * Obtient la valeur de la propriete baseId.
     * 
     */
    public long getBaseId() {
        return baseId;
    }

    /**
     * Definit la valeur de la propriete baseId.
     * 
     */
    public void setBaseId(long value) {
        this.baseId = value;
    }

    /**
     * Obtient la valeur de la propriete docId.
     * 
     */
    public long getDocId() {
        return docId;
    }

    /**
     * Definit la valeur de la propriete docId.
     * 
     */
    public void setDocId(long value) {
        this.docId = value;
    }

}
