package ma.eai.boa.xbanking.repository;

import ma.eai.boa.xbanking.entities.TypeAoRd;
import ma.eai.ingdev.fwk.annotation.tx.ContinueOrStartTransaction;
import ma.eai.ingdev.fwk.annotations.Manager;
import ma.eai.ingdev.fwk.dao.GeneriqueDAO;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Manager
@ContinueOrStartTransaction
public class SearchTypesRepDemat extends GeneriqueDAO<TypeAoRd, String> {
    public List<TypeAoRd> SearchTypes(String nature) {
	EaiLog.info("Repository nature => "+nature);
	List<TypeAoRd> list;
	Map<String, Object> params = new HashMap<String, Object>();
	if (nature == null || nature.isEmpty()){
	    Query query = this.createQuery("From TypeAoRd");
	    list = query.list();
	}
	else {
	    params.put("nature", nature);
	    Query query = this.createQuery("from TypeAoRd where nature = :nature",params);
	    query.setParameter("nature", nature);
	    list = query.list();
	}
	return list != null && !list.isEmpty() ? list : Collections.emptyList();
    }
    public List<TypeAoRd> getTypesNotNull() {
	EaiLog.info("Begin getTypesNotNull():");
	List<TypeAoRd> list = null;
	try {
	    Query query = this.createQuery("FROM TypeAoRd WHERE categorie IS NOT NULL");
	    list = query.list();
	    EaiLog.info("=> SearchRepository listType  size.:" + list.size());
	} catch (Exception e) {
	    EaiLog.error("ERREUR in getTypesNotNull() "+e);
	}
	EaiLog.info("End getTypesNotNull() :");
	return list != null && !list.isEmpty() ? list : null;
    }

}
