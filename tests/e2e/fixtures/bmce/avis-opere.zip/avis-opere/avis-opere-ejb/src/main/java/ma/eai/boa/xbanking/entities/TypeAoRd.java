package ma.eai.boa.xbanking.entities;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "AO_RD_TYPE")
public class TypeAoRd implements Serializable {
    private static final long serialVersionUID = -1474799622712735125L;
    @Id
    private String code;
    @Column(name = "LIBELLE")
    private String libelle;
    @Column(name = "NATURE")
    private String categorie;
    @Column(name = "DATE_CREATION")
    private String DATE_CREATION;

    public String getDATE_CREATION() {
	return DATE_CREATION;
    }

    public void setDATE_CREATION(String DATE_CREATION) {
	this.DATE_CREATION = DATE_CREATION;
    }

    public String getCode() {
	return code;
    }

    public void setCode(String code) {
	this.code = code;
    }

    public String getLibelle() {
	return libelle;
    }

    public void setLibelle(String libelle) {
	this.libelle = libelle;
    }

    public String getCategorie() {
	return categorie;
    }

    public void setCategorie(String categorie) {
	this.categorie = categorie;
    }
}

