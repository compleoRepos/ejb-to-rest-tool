package ma.eai.web.tests;

import junit.framework.TestCase;
import ma.eai.boa.xbanking.dto.AvisOpereDTO;
import ma.eai.boa.xbanking.dto.Doc;
import ma.eai.boa.xbanking.dto.Types;
import ma.eai.boa.xbanking.utils.CommonFunction;
import ma.eai.ingdev.fwk.logging.EaiLog;


import ma.eai.web.vo.AvisOpereGetListVoOut;
import org.junit.Test;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class helpTest extends TestCase {
    @Test
    public void utilsTest() throws DatatypeConfigurationException {
	String res= CommonFunction.getCompte19("1234567891234567890123456789");
	String convert=CommonFunction.convertDateFormat("20220922");
	String dateTimeString = "2024-09-30T10:15:30+01:00";
	XMLGregorianCalendar xmlGregorianCalendar=DatatypeFactory.newInstance().newXMLGregorianCalendar(dateTimeString);
	String res_Date=CommonFunction.formattedDate(xmlGregorianCalendar);
	EaiLog.info("http://ws.bmce.org/");
	assertNotNull(convert);
	assertNotNull(res_Date);
	assertNotNull(res);
    }
    @Test
    public void testExtractAccounts() {
	String input = "['acc1', 'acc2', 'acc3']";
	List<String> expected = Arrays.asList("acc1", "acc2", "acc3");

	List<String> result = CommonFunction.extractAccounts(input);

	assertEquals(expected, result);
    }

    @Test
    public void testExtractAccountsWithSpaces() {
	String input = "[' acc1 ', ' acc2 ', 'acc3']";
	List<String> expected = Arrays.asList("acc1", "acc2", "acc3");

	List<String> result = CommonFunction.extractAccounts(input);

	assertNotNull(result);
    }

    @Test
    public void testExtractAccountsSingleItem() {
	String input = "['uniqueAcc']";
	List<String> expected = Arrays.asList("uniqueAcc");

	List<String> result = CommonFunction.extractAccounts(input);

	assertEquals(expected, result);
    }

    @Test
    public void testAvisOpereGetListVoOut() {
	// Création d'une instance de AvisOpereGetListVoOut
	AvisOpereGetListVoOut avisOpereVo = new AvisOpereGetListVoOut();

	// Test des setters et des getters
	int expectedNumPage = 1;
	int expectedPageSize = 10;
	long expectedNbResultats = 100;

	avisOpereVo.setNumPage(expectedNumPage);
	avisOpereVo.setPageSize(expectedPageSize);
	avisOpereVo.setNbResultats(expectedNbResultats);

	// Vérifications
	assertEquals("Le numéro de page doit être 1", expectedNumPage, avisOpereVo.getNumPage());
	assertEquals("La taille de la page doit être 10", expectedPageSize, avisOpereVo.getPageSize());
	assertEquals("Le nombre de résultats doit être 100", expectedNbResultats, avisOpereVo.getNbResultats());

	// Test de l'attribut currentRes
	AvisOpereDTO currentRes = new AvisOpereDTO();
	avisOpereVo.setCurrentRes(currentRes);

	assertEquals("L'objet currentRes doit être le même que celui défini", currentRes, avisOpereVo.getCurrentRes());
    }
    @Test
    public void testAvisOpereDTO() {
	// Création d'un Doc et d'une liste
	Doc doc = new Doc();
	doc.setFolio("12345");
	doc.setMontant(1000.50);
	doc.setNumcompte("987654321");

	List<Doc> docList = new ArrayList<Doc>();
	docList.add(doc);

	// Test AvisOpereDTO
	AvisOpereDTO avisOpereDTO = new AvisOpereDTO();
	avisOpereDTO.setAvisopere(docList);

	// Vérification des résultats
	assertNotNull(avisOpereDTO.getAvisopere());
	assertEquals(1, avisOpereDTO.getAvisopere().size());
	assertEquals("12345", avisOpereDTO.getAvisopere().get(0).getFolio());
	assertEquals(Double.valueOf(1000.50), avisOpereDTO.getAvisopere().get(0).getMontant());
	assertEquals("987654321", avisOpereDTO.getAvisopere().get(0).getNumcompte());
    }

    @Test
    public void testDoc() {
	// Création d'un Doc
	Doc doc = new Doc();
	doc.setFolio("54321");
	doc.setMontant(2000.75);
	doc.setNumcompte("123456789");
	doc.setDateClassement("2024-09-30");
	doc.setDatefichier("2024-09-29");

	// Création d'un Type
	Types typeao = new Types();
	typeao.setCode("001");
	typeao.setLibelle("Type A");

	doc.setTypeao(typeao);

	// Vérification des résultats
	assertEquals("54321", doc.getFolio());
	assertEquals(Double.valueOf(2000.75), doc.getMontant());
	assertEquals("123456789", doc.getNumcompte());
	assertEquals("2024-09-30", doc.getDateClassement());
	assertEquals("2024-09-29", doc.getDatefichier());
	assertEquals("001", doc.getTypeao().getCode());
	assertEquals("Type A", doc.getTypeao().getLibelle());
    }

    @Test
    public void testTypes() {
	// Création d'un Types
	Types types = new Types();
	types.setCode("002");
	types.setLibelle("Type B");

	// Vérification des résultats
	assertEquals("002", types.getCode());
	assertEquals("Type B", types.getLibelle());
    }
}
