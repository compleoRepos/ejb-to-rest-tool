package ma.eai.web.tests.usecasesTest;

import ma.eai.boa.xbanking.dto.RepdematDoc;
import ma.eai.boa.xbanking.service.CallDocubase;
import ma.eai.boa.xbanking.service.repdemat.RepdematService;
import ma.eai.boa.xbanking.servicedata.ws.Document;
import ma.eai.boa.xbanking.servicedata.ws.Pager;
import ma.eai.boa.xbanking.usecases.SearchAvisOpereUC;
import ma.eai.ingdev.fwk.exceptions.FwkRollbackException;
import ma.eai.ingdev.fwk.logging.EaiLog;
import ma.eai.web.vo.RepdematGetListVoOut;
import ma.eai.web.vo.SearchAvisOpereVO;
import net.java.dev.jaxb.array.StringArray;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import javax.xml.datatype.DatatypeFactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * ✅ Java 8-compatible full coverage test for SearchAvisOpereUC
 */
public class SearchAvisOpereUCTest {

    @Mock private RepdematService mockRepdematService;
    @Mock private CallDocubase mockCallDocubase;
    @Mock private Pager mockPager;
    @Mock private Document mockDocument;
    private SearchAvisOpereUC searchAvisOpereUC;

    @Before
    public void setup() throws Exception {
	MockitoAnnotations.initMocks(this);
	searchAvisOpereUC = new SearchAvisOpereUC();

	java.lang.reflect.Field f1 = SearchAvisOpereUC.class.getDeclaredField("repdematService");
	f1.setAccessible(true);
	f1.set(searchAvisOpereUC, mockRepdematService);

	java.lang.reflect.Field f2 = SearchAvisOpereUC.class.getDeclaredField("callDocubase");
	f2.setAccessible(true);
	f2.set(searchAvisOpereUC, mockCallDocubase);
    }

    // ---------------- execute() happy path ----------------
    @Test
    public void testExecute_Success() throws Exception {
	try (MockedStatic<EaiLog> mockedEaiLog = mockStatic(EaiLog.class);
		MockedStatic<ma.eai.boa.xbanking.utils.CommonFunction> mockedCommon =
			mockStatic(ma.eai.boa.xbanking.utils.CommonFunction.class)) {

	    SearchAvisOpereVO in = new SearchAvisOpereVO();
	    in.setCategorie("C1");
	    in.setTypeavis("*");
	    in.setNumcompte("123456789012345678901234");
	    in.setComptes("C1,C2");
	    in.setDated("2025-10-01");
	    in.setDatef("2025-10-29");
	    in.setNumPage(1);
	    in.setPageSize(10);
	    in.setMontantmin((double) 0);
	    in.setMontantmax(1000.0);

	    when(mockRepdematService.getReqTypeAvis(anyString())).thenReturn("T1,T2");
	    mockedCommon.when(() -> ma.eai.boa.xbanking.utils.CommonFunction.convertDateFormat(anyString()))
		    .thenReturn("2025-10-01");
	    List<String> accounts = Arrays.asList("ACC1", "ACC2");
	    mockedCommon.when(() -> ma.eai.boa.xbanking.utils.CommonFunction.extractAccounts(anyString()))
		    .thenReturn(accounts);

	    when(mockCallDocubase.appelDocubase(any(), any(), anyString(), anyString(),
		    anyInt(), anyInt(), anyDouble(), anyDouble()))
		    .thenReturn(mockPager);
	    when(mockPager.getNombreTotalDeDocument()).thenReturn(2L);
	    List<Document> docs = new ArrayList<Document>();
	    docs.add(mockDocument);
	    docs.add(mockDocument);
	    when(mockPager.getDocuments()).thenReturn(docs);

	    when(mockDocument.getBase()).thenReturn("BASE");
	    when(mockDocument.getBaseId()).thenReturn(10L);
	    when(mockDocument.getDateClassement()).thenReturn(
		    DatatypeFactory.newInstance().newXMLGregorianCalendar("2025-10-28"));
	    when(mockDocument.getDocId()).thenReturn(10L);
	    when(mockDocument.getTypeDocument()).thenReturn("TYPE");
	    when(mockDocument.getNumeroCompte()).thenReturn("ACC123");
	    when(mockDocument.getMontant()).thenReturn(String.valueOf(100.0));
	    mockedCommon.when(() -> ma.eai.boa.xbanking.utils.CommonFunction.formattedDate(any()))
		    .thenReturn("28/10/2025");

	    Object result = searchAvisOpereUC.execute(in);
	    assertNotNull(result);
	    assertTrue(result instanceof RepdematGetListVoOut);

	    RepdematGetListVoOut out = (RepdematGetListVoOut) result;
	    assertEquals(2, out.getNbResultats());
	    assertNotNull(out.getCurrentRes());
	    assertFalse(out.getCurrentRes().getRow().isEmpty());
	}
    }

    // ---------------- execute() exception path ----------------
    @Test(expected = FwkRollbackException.class)
    public void testExecute_WithException() throws Exception {
	try (MockedStatic<EaiLog> mockedEaiLog = mockStatic(EaiLog.class)) {
	    SearchAvisOpereVO in = new SearchAvisOpereVO();
	    in.setCategorie("C1");
	    when(mockRepdematService.getReqTypeAvis(anyString()))
		    .thenThrow(new RuntimeException("Simulated failure"));
	    searchAvisOpereUC.execute(in);
	}
    }

    // ---------------- getListDoc() with valid Pager ----------------
    @Test
    public void testGetListDoc_ValidPager() throws Exception {
	try (MockedStatic<ma.eai.boa.xbanking.utils.CommonFunction> mockedCommon =
		mockStatic(ma.eai.boa.xbanking.utils.CommonFunction.class)) {

	    Pager pager = mock(Pager.class);
	    Document doc = mock(Document.class);
	    List<Document> docs = new ArrayList<Document>();
	    docs.add(doc);
	    when(pager.getDocuments()).thenReturn(docs);
	    when(doc.getBase()).thenReturn("BASE");
	    when(doc.getBaseId()).thenReturn(10L);
	    when(doc.getDocId()).thenReturn(10L);
	    when(doc.getTypeDocument()).thenReturn("TYPE");
	    when(doc.getNumeroCompte()).thenReturn("ACC123");
	    when(doc.getMontant()).thenReturn(String.valueOf(100.0));
	    when(doc.getDateClassement()).thenReturn(
		    DatatypeFactory.newInstance().newXMLGregorianCalendar("2025-10-28"));
	    mockedCommon.when(() -> ma.eai.boa.xbanking.utils.CommonFunction.formattedDate(any()))
		    .thenReturn("28/10/2025");

	    List<RepdematDoc> list = searchAvisOpereUC.getListDoc(pager);
	    assertEquals(1, list.size());
	    assertEquals("ACC123", list.get(0).getNumCompte());
	}
    }

    // ---------------- getListDoc() null Pager ----------------
    @Test
    public void testGetListDoc_NullPager() {
	try (MockedStatic<EaiLog> mockedEaiLog = mockStatic(EaiLog.class)) {
	    List<RepdematDoc> list = searchAvisOpereUC.getListDoc(null);
	    assertNull(list);
	    mockedEaiLog.verify(() -> EaiLog.info(contains("Result of Pager is null")));
	}
    }

    // ---------------- checkCompteLength() branches ----------------
    @Test
    public void testCheckCompteLength_WithNumAccount() {
	StringArray arr = searchAvisOpereUC.checkCompteLength("123456789012345678901234", "IGNORED");
	assertFalse(arr.getItem().isEmpty());
    }

    @Test
    public void testCheckCompteLength_WithComptesList() {
	try (MockedStatic<ma.eai.boa.xbanking.utils.CommonFunction> mockedCommon =
		mockStatic(ma.eai.boa.xbanking.utils.CommonFunction.class);
		MockedStatic<EaiLog> mockedEaiLog = mockStatic(EaiLog.class)) {

	    List<String> accounts = Arrays.asList("ACC1", "ACC2");
	    mockedCommon.when(() -> ma.eai.boa.xbanking.utils.CommonFunction.extractAccounts(anyString()))
		    .thenReturn(accounts);

	    StringArray arr = searchAvisOpereUC.checkCompteLength("*", "ACC1,ACC2");
	    assertEquals(2, arr.getItem().size());
	}
    }

    // ---------------- typesCheck() branches ----------------
    @Test
    public void testTypesCheck_WithSpecificType() {
	StringArray arr = searchAvisOpereUC.typesCheck("CAT", "T1", "T1,T2");
	assertEquals(1, arr.getItem().size());
    }

    @Test
    public void testTypesCheck_WithAllTypesAndCategory() {
	try (MockedStatic<EaiLog> mockedEaiLog = mockStatic(EaiLog.class)) {
	    StringArray arr = searchAvisOpereUC.typesCheck("CAT", "*", "T1,T2");
	    assertEquals(2, arr.getItem().size());
	}
    }
}
