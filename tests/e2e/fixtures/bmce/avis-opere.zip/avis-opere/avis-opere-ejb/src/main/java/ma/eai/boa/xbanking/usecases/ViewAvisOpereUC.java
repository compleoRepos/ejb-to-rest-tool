package ma.eai.boa.xbanking.usecases;


import finatech.edoc.WsEdoc;
import finatech.edoc.WsEdocService;
import ma.eai.boa.xbanking.utils.Constant;
import ma.eai.boa.xbanking.utils.SoapUiLikeLoggingHandler;
import ma.eai.midw.integration.Services;
import ma.eai.web.vo.CurrentResult;
import ma.eai.web.vo.ViewAvisOpereVO;
import ma.eai.web.vo.ViewAvisOpereVoOut;
import ma.eai.ingdev.fwk.annotations.UseCase;
import ma.eai.ingdev.fwk.exceptions.FwkRollbackException;
import ma.eai.ingdev.fwk.logging.EaiLog;
import ma.eai.ingdev.fwk.uc.BaseUseCase;
import ma.eai.ingdev.fwk.uc.ValueObject;

import ma.eai.web.vo.AvisOpere;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.xml.ws.handler.Handler;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

//UC COMMUN POUR AVISOPERE ET REPDEMAT
@UseCase
@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = FwkRollbackException.class)
public class ViewAvisOpereUC implements BaseUseCase {
    @Override
    public ValueObject execute(ValueObject in) throws FwkRollbackException {
	EaiLog.info("==START ViewAvisOpereUC==");
	try {
	    ViewAvisOpereVO avisVO = (ViewAvisOpereVO) in;

	    String guid = avisVO.getGuid();
	    String baseName = avisVO.getBaseName();
	    String numCompte = avisVO.getNumCompte();

	    long start = System.currentTimeMillis();
	    String docubaseEdocWsdlUrl = Services.find(Constant.DOCUBASE_EDOCS_URL, String.class);
	    URL wsdlEdocFromUDDI= null;
	    try {
		wsdlEdocFromUDDI = new URL(docubaseEdocWsdlUrl);
	    } catch (MalformedURLException e) {
		throw new RuntimeException(e);
	    }
	    WsEdocService wsEdocServiceLocator = new WsEdocService(wsdlEdocFromUDDI);
	    wsEdocServiceLocator.setHandlerResolver(portInfo -> {
		List<Handler> handlerChain = new ArrayList<Handler>();
		handlerChain.add(new SoapUiLikeLoggingHandler());
		return handlerChain;
	    });
	    WsEdoc wsEdoc = wsEdocServiceLocator.getWsEdocPort();
	    String response = wsEdoc.getDocumentByGID(Long.parseLong(guid), baseName, numCompte);
	    long end = System.currentTimeMillis();
	    EaiLog.info("TEMPS REPONSE WEB SERVCICE getURL :" + (end - start) + " ms");
	    EaiLog.info("value URL  depuis webservice=================> " + response);

	    ViewAvisOpereVoOut out = getViewAvisOpereVoOut(response);
	    EaiLog.info("---- Fin ViewAvisOpereUC --------");
	    return out;
	} catch (Exception e) {
	    EaiLog.error("######  Exception appel web service finatech "+e+e.getMessage());
	    throw new FwkRollbackException("Erreur lors de l'exécution de ViewAvisOpereUC");
	}
    }

	private static ViewAvisOpereVoOut getViewAvisOpereVoOut(String response) {
	    ViewAvisOpereVoOut out = new ViewAvisOpereVoOut();
	    CurrentResult res = new CurrentResult();
	    AvisOpere avisOpere = new AvisOpere();

	    avisOpere.setUrl(response);
	    res.setRow(avisOpere);
	    out.setCurrentRes(res);
	    out.setNbResultats(0);
	    out.setPageSize(0);
	    out.setNumPage(0);
	    return out;
	}
}
