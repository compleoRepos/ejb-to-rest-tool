package ma.eai.web.vo;

import ma.eai.ingdev.fwk.uc.ValueObject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "object")
public class ViewAvisOpereVoOut implements ValueObject {
    private static final long serialVersionUID = 1L;
    private long nbResultats;
    private int pageSize;
    private int numPage;

    CurrentResult currentRes;

    public long getNbResultats() {
	return nbResultats;
    }

    public void setNbResultats(long nbResultats) {
	this.nbResultats = nbResultats;
    }

    public int getPageSize() {
	return pageSize;
    }

    public void setPageSize(int pageSize) {
	this.pageSize = pageSize;
    }

    public int getNumPage() {
	return numPage;
    }

    public void setNumPage(int numPage) {
	this.numPage = numPage;
    }

    public CurrentResult getCurrentRes() {
	return currentRes;
    }

    public void setCurrentRes(CurrentResult currentRes) {
	this.currentRes = currentRes;
    }
}
