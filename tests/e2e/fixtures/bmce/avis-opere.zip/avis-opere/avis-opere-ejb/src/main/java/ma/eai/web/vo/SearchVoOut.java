package ma.eai.web.vo;

import ma.eai.ingdev.fwk.uc.ValueObject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "object")
public class SearchVoOut implements ValueObject {
    private static final long serialVersionUID = 1L;
    CurrentRes currentRes;

    public CurrentRes getCurrentRes() {
	return currentRes;
    }

    public void setCurrentRes(CurrentRes currentRes) {
	this.currentRes = currentRes;
    }
}
