package ma.eai.boa.xbanking.usecases;

import ma.eai.boa.xbanking.entities.TypeAO;
import ma.eai.boa.xbanking.service.avisopere.ISearchService;
import ma.eai.ingdev.fwk.annotations.UseCase;
import ma.eai.ingdev.fwk.exceptions.FwkRollbackException;
import ma.eai.ingdev.fwk.logging.EaiLog;
import ma.eai.ingdev.fwk.uc.BaseUseCase;
import ma.eai.ingdev.fwk.uc.ValueObject;
import ma.eai.web.vo.CurrentRes;
import ma.eai.web.vo.SearchVO;
import ma.eai.web.vo.SearchVoOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@UseCase
@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = FwkRollbackException.class)
public class AvisOpereGetListTypeDocumentUC implements BaseUseCase {

    @Autowired
    ISearchService searchService;

    @Override
    public ValueObject execute(ValueObject in) throws FwkRollbackException {
	EaiLog.info("==== DEBUT RECUPERATION TYPES AVISOPERE  AvisOpereGetListTypeDocumentUC=====");
	SearchVoOut out = new SearchVoOut();
	try {
	    SearchVO searchVOIn = (SearchVO) in;
	    TypeAO type = new TypeAO();
	    type.setCode("*");
	    type.setLibelle("Tous les types");

	    List<TypeAO> resRech = searchService.getListTypes();
	    resRech.add(0, type);
	    // fin modification de 30/04/20202
	    EaiLog.info("========> size final:.........:" + resRech.size());
	    CurrentRes res = new CurrentRes();
	    res.setAvisopere(resRech);
	    out.setCurrentRes(res);
	    EaiLog.info("==========Fiiin AvisOpereGetListTypeDocumentUC ......");
	}catch (Exception e){
	    EaiLog.error("Erreur lors de l'exécution de AvisOpereGetListTypeDocumentUC : " + e.getMessage(), e);
	    throw new FwkRollbackException("Erreur lors de l'exécution de AvisOpereGetListTypeDocumentUC");
	}
	return out;
    }
}
