CREATE SEQUENCE ID_FORMATION_SEQ
    INCREMENT BY 1
    START WITH 1
    MINVALUE 1
    MAXVALUE 999999999
    CACHE 20;

CREATE TABLE FORMATION_COMPTE (
  ID NUMBER(10,0) NOT NULL PRIMARY KEY,
  RIB VARCHAR2(50) NOT NULL,
  DATE_CREATION DATE NOT NULL,
  SOLDE NUMBER(15,2) NOT NULL,
  USER_ID NUMBER(10,0) NOT NULL
);

CREATE TABLE FORMATION_CLIENT (
  ID NUMBER(10,0) NOT NULL PRIMARY KEY,
  NOM VARCHAR2(20) NOT NULL,
  PRENOM VARCHAR2(15) NOT NULL,
  EMAIL VARCHAR2(100) NOT NULL,
  DATENAISSANCE DATE NOT NULL
);

insert into FORMATION_CLIENT(id,nom,prenom,email,datenaissance) 
values (ID_FORMATION_SEQ.nextval,'nom1éà','prenom1','contact1@eai.com','01/01/1986');
insert into FORMATION_CLIENT(id,nom,prenom,email,datenaissance) 
values (ID_FORMATION_SEQ.nextval,'nom2','prenom2','contact2@eai.com','01/01/1987');

insert into FORMATION_COMPTE(id,rib,date_creation,solde,user_id) 
values (ID_FORMATION_SEQ.nextval,'001551654987032135232136','01/03/2020',12215.33,(select id from FORMATION_CLIENT where nom = 'nom1éà'));
insert into FORMATION_COMPTE(id,rib,date_creation,solde,user_id) 
values (ID_FORMATION_SEQ.nextval,'001691260987032135232136','02/02/2020',126005.33,(select id from FORMATION_CLIENT where nom = 'nom1éà'));
insert into FORMATION_COMPTE(id,rib,date_creation,solde,user_id) 
values (ID_FORMATION_SEQ.nextval,'002131654987006535232136','01/03/2015',12200.77,(select id from FORMATION_CLIENT where nom = 'nom2'));
insert into FORMATION_COMPTE(id,rib,date_creation,solde,user_id) 
values (ID_FORMATION_SEQ.nextval,'001011260966315235232136','01/03/2014',586005.33,(select id from FORMATION_CLIENT where nom = 'nom2'));

commit;