package ma.eai.web.vo;

import ma.eai.ingdev.fwk.uc.ValueObject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "object")
public class ViewAvisOpereVO implements ValueObject {
    private static final long serialVersionUID = 1L;
    private String guid;
    private String baseName;
    private String numCompte;

    public String getGuid() {
	return guid;
    }

    public void setGuid(String guid) {
	this.guid = guid;
    }

    public String getBaseName() {
	return baseName;
    }

    public void setBaseName(String baseName) {
	this.baseName = baseName;
    }

    public String getNumCompte() {
	return numCompte;
    }

    public void setNumCompte(String numCompte) {
	this.numCompte = numCompte;
    }
}
