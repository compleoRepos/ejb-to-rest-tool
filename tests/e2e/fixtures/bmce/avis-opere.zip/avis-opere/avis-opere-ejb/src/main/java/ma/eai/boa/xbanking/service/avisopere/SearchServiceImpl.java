package ma.eai.boa.xbanking.service.avisopere;

import ma.eai.boa.xbanking.entities.TypeAO;
import ma.eai.ingdev.fwk.annotation.tx.ContinueOrStartTransaction;

import ma.eai.boa.xbanking.repository.SearchRepo;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@ContinueOrStartTransaction
public class SearchServiceImpl implements ISearchService {
    @Autowired
    SearchRepo searchRepo;

    @Override
    public List<TypeAO> getListTypes() {
	List<TypeAO> types = searchRepo.SearchTypes();
	EaiLog.info("......... Search service impl =========>" + types.size());
	return types;
    }

    @Override
    public String getReqTypeAvis() {
	List<TypeAO> list = getListTypes();
	String reqType = "";
	for (TypeAO type : list) {
	    //reqType+="'"+type.getCode()+"',";
	    reqType += type.getCode() + ",";
	}
	reqType = reqType.substring(0, reqType.length() - 1);
	EaiLog.info("==============les types getReqTypeAvis()=========" + reqType);
	return reqType;
    }
}
