package ma.eai.web.vo;

import java.io.Serializable;

public class AvisOpere implements Serializable {
    private static final long serialVersionUID = -1474799682712735125L;
    private String url;

    public String getUrl() {
	return url;
    }

    public void setUrl(String url) {
	this.url = url;
    }
}
