
package ma.eai.boa.xbanking.servicedata.ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Classe Java pour pager complex type.
 * 
 * <p>Le fragment de schema suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="pager">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="nombreTotalDeDocument" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="documents" type="{http://ws.bmce.org}document" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "pager", propOrder = {
    "nombreTotalDeDocument",
    "documents"
})
public class Pager {

    protected long nombreTotalDeDocument;
    protected List<Document> documents;

    /**
     * Obtient la valeur de la propriete nombreTotalDeDocument.
     * 
     */
    public long getNombreTotalDeDocument() {
        return nombreTotalDeDocument;
    }

    /**
     * Definit la valeur de la propriete nombreTotalDeDocument.
     * 
     */
    public void setNombreTotalDeDocument(long value) {
        this.nombreTotalDeDocument = value;
    }

    /**
     * Gets the value of the documents property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the documents property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocuments().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Document }
     * 
     * 
     */
    public List<Document> getDocuments() {
        if (documents == null) {
            documents = new ArrayList<Document>();
        }
        return this.documents;
    }

}
