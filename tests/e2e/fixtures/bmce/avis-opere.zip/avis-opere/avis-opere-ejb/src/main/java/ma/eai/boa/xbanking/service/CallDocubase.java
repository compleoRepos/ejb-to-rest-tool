package ma.eai.boa.xbanking.service;

import ma.eai.boa.xbanking.servicedata.ws.Pager;
import ma.eai.boa.xbanking.servicedata.ws.ServiceData;
import ma.eai.boa.xbanking.servicedata.ws.ServiceDataService;
import ma.eai.boa.xbanking.utils.Constant;
import ma.eai.boa.xbanking.utils.SoapUiLikeLoggingHandler;
import ma.eai.ingdev.fwk.logging.EaiLog;
import ma.eai.midw.integration.Services;
import net.java.dev.jaxb.array.StringArray;

import org.springframework.stereotype.Service;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

@Service
public class CallDocubase {
    public Pager appelDocubase(StringArray arrCompte, StringArray arrType,
	    String DateDebut,String Datefin, int numPage,int pageSize ,
	    double montantmin, double montantmax){
	EaiLog.info("Appel web Service DOCUBASE.:");
	String docubaseServiceDataWsdlUrl = Services.find(Constant.DOCUBASE_SERVICEDATA_URL, String.class);
	URL wsdlServiceDataFromUDDI= getUrlFromUddi(docubaseServiceDataWsdlUrl);
	Pager resultat = null;
	try {
	    long startDOCUBASE = System.currentTimeMillis();
	    ServiceDataService serviceDataService = new ServiceDataService(wsdlServiceDataFromUDDI);
	    ServiceData serviceData = serviceDataService.getServiceDataPort();
	    BindingProvider bp = (BindingProvider) serviceData;
	    List<Handler> handlers = new ArrayList<Handler>();
	    handlers.addAll(bp.getBinding().getHandlerChain());
	    handlers.add(new SoapUiLikeLoggingHandler());
	    bp.getBinding().setHandlerChain(handlers);
	    resultat = serviceData.searchByMontant(arrCompte, arrType, DateDebut, Datefin, numPage,
		    pageSize, montantmin, montantmax);
	    long endDOCUBASE = System.currentTimeMillis();
	    EaiLog.info("TEMPS DE REPONSE WS DOCUBASE Documents :" + (endDOCUBASE - startDOCUBASE) + " ms");
	    EaiLog.info("Nombre TOTAL DES DOCS Depuis WS" + resultat.getNombreTotalDeDocument());
	}catch (Exception e){
	    EaiLog.error("Erreur lors de l'appel au WS DOCUBASE : " + e.getMessage()+ e);
	    throw new RuntimeException("Erreur lors de l'appel au WS DOCUBASE"+ e);
	}
	return resultat;
    }

    private URL getUrlFromUddi(String docubaseServiceDataWsdlUrl){
	try {
	    return  new URL(docubaseServiceDataWsdlUrl);
	} catch (MalformedURLException e) {
	    throw new RuntimeException(e);
	}
    }
}
