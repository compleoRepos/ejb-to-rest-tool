package ma.eai.web.vo;

import ma.eai.ingdev.fwk.uc.ValueObject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "object")
public class SearchVoRdOut implements ValueObject {
    private static final long serialVersionUID = 1L;
    CurrentResRd currentRes;

    public CurrentResRd getCurrentRes() {
	return currentRes;
    }

    public void setCurrentRes(CurrentResRd currentRes) {
	this.currentRes = currentRes;
    }
}
