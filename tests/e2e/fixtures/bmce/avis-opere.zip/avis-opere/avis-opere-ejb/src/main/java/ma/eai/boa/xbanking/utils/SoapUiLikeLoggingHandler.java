package ma.eai.boa.xbanking.utils;

import ma.eai.ingdev.fwk.logging.EaiLog;

import java.io.ByteArrayOutputStream;
import java.util.Set;
import javax.xml.namespace.QName;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import javax.xml.soap.SOAPMessage;

public class SoapUiLikeLoggingHandler implements SOAPHandler<SOAPMessageContext> {

    @Override
    public boolean handleMessage(SOAPMessageContext context) {
	Boolean outbound = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);

	if (outbound) {
	    logSoap(context.getMessage(), "SOAP REQUEST ");
	} else {
	    logSoap(context.getMessage(), "SOAP RESPONSE ");
	}
	return true;
    }

    @Override
    public boolean handleFault(SOAPMessageContext context) {
	logSoap(context.getMessage(), "SOAP FAULT");
	return true;
    }

    private void logSoap(SOAPMessage message, String title) {
	try {
	    ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    message.writeTo(baos);

	    String xml = baos.toString("UTF-8");

	    EaiLog.info("============ " + title + " ============\n" + xml +
		    "\n========================================");

	} catch (Exception e) {
	    EaiLog.error("Erreur logging SOAP"+ e);
	}
    }

    @Override
    public void close(MessageContext context) {
	//empty constructor
    }

    @Override
    public Set<QName> getHeaders() {
	return null;
    }
}

