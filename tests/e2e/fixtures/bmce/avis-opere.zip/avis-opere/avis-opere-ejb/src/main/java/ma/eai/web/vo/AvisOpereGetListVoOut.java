package ma.eai.web.vo;

import ma.eai.boa.xbanking.dto.AvisOpereDTO;
import ma.eai.ingdev.fwk.uc.ValueObject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "object")
public class AvisOpereGetListVoOut implements ValueObject {
    private static final long serialVersionUID = 1L;
    private int numPage;
    private int pageSize;
    private long nbResultats;
    private AvisOpereDTO currentRes;

    public int getNumPage() {
	return numPage;
    }

    public void setNumPage(int numPage) {
	this.numPage = numPage;
    }

    public int getPageSize() {
	return pageSize;
    }

    public void setPageSize(int pageSize) {
	this.pageSize = pageSize;
    }

    public long getNbResultats() {
	return nbResultats;
    }

    public void setNbResultats(long nbResultats) {
	this.nbResultats = nbResultats;
    }

    public AvisOpereDTO getCurrentRes() {
	return currentRes;
    }

    public void setCurrentRes(AvisOpereDTO currentRes) {
	this.currentRes = currentRes;
    }
}
