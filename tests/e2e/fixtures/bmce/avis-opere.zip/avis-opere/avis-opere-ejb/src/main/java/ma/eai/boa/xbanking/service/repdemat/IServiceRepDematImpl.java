package ma.eai.boa.xbanking.service.repdemat;

import ma.eai.boa.xbanking.entities.TypeAoRd;
import ma.eai.boa.xbanking.repository.SearchTypesRepDemat;
import ma.eai.ingdev.fwk.annotation.tx.ContinueOrStartTransaction;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
//classe DEDIE  AU PROJET REPDEMAT

@Service
@ContinueOrStartTransaction
public class IServiceRepDematImpl implements IServiceRepDemat{
    @Autowired
    SearchTypesRepDemat searchRepo;
    @Override
    public List<TypeAoRd> getListTypes(String nature) {
	EaiLog.info("category nature Service => "+nature);
	return searchRepo.SearchTypes(nature);
    }
    public List<TypeAoRd> getTypesNotNull(){
	List<TypeAoRd> types = searchRepo.getTypesNotNull();
	EaiLog.info("List des types with nature not null => "+types.size());
	return types;
    }

}
