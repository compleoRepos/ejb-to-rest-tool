package ma.eai.boa.xbanking.usecases;

import ma.eai.boa.xbanking.models.GedOutPutDocument;
import ma.eai.boa.xbanking.service.avisopere.GedServiceBackup;
import ma.eai.web.vo.CurrentResult;
import ma.eai.web.vo.ViewAvisOpereVoOut;
import ma.eai.web.vo.ViewReleveSeulePageVO;
import ma.eai.ingdev.fwk.annotations.UseCase;
import ma.eai.ingdev.fwk.exceptions.FwkRollbackException;
import ma.eai.ingdev.fwk.logging.EaiLog;
import ma.eai.ingdev.fwk.uc.BaseUseCase;
import ma.eai.ingdev.fwk.uc.ValueObject;

import ma.eai.web.vo.AvisOpere;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@UseCase
@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = FwkRollbackException.class)
public class ViewReleveSeulePageUC implements BaseUseCase {

    @Override
    public ValueObject execute(ValueObject in) throws FwkRollbackException {
	EaiLog.info("START ViewReleveSeulePageUC_");

	ViewReleveSeulePageVO avisVO = (ViewReleveSeulePageVO) in;
	String dateDebut = avisVO.getDateDebut();
	String dateFin = avisVO.getDateFin();
	String numCompte = avisVO.getNumCompte();

	try {
	    GedOutPutDocument documentRelve = GedServiceBackup.getdocumentRelve(numCompte, dateDebut, dateFin);
	    ViewAvisOpereVoOut out = new ViewAvisOpereVoOut();
	    CurrentResult res = new CurrentResult();
	    AvisOpere avisOpere = new AvisOpere();

	    res.setRow(avisOpere);
	    out.setCurrentRes(res);
	    out.setNbResultats(0);
	    out.setPageSize(0);
	    out.setNumPage(0);

	    if (documentRelve.getListDocuments() != null && documentRelve.getListDocuments().size() > 0) {
		EaiLog.info("------ URL --------"
			+ documentRelve.getListDocuments().get(0).getListFichiers().get(0).getFichier());
		avisOpere.setUrl(documentRelve.getListDocuments().get(0).getListFichiers().get(0).getFichier());
	    }
	    EaiLog.info("====== fin ViewReleveSeulePageUC ===");
	    return out;
	} catch (Exception e) {
	    EaiLog.error("######  Exception appel web service "+e+e.getMessage());
	    throw new FwkRollbackException("Erreur lors de l'exécution de ViewReleveSeulePageUC");
	}
    }
}