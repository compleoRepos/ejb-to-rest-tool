package ma.eai.boa.xbanking.service.avisopere;

import ma.eai.boa.xbanking.entities.TypeAO;

import java.util.List;

/**
 * Exemple d'interface Service
 *
 * @author ingdev
 */
public interface ISearchService {

    List<TypeAO> getListTypes();

    String getReqTypeAvis();

}
