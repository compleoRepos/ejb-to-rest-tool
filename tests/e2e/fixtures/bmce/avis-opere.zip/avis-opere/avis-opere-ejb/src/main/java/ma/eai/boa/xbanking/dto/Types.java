package ma.eai.boa.xbanking.dto;

import java.io.Serializable;

public class Types implements Serializable {
    private static final long serialVersionUID = 1L;
    private String code;
    private String libelle;

    public String getCode() {
	return code;
    }

    public void setCode(String code) {
	this.code = code;
    }

    public String getLibelle() {
	return libelle;
    }

    public void setLibelle(String libelle) {
	this.libelle = libelle;
    }
}
