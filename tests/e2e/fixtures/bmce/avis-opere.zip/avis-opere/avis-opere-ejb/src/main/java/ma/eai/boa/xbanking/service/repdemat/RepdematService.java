package ma.eai.boa.xbanking.service.repdemat;

import ma.eai.boa.xbanking.entities.TypeAoRd;
import ma.eai.ingdev.fwk.annotation.tx.ContinueOrStartTransaction;
import ma.eai.ingdev.fwk.logging.EaiLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.PersistenceException;
import java.util.List;

@Service
@ContinueOrStartTransaction
public class RepdematService {
    @Autowired
    private IServiceRepDemat searchService ;
    public String getReqCat() throws PersistenceException {
	List<TypeAoRd> list = searchService.getTypesNotNull();
	String reqType="";
	for(TypeAoRd type : list){
	    reqType+="'"+type.getCode()+"',";
	}
	reqType=reqType.substring(0,reqType.length()-1);
	return reqType;
    }
    public String getReqTypeAvis(String nature) throws PersistenceException {
	EaiLog.info("nature en entre..."+nature);
	List<TypeAoRd> list = null;
	list = searchService.getListTypes(nature);
	String reqType="";
	for(TypeAoRd type : list){
	    reqType+=""+type.getCode()+",";
	}
	reqType=reqType.substring(0,reqType.length()-1);
	return reqType;
    }
}
