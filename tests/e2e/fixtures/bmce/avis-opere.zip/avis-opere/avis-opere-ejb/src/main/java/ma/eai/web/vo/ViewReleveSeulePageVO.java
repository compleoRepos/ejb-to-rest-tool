package ma.eai.web.vo;

import ma.eai.ingdev.fwk.uc.ValueObject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "object")
public class ViewReleveSeulePageVO implements ValueObject {

    private static final long serialVersionUID = 1L;
    private String dateDebut;
    private String dateFin;
    private String numCompte;

    public String getDateDebut() {
	return dateDebut;
    }

    public void setDateDebut(String dateDebut) {
	this.dateDebut = dateDebut;
    }

    public String getDateFin() {
	return dateFin;
    }

    public void setDateFin(String dateFin) {
	this.dateFin = dateFin;
    }

    public String getNumCompte() {
	return numCompte;
    }

    public void setNumCompte(String numCompte) {
	this.numCompte = numCompte;
    }
}
