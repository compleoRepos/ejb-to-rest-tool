package ma.eai.web.vo;

import ma.eai.ingdev.fwk.uc.ValueObject;

import javax.xml.bind.annotation.XmlRootElement;

//CLASSE DEDIE AU PROJET REPDEMAT
@XmlRootElement(name = "object")
public class GetTypeDocumentVO implements ValueObject {

    private static final long serialVersionUID = 1L;
    private String categorie;

    public String getCategorie() {
	return categorie;
    }

    public void setCategorie(String categorie) {
	this.categorie = categorie;
    }
}
