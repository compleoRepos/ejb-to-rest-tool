package ma.eai.boa.xbanking.service.repdemat;

import ma.eai.boa.xbanking.entities.TypeAoRd;

import java.util.List;
//classe DEDIE  AU PROJET REPDEMAT
public interface IServiceRepDemat {
    List<TypeAoRd> getListTypes(String nature);
    List<TypeAoRd> getTypesNotNull();
}
