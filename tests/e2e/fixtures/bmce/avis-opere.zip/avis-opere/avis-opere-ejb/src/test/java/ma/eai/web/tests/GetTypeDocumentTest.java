package ma.eai.web.tests;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import ma.eai.boa.xbanking.entities.TypeAoRd;
import ma.eai.boa.xbanking.service.repdemat.IServiceRepDemat;
import ma.eai.boa.xbanking.usecases.GetTypeDocument;
import ma.eai.ingdev.fwk.exceptions.FwkRollbackException;
import ma.eai.web.vo.CurrentResRd;
import ma.eai.web.vo.GetTypeDocumentVO;
import ma.eai.web.vo.SearchVoRdOut;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

public class GetTypeDocumentTest {

    @Mock
    private IServiceRepDemat searchService;

    @InjectMocks
    private GetTypeDocument getTypeDocumentUC;

    @Before
    public void setup() {
	MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testExecute_WithCategorie() throws FwkRollbackException {
	// Arrange
	GetTypeDocumentVO input = new GetTypeDocumentVO();
	input.setCategorie("Facture");

	List<TypeAoRd> mockedList = new ArrayList<>();
	TypeAoRd type1 = new TypeAoRd();
	type1.setCode("T1");
	type1.setLibelle("Type 1");
	type1.setCategorie("Facture");
	mockedList.add(type1);

	when(searchService.getListTypes("Facture")).thenReturn(mockedList);

	// Act
	SearchVoRdOut result = (SearchVoRdOut) getTypeDocumentUC.execute(input);

	// Assert
	assertNotNull(result);
	CurrentResRd currentRes = result.getCurrentRes();
	assertNotNull(currentRes);
	List<TypeAoRd> rows = currentRes.getRow();
	assertNotNull(rows);
	assertFalse(rows.isEmpty());

	// Le 1er élément ajouté dans la méthode doit avoir code "*"
	/*assertEquals("*", rows.get(0).getCode());
	assertEquals("Choisissez un type d'avis...", rows.get(0).getLibelle());
	assertEquals("Facture", rows.get(0).getCategorie());
*/
	// Le 2e élément est notre mock
	assertEquals("T1", rows.get(0).getCode());
	assertEquals("Type 1", rows.get(0).getLibelle());
    }

    @Test
    public void testExecute_WithNullCategorie() throws FwkRollbackException {
	// Arrange
	GetTypeDocumentVO input = new GetTypeDocumentVO();
	input.setCategorie(null);

	List<TypeAoRd> mockedList = new ArrayList<>();
	TypeAoRd type1 = new TypeAoRd();
	type1.setCode("T2");
	type1.setLibelle("Type 2");
	type1.setCategorie(null);
	mockedList.add(type1);

	when(searchService.getListTypes(null)).thenReturn(mockedList);

	// Act
	SearchVoRdOut result = (SearchVoRdOut) getTypeDocumentUC.execute(input);

	// Assert
	assertNotNull(result);
	CurrentResRd currentRes = result.getCurrentRes();
	assertNotNull(currentRes);
	List<TypeAoRd> rows = currentRes.getRow();
	assertNotNull(rows);
	assertFalse(rows.isEmpty());

	/*assertEquals("*", rows.get(0).getCode());
	assertEquals("Choisissez un type d'avis...", rows.get(0).getLibelle());
	assertNull(rows.get(0).getCategorie());
*/
	assertEquals("T2", rows.get(0).getCode());
	assertEquals("Type 2", rows.get(0).getLibelle());
    }

    @Test(expected = FwkRollbackException.class)
    public void testExecute_ThrowsException() throws FwkRollbackException {
	// Arrange
	GetTypeDocumentVO input = new GetTypeDocumentVO();
	input.setCategorie("Erreur");

	when(searchService.getListTypes(any())).thenThrow(new RuntimeException("Erreur technique"));

	// Act
	getTypeDocumentUC.execute(input);

	// Assert : exception attendue, test réussi si lancée
    }
}

