package ma.eai.web.tests;

import junit.framework.TestCase;
import ma.eai.boa.xbanking.avisopereBean;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.Parser;
import ma.eai.commons.utilities.UtilFile;
import ma.eai.commons.utilities.UtilString;
import ma.eai.ingdev.fwk.logging.EaiLog;

public class GetTypesUCTest extends TestCase {
    public void testCase() throws Exception {

        try {
            System.setProperty("execution.env", "dev");
            avisopereBean reventBean = new avisopereBean();
            Envelope env = Parser.unmarshall(UtilString.toString(UtilFile.searchResource("SearchUC.xml")));
            Envelope envRetour = reventBean.process(env);
            String envString = Parser.marshall(envRetour);

            assertNotNull(envString);

            EaiLog.info("Resultat :" + envString);

        } catch (Exception e) {
            EaiLog.error(e);
        }
    }
}
