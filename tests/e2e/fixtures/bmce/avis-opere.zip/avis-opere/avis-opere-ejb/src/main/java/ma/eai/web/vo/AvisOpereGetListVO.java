package ma.eai.web.vo;

import ma.eai.ingdev.fwk.uc.ValueObject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "object")
public class AvisOpereGetListVO implements ValueObject {
    private static final long serialVersionUID = 1L;
    private String numcompte;
    private String datedebut;
    private String datefin;
    private String ntiere;
    private String type;
    private Double montantmin;
    private Double montantmax;
    private int numPage;
    private int pageSize;

    public String getNumcompte() {
	return numcompte;
    }

    public void setNumcompte(String numcompte) {
	this.numcompte = numcompte;
    }

    public String getDatedebut() {
	return datedebut;
    }

    public void setDatedebut(String datedebut) {
	this.datedebut = datedebut;
    }

    public String getDatefin() {
	return datefin;
    }

    public void setDatefin(String datefin) {
	this.datefin = datefin;
    }

    public String getNtiere() {
	return ntiere;
    }

    public void setNtiere(String ntiere) {
	this.ntiere = ntiere;
    }

    public String getType() {
	return type;
    }

    public void setType(String type) {
	this.type = type;
    }

    public Double getMontantmax() {
	return montantmax;
    }

    public void setMontantmax(Double montantmax) {
	this.montantmax = montantmax;
    }

    public Double getMontantmin() {
	return montantmin;
    }

    public void setMontantmin(Double montantmin) {
	this.montantmin = montantmin;
    }

    public int getNumPage() {
	return numPage;
    }

    public void setNumPage(int numPage) {
	this.numPage = numPage;
    }

    public int getPageSize() {
	return pageSize;
    }

    public void setPageSize(int pageSize) {
	this.pageSize = pageSize;
    }
}
