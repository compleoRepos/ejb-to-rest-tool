package ma.eai.web.vo;

import ma.eai.boa.xbanking.entities.TypeAO;
import ma.eai.ingdev.fwk.uc.ValueObject;

import java.util.List;
public class CurrentRes implements ValueObject {
    private static final long serialVersionUID = 1L;
    private List<TypeAO> avisopere;

    public List<TypeAO> getAvisopere() {
	return avisopere;
    }

    public void setAvisopere(List<TypeAO> avisopere) {
	this.avisopere = avisopere;
    }
}
