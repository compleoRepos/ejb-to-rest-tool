package ma.eai.web.tests;

import junit.framework.TestCase;
import ma.eai.boa.xbanking.avisopereBean;
import ma.eai.boa.xbanking.utils.Constant;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.Parser;
import ma.eai.commons.utilities.UtilFile;
import ma.eai.commons.utilities.UtilString;
import ma.eai.ingdev.fwk.logging.EaiLog;
import ma.eai.midw.integration.Services;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockedStatic;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mockStatic;

@RunWith(MockitoJUnitRunner.class)
public class AvisOpereGetListUCTest extends TestCase {
    @Test
    public void testCase() throws Exception {

        try (MockedStatic<Services> mockedServices = mockStatic(Services.class)){
            mockedServices.when(() -> Services.find(Constant.DOCUBASE_SERVICEDATA_URL, String.class)).thenReturn("https://docubase-ws-dy.bankofafrica.ma:8443/ServiceDataV9/ServiceData?wsdl");
            System.setProperty("execution.env", "dev");
            avisopereBean reventBean = new avisopereBean();
            Envelope env = Parser.unmarshall(UtilString.toString(UtilFile.searchResource("AvOpGetList.xml")));
            Envelope envRetour = reventBean.process(env);
            String envString = Parser.marshall(envRetour);

            assertNotNull(envString);

            EaiLog.info("Resultat :" + envString);

        } catch (Exception e) {
            EaiLog.error(e);
        }
    }
}
