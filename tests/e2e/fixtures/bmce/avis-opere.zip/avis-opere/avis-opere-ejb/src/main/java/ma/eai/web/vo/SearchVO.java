package ma.eai.web.vo;

import ma.eai.ingdev.fwk.uc.ValueObject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "object")
public class SearchVO implements ValueObject {
    private static final long serialVersionUID = 1L;
    private String ContratBAD;

    public String getContratBAD() {
	return ContratBAD;
    }

    public void setContratBAD(String contratBAD) {
	ContratBAD = contratBAD;
    }
}